"""
FALLBACK — only if you cannot create a Code Repository.

Code Workbook version of the nc_defects transform.
1. In the workbook, open Global code (Python) and paste the whole of
   nc_defect_parser.py there.
2. Add the SAP NC dataset to the workbook. In the new transform's Inputs tab,
   set its input type to "Pandas dataframe".
3. Create a Python transform named nc_defects with that dataset as its input,
   and paste the function below. The argument name must match the input's
   alias in the workbook: rename `sap_nc` if your alias differs.
4. Turn on "Save as dataset" for the nc_defects node, then run it.
"""
import pandas as pd

NC_COLUMN = "notification_number"             # EDIT if your SAP dataset names it differently
TEXT_COLUMN = "description_long_text"         # EDIT if your SAP dataset names it differently


def nc_defects(sap_nc):
    COLUMNS = ["notification_number", "nc_id", "seq", "code", "fin", "text", "source_format",
               "groupe", "sous_groupe", "famille", "categorie", "type_reporting", "mode_erreur", "sub_code", "confidence", "resolved_by",
               "cdve", "defaut_cable", "cable_preuve", "etat_cable", "nc_cable",
               "provenance", "provenance_force", "qty", "parser_version"]
    src = sap_nc[[NC_COLUMN, TEXT_COLUMN]].rename(
        columns={NC_COLUMN: "notification_number", TEXT_COLUMN: "description_long_text"})
    src["notification_number"] = src["notification_number"].astype(str).str.strip()
    src["description_long_text"] = src["description_long_text"].fillna("").astype(str)
    src = src.drop_duplicates("notification_number")
    _, defects = explode_dataframe(src)          # from the parser pasted in Global code
    if defects.empty:
        return pd.DataFrame({c: pd.Series(dtype="object") for c in COLUMNS})
    defects["nc_id"] = defects["notification_number"].str.lstrip("0")
    defects["parser_version"] = "4.5"
    for c in COLUMNS:
        if c in ("seq", "qty"):
            defects[c] = pd.to_numeric(defects[c], errors="coerce").fillna(1).astype("int64")
        elif c in ("defaut_cable", "cdve"):
            defects[c] = defects[c].fillna(False).astype(bool)
        else:
            defects[c] = defects[c].fillna("").astype(str) if c in defects else ""
    return defects[COLUMNS]
