"""
Skywise (Foundry) transform: SAP NC long texts -> one row per defect ("nc_defects").

Where it goes: in a Python transforms Code Repository, next to nc_defect_parser.py,
in the folder that holds the example transform (usually src/<project>/datasets/).
What to edit: the two dataset paths below, and the two column names if yours differ.
Then: Commit, Build. The output dataset is created on the first build.

pandas must be listed as a run dependency of the repository (Libraries panel,
or meta.yml), otherwise the build fails on "No module named pandas".
"""
from transforms.api import transform_pandas, Input, Output
import pandas as pd

from . import nc_defect_parser as P            # the parser file sits in the same folder

# --------------------------------------------------------------------------- #
# EDIT THESE
# --------------------------------------------------------------------------- #
SAP_NC_DATASET = "/EDIT/path/of/the/SAP NC dataset your dashboard already uses"
OUTPUT_DATASET = "/EDIT/path/of/your/project/folder/nc_defects"
NC_COLUMN = "notification_number"             # NC number column in the SAP dataset
TEXT_COLUMN = "description_long_text"         # long text column in the SAP dataset
# --------------------------------------------------------------------------- #

PARSER_VERSION = "4.5"

# Output columns, in order, with a fixed type each (an all-empty column would
# otherwise have no type and the build would fail).
TEXT_COLS = ["notification_number", "nc_id", "code", "fin", "text", "source_format",
             "type_reporting", "mode_erreur", "groupe", "sous_groupe", "categorie", "famille", "sub_code", "confidence",
             "resolved_by", "cable_preuve", "etat_cable", "nc_cable", "provenance",
             "provenance_force", "parser_version"]
INT_COLS = ["seq", "qty"]
BOOL_COLS = ["defaut_cable", "cdve"]
COLUMNS = ["notification_number", "nc_id", "seq", "code", "fin", "text", "source_format",
           "groupe", "sous_groupe", "famille", "categorie", "type_reporting", "mode_erreur", "sub_code", "confidence", "resolved_by",
           "cdve", "defaut_cable", "cable_preuve", "etat_cable", "nc_cable",
           "provenance", "provenance_force", "qty", "parser_version"]


def parse_to_defects(sap_nc: pd.DataFrame) -> pd.DataFrame:
    """SAP NC rows in, one row per defect out. Pure pandas, testable outside Foundry."""
    src = sap_nc[[NC_COLUMN, TEXT_COLUMN]].rename(
        columns={NC_COLUMN: "notification_number", TEXT_COLUMN: "description_long_text"})
    src["notification_number"] = src["notification_number"].astype(str).str.strip()
    src["description_long_text"] = src["description_long_text"].fillna("").astype(str)
    src = src.drop_duplicates("notification_number")
    _, defects = P.explode_dataframe(src)
    if defects.empty:
        return pd.DataFrame({c: pd.Series(dtype="object") for c in COLUMNS})
    defects["nc_id"] = defects["notification_number"].str.lstrip("0")
    defects["parser_version"] = PARSER_VERSION
    for c in TEXT_COLS:
        defects[c] = defects[c].fillna("").astype(str) if c in defects else ""
    for c in INT_COLS:
        defects[c] = pd.to_numeric(defects[c], errors="coerce").fillna(1).astype("int64")
    for c in BOOL_COLS:
        defects[c] = defects[c].fillna(False).astype(bool)
    return defects[COLUMNS]


@transform_pandas(
    Output(OUTPUT_DATASET),
    sap_nc=Input(SAP_NC_DATASET),
)
def nc_defects(sap_nc):
    return parse_to_defects(sap_nc)
