/* q_mft_topics — the list of MFT topics, to fill the dropdown w_topic
   Returns: topic_id, label. Set the dropdown's values to {{q_mft_topics.topic_id}}
   and its labels to {{q_mft_topics.label}}. */
SELECT topic_id,
       topic_id || ' · ' || topic_en AS label
FROM foundry_sync.mft_actions
ORDER BY topic_id;
