/* q_mft_categories — for one MFT topic, which categories make it up, before vs after
   Most useful for the A330 "Mise en oeuvre" topic, which spans nine categories.
   Returns one row per category and period: category, period ('13 weeks before' or
   'Since action start'), defects, weeks, per_week. Per week, because the two periods
   have different lengths. Needs: dropdown widget w_topic. */
WITH nc AS (                                           -- EDIT: SAP table and column names
    SELECT ltrim(notification_number::text, '0')               AS nc_id,
           (creation_time::timestamptz)::date                  AS created_on,
           programme::text                                     AS program,
           COALESCE(station_description::text, '')             AS station,
           COALESCE(status_open_closed::text, '') = 'deleted'  AS is_deleted,
           COALESCE(liability_description::text, '') ILIKE '%SUPPLIER%' AS is_supplier
    FROM foundry_sync.sap_nc
),
d AS (
    SELECT n.created_on, n.program, n.station, f.categorie,
           COALESCE(f.etat_cable::text, '') AS etat_cable,
           COALESCE(f.text::text, '')       AS text
    FROM foundry_sync.nc_defects f
    JOIN nc n ON n.nc_id = ltrim(f.notification_number::text, '0')
    WHERE NOT n.is_deleted
      AND NOT n.is_supplier
),
m AS (
    SELECT topic_id, program,
           date_trunc('week', NULLIF(action_start::text, '')::date)::date AS start_week,
           COALESCE(rule_categories::text, '')       AS rule_categories,
           COALESCE(rule_etat_cable::text, '')       AS rule_etat_cable,
           COALESCE(rule_text_regex::text, '')       AS rule_text_regex,
           COALESCE(rule_station_regex::text, '')    AS rule_station_regex
    FROM foundry_sync.mft_actions
    WHERE topic_id = '{{w_topic.selectedValue}}'
),
p AS (                                                  -- the two periods, whole weeks only
    SELECT '13 weeks before' AS period, 1 AS ord,
           (start_week - INTERVAL '13 weeks')::date AS p_from, start_week AS p_to
    FROM m
    UNION ALL
    SELECT 'Since action start', 2, start_week, date_trunc('week', CURRENT_DATE)::date
    FROM m
),
hits AS (
    SELECT d.categorie, d.created_on
    FROM d JOIN m ON d.program = m.program
    WHERE (m.rule_categories    = '' OR d.categorie = ANY (string_to_array(m.rule_categories, '|')))
      AND (m.rule_etat_cable    = '' OR d.etat_cable = m.rule_etat_cable)
      AND (m.rule_text_regex    = '' OR d.text    ~* m.rule_text_regex)
      AND (m.rule_station_regex = '' OR d.station ~* m.rule_station_regex)
)
SELECT h.categorie                                              AS category,
       p.period,
       COUNT(*)                                                 AS defects,
       GREATEST((p.p_to - p.p_from) / 7, 0)                     AS weeks,
       ROUND(COUNT(*)::numeric / NULLIF(GREATEST((p.p_to - p.p_from) / 7, 0), 0), 1) AS per_week
FROM hits h
JOIN p ON h.created_on >= p.p_from AND h.created_on < p.p_to
GROUP BY h.categorie, p.period, p.ord, p.p_from, p.p_to
ORDER BY h.categorie, p.ord;
