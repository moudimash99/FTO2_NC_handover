/* q_pareto — defects by Pareto group (bar chart)
   Order: Câblage, Branchement, Dommage & manquant, Métallisation by count, then the groups shown
   aside, always last and in this order: Amont, FOD, Dossier, Non classé.
   Returns: pareto_group, defects, aside (true/false), pct, cumulative_pct, ord.
   What is inside each group is in q_pareto_detail.
   Needs: dropdown widget w_program (All / A330 / A350).
   Period: from the date on the marked line to today. */
WITH nc AS (                                           -- EDIT: SAP table and column names
    SELECT ltrim(notification_number::text, '0')               AS nc_id,
           (creation_time::timestamptz)::date                  AS created_on,
           programme::text                                     AS program,
           COALESCE(status_open_closed::text, '') = 'deleted'  AS is_deleted,
           COALESCE(liability_description::text, '') ILIKE '%SUPPLIER%' AS is_supplier
    FROM foundry_sync.sap_nc
),
d AS (
    SELECT f.groupe
    FROM foundry_sync.nc_defects f
    JOIN nc n ON n.nc_id = ltrim(f.notification_number::text, '0')
    WHERE NOT n.is_deleted
      AND NOT n.is_supplier
      AND n.created_on >= DATE '2026-01-01'            -- EDIT: start of the period
      AND ('{{w_program.selectedValue}}' IN ('', 'All') OR n.program = '{{w_program.selectedValue}}')
),
c AS (
    SELECT groupe AS pareto_group,
           COUNT(*) AS defects,
           CASE groupe WHEN 'Amont' THEN 1 WHEN 'FOD' THEN 2 WHEN 'Dossier' THEN 3
                       WHEN 'Non classé' THEN 4 ELSE 0 END AS aside_rank
    FROM d
    GROUP BY 1
),
o AS (
    SELECT c.*,
           ROW_NUMBER() OVER (ORDER BY aside_rank,
                                       CASE WHEN aside_rank = 0 THEN -defects ELSE 0 END,
                                       pareto_group) AS ord
    FROM c
)
SELECT pareto_group,
       defects,
       aside_rank > 0                                    AS aside,
       ROUND(100.0 * defects / SUM(defects) OVER (), 1) AS pct,
       ROUND(100.0 * SUM(defects) OVER (ORDER BY ord ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW)
             / SUM(defects) OVER (), 1)                  AS cumulative_pct,
       ord
FROM o
ORDER BY ord;
