/* q_mft_summary — every MFT topic on one line: is the action moving the numbers?
   Returns one row per topic: topic_id, topic, program, action_start, owner, status,
   per_week_before (average over the 13 weeks before the action started),
   per_week_after (average since it started), weeks_after,
   per_100_before / per_100_after (the topic's share of all the program's defects,
   which corrects for busy and quiet weeks).
   Averages only use weeks in which the program had at least one defect, so
   shutdown weeks do not pull them down. No widget needed (table widget). */
WITH nc AS (                                           -- EDIT: SAP table and column names
    SELECT ltrim(notification_number::text, '0')               AS nc_id,
           (creation_time::timestamptz)::date                  AS created_on,
           programme::text                                     AS program,
           COALESCE(station_description::text, '')             AS station,
           COALESCE(status_open_closed::text, '') = 'deleted'  AS is_deleted,
           COALESCE(liability_description::text, '') ILIKE '%SUPPLIER%' AS is_supplier
    FROM foundry_sync.sap_nc
),
d AS (
    SELECT n.created_on, n.program, n.station, f.categorie,
           COALESCE(f.etat_cable::text, '') AS etat_cable,
           COALESCE(f.text::text, '')       AS text
    FROM foundry_sync.nc_defects f
    JOIN nc n ON n.nc_id = ltrim(f.notification_number::text, '0')
    WHERE NOT n.is_deleted
      AND NOT n.is_supplier
      AND n.created_on >= DATE '2026-01-01'
),
m AS (
    SELECT topic_id, topic_en, program, owner::text AS owner, status::text AS status,
           NULLIF(action_start::text, '')::date      AS action_start,
           COALESCE(rule_categories::text, '')       AS rule_categories,
           COALESCE(rule_etat_cable::text, '')       AS rule_etat_cable,
           COALESCE(rule_text_regex::text, '')       AS rule_text_regex,
           COALESCE(rule_station_regex::text, '')    AS rule_station_regex
    FROM foundry_sync.mft_actions
),
weeks AS (
    SELECT generate_series(date_trunc('week', DATE '2026-01-01'),
                           date_trunc('week', CURRENT_DATE) - INTERVAL '1 week',
                           INTERVAL '1 week')::date AS week
),
hits AS (
    SELECT m.topic_id, date_trunc('week', d.created_on)::date AS week, COUNT(*) AS defects
    FROM d JOIN m ON d.program = m.program
    WHERE (m.rule_categories    = '' OR d.categorie = ANY (string_to_array(m.rule_categories, '|')))
      AND (m.rule_etat_cable    = '' OR d.etat_cable = m.rule_etat_cable)
      AND (m.rule_text_regex    = '' OR d.text    ~* m.rule_text_regex)
      AND (m.rule_station_regex = '' OR d.station ~* m.rule_station_regex)
    GROUP BY 1, 2
),
prog AS (
    SELECT program, date_trunc('week', created_on)::date AS week, COUNT(*) AS program_defects
    FROM d
    GROUP BY 1, 2
),
g AS (                                                  -- topic x week grid, busy weeks only
    SELECT m.topic_id, w.week, COALESCE(h.defects, 0) AS defects, p.program_defects,
           CASE WHEN m.action_start IS NULL THEN NULL
                WHEN w.week >= date_trunc('week', m.action_start)::date THEN 'after'
                WHEN w.week >= (date_trunc('week', m.action_start) - INTERVAL '13 weeks')::date THEN 'before'
           END AS phase
    FROM m CROSS JOIN weeks w
    JOIN prog p ON p.program = m.program AND p.week = w.week
    LEFT JOIN hits h ON h.topic_id = m.topic_id AND h.week = w.week
)
SELECT m.topic_id,
       m.topic_en                                                                  AS topic,
       m.program,
       m.action_start,
       m.owner,
       m.status,
       ROUND(AVG(CASE WHEN g.phase = 'before' THEN g.defects END), 1)              AS per_week_before,
       ROUND(AVG(CASE WHEN g.phase = 'after'  THEN g.defects END), 1)              AS per_week_after,
       SUM(CASE WHEN g.phase = 'after' THEN 1 ELSE 0 END)                          AS weeks_after,
       ROUND(100.0 * SUM(CASE WHEN g.phase = 'before' THEN g.defects END)
             / NULLIF(SUM(CASE WHEN g.phase = 'before' THEN g.program_defects END), 0), 1) AS per_100_before,
       ROUND(100.0 * SUM(CASE WHEN g.phase = 'after' THEN g.defects END)
             / NULLIF(SUM(CASE WHEN g.phase = 'after' THEN g.program_defects END), 0), 1)  AS per_100_after
FROM m
LEFT JOIN g ON g.topic_id = m.topic_id
GROUP BY m.topic_id, m.topic_en, m.program, m.action_start, m.owner, m.status
ORDER BY m.topic_id;
