/* q_client_returns — NCs raised at a customer site (plant other than FTO2), by Pareto group
   Returns one row per Pareto group: pareto_group, defects, ncs, plus two totals repeated on
   every row for the headline tiles: client_ncs (all) and client_ncs_open (not deleted).
   Tiles: {{q_client_returns.client_ncs[0]}} and {{q_client_returns.client_ncs_open[0]}}.
   Needs: dropdown widget w_program. */
WITH nc AS (                                           -- EDIT: SAP table and column names
    SELECT ltrim(notification_number::text, '0')               AS nc_id,
           (creation_time::timestamptz)::date                  AS created_on,
           programme::text                                     AS program,
           COALESCE(plant::text, '')                           AS plant,
           COALESCE(status_open_closed::text, '') = 'deleted'  AS is_deleted
    FROM foundry_sync.sap_nc
    WHERE COALESCE(plant::text, '') <> 'FTO2'           -- EDIT if your own plant code differs
      AND (creation_time::timestamptz)::date >= DATE '2026-01-01'
      AND ('{{w_program.selectedValue}}' IN ('', 'All') OR programme::text = '{{w_program.selectedValue}}')
),
t AS (
    SELECT COUNT(*) AS client_ncs,
           SUM(CASE WHEN NOT is_deleted THEN 1 ELSE 0 END) AS client_ncs_open
    FROM nc
)
SELECT f.groupe                 AS pareto_group,
       COUNT(*)                 AS defects,
       COUNT(DISTINCT n.nc_id)  AS ncs,
       MAX(t.client_ncs)        AS client_ncs,
       MAX(t.client_ncs_open)   AS client_ncs_open
FROM foundry_sync.nc_defects f
JOIN nc n ON n.nc_id = ltrim(f.notification_number::text, '0')
CROSS JOIN t
WHERE NOT n.is_deleted
GROUP BY 1
ORDER BY CASE f.groupe WHEN 'Amont' THEN 1 WHEN 'FOD' THEN 2 WHEN 'Dossier' THEN 3
                       WHEN 'Non classé' THEN 4 ELSE 0 END,
         2 DESC, 1;
