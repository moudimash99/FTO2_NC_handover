/* q_unlocked_by_fin — A350 connectors not locked, per connector (FIN)
   Answers MFT A350-02 action 1: is there a recurrence on VT / VG, and on which pins?
   Returns one row per FIN: fin_family (VG, VT, VC...), fin, defects, ncs,
   pins (terminals named in the text), first_seen, last_seen.
   The chart by family is a GROUP BY on fin_family of this result, or a second
   query that sums defects by fin_family. */
WITH nc AS (                                           -- EDIT: SAP table and column names
    SELECT ltrim(notification_number::text, '0')               AS nc_id,
           (creation_time::timestamptz)::date                  AS created_on,
           programme::text                                     AS program,
           COALESCE(status_open_closed::text, '') = 'deleted'  AS is_deleted,
           COALESCE(liability_description::text, '') ILIKE '%SUPPLIER%' AS is_supplier
    FROM foundry_sync.sap_nc
),
d AS (
    SELECT n.nc_id, n.created_on, f.fin, COALESCE(f.text::text, '') AS text
    FROM foundry_sync.nc_defects f
    JOIN nc n ON n.nc_id = ltrim(f.notification_number::text, '0')
    WHERE NOT n.is_deleted
      AND NOT n.is_supplier
      AND n.program = 'A350'
      AND f.categorie = 'Connectors not locked'
      AND n.created_on >= DATE '2026-01-01'
)
SELECT COALESCE(substring(upper(COALESCE(fin, '')) from '[0-9]+([A-Z]{2})'), '(none)')  AS fin_family,
       upper(regexp_replace(COALESCE(fin, ''), '\s+', '', 'g'))                         AS fin,
       COUNT(*)                                                                          AS defects,
       COUNT(DISTINCT nc_id)                                                             AS ncs,
       COALESCE(string_agg(DISTINCT upper(substring(text from '(?i)borne\s+([0-9]{1,2}[a-z]?|[a-z]{1,2})\y')), ', '), '') AS pins,
       MIN(created_on)                                                                   AS first_seen,
       MAX(created_on)                                                                   AS last_seen
FROM d
GROUP BY 1, 2
ORDER BY defects DESC, last_seen DESC;
