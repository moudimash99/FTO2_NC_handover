/* q_pareto_detail — what is inside one Pareto group (drill-down under the Pareto)
   Branchement: Inversion, Erreur de branchement, Déverrouillage, Non connecté.
   Câblage: the object worked on (Frettage / colliers, Cheminement, Identification...).
   Dommage & manquant: "Dommage · pièce", "Manquant · colliers", "Pièce HS ou non conforme"...
   Métallisation: Bleu manquant, Bleu à reprendre ou débordant, Mesure de masse, Tresse.
   Returns: detail, defects, pct_of_group.
   Needs: dropdown widgets w_program, and w_group with values {{q_pareto.pareto_group}}.
   Period: same start date as q_pareto. */
WITH nc AS (                                           -- EDIT: SAP table and column names
    SELECT ltrim(notification_number::text, '0')               AS nc_id,
           (creation_time::timestamptz)::date                  AS created_on,
           programme::text                                     AS program,
           COALESCE(status_open_closed::text, '') = 'deleted'  AS is_deleted,
           COALESCE(liability_description::text, '') ILIKE '%SUPPLIER%' AS is_supplier
    FROM foundry_sync.sap_nc
),
d AS (
    SELECT f.sous_groupe
    FROM foundry_sync.nc_defects f
    JOIN nc n ON n.nc_id = ltrim(f.notification_number::text, '0')
    WHERE NOT n.is_deleted
      AND NOT n.is_supplier
      AND n.created_on >= DATE '2026-01-01'            -- EDIT: start of the period, as in q_pareto
      AND ('{{w_program.selectedValue}}' IN ('', 'All') OR n.program = '{{w_program.selectedValue}}')
      AND f.groupe = '{{w_group.selectedValue}}'
),
c AS (
    SELECT sous_groupe AS detail, COUNT(*) AS defects
    FROM d
    GROUP BY 1
)
SELECT detail,
       defects,
       ROUND(100.0 * defects / SUM(defects) OVER (), 1) AS pct_of_group
FROM c
ORDER BY defects DESC, detail;
