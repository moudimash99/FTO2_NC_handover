/* q_monthly_topics — the three MFT families per month (stacked bar chart)
   Returns one row per month and family: month, topic, defects, plus the month's
   all_defects and all_ncs repeated on each row (for a table or a tooltip).
   Topics (MFT): Inversion & erreur (family Branchement: wiring errors only),
   Câbles, Déverrouillage. Each defect has exactly one family, so the three never
   overlap and can be stacked. Not the same as the Pareto group Branchement,
   which also holds Déverrouillage and Non connecté.
   Needs: dropdown widget w_program (All / A330 / A350).
   Counting: one row = one defect. Deleted and supplier-liable NCs are left out. */
WITH nc AS (                                           -- EDIT: SAP table and column names
    SELECT ltrim(notification_number::text, '0')               AS nc_id,
           (creation_time::timestamptz)::date                  AS created_on,
           programme::text                                     AS program,
           COALESCE(status_open_closed::text, '') = 'deleted'  AS is_deleted,
           COALESCE(liability_description::text, '') ILIKE '%SUPPLIER%' AS is_supplier
    FROM foundry_sync.sap_nc
),
d AS (
    SELECT n.nc_id, to_char(date_trunc('month', n.created_on), 'YYYY-MM') AS month, f.famille
    FROM foundry_sync.nc_defects f
    JOIN nc n ON n.nc_id = ltrim(f.notification_number::text, '0')
    WHERE NOT n.is_deleted
      AND NOT n.is_supplier
      AND n.created_on >= DATE '2026-01-01'
      AND ('{{w_program.selectedValue}}' IN ('', 'All') OR n.program = '{{w_program.selectedValue}}')
),
months AS (
    SELECT month, COUNT(*) AS all_defects, COUNT(DISTINCT nc_id) AS all_ncs
    FROM d
    GROUP BY 1
),
topics AS (
    SELECT * FROM (VALUES (1, 'Branchement', 'Inversion & erreur'), (2, 'Câbles', 'Câbles'),
                          (3, 'Déverrouillage', 'Déverrouillage')) AS t(ord, famille, topic)
)
SELECT m.month,
       t.topic,
       COUNT(d.nc_id)  AS defects,
       m.all_defects,
       m.all_ncs
FROM months m
CROSS JOIN topics t
LEFT JOIN d ON d.month = m.month AND d.famille = t.famille
GROUP BY m.month, t.ord, t.topic, m.all_defects, m.all_ncs
ORDER BY m.month, t.ord;
