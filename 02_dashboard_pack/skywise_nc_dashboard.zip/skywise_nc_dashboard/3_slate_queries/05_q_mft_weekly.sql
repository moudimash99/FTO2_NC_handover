/* q_mft_weekly — one MFT topic, week by week, before and after its action started
   Returns one row per ISO week: iso_week, week_start, phase (Before / After action start /
   No start date), defects (defects that match the topic's rule), program_defects (all
   defects of that program that week), per_100_defects.
   Needs: dropdown widget w_topic, filled from q_mft_topics.
   The rule comes from the mft_actions table: program + categories + optional cable
   state, text regex and station regex. Change the table, not this query. */
WITH nc AS (                                           -- EDIT: SAP table and column names
    SELECT ltrim(notification_number::text, '0')               AS nc_id,
           (creation_time::timestamptz)::date                  AS created_on,
           programme::text                                     AS program,
           COALESCE(station_description::text, '')             AS station,
           COALESCE(status_open_closed::text, '') = 'deleted'  AS is_deleted,
           COALESCE(liability_description::text, '') ILIKE '%SUPPLIER%' AS is_supplier
    FROM foundry_sync.sap_nc
),
d AS (
    SELECT n.created_on, n.program, n.station, f.categorie,
           COALESCE(f.etat_cable::text, '') AS etat_cable,
           COALESCE(f.text::text, '')       AS text
    FROM foundry_sync.nc_defects f
    JOIN nc n ON n.nc_id = ltrim(f.notification_number::text, '0')
    WHERE NOT n.is_deleted
      AND NOT n.is_supplier
      AND n.created_on >= DATE '2026-01-01'
),
m AS (
    SELECT topic_id, program,
           NULLIF(action_start::text, '')::date      AS action_start,
           COALESCE(rule_categories::text, '')       AS rule_categories,
           COALESCE(rule_etat_cable::text, '')       AS rule_etat_cable,
           COALESCE(rule_text_regex::text, '')       AS rule_text_regex,
           COALESCE(rule_station_regex::text, '')    AS rule_station_regex
    FROM foundry_sync.mft_actions
    WHERE topic_id = '{{w_topic.selectedValue}}'
),
weeks AS (
    SELECT generate_series(date_trunc('week', DATE '2026-01-01'),
                           date_trunc('week', CURRENT_DATE) - INTERVAL '1 week',   -- last complete week
                           INTERVAL '1 week')::date AS week
),
hits AS (
    SELECT date_trunc('week', d.created_on)::date AS week, COUNT(*) AS defects
    FROM d JOIN m ON d.program = m.program
    WHERE (m.rule_categories    = '' OR d.categorie = ANY (string_to_array(m.rule_categories, '|')))
      AND (m.rule_etat_cable    = '' OR d.etat_cable = m.rule_etat_cable)
      AND (m.rule_text_regex    = '' OR d.text    ~* m.rule_text_regex)
      AND (m.rule_station_regex = '' OR d.station ~* m.rule_station_regex)
    GROUP BY 1
),
prog AS (
    SELECT date_trunc('week', d.created_on)::date AS week, COUNT(*) AS program_defects
    FROM d JOIN m ON d.program = m.program
    GROUP BY 1
)
SELECT to_char(w.week, 'IYYY-"W"IW')                                    AS iso_week,
       w.week                                                           AS week_start,
       CASE WHEN m.action_start IS NULL THEN 'No start date'
            WHEN w.week >= date_trunc('week', m.action_start)::date THEN 'After action start'
            ELSE 'Before' END                                           AS phase,
       COALESCE(h.defects, 0)                                           AS defects,
       COALESCE(p.program_defects, 0)                                   AS program_defects,
       ROUND(100.0 * COALESCE(h.defects, 0) / NULLIF(p.program_defects, 0), 1) AS per_100_defects
FROM weeks w
CROSS JOIN m
LEFT JOIN hits h ON h.week = w.week
LEFT JOIN prog p ON p.week = w.week
ORDER BY w.week;
