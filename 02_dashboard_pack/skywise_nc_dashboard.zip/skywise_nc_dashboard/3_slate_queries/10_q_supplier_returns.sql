/* q_supplier_returns — NCs where SAP makes the supplier liable, by Pareto group
   These NCs are left out of every other query. Returns one row per Pareto group:
   pareto_group, defects, ncs, plus supplier_ncs (all) and supplier_ncs_open (not deleted)
   repeated on every row for the headline tiles.
   Needs: dropdown widget w_program. */
WITH nc AS (                                           -- EDIT: SAP table and column names
    SELECT ltrim(notification_number::text, '0')               AS nc_id,
           (creation_time::timestamptz)::date                  AS created_on,
           programme::text                                     AS program,
           COALESCE(status_open_closed::text, '') = 'deleted'  AS is_deleted
    FROM foundry_sync.sap_nc
    WHERE COALESCE(liability_description::text, '') ILIKE '%SUPPLIER%'
      AND (creation_time::timestamptz)::date >= DATE '2026-01-01'
      AND ('{{w_program.selectedValue}}' IN ('', 'All') OR programme::text = '{{w_program.selectedValue}}')
),
t AS (
    SELECT COUNT(*) AS supplier_ncs,
           SUM(CASE WHEN NOT is_deleted THEN 1 ELSE 0 END) AS supplier_ncs_open
    FROM nc
)
SELECT f.groupe                 AS pareto_group,
       COUNT(*)                 AS defects,
       COUNT(DISTINCT n.nc_id)  AS ncs,
       MAX(t.supplier_ncs)      AS supplier_ncs,
       MAX(t.supplier_ncs_open) AS supplier_ncs_open
FROM foundry_sync.nc_defects f
JOIN nc n ON n.nc_id = ltrim(f.notification_number::text, '0')
CROSS JOIN t
WHERE NOT n.is_deleted
GROUP BY 1
ORDER BY CASE f.groupe WHEN 'Amont' THEN 1 WHEN 'FOD' THEN 2 WHEN 'Dossier' THEN 3
                       WHEN 'Non classé' THEN 4 ELSE 0 END,
         2 DESC, 1;
