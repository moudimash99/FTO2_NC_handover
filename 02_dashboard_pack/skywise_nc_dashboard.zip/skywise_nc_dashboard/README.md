# Skywise NC dashboard — install pack

Follow the handover doc "Skywise NC Dashboard Handover" step by step. This pack holds the files it refers to.

| Folder | Files | Used in |
| --- | --- | --- |
| 1_parser | nc_defect_parser.py (v4.5), nc_defects_transform.py, nc_defects_code_workbook.py (fallback) | Step 1 |
| 2_mft | mft_actions.csv (9 MFT topics, A330 and A350) | Step 2 |
| 3_slate_queries | 01 to 10, one Slate query each | Step 4 |
| 4_check | expected_values.csv (from the SAP extract of 6 July 2026) | Step 6 |

Lines to edit are marked EDIT. Nothing else needs changing.

The Pareto (queries 02 and 03) counts by `groupe`: Câblage, Branchement, Dommage & manquant, Métallisation, then Amont, FOD, Dossier and Non classé aside. The MFT queries (01, 04 to 08) still use `famille` and `categorie`.
