FTO2 NC dashboard
=================

for_users/        The documents for the people who use the dashboard: start with "1 Introduction", then the
                  "Start here" of your role (QLS, QCM, Manager); one "Deep dive" per tab; "7" the MFT page, "8" the NC
                  writer. English in en/, French in fr/.

for_developers/   The documents for the person who maintains the dashboard: start with "1 Start here". English in
                  en/, French in fr/.
  FTO2_Skywise_installation.zip   Every file of the Skywise set-up: the update (notebook, or Code Repository in
                                  code_repository/), the pages and their queries, the settings.
  source/                         The code, the settings, the checks and their reference data.

The dashboard itself is a Skywise (Slate) application: open it from its link.
