FTO2 NC dashboard
=================

for_users/
  FTO2_NC_Dashboard_User_Guide.pdf       Reading the dashboard and the MFT page. For everyone.
  FTO2_NC_Dashboard_Settings_Guide.pdf   What to keep up to date (tables, downloads, the yearly change) and how
                                         to run the update. For the person in charge of the dashboard.
  FTO2_NC_Dashboard_Access_Guide.pdf     Who needs which rights in Skywise, and the checks before the dashboard
                                         changes hands. For the owner of the dashboard in Skywise.

for_developers/
  FTO2_NC_Dashboard_Technical_Manual_EN.pdf   How it works, how to keep it working, how to change it.
  FTO2_NC_Dashboard_Manuel_Technique_FR.pdf   The same, in French.
  FTO2_Skywise_installation.zip               Every file the Skywise set-up needs (technical manual, chapter 7).
  source/                                     The code, the settings as first installed, the checks and their
                                              reference data (technical manual, chapter 8).

The dashboard itself is a Skywise (Slate) application: open it from its link.
