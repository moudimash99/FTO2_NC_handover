/* FTO2 NC dashboard, Skywise levels 2 and 3: data from the Slate queries q_fto2_nc, q_fto2_def, q_fto2_ref and q_fto2_dis (optional) through the code sandbox's state. */
window.FTO2_EMBED = true;
window.FTO2_PAGE = 'main';
window.FTO2_REF = null;   // null: the reference data comes from the query q_fto2_ref
function fto2RefBlocks(v) {
  if (typeof v === 'string') { try { v = JSON.parse(v); } catch (e) { return null; } }
  if (!v || (!Array.isArray(v) && !Object.keys(v).length)) return null;
  var rows = Array.isArray(v) ? v : (v.partie || []).map(function (p, i) { return { partie: p, morceau: v.morceau[i], texte: v.texte[i] }; });
  if (!rows.length) return null;
  var by = {}, out = {};
  rows.forEach(function (r) { (by[r.partie] = by[r.partie] || []).push(r); });
  Object.keys(by).forEach(function (p) {
    out[p] = JSON.parse(by[p].sort(function (a, b) { return +a.morceau - +b.morceau; }).map(function (r) { return r.texte; }).join(''));
  });
  return out;
}
// The settings of the Fusion sheet "Target and pages" (dataset fto2_set_targets, Slate query q_fto2_set_targets, state key
// "reglages"; optional): the page reads them itself, so that a change in the sheet shows without waiting for the notebook's
// next run. One row per setting, columns nom and valeur (names written in any case, with or without accents, spaces or signs);
// the table comes as rows, one array per column, or JSON text. Each line below replaces the reference value (fto2/reference.py,
// page_settings) before the page uses it; a line missing or wrong keeps the reference value, and the console says which.
function fto2Reglages(SET, v) {
  function say(kind, t) { if (window.console && console[kind]) console[kind]('[FTO2] Fusion settings (q_fto2_set_targets): ' + t); }
  if (typeof v === 'string') { var s = v.trim(); try { v = s ? JSON.parse(s) : null; } catch (e) { say('warn', 'not readable as a table: every reference value is kept'); return []; } }
  if (!SET || !v || typeof v !== 'object') { say('warn', 'no table received: every reference value is kept'); return []; }
  function key(t) { return String(t == null ? '' : t).normalize('NFKD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^0-9a-z]/g, ''); }
  function text(x) { return String(x == null ? '' : x).replace(/\u00a0/g, ' ').trim(); }
  function num(x) {   // 0.25, '0,25', ' 4 ': a number; null otherwise
    if (typeof x === 'number') return isFinite(x) ? x : null;
    var t = text(x).replace(/,/g, '.');
    return /^[-+]?(\d+\.?\d*|\.\d+)(e[-+]?\d+)?$/i.test(t) ? parseFloat(t) : null;
  }
  function share(x) {   // 0.25, '0,25', '25 %' and 25 all mean a quarter
    var n = num(typeof x === 'string' ? x.replace(/%/g, '') : x);
    if (n != null && n > 1) n = n / 100;
    return n != null && n >= 0 && n <= 1 ? n : undefined;
  }
  function coef(x) { return Math.round((1 - x) * 1e12) / 1e12; }
  var rows = v;
  if (!Array.isArray(v)) {   // one array per column, as Slate gives a query result
    rows = []; var cols = Object.keys(v), n = 0;
    cols.forEach(function (c) { if (Array.isArray(v[c]) && v[c].length > n) n = v[c].length; });
    for (var i = 0; i < n; i++) { var o = {}; cols.forEach(function (c) { o[c] = Array.isArray(v[c]) ? v[c][i] : null; }); rows.push(o); }
  }
  var got = {};
  rows.forEach(function (r) {
    if (!r || typeof r !== 'object') return;
    var nom = null, val = null;
    Object.keys(r).forEach(function (c) { var k = key(c); if (k === 'nom') nom = r[c]; else if (k === 'valeur') val = r[c]; });
    if (key(nom)) got[key(nom)] = val;
  });
  var DEF = SET.defauts || (SET.defauts = {});
  // [line of the sheet, what it must be, its reading (undefined: wrong), the value the page has, how to set it]
  var LINES = [
    ['objectif_baisse', 'a share (0.25, 0,25 or 25 %)', share, function () { return SET.objectif_baisse; },
      function (x) { SET.objectif_baisse = x; SET.objectif_coef = coef(x); }],
    ['defaut_phase', 'SERIE, REC, FTI or empty', function (x) { var t = text(x).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toUpperCase();
      return ['SERIE', 'REC', 'FTI', ''].indexOf(t) >= 0 ? t : undefined; }, function () { return DEF.phase; }, function (x) { DEF.phase = x; }],
    ['defaut_responsabilite', 'letters among f, s, o', function (x) { var t = text(x).toLowerCase();
      return t && !/[^fso]/.test(t) ? 'fso'.split('').filter(function (c) { return t.indexOf(c) >= 0; }).join('') : undefined; },
      function () { return DEF.liab; }, function (x) { DEF.liab = x; }],
    ['defaut_periode', 'one of ytd, m1, mp, m3, m6, m12, all', function (x) { var t = text(x).toLowerCase();
      return ['ytd', 'm1', 'mp', 'm3', 'm6', 'm12', 'all'].indexOf(t) >= 0 ? t : undefined; }, function () { return DEF.preset; }, function (x) { DEF.preset = x; }],
    ['action_objectif_baisse', 'a share (0.3, 0,3 or 30 %)', share, function () { return SET.action_baisse; },
      function (x) { SET.action_baisse = x; SET.action_coef = coef(x); }],
    ['action_semaines_tenues', 'a whole number of weeks, 1 or more', function (x) { var n = num(x); return n != null && n >= 1 && Math.floor(n) === n ? n : undefined; },
      function () { return SET.action_semaines; }, function (x) { SET.action_semaines = x; }]
  ];
  var used = [], missing = [];
  LINES.forEach(function (L) {
    var k = key(L[0]);
    if (!Object.prototype.hasOwnProperty.call(got, k)) { missing.push(L[0]); return; }
    var x = L[2](got[k]), was = L[3]();
    if (x === undefined) { say('warn', L[0] + ': "' + text(got[k]) + '" is not ' + L[1] + ', the reference value ' + JSON.stringify(was) + ' is kept'); return; }
    if (x === was) return;
    L[4](x); used.push(L[0] + ' ' + JSON.stringify(x) + ' (reference ' + JSON.stringify(was) + ')');
  });
  if (used.length) say('info', 'taken from the sheet: ' + used.join(', '));
  if (missing.length) say('info', 'not in the sheet, the reference value is kept: ' + missing.join(', '));
  return used;
}
/* ===== ADAPTER START ===== */
// The page's data from its two tables, one row per NC and one row per defect line (columns: fto2/core.py, NC_COLUMNS and
// DEF_COLUMNS), plus the fixed references (code sheet, MFT actions, cost parameters, production plan, root-cause tree).
// A table comes as a Slate query result (one array per column) or as rows (an array of objects). Optional: disIn the disruption
// block's aléas, cxIn the cost explanation worked out by the notebook (fto2/cost/explain.py, table fto2_dash_cout).
function fto2FromTables(ncIn, defIn, ref, disIn, cxIn) {
  ref = ref || {};
  function rows(t) {
    if (!t) return [];
    if (Array.isArray(t)) return t;
    var cols = Object.keys(t), n = 0, out = [];
    cols.forEach(function (c) { if (t[c] && t[c].length > n) n = t[c].length; });
    for (var i = 0; i < n; i++) { var o = {}; cols.forEach(function (c) { o[c] = t[c] ? t[c][i] : null; }); out.push(o); }
    return out;
  }
  function str(v) { return v == null ? '' : String(v); }
  function num(v) { var x = typeof v === 'number' ? v : parseFloat(v); return isFinite(x) ? x : 0; }
  function numOrNull(v) { if (v == null || v === '') return null; var x = typeof v === 'number' ? v : parseFloat(v); return isFinite(x) ? x : null; }
  function int(v) { return Math.round(num(v)); }
  function day(v) { if (v == null || v === '') return ''; if (typeof v === 'number') return new Date(v).toISOString().slice(0, 10); return String(v).slice(0, 10); }
  function r2(x) { return Math.round(x * 100) / 100; }
  function isoWeek(iso) {   // '2026-W02', as Python's isocalendar()
    var d = new Date(iso + 'T00:00:00Z'), dow = (d.getUTCDay() + 6) % 7;
    d.setUTCDate(d.getUTCDate() - dow + 3);   // the Thursday of the week decides the year
    var y = d.getUTCFullYear(), j4 = new Date(Date.UTC(y, 0, 4)), t1 = Date.UTC(y, 0, 4 - (j4.getUTCDay() + 6) % 7 + 3);
    var w = 1 + Math.round((d.getTime() - t1) / 6048e5);
    return y + '-W' + (w < 10 ? '0' : '') + w;
  }
  function clean(t) { return t.trim().split(/\s+/).join(' ').replace(/^[ *:\-]+|[ *:\-]+$/g, ''); }
  var ncs = [], byNc = {}, notLiable = [];
  var year = ref.settings && ref.settings.annee ? String(ref.settings.annee) : '';   // the tables hold the comparison year too: the page shows the year followed
  rows(ncIn).forEach(function (r) {
    var id = str(r.nc).trim().replace(/\.0$/, ''), created = day(r.created);
    if (!id || !created || (year && created.slice(0, 4) !== year)) return;
    var k = int(r.on_aec) === 1 ? 1 : 0;   // FTO2's cost only where FTO2 is liable; the NC still counts
    if (!k) notLiable.push(num(r.cost_total));
    var a = [id, created, isoWeek(created), str(r.line), '', int(r.on_aec), str(r.rule), str(r.decision_label), str(r.where_found),
      k * num(r.cost_airbus), k * num(r.cost_global), 0, k * num(r.cost_total), k * num(r.cost_admin), 0, k * num(r.cost_work), 0, k * num(r.cost_material), k * num(r.cost_engineering),
      0, int(r.cable), int(r.defect_lines), str(r.title), str(r.scope), str(r.phase),
      str(r.msn).replace(/\.0$/, ''), str(r.product) || 'Other', str(r.station), r.hour == null || r.hour === '' ? -1 : int(r.hour), numOrNull(r.lead_days), int(r.is_open),
      numOrNull(r.age_days), day(r.closed), str(r.type_nc), str(r.liability), str(r.sap_defect), str(r.sap_cause_group), str(r.sap_cause), str(r.status), str(r.source) || 'sky',
      [num(r.min_alert), num(r.min_writing), num(r.min_support), num(r.min_setup), num(r.min_hands_on), num(r.min_recheck), num(r.hours_engineering), int(r.final_inspection),
        str(r.work_source), str(r.order_state), str(r.rework_orders), str(r.alert_source), str(r.aleas), num(r.min_logistics)], str(r.origin) || 'normal', str(r.plant), k ? 0 : num(r.cost_total),
      str(r.material), str(r.material_label), k * num(r.cost_part)];   // [44] the part the NC is about (SAP material), [45] its label, [46] its value
    if (!k) a._w = [num(r.cost_airbus), num(r.cost_global), num(r.cost_total), num(r.cost_admin), num(r.cost_work), num(r.cost_material), num(r.cost_engineering), num(r.cost_part)];   // REC cost switch (3 Nov)
    ncs.push(a); byNc[id] = { a: a, plant: str(r.plant), lt: str(r.long_text) };
  });
  // products the production plan does not name, put back on their plan product (the settings table 2_produits_alias.csv):
  // [line, product regex, station regex, plan product], first match wins
  var AL = (ref.eqmsn && ref.eqmsn.alias) || [], inPlan = (ref.eqmsn && ref.eqmsn.map) || {};
  if (AL.length) ncs.forEach(function (a) {
    var p = a[26] || 'Other'; if (inPlan[p.toUpperCase()]) return;
    for (var i = 0; i < AL.length; i++) { var x = AL[i];
      if (x[0] === a[3] && new RegExp(x[1]).test(p) && (!x[2] || new RegExp(x[2], 'i').test(a[27]))) { a[26] = x[3]; return; } }
  });
  // FIN: a panel or harness code (…VU, …VB) is the product, not an equipment FIN, and a length (250CM) is no FIN;
  // take the next FIN written in the defect text, else none
  var FIN_RE = /\b(\d{1,4}[A-Z]{2,4}\d{0,4}[A-Z]{0,2})\b/g, FIN_NOT = /V[UB]$|^\d+(CM|MM|M|KG|MN|MIN|H|OHM|MOHM|KOHM|NM|DAN|ER|EME|ND|RD|TH|ST|EA|PCS)$/;
  function finOf(fin, text) {
    if (!fin || !FIN_NOT.test(fin)) return fin;   // also a length or a unit the parser took for a FIN (250CM, 100MOHM)
    var t = text.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toUpperCase(), m; FIN_RE.lastIndex = 0;
    while ((m = FIN_RE.exec(t))) if (!FIN_NOT.test(m[1])) return m[1];
    return '';
  }
  var defects = [], client = {}, lt = {}, qty = {}, pool = [];
  rows(defIn).forEach(function (r) {
    var id = str(r.nc).trim().replace(/\.0$/, ''), n = byNc[id];
    if (!n) return;   // an NC without a creation date is in no selection
    var a = n.a, seq = int(r.seq), k = id + '|' + seq, text = str(r.text);
    defects.push([id, seq, a[1], a[2], a[3], a[4], '', '', '', 0, 0, str(r.cat), str(r.rca), str(r.sub), int(r.minor), int(r.cable), 0, num(r.cost_alloc),
      text, '', a[23], a[24], str(r.subcode), finOf(str(r.fin), text)]);
    if (r.qty != null && r.qty !== '' && int(r.qty) !== 1) qty[k] = int(r.qty);
    if (a[23] === 'client') { client[k] = [str(r.cr_nature), str(r.cr_detection), str(r.cr_symptom), '', n.plant, a[34]]; lt[id] = n.lt; }
    if (a[23] && str(r.label_src) === 'ai' && str(r.ai_conf) === 'high' && text.length >= 30 && text.length <= 170) pool.push([a[1], id, str(r.rca), text]);
  });
  // REC cost switch (3 Nov): a defect line of an NC FTO2 is not liable for gets an equal share of the cost of the NC's work, used when the
  // switch says "Toutes les NC" (its stored share is 0: the cost model only shares FTO2's cost)
  var nLines = {}; defects.forEach(function (d) { nLines[d[0]] = (nLines[d[0]] || 0) + 1; });
  defects.forEach(function (d) { var a = byNc[d[0]].a; if (a._w) d._w = a._w[2] / nLines[d[0]]; });
  // root-cause page: three recent, clearly labelled examples per root cause
  pool.sort(function (x, y) { return x[0] < y[0] ? 1 : x[0] > y[0] ? -1 : 0; });
  var ex = {};
  pool.forEach(function (p) { var e = ex[p[2]] || (ex[p[2]] = []); if (e.length < 3 && !e.some(function (q) { return q[0] === p[1]; })) e.push([p[1], clean(p[3])]); });
  var rca = (ref.rca || []).map(function (o) { var c = {}; for (var key in o) c[key] = o[key]; c.ex = ex[o.rca] || []; return c; });
  // production plan: each product's line is the line of most of its NCs
  var eq = null;
  if (ref.eqmsn) {
    eq = {}; for (var key in ref.eqmsn) eq[key] = ref.eqmsn[key];
    var cnt = {};
    ncs.forEach(function (a) { var p = (eq.map || {})[a[26].toUpperCase()]; if (p && a[3]) { var c = cnt[p] || (cnt[p] = {}); c[a[3]] = (c[a[3]] || 0) + 1; } });
    eq.line = {};
    Object.keys(eq.std || {}).forEach(function (p) { var best = '', bv = 0, c = cnt[p] || {}; Object.keys(c).forEach(function (l) { if (c[l] > bv) { bv = c[l]; best = l; } }); eq.line[p] = best; });
  }
  var to = '', aec = ncs.filter(function (a) { return a[5] === 1; }), sum = function (xs) { return r2(xs.reduce(function (s, a) { return s + a[12]; }, 0)); };
  ncs.forEach(function (a) { if (a[1] > to) to = a[1]; });
  var nlSum = r2(notLiable.reduce(function (s, v) { return s + v; }, 0));
  var cnqp = {}; for (var k2 in (ref.cnqp || {})) cnqp[k2] = ref.cnqp[k2]; cnqp.qty = qty;
  // the disruption block (optional third table): quality aléas that led to no NC [id, opened, line, station, work order, minutes, in block, reason, status, comment]
  // the cost explanation worked out by the notebook, per NC: {eur: 6 steps, factor, adj (FTO2's cost), adjAll (every NC's cost),
  // lines: [seq, minutes, material, class, class in English]}; null without the table (the page works it out itself)
  var cx = null;
  if (cxIn) {
    cx = {};
    rows(cxIn).forEach(function (r) {
      var id = str(r.nc).trim().replace(/\.0$/, ''), n = byNc[id], seq = int(r.seq); if (!n) return;
      var o = cx[id] || (cx[id] = { eur: [0, 0, 0, 0, 0, 0], factor: 1, adj: 0, adjAll: 0, lines: [] });
      if (!seq) { var d = num(r.adjust); o.eur = [num(r.eur_alert), num(r.eur_writing), num(r.eur_support), num(r.eur_setup), num(r.eur_hands_on), num(r.eur_recheck)];
        o.factor = num(r.work_factor) || 1; o.adjAll = Math.abs(d) >= 0.05 ? d : 0; o.adj = n.a[5] === 1 ? o.adjAll : 0; return; }
      var c = str(r.defect_class); o.lines.push([seq, num(r.minutes), num(r.material), c || '—', str(r.defect_class_en) || c || '—']);
    });
    Object.keys(cx).forEach(function (id) { cx[id].lines.sort(function (a, b) { return a[0] - b[0]; }); });
  }
  var dis = disIn ? rows(disIn).map(function (r) { return [str(r.id), day(r.opened), str(r.line), str(r.station), str(r.work_order), num(r.minutes), int(r.in_block), str(r.reason), str(r.status), str(r.comment)]; })
    .filter(function (a) { return a[0] && a[1]; }) : null;
  return { defects: defects, ncs: ncs, rca: rca, client: client, lt: lt, codes: ref.codes || {}, actions: ref.actions || [], cnqp: cnqp, eqmsn: eq, y25: ref.y25 || null, dis: dis, cx: cx, cables: ref.cables || null, settings: ref.settings,
    meta: { from: ref.from || (ref.settings && ref.settings.annee ? ref.settings.annee : to.slice(0, 4)) + '-01-01', to: to, aside: { other: [notLiable.length, nlSum] },
      noLine: ncs.filter(function (a) { var p = String(a[42] || '').trim().toUpperCase(); return (p === 'FTO2' || p === 'FT02') && a[21] === 0; }).length, modelTotal: sum(aec) } };
}
/* ===== ADAPTER END ===== */
(function () {
  var MSG = {
    wait: 'Chargement des données Slate… / Loading the Slate data…',
    empty: 'La requête q_fto2_nc n’a renvoyé aucune ligne : vérifiez la requête et son jeu de données. / The q_fto2_nc query returned no row: check the query and its dataset.',
    noapi: 'État Slate introuvable : ce JavaScript doit tourner dans un code sandbox Slate dont l’état contient les requêtes (voir state.json). / No Slate state: this JavaScript must run in a Slate code sandbox whose state holds the queries (see state.json).',
    cut: 'Attention : exactement {n} lignes reçues pour {q} ; Slate a peut-être coupé la requête (limite de lignes). / Exactly {n} rows received for {q}: Slate may have cut the query (row limit).',
    slow: 'Toujours en attente de {q} : vérifiez que la requête existe, porte ce nom et s’exécute sans erreur. / Still waiting for {q}: check that the query exists, has this name and runs without error.',
    fnDown: 'La fonction Slate {f} {fr} : ce calcul est fait dans la page. / The Slate function {f} {en}: the page computes it itself.',
    fnLate: ['n’a pas répondu en 15 s', 'gave no answer within 15 s'],
    fnErr: ['a échoué ({m})', 'failed ({m})']
  };
  function showError(msg) {
    var e = document.getElementById('fto2-err');
    if (e) { e.hidden = false; e.textContent = 'Le tableau de bord n\'a pas pu s\'afficher / The dashboard could not load: ' + msg; }
    var w = document.getElementById('fto2-wait'); if (w) w.hidden = true;
    if (window.console) console.error('[FTO2 dashboard]', msg);
  }
  window.addEventListener('error', function (ev) { showError((ev && ev.message) || 'unknown error'); });
  function status(msg, warn) {
    var e = document.getElementById('fto2-wait');
    if (!e) return;
    e.hidden = !msg; e.textContent = msg || ''; e.className = 'fto2-wait' + (warn ? ' warn' : '');
  }
  function main() {
(function () {
  'use strict';
  var D = window.DASH, EMBED = !!window.FTO2_EMBED;
  // the pages' settings, from config/ through the backend (fto2/reference.py page_settings): target cut, month weights, shutdown
  // weeks, MSN minimum, filters at opening, categories, line colours, alarm settings
  var SET = D.settings, EQMIN = SET.msn_minimum;
  window.FTO2_ALARM_P = SET.alarmes; window.FTO2_PLACEHOLDER = SET.placeholder;
  // the year followed and the year it is compared with (config/2_parametres.csv: annee, annee_comparaison), as text. The page
  // was first written for 2026 against 2025: in its names, "26" stands for the year followed and "25" for the comparison year
  // (D.y25, v2Y25b, r25...). The texts name them {YEAR} and {PREV}; withYears writes the years in, once, when a table of texts
  // is declared (and the target's cut, {CUT}).
  var YEAR = String(SET.annee || String(D.meta.from).slice(0, 4)), PREV = String(SET.annee_ref || +YEAR - 1);
  window.FTO2_YEAR = +YEAR;   // read by the alarm block: its weeks are those of the year followed
  var CUT = String(Math.round(SET.objectif_baisse * 1000) / 10);   // the target's cut in percent (config/2_reglages_pages.csv, objectif_baisse): {CUT} in the texts
  // last year's volume: products delivered (the Livraisons sheet, 2025) or built, measured as this year's (from 2027)
  var BUILT25 = !!(D.y25 && D.y25.delivered === 'built'), DELW = BUILT25
    ? { '{LIVC}': 'Fabriqués', '{DLVC}': 'Built', '{LIV}': 'fabriqu', '{LIVN}': 'production', '{LIVN1}': 'production', '{DLV}': 'built', '{DLVN}': 'production', '{DLVN1}': 'production' }
    : { '{LIVC}': 'Livrés', '{DLVC}': 'Delivered', '{LIV}': 'livr', '{LIVN}': 'livraisons', '{LIVN1}': 'livraison', '{DLV}': 'delivered', '{DLVN}': 'deliveries', '{DLVN1}': 'delivery' };
  function withYears(o) {
    if (typeof o === 'string') {
      Object.keys(DELW).forEach(function (k) { o = o.split(k).join(DELW[k]); });
      return o.split('{YEAR}').join(YEAR).split('{PREV}').join(PREV).split('{CUT}').join(CUT);
    }
    if (Array.isArray(o)) return o.map(withYears);
    if (o && typeof o === 'object') Object.keys(o).forEach(function (k) { o[k] = withYears(o[k]); });
    return o;
  }
  // defect row: [nc, seq, date, week, line, perimetre, catP, rcaP, subP, minorP, cableP, cat, rca, sub, minor, cable, allocP, alloc, snippet, (empty), scope, phase, officialSubCode]
  // NC row:     [nc, date, week, line, perimetre, onAEC, rule, ruleLabel, whereFound, c1, c2, c3P, c3, admin, workP, work, matP, mat, eng, cableP, cable, lines, title, scope, phase,
  //              msn, product, station, hour, lead, open, age, closure date, type, liability, SAP defect, SAP cause group, SAP cause, status, data source]
  // D.client:   { 'nc|seq': [damageType, detection, symptom, rootCauseText, plant, liability] }, D.lt: { nc: long text } (customer returns only)
  var MONTHS_FR = ['janv.', 'févr.', 'mars', 'avr.', 'mai', 'juin', 'juil.', 'août', 'sept.', 'oct.', 'nov.', 'déc.'];
  var MONTHS_EN = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  var STR = withYears({
    fr: {
      kmNc: 'Compté en NC', kmDef: 'Compté en défauts', kmEur: 'En euros',
      tabOv: 'Vue d’ensemble', nKD: 'Défauts', nKDP: 'Défauts par NC', nKDPs: 'NC avec au moins un défaut lu', nKC: 'Coût de non-qualité', stTip: '{c} closes · {o} ouvertes',
      cabLabel: 'Défauts câble dans les barres', cabHide: 'Masqués', cabShow: 'Affichés',
      measureLabel: 'Mesure', mVol: 'Volume (défauts)', mCost: 'Coût de non-qualité', figTopCat: 'Première catégorie', figCableShare: 'Part des défauts câble', cabSub: '{n} défauts câble',
      kTopCat: 'Première catégorie en coût', kCableShare: 'Part du coût liée aux défauts câble',
      ncTitle: 'Vue d’ensemble', ncSub: 'Chaque NC compte une fois, quel que soit son nombre de défauts.',
      nK1: 'NC', nK2: 'NC encore ouvertes', nK3: 'Délai médian de clôture', nK3s: 'NC closes, en jours', nK4: 'Couverture du parsage', nK4s: 'NC avec au moins un défaut lu',
      dProg: 'NC par programme', dProdC: 'Produit', dProdCSub: '10 premiers produits.', dProd: 'NC par produit', dProdSub: '15 premiers produits.', dStatus: 'Décision et statut', keyClosed: 'Closes', keyOpen: 'Ouvertes', ofWhichOpen: '{n} dont {c} ouvertes',
      dMonthNc: 'NC ouvertes et closes par mois', monthNcSub: 'Ouvertes : mois de création. Closes : mois de clôture. Cliquez sur un mois pour garder les NC créées ce mois-là.', lnOpened: 'Ouvertes', lnClosed: 'Closes',
      dType: 'Type de NC', typeSub: 'Type enregistré pour la NC (registre ou règle du pipeline).', dLiab: 'Responsabilité', liabSub: '15 premières responsabilités (champ « liability » de SAP).',
      dSapDef: 'Code défaut SAP', sapDefSub: '10 premiers codes. Libellés SAP en anglais.', dSapCause: 'Cause SAP', sapCauseSub: '20 premières causes. Libellés SAP en anglais.',
      tblNcs: 'Détail des NC', nType: 'Type', nStatus: 'Statut', st_open: 'Ouverte', st_closed: 'Close', st_deleted: 'Supprimée',
      dFin: 'FIN (repère)', finSub: '20 repères les plus cités. Les défauts sans FIN écrit n’apparaissent pas.', cFin: 'FIN',
      ty_CABLES: 'Câbles', ty_TEST: 'Test', ty_INTERNE: 'Interne', 'ty_CONTROLE FINAL': 'Contrôle final', ty_FOURNISSEUR: 'Fournisseur', 'ty_CASSE INTERNE': 'Casse interne',
      'ty_DEMANDE DE DQN': 'Demande de DQN', ty_DAMAGES: 'Dommages', ty_CASSE: 'Casse', 'ty_RETOUR CLIENT': 'Retour client',
      a320fam: 'A320 (famille)', legSerie: 'FTO2', legRet: 'Retours clients',
      retNote: 'Retours clients : coût estimé par le modèle CNQ, factures réelles non disponibles.',
      hProd: 'Famille de produit', hScope: 'Type', hProg: 'Programme', hPerMsn: 'Coût par MSN', hMaxMsn: 'MSN le plus cher', hNcs: 'NC',
      k_msn: 'Avions', t_msn: 'Coût par avion (MSN)', s_msn: 'Une barre par MSN, dans l’ordre du début de production.',
      msnCount: '{n} MSN', msnTip: 'FTO2 {s} · retours {c}', msnLiab: '{n} NC (dont {k} imputables à FTO2)', msnZeroLeg: 'Trait gris : aucun coût pour FTO2', msnFirst: 'première NC le {d}', msnRecent: 'récent',
      msnRecentLeg: 'Première NC il y a moins de 30 jours', msnInProd: 'en production', msnInProdLeg: 'En production à la date des données (tableau Avances / Retards)',
      msnBefore: 'Commencé avant {YEAR} : {n} NC en {PREV}, hors de cette vue', msnBeforeLeg: 'Gris pâle : commencé avant {YEAR} (NC en {PREV}, hors de cette vue)', hNcType: 'Type', hNcTitle: 'Titre', avgShort: 'moy. {v}', avgLeg: 'Moyenne du programme', msnClick: 'Cliquez sur une barre pour afficher les NC de cet avion.', msnHead: '{n} NC (dont {k} imputables à FTO2) · {c}',
      k_prod: 'Produits', t_prod: 'Coût par famille de produit', s_prod: 'NC FTO2 et retours clients ; nombre de NC, d’avions (MSN) et coût moyen par avion. Les 10 familles les plus coûteuses, les autres regroupées.',
      prodTip: 'FTO2 {s} · retours {c} · {n} NC · {k} MSN', prodUnknown: 'Non identifié', prodRest: '{n} autres familles',
      k_lead: 'Délais', t_lead: 'Combien de temps une NC reste ouverte', s_lead: 'Part des NC encore ouvertes N jours après leur création, par décision. Les NC encore ouvertes comptent jusqu’à aujourd’hui (méthode de Kaplan-Meier). Point : la moitié des NC sont closes. Cliquez à un nombre de jours pour garder les NC encore ouvertes à ce moment-là.',
     
      g_rw: 'Retouche', g_rej: 'Rebut / rejet', g_oth: 'Autres décisions', axDays: 'Jours depuis la création de la NC', daysShort: '{n} j', medDays: 'médiane {n} j', medLeg: 'Médiane : 50 % closes',
      hMedian: 'Médiane', hOpen7: 'Ouvertes à 7 j', hOpen30: 'Ouvertes à 30 j', hStillOpen: 'Encore ouvertes', kmTipH: 'Jour {d}', kmOpen: 'encore ouvertes',
      k_station: 'Postes', t_station: 'Défauts par poste et catégorie', s_station: 'Les 12 postes où les NC portent le plus de défauts (poste de rédaction de la NC).',
      stTip: '{n} défauts · {p} du poste', noStation: 'Poste non renseigné', hStation: 'Poste',
      asof: 'Données au {to}', asideGroup: 'Non classé', dataView: 'Voir les données', hDay: 'Jour', hDays: 'Jours avec défauts', hPerDay: 'Défauts par jour', hFrom: 'De', hTo: 'Vers', hPerDef: 'Coût par défaut',
      k_cal: 'Rythme', t_cal: 'Calendrier des défauts', s_cal: 'Défauts par jour de création de la NC ; à droite, la part de chaque jour de la semaine. Case grise : aucun défaut ce jour-là (jour férié, fermeture).',
      calTip: '{n} défauts · {k} NC', calNone: 'Aucun défaut', calLeg: 'Défauts par jour', wdProfile: 'Part par jour de la semaine', wdTip: '{p} des défauts · {n}',
      k_flow: 'Flux', t_flow: 'Du lieu de détection à la décision', s_flow: 'Défauts : où la NC a été trouvée, catégorie du défaut, décision prise sur la NC. Épaisseur = nombre de défauts. Survolez un nœud pour isoler ses flux.',
      flowTip: '{n} défauts · {p} de « {c} »', nodeTip: '{n} défauts · {p}',
      colWhere: 'Trouvé à', colCat: 'Catégorie', colDec: 'Décision',
      w_fin: 'Contrôle final', w_test: 'Test', w_cab: 'Câbles', w_int: 'Interne', w_oth: 'Autres', d_rw: 'Retouche', d_rej: 'Rebut / rejet', d_exc: 'Échange', d_oth: 'Autres décisions',
      k_bub: 'Coût', t_bub: 'Volume ou coût unitaire', s_bub: 'Une bulle par cause (au moins 3 défauts). À droite : fréquente ; en haut : chère par défaut ; surface : coût total. Les pointillés relient les points de même coût total.',
      bubTip: '{n} défauts · {c} au total · {a} par défaut', axDef: 'Nombre de défauts (échelle logarithmique)', axAvg: 'Coût moyen par défaut', bubLeg: 'Cause (surface = coût total)', isoLeg: 'Même coût total',
      k_cmo: 'Évolution', t_cmo: 'Les causes mois par mois', s_cmo: 'Les premières causes de la sélection, plus celles ajoutées à la main (Déverrouillage et FOD d’office, pour la sécurité), ou de la même façon les catégories du Pareto. Mesure : celle de l’onglet, ou les NC.',
      cmoLvl: 'Regrouper par', cmoTopC: 'Premières catégories', cmoLessC: 'Une catégorie de moins', cmoMoreC: 'Une catégorie de plus', cmoAddC: '+ Ajouter une catégorie', cmoRca: 'Causes', cmoCat: 'Catégories', cmoLegncC: 'NC par mois : une NC compte une fois pour chaque catégorie qu’elle a.', cmoMeas: 'Mesure', cmoNc: 'NC', cmoTop: 'Premières causes', cmoLess: 'Une cause de moins', cmoMore: 'Une cause de plus', cmoAdd: '+ Ajouter une cause', cmoDel: 'Retirer {c}', cmoAdded: 'ajoutée',
      cmoTipvol: '{v} défauts', cmoTipcost: 'coût : {v}', cmoTipnc: '{v} NC', cmoLegvol: 'Défauts par mois.', cmoLegcost: 'Coût de non-qualité par mois.', cmoLegnc: 'NC par mois : une NC compte une fois pour chaque cause qu’elle a.',
      pngB: 'Image', pngT: 'Enregistrer ce graphique en image (PNG), avec son titre et sa légende', vqBoth: 'A330 et A350', vqSegL: 'Lignes', c78None: 'La cause suivie', c78One: 'Ligne {l}.', c78Both: 'A330 et A350 : sans l’A320, dont les petites pièces comptées à l’unité feraient baisser le taux.',
      k_bump: 'Évolution', t_bump: 'Classement mensuel des causes', s_bump: 'Rang de chacune des 8 premières causes, mois par mois. Cliquez sur une courbe pour la suivre.',
      bumpTip: '{r} · {n} défauts', bumpNone: 'Aucun défaut ce mois-ci', lowVol: 'volume faible', lowTip: '{n} défauts : mois peu chargé, rangs moins fiables', beyond: '>10',
      unit: 'Qualité', title: 'Non-conformités FTO2', period: 'NC créées du {from} au {to}',
      minorLabel: 'Défauts mineurs', minorIn: 'Inclus', minorOut: 'Exclus',
      tabPareto: 'Pareto', tabCost: 'Pareto des coûts', tabCnq: 'Coût de non-qualité', tabClient: 'Retours clients', tabCbl: 'Câbles', tabRca: 'Définitions', tabPplan: 'Production',
      serieSub: 'NC émises à FTO2 (plant FTO2), toutes : supprimées et hors responsabilité FTO2 comprises.', serieSubAec: 'NC émises à FTO2 (plant FTO2) dont FTO2 est responsable, supprimées comprises.', serieSubAllAec: 'NC dont FTO2 est responsable, émises à FTO2 ou ailleurs (retours clients compris).', serieSubAll: 'Toutes les NC, émises à FTO2 ou dans d’autres usines (retours clients compris).',
      csvLab: 'Télécharger les NC de la sélection (une ligne par défaut, pour Excel) :', csvShort: 'Extrait court', csvFull: 'Extrait complet', csvT: 'Les NC de la sélection, une ligne par défaut, à ouvrir dans Excel', csvName: 'NC FTO2 - {k} du {a} au {b}', csvKs: 'extrait court', csvKf: 'extrait complet',
      csvCols: 'NC|Date de création|Ligne|MSN|Produit|Poste|Catégorie|Cause|Sous-catégorie|Sous-code|FIN|Texte du défaut|Coût FTO2 de la NC (€)',
      csvMore: 'Titre de la NC|N° du défaut|Coût du défaut (€)|Phase|Type de NC|Origine|Responsabilité|Lieu de détection|Décision|Statut|Ouverte|Close le|Âge (jours)|Lignes de défaut|Mineur|Câble|Semaine|Source des données|Sortie du pipeline|Article SAP|Libellé de l’article|Coût du travail (€)|Coût matière (€)|Coût de gestion (€)|Coût ingénierie (€)|Coût de la pièce (€)|Aléas|Ordres de reprise', csvOrg: 'série|retour client|autre usine', csvYes: 'oui|non',
      infoBtn: 'Comment la sélection est faite', inf_title: 'Ce que chaque filtre retire, dans l’ordre', inf_out: 'Retirées', inf_left: 'Restent',
      inf_start: 'NC fournies par le pipeline', inf_startS: '{a} sortie normale · {b} IDs manquants ; le tableau n’en retire aucune d’office',
      inf_period: 'Période', inf_phase: 'Type de production', inf_line: 'Avion', inf_src: 'Source des données', inf_org: 'Origine (pipeline)', inf_plant: 'Usine FTO2 uniquement (plant = FTO2 ou FT02)', inf_pick: 'Clic sur un graphique',
      inf_all: 'tout (non appliqué)', inf_phaseS: 'retire {v}', inf_plantS: 'retire les NC dont le plant n’est pas FTO2 : {c} retours clients · {o} autres{p}',
      inf_plantNo: 'non : les retours clients et les NC des autres usines restent', inf_liab: 'Responsabilité', inf_liabS: 'retire : {p}', inf_liabNo: 'toutes : FTO2, fournisseurs et autres', inf_costAll: 'Coût : toutes les NC (REC), aussi celles dont FTO2 n’est pas responsable : le coût de leur traitement.', inf_end: 'Sélection', inf_endS: '{d} défauts',
      inf_cost: 'Coût : compté seulement là où FTO2 est responsable. {n} NC de la sélection comptent comme NC avec un coût de 0 € (leur traitement selon le modèle : {e}).',
      inf_minor: 'Défauts mineurs {v} : ce choix change le nombre de défauts, pas le nombre de NC.', inf_nodef: '{n} NC de la sélection n’ont aucune ligne de défaut lisible : comptées en NC et en coût, pas en défauts.',
      inf_cli: 'Onglet Retours clients : il montre les retours clients des mêmes filtres, quel que soit l’interrupteur usine ({n} NC).', inf_in: 'inclus', inf_ex: 'exclus',
      alBtn: 'Alarmes', alT: 'À regarder · {w}', alUp: '{w} en hausse depuis {s}', alAll: 'Toutes les causes', alSt: 'poste {v}', alCab: 'Câbles · {v}', alDont: 'dont {l}', alAlso: 'aussi : {l}',
      alNone: 'Rien à signaler.', alShort: 'Pas encore assez de semaines pour comparer.', alOther: '+{n} sur les autres lignes', alSeen: 'Vu', alBack: 'Remettre', alSeenL: 'Vues ({n})',
      alMaj: 'Majeure', alMin: 'Mineure', alWk: 'S{n}', alClose: 'Fermer', alCross: '{w} en hausse sur plusieurs lignes depuis {s}', alCreep: '{w} en hausse lente depuis {s}',
      alPlane: 'MSN {m} : {n} NC, un {p} en a {d} d’habitude', alAct: 'action en cours : {t}', alMore: '{n} de plus',
      cbTitle: 'Suivi NC câbles', cbNoData: 'Le suivi des câbles n’est pas chargé.', cbF1: 'Demandes de câble', cbF2: 'Part impression {q}', cbF3: 'Lignes avec une cause', cbF4: 'Câbles récurrents', cbF5: 'Lignes avec une action',
      cbMonth: 'Demandes par mois et imputation', cbShare: 'Part impression : {v}', cbMx: 'Motif × imputation', cbTypes: 'Types de câble', cbCauses: 'Causes (proposées)', cbRec: 'Câbles récurrents', cbList: 'Demandes',
      cbMotif: 'Motif', cbProd: 'Prod. ligne', cbMach: 'Impr. machine', cbOper: 'Impr. opérateur', cbOther: 'Autre', cbCable: 'Câble', cbMotifs: 'Motifs', cbImp: 'Imputation', cbWk: 'Sem.', cbProg: 'Prog.', cbCause: 'Cause (proposée)', cbCables: 'Câbles', cbCom: 'Commentaire',
      cbI0: 'Production ligne', cbI1: 'Impression – machine', cbI2: 'Impression – opérateur', cbI3: 'Définition', cbI4: 'Non renseigné', cbN: '{n} demandes', cbN1: '1 demande', cbNc: '{n} demandes · {c} câbles', cbCount: 'Compter', cbReq: 'Demandes', cbCab: 'Câbles', cbCabNote: 'Une demande compte pour le nombre de câbles qu’elle demande (un, si aucun câble n’est écrit).',
      cbF1c: 'Câbles demandés', cbF3c: 'Câbles avec une cause', cbF5c: 'Câbles avec une action', cbMonthC: 'Câbles demandés par mois et imputation', cbSearch: 'Rechercher', cbNone: 'Aucune demande pour ce choix.', cbClear: 'Tout effacer', cbCableChip: 'Câble {c}', cbQ: 'T',
      ppTitle: 'Production : les volumes derrière les taux', ppSub: 'Combien de MSN sont produits, prévus et {LIV}és, ligne par ligne et produit par produit ; puis comment ces chiffres servent aux taux, aux prévisions et aux objectifs.',
      ppF1: 'MSN produits sur la période', ppF2: 'MSN prévus en {YEAR} (année)', ppF3: 'produits {LIV}és en {PREV}', ppF4: 'NC rattachées au plan / toutes les NC',
      ppLines: 'Par ligne', ppLinesS: 'Taux = NC ÷ MSN produits sur la période. Objectif = taux {PREV} − {CUT} % ; * : pas de {PREV}, taux {YEAR} − {CUT} %.', ppProds: 'Par produit', ppProdsS: 'Les produits du plan de production, ligne par ligne.',
      ppMonth: 'MSN prévus, mois par mois', ppMonthS: 'Plan de production {YEAR} par ligne.', ppLight: 'Plus clair : mois à venir (prévision).', ppTipV: '{v} MSN', ppPlanned: 'prévu', connOnly: 'Erreurs de branchement par MSN : A330 et A350 seulement. Choisissez une de ces lignes, ou toutes.', vqOnly: 'Causes {PREV} contre {YEAR} : A330 et A350 seulement. Choisissez une de ces lignes, ou toutes.', v2InclOut: 'dont {n} hors plan (produits sans volume au plan)', ciMsn: '{e} MSN', ciDot: 'taux (NC par MSN)', ciLine: 'fourchette à 95 %',
      pinStatL: 'inversions avec leurs deux broches écrites', pinAdjL: 'entre deux broches qui se suivent', pinRepL: 'paires de broches sur plusieurs avions', pinNone: 'Aucune inversion avec ses deux broches écrites dans la sélection.',
      pinAc1: '1 avion', pinAcN: '{n} avions', pinAc3: '3 avions ou plus', pinTip: 'Broches {a} ↔ {b}', pinNextY: 'deux broches qui se suivent', pinNextN: 'broches éloignées',
      pinNo25: 'Pas de comparaison {PREV} : les textes des défauts {PREV} ne sont pas dans les données.', pinCols: ['FIN', 'Broches', 'Voisines', 'Avions'], pinY: 'oui', pinN: 'non', ppCurTip: '{p} compté comme produit au {d}, le reste prévu', ppCurL: 'Mois en cours ({m}) : la part des jours passés au {d}, le reste plus clair.',
      ppCur: 'Les NC vont au-delà de ce que le plan donne comme produit : le mois en cours compte pour la part de ses jours passés, le reste du mois va dans la prévision. Ainsi les NC de ce mois comptent partout, comme dans la Vue d’ensemble.',
      ppL: 'Ligne', ppP: 'Produit', ppEq: 'MSN produits {YEAR}', ppYr: 'MSN prévus {YEAR}', ppD25: '{LIVC} {PREV}', ppNc25: 'NC {PREV}', ppNc: 'NC {YEAR}', ppRate: 'NC par MSN {YEAR}', ppR25: 'Taux {PREV}', ppTgt: 'Objectif {YEAR} (NC par MSN)', ppTgtY: 'Objectif {YEAR} (NC)', pp25m: '{PREV} − {CUT} %',
      ppNone: 'Le plan de production réel n’est pas chargé.', slWait: 'Calcul dans Slate…', ppHowT: 'Comment ces chiffres sont faits et utilisés',
      ppH1t: 'D’où viennent les volumes', ppH1: '{YEAR} : le tableau Avances / Retards. Un MSN compte pour 1, réparti sur les jours travaillés entre son impression et son OTA : du lundi au vendredi, hors jours fériés et fermetures ; les semaines de congés autour de la fermeture d’été comptent pour moitié. Juillet et août font ainsi environ 60 % d’un mois normal.', ppH1s: '{PREV} : la feuille Livraisons {PREV}, produits livrés par mois.', ppH1p: '{PREV} : le même tableau, mesuré comme {YEAR} : chaque produit réparti sur les jours ouvrés de sa fabrication.',
      ppH2t: 'Comment une NC est rattachée à un produit', ppH2: 'Le produit de la NC (Produit_auto du pipeline) est relié à un produit du plan. {n} NC n’ont pas de produit du plan ({p}) : elles comptent dans tous les totaux, mais pas dans les taux par MSN, les prévisions par produit ni les objectifs par ligne.',
      ppH3t: 'Ce qu’on en fait', ppH3: 'NC par MSN = NC d’un mois ÷ MSN produits ce mois-là. Prévision à décembre = taux de la période × MSN prévus. Objectif d’une ligne = son taux {PREV} (NC par produit {LIV}é) − {CUT} %, × sa production {YEAR} ; objectif toutes lignes = somme des lignes, plus les NC hors plan de {PREV} − {CUT} %. Objectif de coût : le même calcul avec le coût. Un produit sans {LIVN1} en {PREV}{x} garde son rythme {YEAR} comme objectif.',
      ppH4t: 'À savoir', ppH4: 'A320 : les produits sont de petites pièces comptées à l’unité ({a} {LIV}ées en {PREV}), d’où un taux par unité très bas ; c’est pourquoi l’objectif se fait ligne par ligne et pas sur un taux commun. A400M : les textes des NC sont masqués ; une NC reçoit un défaut tiré de son titre quand le titre nomme un problème connu.',
      fbTitle: 'Filtres', fSrc: 'Source des données', fOrg: 'Origine (pipeline)', org_all: 'Les deux sorties', org_normal: 'Sortie normale', org_missing_ids: 'IDs manquants', src_all: 'Toutes les données', src_sky: 'Skywise seulement', src_man: 'Listes manuelles (GPS ou Test)', src_gps: 'Registre GPS', src_test: 'Liste Test',
      fPlant: 'Usine FTO2 uniquement', fLiab: 'Responsabilité', fCost: 'Coût', liab_f: 'FTO2', liab_s: 'Fournisseurs', liab_o: 'Autres', liab_all: 'Toutes', cost_fto2: 'FTO2 responsable', cost_all: 'Toutes les NC', fYes: 'Oui', fNo: 'Non', fPlantOff: 'Sans effet ici : l’onglet sépare déjà FTO2 et retours clients.',
      fPhase: 'Type de production', ph_all: 'Tous', ph_SERIE: 'Série', ph_REC: 'REC', ph_FTI: 'FTI', fLine: 'Avion', line_all: 'Tous les avions',
      fPeriod: 'Période', pr_ytd: 'Depuis le 1er janvier', pr_m1: '30 derniers jours', pr_mp: 'Dernier mois complet', pr_m3: '3 derniers mois', pr_m6: '6 derniers mois', pr_m12: '12 derniers mois', pr_all: 'Toutes les dates', pr_custom: 'Dates choisies',
      fFrom: 'Du', fTo: 'Au', fReset: 'Réinitialiser', pkClear: 'Retirer ce filtre', pk_wgrp: 'Trouvée à', pk_age: 'Encore ouvertes', pkAgeV: 'plus de {n} jours après leur création', kmAgeMark: 'filtre : ouvertes après {n} j', kmClick: 'Cliquez : garder les {n} NC encore ouvertes après {d} jours', pk_stcat: 'Poste et catégorie', pk_finmsn: 'FIN et avion', pk_dgrp: 'Décision', pk_lgrp: 'Décision', pk_open: 'Statut', pkOpenV: 'encore ouvertes', kmOpenN: 'Encore ouvertes : {n}', pk_month: 'Mois', pk_week: 'Semaine', pk_day: 'Jour', pk_prod: 'Produit', pk_pprod: 'Produit', pk_msn: 'Avion (MSN)', pk_station: 'Poste', pk_type: 'Type de NC', pk_ntype: 'Type de NC', pk_rule: 'Décision', pk_where: 'Détection', pk_nc: 'NC', pk_hour: 'Heure', pk_cat: 'NC avec un défaut', pk_rca: 'NC avec la cause', pk_sub: 'NC avec le défaut', pk_fin: 'NC avec un défaut sur', pk_code: 'NC avec le sous-code', fbSum: '{n} NC · {d} défauts dans la sélection', fbSumCli: '{n} NC retours clients · {d} défauts dans la sélection',
      foot5: 'Source des données : toutes les NC viennent de Skywise ; « Registre GPS » et « Liste Test » : les NC retrouvées aussi dans le registre GPS ou la liste Test (champ Ext_Source). Type de production : phase de la NC (Série, REC, FTI). Périodes comptées jusqu’à la dernière NC de l’extraction.',
      paretoTitle: 'Pareto des défauts', costTitle: 'Pareto des coûts de non-qualité',
      costSub: 'Le coût de chaque NC est réparti entre ses défauts ; les NC A400M sans texte forment une ligne à part.',
      kTotal: 'Coût de non-qualité', kPerNc: 'Coût moyen par NC', kTop: 'Première cause en coût', topCostSub: '{e} · {p}',
      tblCost: 'Détail des défauts et de leur coût', cCost: 'Coût réparti', hCost: 'Coût', hDef: 'Défauts', hNc: 'NC', hCum: 'Cumul', cShare: 'Part de NC', ncShareNote: 'NC : chaque NC est partagée entre ses défauts (1 défaut d’une NC qui en compte 35 = 1/35 de NC).', cnqTitle: 'Coût de non-qualité', clientTitle: 'Retours clients',
      clientSub: 'NC émises hors de FTO2 (lignes d’assemblage, clients) sous responsabilité FTO2.',
      rcaTitle: 'Définitions : catégories, causes et sous-catégories', rcaSub: 'Définition de chaque cause, sous-catégories et codes officiels, chiffres et exemples réels.',
      figDefects: 'Défauts', figNcs: 'NC', figPerNc: 'Défauts par NC (moyenne)', figTopRca: 'Première cause', topSub: '{n} défauts · {p}',
      dCat: 'Catégorie', dRca: 'Cause (RCA)', dLine: 'Ligne', dMonth: 'Mois de création', dWhere: 'Où la NC a été trouvée', dRule: 'Décision', cableSubCnq: 'Lignes de défaut où le câble lui-même est à refaire ou à refournir, quel que soit le type de la NC : un défaut câble trouvé au test compte ici, pas dans « NC câbles ».', keyCable: 'Défauts câble', keyOther: 'Autres défauts', cCab: 'Câble', ofWhichCable: '{n} dont {c} câble', dPhase: 'Phase', dNat: 'Nature du dommage', dCode: 'Sous-code officiel', codeSub: 'Sous-codes de la fiche de codes officielle de retouche.', cCode: 'Sous-code',
      natOnly: 'Défauts « Élément endommagé ».',
      paretoSub: 'Défauts par catégorie, du plus fréquent au moins fréquent.', aside: 'Non classé',
      hint: 'Cliquez sur une barre pour filtrer les autres graphiques et le détail.', clearAll: 'Tout effacer', clear: 'Effacer',
      tblWhere: 'Détail des NC : produit, avion, poste', tblWhereSub: 'Cliquez sur une ligne, un produit, un MSN ou un poste pour filtrer toute la page. Toutes les NC de la sélection, les plus récentes en premier.',
      wtProd: 'Produit', wtMsn: 'MSN', wtSt: 'Poste', wtType: 'Type', wtCost: 'Coût', wtTitle: 'Titre',
      tblDefects: 'Détail des défauts', tblNc: 'Détail des NC et de leur coût', tblClient: 'Détail des retours clients',
      tblClientSub: 'Cliquez sur une ligne pour lire le texte de la NC.',
      search: 'Rechercher (NC, texte, FIN…)', shown: '{n} sur {t}', more: 'Afficher {n} de plus',
      cNc: 'NC', cDate: 'Date', cLine: 'Ligne', cCat: 'Catégorie', cRca: 'Cause (RCA)', cSub: 'Sous-catégorie', cText: 'Défaut', cWhy: 'Cause',
      lineLabel: 'Ligne', allLines: 'Toutes', total: 'Total', cnqSub: 'Estimation à partir des temps du processus AEC : alerte, rédaction, support technique, reprise et contrôle, chiffrés défaut par défaut.',
      nKR: 'NC par MSN', nKRs: 'NC ÷ MSN produits', ovMore: 'Autres listes et graphiques', cnqMore: 'Autres graphiques du coût', parMore: 'Autres graphiques', whereMore: 'Autres graphiques',
      allLines: 'Toutes lignes', v2Tgt: 'Objectif', v2Above: 'Au-dessus de l’objectif', v2Below: 'Sous l’objectif', v2TgtPh: 'Objectif (fictif)', v2Ph: 'fictif',
      v2Ph25: '{PREV} fictif (= {YEAR})', v2Y25b: '{PREV}, même filtre', v2Y25c: '{PREV} à la même date', v2Y25at: '{PREV} à la même date : {v}', v2TgtCumR: 'Objectif cumulé ({PREV} − {CUT} %)', v2StTgtR: 'objectif de l’année ({PREV} − {CUT} %)', v2StBudR: 'objectif de coût de l’année ({PREV} − {CUT} %)', v2StTgtL: 'objectif de l’année, somme des lignes', v2StBudL: 'objectif de coût de l’année, somme des lignes', v2TgtCumL: 'Objectif cumulé, ligne par ligne', v2BudL: 'Objectif de coût cumulé, ligne par ligne', v2TgtBar: 'Objectif', v2BudBar: 'Objectif', v2TgtN: '{a} NC pour un objectif de {t} NC (somme des lignes)', v2Mix: 'taux {PREV} au mix {YEAR} : {v}', v2BudR: 'Objectif de coût au prorata (coût {PREV} − {CUT} %)', v2TgtR: 'Objectif : taux {PREV} − {CUT} %', v2NoCli25: '{PREV} sans retours client (absents de l’extraction {PREV})', v2Rate25: '{PREV} : {v} NC par produit {LIV}é', v2Rate25s: 'Taux {PREV}', v2BudR2: 'objectif', v2MTgt: 'objectif mensuel {v} (fictif)', v2BudPh: 'Objectif de coût au prorata (fictif)', v2Y25: '{PREV}', v2Y26: '{YEAR} prévu', v2Flat: 'Stable', 
      vpFc: 'Fait et prévision', vpMsn: 'Par MSN', vpFcK: 'Volumes', vpFcT: 'NC, défauts et coût attendus d’ici décembre, produit par produit', vpFcS: 'Réalisé, puis prévision : volume de la période par MSN × MSN prévus jusqu’à décembre.', vpFcH: 'fait → fin décembre', vpDec: 'Prévu à fin décembre', xPartial: 'Semaine en cours non tracée (incomplète) : {n} NC', vpOutRow: 'Produit hors plan', vpOutL: 'Produits hors plan {l}', vpNoFc: 'pas de prévision', vpOwnPace: 'à son rythme', vpOut: '{n} NC sans produit du plan de production, comptées dans les totaux', dType: 'Répartition du coût par type de NC', typeSub: 'Type de la NC, là où elle a été trouvée ; « NC câbles » = NC du type Câbles ; 100 % = coût de la sélection.', ty_cab: 'NC câbles', ty_fin: 'Contrôle final', ty_test: 'Test', ty_int: 'Interne', ty_sup: 'Fournisseurs', ty_oth: 'Autres', wlCh_prod: 'Produits', wlCh_ac: 'Avions', wlCh_st: 'Postes', wlChs_prod: 'Taux, carte mensuelle, précision, projection et coût, produit par produit.', wlChs_ac: 'Coût par avion et FIN qui reviennent.', wlChs_st: 'Défauts par poste de rédaction de la NC.',
      v2MonTgt: 'objectif du mois {v}', v2CurTip: 'mois en cours, {d} jours sur {n} · objectif à date {v}', v2CurLeg: 'Mois en cours : objectif au prorata des jours travaillés', v2CurPt: 'mois en cours : données au {d} seulement', v2CurPtL: 'Mois en cours (données au {d})', v2Cum: '{v} NC cumulées', v2Fc: 'prévues', v2TgtShort: 'objectif', v2Under: 'Mois sous son objectif', v2Over: 'Mois au-dessus de son objectif', v2CumLeg: 'NC cumulées', v2TgtCum: 'Objectif cumulé (fictif)', v2MonthW: 'Chaque mois compte selon son volume de travail prévu au plan de production.', v2PerMsnV: '{v} par MSN', v2StNow: 'NC depuis le début de la période', v2StFc: 'prévus à fin décembre', v2StTgt: 'objectif de l’année (fictif)', v2StCost: 'cumulés sur la période', v2StBud: 'objectif de coût de l’année (fictif)', v2QPer: 'Par MSN produit : la fermeture d’août ne pèse pas.', v2Q25: '{PREV} : défauts par produit {LIV}é (causes lues par le parseur) ; {YEAR} : par MSN produit.', v2Avg25: 'Moyenne {PREV} (par produit {LIV}é)', v2QMonth: 'Moyenne par mois.', v2PerMsn: 'par MSN', v2Ac: '{n} avions',
      scVol: 'Volume par mois', scTot: 'Total', scRate: 'Par MSN, par mois', scRateP: 'Par MSN', scLast3: '3 derniers mois', scNc: 'NC', scDef: 'Défauts', scCost: 'Coût',
      scNote: 'Par MSN : NC, défauts et coût des produits rattachés au fichier de production. Petit chiffre : écart des 3 derniers mois à la période.',
      tabWhere: 'Localisation', whereTitle: 'Localisation des NC', whereSub: 'Produits, lignes, avions et postes, rapportés au volume produit quand c’est possible.', cxSum: 'Expliquer le calcul',
      cxStepsT: 'Les étapes d’une NC, avec leur temps et leur coût',
      cxStepsSub: 'Chaque NC suit six étapes. Le coût est la somme des minutes au taux horaire, plus l’ingénierie et la matière. La dernière ligne de chaque étape donne son total sur la sélection.',
      cs_alert: 'Aléa', cs_writing: 'Rédaction de la NC', cs_support: 'Support technique', cs_setup: 'Préparation', cs_hands: 'Intervention', cs_recheck: 'Recontrôle et clôture',
      cu_alert: 'l’opérateur signale le défaut', cu_writing: '{x} min au contrôle final', cu_support: 'vérification, estimation, ordre de travail',
      cu_setup: 'badgeage, approvisionnement, mise en place', cu_hands: 'minutes de chaque défaut relevé', cu_recheck: 'contrôle de la retouche, puis clôture',
      cxModelH: 'Règles particulières du modèle {v}', cxR1: 'Pas d’alerte pour une NC trouvée au test ou au contrôle final ; un retour client a toujours l’alerte.', cxR2: 'Erreurs de connexion : la première d’une NC compte {a} min, chacune des suivantes {b} min.', cxR3: 'NC internes : préparation et intervention × {f}.', cxR4: 'Rejet avec un ordre de retouche : le travail est compté comme une retouche, plus la valeur de la pièce.', cxR5: 'Ordre de retouche clos et planifié : son temps prévu remplace préparation et intervention (sans la règle des connexions ni le × 2). {n} NC de la sélection.', cxR6: 'Aléa qualité relié à la NC (même ordre de travail, NC créée de {a} h avant à {b} h après) : son temps perdu déclaré remplace les {x} min de l’alerte. {n} NC de la sélection.',
      cxPerNc: '{c} par NC', cxHandsV: 'selon les défauts', cxSel: 'Sur les NC filtrées : {c} au total · {p} du coût',
      cxSumH: 'Ce que coûtent les {n} NC de la sélection', cxSteps6: 'Les six étapes', cxSteps6V: 'détail ci-dessus, étape par étape', cxShare: '{p} du coût', cxPerDqn: 'par demande de DQN',
      cxEng: 'Étude d’ingénierie', cxEngV: 'DQN : {h} h × {r} €/h = {c}', cxMat: 'Matière', cxMatV: 'somme de la matière des défauts', cxTot: 'Total de la sélection', cxTotV: '{n} NC',
      cxFormula: 'Coût = minutes de chaque étape ÷ 60 × le taux de qui la fait (production {p} €/h, qualité {q} €/h, ME {m} €/h) + ingénierie + matière. Préparation et intervention : minimum {f} min.', cxAtRate: 'à {r} €/h',
      cxExample: 'Exemple, une retouche avec un seul défaut de 10 min : {a} + {b} + {c} + {d} + 10 + {e} = {m} min, soit {c2}.',
      cxRulesSum: 'Voir ce qui est compté pour chaque décision',
      cxRuleH: ['Décision', 'NC', 'Aléa', 'Rédaction', 'Support', 'Travail et matière', 'Recontrôle', 'Ingénierie', 'Pièce', 'Standard Airbus', 'Origine'],
      bk_LOCAL: 'Processus décrit par AEC', bk_RULE: 'Règle AEC', bk_ASSUMED: 'Hypothèse', bk_OFFICIAL: 'Officiel Airbus', bk_TEAM: 'Table de l’équipe', bk_BORROWED: 'Emprunté', bk_DERIVED: 'Règle de l’équipe',
      cxNcT: 'Le calcul sur une NC réelle', cxNum: 'Numéro de NC', cxShow: 'Afficher', cxNone: 'Aucune NC ne porte ce numéro dans les données. Choisir un numéro dans la liste.',
      ex_one: 'Retouche à un défaut', ex_many: 'Retouche à plusieurs défauts', ex_final: 'Retouche au contrôle final', ex_noline: 'Retouche sans ligne de défaut',
      ex_rej: 'Rejet', ex_rejrw: 'Rejet avec ordre de retouche', r_notaec: 'Hors responsabilité FTO2', r_notaec_how: 'FTO2 n’est pas responsable de cette NC : elle compte comme NC, son coût pour FTO2 est 0', ex_order: 'Temps de l’ordre de retouche', fx_org: 'Origine', fx_order: 'Ordre de retouche', fx_mat: 'Matériel', n_logi: ' + {x} min de logistique (approvisionnement de la pièce)', os_used: 'temps prévu utilisé', os_open: 'pas encore clos : temps du modèle', os_no_time: 'clos sans temps prévu : temps du modèle', os_not_found: 'hors des opérations disponibles : temps du modèle', os_none: 'opérations non chargées : temps du modèle', n_ordSetup: 'Temps prévu des opérations de préparation, contrôle et clôture de l’ordre de retouche', n_ordWork: 'Temps prévu des opérations de travail et de test de l’ordre de retouche, à la place du modèle', dl_ord: 'Temps du modèle, pour information (l’intervention comptée est celle de l’ordre) ; la matière est reprise ci-dessus', ex_exc: 'Échange', ex_dqn: 'Demande de DQN', ex_cli: 'Retour client',
      fx_nc: 'NC', fx_date: 'Créée le', fx_line: 'Ligne', fx_dec: 'Décision', fx_where: 'Détection', fx_lines: 'Lignes de défaut',
      cxH: ['Étape', 'Calcul', 'Minutes', 'Coût (taux de l’étape)'],
      n_once: '{x} min, une fois par NC', n_alea: 'temps perdu déclaré sur l’aléa qualité {a}, qui a mené à la NC', ex_alea: 'Temps de l’aléa déclaré', n_noalert: 'pas d’alerte : NC trouvée au test ou au contrôle final', n_x2: '{s} · × {f} (NC interne)', n_plain: '{x} min', n_final: '{x} min car détectée au contrôle final',
      n_floor: 'relevée de {a} à {b} min pour que préparation et intervention atteignent {f} min', n_noline: 'aucune ligne de défaut : forfait de {x} min',
      n_lines: '{n} ligne(s) de défaut, détaillées ci-dessous', n_off: 'non compté pour cette décision',
      r_eng: 'Étude d’ingénierie', r_eng_how: '{h} h à {r} €/h', r_mat: 'Matière', r_mat_how: 'somme de la matière des lignes de défaut',
      r_part: 'Valeur de la pièce', r_part_how: 'matériel sans prix dans la liste des prix : compté 0 €', r_part_none: 'aucun matériel sur la NC : compté 0 €', r_part_list: 'prix du matériel (liste des prix) × quantité', r_adj: 'Retour client : forfait ou montant réel', r_tot: 'Total niveau 3',
      x2_line: 'Niveau 2, moyenne globale : {m} min aux temps moyens, soit {c}.', x1_line: 'Niveau 1, standard Airbus : {c} pour une décision « {l} », quel que soit le nombre de défauts.',
      d_lines: 'Voir les {n} lignes de défaut de cette NC', dlH: ['#', 'Texte saisi', 'Classe (cause racine)', 'Minutes', 'Matière'],
      dl_on: 'Somme, reprise ci-dessus en intervention et matière', dl_off: 'Somme, non comptée : cette décision ne comporte pas de travail',
      stripTotal: 'Total FTO2', stripSerie: 'Émises à FTO2', stripClient: 'Retours clients', stripDis: 'À côté, aléas qualité sans NC', disK: 'À côté du coût', disH: 'Aléas qualité sans NC', disS: 'Temps perdu déclaré dans MES sur les aléas qualité qui n’ont mené à aucune NC (même ordre de travail, de 2 h avant à 72 h après). Montré à côté du coût de non-qualité, non ajouté.', disEur: 'à {r} €/h', disHours: 'heures perdues', disN: 'aléas', disLed: '{n} NC de la sélection partent d’un aléa qualité : son temps déclaré est dans leur coût, à l’étape alerte.', disErma: '{n} aléas sur le MIP / 1101VB laissés de côté ({h} h) : une NC ERMA est possible, à vérifier.', disMonth: 'Heures perdues par mois', disLine: 'Par ligne', disList: 'Les {n} aléas, un par ligne', disCols: ['Aléa', 'Ouvert le', 'Ligne', 'Poste', 'Minutes', 'Ce que l’opérateur a écrit'], disNone: 'Aucun aléa qualité sans NC pour ce filtre.', disPhase: 'Les aléas sont ceux de l’atelier (série) : rien pour cette phase.', disOut: 'hors bloc (ERMA possible)', disMin: '{v} min',
      cTotal: 'Coût de non-qualité', cNcs: 'NC', cPerNc: 'Coût moyen par NC', cCable: 'Coût des défauts câble, toutes NC', cCableSub: '{p} du coût',
      cWo: 'Comment la retouche est chiffrée', cWoSub: 'Un OF de retouche clos avec des temps planifiés remplace les minutes du modèle (préparation et travail). NC dont FTO2 est responsable.',
      woOrder: 'Temps planifié de l’OF de retouche', woModel: 'Minutes du modèle par défaut', woVal: '{n} NC ({p}) · {c}', woStates: 'Chiffrées par le modèle : {o} OF encore ouverts, {t} OF sans temps, {f} sans OF trouvé.',
      cLevels: 'Comparaison des méthodes de chiffrage', cLevelsSub: 'Standard Airbus : coût forfaitaire par décision. Moyenne AEC : temps moyens par NC. Détail par défaut : étapes AEC et reprise calculée pour chaque défaut (méthode retenue).',
      lvl1: 'Standard Airbus', lvl2: 'Moyenne AEC', lvl3: 'Détail par défaut',
      cByCat: 'Coût par catégorie de défaut', cByCatSub: 'Coût de chaque NC réparti entre ses défauts.', noLine: 'NC A400M (sans texte)',
      cable: 'Câble', kNc: 'NC', kDate: 'Date', kLine: 'Ligne', kWhere: 'Trouvée', kRule: 'Décision', kLines: 'Défauts', kCable: 'Câble', kC3: 'Coût', kTitle: 'Titre', yes: 'oui',
      rNcs: 'NC retours clients', rDamaged: 'Élément endommagé', rPhys: 'Dommage physique', rCost: 'Coût de non-qualité',
      nat_phys: 'Dommage physique', nat_hs: 'Composant hors service', nat_recu: 'Reçu cassé', nat_nc: 'Cause non écrite',
      hSnip: 'Défaut', hLong: 'Texte de la NC', hInfo: 'Informations', iTitle: 'Titre', iPlant: 'Site émetteur', iLiab: 'Responsabilité', iDet: 'Détection', iSym: 'Conséquence observée', iNone: '—',
      rcaHowTitle: 'Comment un défaut reçoit sa cause', rRca: 'Cause (RCA)', rCat: 'Catégorie', rDef: 'Défauts FTO2', rShare: 'Part', rNc: 'NC', rCostS: 'Coût FTO2', rCli: 'Retours clients',
      rcaHow1: 'Chaque défaut reçoit une sous-catégorie, qui donne une seule cause (RCA), qui donne une seule catégorie du Pareto. Les sous-catégories regroupent les sous-codes officiels de la fiche de codes.',
      rcaHow2: 'Un code officiel écrit dans la NC l’emporte ; sinon le texte de la NC décide. Quand le texte décrit une cause et sa conséquence, le défaut est classé sur la cause.',
      stepCode: 'sous-codes officiels', stepSub: 'sous-catégories', stepRca: 'causes (RCA)', stepCat: 'catégories du Pareto',
      subsTitle: 'Sous-catégories et codes officiels', exTitle: 'Exemples', minorTag: 'mineur', noEx: 'Pas d’exemple sur la période.',
      foot1: 'Source : extraction SAP Skywise, NC créées du {from} au {to}.',
      foot2: 'NC FTO2 : plant FTO2 ou FT02 (une NC du registre GPS ou de la liste Test aussi, seulement si elle est à ce plant) ; toutes comptent, supprimées comprises. Retours clients : type « NC Retour client » du pipeline avec FTO2 dans la responsabilité. Coût : seulement là où FTO2 est responsable. Les défauts sont classés par cause à partir du texte complet de chaque NC.',
      foot3: 'Les {n} NC sans ligne de défaut lisible (A400M sans texte, NC supprimées…) sont comptées en NC et en coût mais pas en défauts. Les {o} NC dont FTO2 n’est pas responsable comptent comme NC avec un coût de 0 pour FTO2 (leur traitement selon le modèle : {oe}).',
      footPart0: 'la valeur des pièces rebutées n’est pas incluse', footPart1: 'la valeur des pièces rebutées ou échangées est comptée quand leur prix est connu',
      foot4: 'Semaines de fermeture (moins de {sh} % d’une semaine travaillée normale, d’après le calendrier des fermetures) exclues des moyennes hebdomadaires. Défauts mineurs : tyrap, frette, ficelle, capuchon, cerise ou bouchon manquant. Coût : chaque étape au taux de qui la fait (production {rp} €/h, qualité {rq} €/h, ME {rm} €/h ; ingénierie {re} €/h), temps du processus estimés par l’équipe ; {pv}. Coût des défauts câble : coût des NC concernées ; quand une NC contient aussi d’autres défauts, son coût est partagé entre ses défauts.'
    },
    en: {
      kmNc: 'Counted in NCs', kmDef: 'Counted in defects', kmEur: 'In euros',
      tabOv: 'Overview', nKD: 'Defects', nKDP: 'Defects per NC', nKDPs: 'NCs with at least one defect read', nKC: 'Cost of non-quality', stTip: '{c} closed · {o} open',
      cabLabel: 'Cable defects in the bars', cabHide: 'Hidden', cabShow: 'Shown',
      measureLabel: 'Measure', mVol: 'Volume (defects)', mCost: 'Cost of non-quality', figTopCat: 'Top category', figCableShare: 'Share of cable defects', cabSub: '{n} cable defects',
      kTopCat: 'Top category by cost', kCableShare: 'Share of cost from cable defects',
      ncTitle: 'Overview', ncSub: 'Each NC counts once, whatever its number of defects.',
      nK1: 'NCs', nK2: 'NCs still open', nK3: 'Median time to close', nK3s: 'closed NCs, in days', nK4: 'Parsing coverage', nK4s: 'NCs with at least one defect read',
      dProg: 'NCs by programme', dProdC: 'Product', dProdCSub: 'Top 10 products.', dProd: 'NCs by product', dProdSub: 'Top 15 products.', dStatus: 'Decision and status', keyClosed: 'Closed', keyOpen: 'Open', ofWhichOpen: '{n}, of which {c} open',
      dMonthNc: 'NCs opened and closed per month', monthNcSub: 'Opened: month created. Closed: month closed. Click a month to keep the NCs created that month.', lnOpened: 'Opened', lnClosed: 'Closed',
      dType: 'NC type', typeSub: 'Type recorded for the NC (register or pipeline rule).', dLiab: 'Liability', liabSub: 'Top 15 liabilities (SAP “liability” field).',
      dSapDef: 'SAP defect code', sapDefSub: 'Top 10 codes.', dSapCause: 'SAP cause', sapCauseSub: 'Top 20 causes.',
      tblNcs: 'NC detail', nType: 'Type', nStatus: 'Status', st_open: 'Open', st_closed: 'Closed', st_deleted: 'Deleted',
      dFin: 'FIN (reference)', finSub: 'Top 20 references. Defects with no FIN written are left out.', cFin: 'FIN',
      ty_CABLES: 'Cables', ty_TEST: 'Test', ty_INTERNE: 'Internal', 'ty_CONTROLE FINAL': 'Final inspection', ty_FOURNISSEUR: 'Supplier', 'ty_CASSE INTERNE': 'Internal breakage',
      'ty_DEMANDE DE DQN': 'DQN request', ty_DAMAGES: 'Damage', ty_CASSE: 'Breakage', 'ty_RETOUR CLIENT': 'Customer return',
      a320fam: 'A320 family', legSerie: 'FTO2', legRet: 'Customer returns',
      retNote: 'Customer returns: cost estimated by the CNQ model; actual invoices not available.',
      hProd: 'Product family', hScope: 'Type', hProg: 'Programme', hPerMsn: 'Cost per MSN', hMaxMsn: 'Most expensive MSN', hNcs: 'NCs',
      k_msn: 'Aircraft', t_msn: 'Cost per aircraft (MSN)', s_msn: 'One bar per MSN, in order of the start of production.',
      msnCount: '{n} MSNs', msnTip: 'FTO2 {s} · returns {c}', msnLiab: '{n} NCs (of which {k} FTO2 liable)', msnZeroLeg: 'Grey mark: no cost for FTO2', msnFirst: 'first NC {d}', msnRecent: 'recent',
      msnRecentLeg: 'First NC less than 30 days ago', msnInProd: 'in production', msnInProdLeg: 'In production at the data date (Avances / Retards table)',
      msnBefore: 'Started before {YEAR}: {n} NCs in {PREV}, outside this view', msnBeforeLeg: 'Pale grey: started before {YEAR} (NCs in {PREV}, outside this view)', hNcType: 'Type', hNcTitle: 'Title', avgShort: 'avg {v}', avgLeg: 'Programme average', msnClick: 'Click a bar to list that aircraft’s NCs.', msnHead: '{n} NCs (of which {k} FTO2 liable) · {c}',
      k_prod: 'Products', t_prod: 'Cost by product family', s_prod: 'FTO2 NCs and customer returns; number of NCs, aircraft (MSNs) and average cost per aircraft. The 10 costliest families, the rest grouped.',
      prodTip: 'FTO2 {s} · returns {c} · {n} NCs · {k} MSNs', prodUnknown: 'Not identified', prodRest: '{n} other families',
      k_lead: 'Lead time', t_lead: 'How long an NC stays open', s_lead: 'Share of NCs still open N days after creation, by decision. NCs still open count until today (Kaplan-Meier). Dot: half of the NCs are closed. Click at a number of days to keep the NCs still open by then.',
     
      g_rw: 'Rework', g_rej: 'Scrap / rejection', g_oth: 'Other decisions', axDays: 'Days since the NC was created', daysShort: '{n} d', medDays: 'median {n} d', medLeg: 'Median: 50% closed',
      hMedian: 'Median', hOpen7: 'Open at 7 d', hOpen30: 'Open at 30 d', hStillOpen: 'Still open', kmTipH: 'Day {d}', kmOpen: 'still open',
      k_station: 'Stations', t_station: 'Defects by station and category', s_station: 'The 12 stations whose NCs carry the most defects (station where the NC was written).',
      stTip: '{n} defects · {p} of the station', noStation: 'Station not recorded', hStation: 'Station',
      asof: 'Data as of {to}', asideGroup: 'Unclassified', dataView: 'Show the data', hDay: 'Day', hDays: 'Days with defects', hPerDay: 'Defects per day', hFrom: 'From', hTo: 'To', hPerDef: 'Cost per defect',
      k_cal: 'Rhythm', t_cal: 'Defect calendar', s_cal: 'Defects by NC creation day; on the right, each weekday’s share. Grey cell: no defect that day (public holiday, shutdown).',
      calTip: '{n} defects · {k} NCs', calNone: 'No defect', calLeg: 'Defects per day', wdProfile: 'Share by weekday', wdTip: '{p} of defects · {n}',
      k_flow: 'Flow', t_flow: 'From where it is found to the decision', s_flow: 'Defects: where the NC was found, defect category, decision taken on the NC. Width = number of defects. Hover a node to isolate its flows.',
      flowTip: '{n} defects · {p} of “{c}”', nodeTip: '{n} defects · {p}',
      colWhere: 'Found at', colCat: 'Category', colDec: 'Decision',
      w_fin: 'Final inspection', w_test: 'Test', w_cab: 'Cables', w_int: 'Internal', w_oth: 'Other', d_rw: 'Rework', d_rej: 'Scrap / rejection', d_exc: 'Exchange', d_oth: 'Other decisions',
      k_bub: 'Cost', t_bub: 'Volume or unit cost', s_bub: 'One bubble per root cause (3 defects or more). Right: frequent; up: expensive per defect; area: total cost. Dotted curves join points of equal total cost.',
      bubTip: '{n} defects · {c} in total · {a} per defect', axDef: 'Number of defects (log scale)', axAvg: 'Average cost per defect', bubLeg: 'Root cause (area = total cost)', isoLeg: 'Equal total cost',
      k_cmo: 'Trend', t_cmo: 'Root causes month by month', s_cmo: 'The top root causes of the selection, plus those added by hand (Unlocked contact and FOD from the start, for safety), or the Pareto categories in the same way. Measure: the tab’s, or NCs.',
      cmoLvl: 'Group by', cmoTopC: 'Top categories', cmoLessC: 'One category less', cmoMoreC: 'One category more', cmoAddC: '+ Add a category', cmoRca: 'Root causes', cmoCat: 'Categories', cmoLegncC: 'NCs per month: an NC counts once for each category it has.', cmoMeas: 'Measure', cmoNc: 'NCs', cmoTop: 'Top root causes', cmoLess: 'One root cause less', cmoMore: 'One root cause more', cmoAdd: '+ Add a root cause', cmoDel: 'Remove {c}', cmoAdded: 'added',
      cmoTipvol: '{v} defects', cmoTipcost: 'cost: {v}', cmoTipnc: '{v} NCs', cmoLegvol: 'Defects per month.', cmoLegcost: 'Cost of non-quality per month.', cmoLegnc: 'NCs per month: an NC counts once for each root cause it has.',
      pngB: 'Image', pngT: 'Save this chart as an image (PNG), with its title and key', vqBoth: 'A330 and A350', vqSegL: 'Lines', c78None: 'The root cause followed', c78One: 'Line {l}.', c78Both: 'A330 and A350: without the A320, whose small parts counted one by one would pull the rate down.',
      k_bump: 'Trend', t_bump: 'Monthly ranking of root causes', s_bump: 'Rank of each of the top 8 root causes, month by month. Click a line to follow it.',
      bumpTip: '{r} · {n} defects', bumpNone: 'No defect this month', lowVol: 'low volume', lowTip: '{n} defects: light month, ranks less reliable', beyond: '>10',
      unit: 'Quality', title: 'FTO2 Non-conformities', period: 'NCs created {from} to {to}',
      minorLabel: 'Minor defects', minorIn: 'Included', minorOut: 'Excluded',
      tabPareto: 'Pareto', tabCost: 'Cost Pareto', tabCnq: 'Cost of non-quality', tabClient: 'Customer returns', tabCbl: 'Cables', tabRca: 'Definitions', tabPplan: 'Production',
      serieSub: 'Every NC raised at FTO2 (plant FTO2), deleted and not-liable ones included.', serieSubAec: 'NCs raised at FTO2 (plant FTO2) that FTO2 is liable for, deleted ones included.', serieSubAllAec: 'NCs FTO2 is liable for, raised at FTO2 or elsewhere (customer returns included).', serieSubAll: 'Every NC, raised at FTO2 or at other plants (customer returns included).',
      csvLab: 'Download the NCs of the selection (one row per defect, for Excel):', csvShort: 'Short extract', csvFull: 'Full extract', csvT: 'The NCs of the selection, one row per defect, to open in Excel', csvName: 'FTO2 NCs - {k} from {a} to {b}', csvKs: 'short extract', csvKf: 'full extract',
      csvCols: 'NC|Created|Line|MSN|Product|Station|Category|Cause|Sub-category|Sub-code|FIN|Defect text|FTO2 cost of the NC (EUR)',
      csvMore: 'NC title|Defect no.|Defect cost (EUR)|Phase|NC type|Origin|Liability|Where found|Decision|Status|Open|Closed on|Age (days)|Defect lines|Minor|Cable|Week|Data source|Pipeline output|SAP material|Material label|Work cost (EUR)|Material cost (EUR)|Handling cost (EUR)|Engineering cost (EUR)|Part cost (EUR)|Aléas|Rework orders', csvOrg: 'series|customer return|other plant', csvYes: 'yes|no',
      infoBtn: 'How the selection is made', inf_title: 'What each filter removes, in order', inf_out: 'Removed', inf_left: 'Left',
      inf_start: 'NCs from the pipeline', inf_startS: '{a} normal output · {b} missing IDs; the page drops none of them by itself',
      inf_period: 'Period', inf_phase: 'Production type', inf_line: 'Aircraft', inf_src: 'Data source', inf_org: 'Origin (pipeline)', inf_plant: 'FTO2 plant only (plant = FTO2 or FT02)', inf_pick: 'Click on a chart',
      inf_all: 'all (not applied)', inf_phaseS: 'removes {v}', inf_plantS: 'removes NCs whose plant is not FTO2: {c} customer returns · {o} others{p}',
      inf_plantNo: 'off: customer returns and other plants’ NCs stay', inf_liab: 'Liability', inf_liabS: 'removes: {p}', inf_liabNo: 'all: FTO2, suppliers and others', inf_costAll: 'Cost: every NC (REC), also those FTO2 is not liable for: the cost of their handling.', inf_end: 'Selection', inf_endS: '{d} defects',
      inf_cost: 'Cost: counted only where FTO2 is liable. {n} NCs of the selection count as NCs with a cost of €0 (their handling in the model: {e}).',
      inf_minor: 'Minor defects {v}: this changes the number of defects, not the number of NCs.', inf_nodef: '{n} NCs of the selection have no readable defect line: counted as NCs and in the cost, not as defects.',
      inf_cli: 'Customer returns tab: it shows the customer returns under the same filters, whatever the plant switch ({n} NCs).', inf_in: 'included', inf_ex: 'excluded',
      alBtn: 'Alarms', alT: 'To look at · {w}', alUp: '{w} rising since {s}', alAll: 'All causes', alSt: 'station {v}', alCab: 'Cables · {v}', alDont: 'including {l}', alAlso: 'also: {l}',
      alNone: 'Nothing to report.', alShort: 'Not enough weeks yet to compare.', alOther: '+{n} on the other lines', alSeen: 'Seen', alBack: 'Put back', alSeenL: 'Seen ({n})',
      alMaj: 'Major', alMin: 'Minor', alWk: 'W{n}', alClose: 'Close', alCross: '{w} rising on several lines since {s}', alCreep: '{w} creeping up since {s}',
      alPlane: 'MSN {m}: {n} NCs, a {p} usually has {d}', alAct: 'action in progress: {t}', alMore: '{n} more',
      cbTitle: 'Cable NC tracker', cbNoData: 'The cable tracker is not loaded.', cbF1: 'Cable requests', cbF2: 'Printing share {q}', cbF3: 'Rows with a cause', cbF4: 'Recurring cables', cbF5: 'Rows with an action',
      cbMonth: 'Requests per month by imputation', cbShare: 'Printing share: {v}', cbMx: 'Reason × imputation', cbTypes: 'Cable types', cbCauses: 'Causes (proposed)', cbRec: 'Recurring cables', cbList: 'Requests',
      cbMotif: 'Reason', cbProd: 'Prod. line', cbMach: 'Print. machine', cbOper: 'Print. operator', cbOther: 'Other', cbCable: 'Cable', cbMotifs: 'Reasons', cbImp: 'Imputation', cbWk: 'Wk', cbProg: 'Prog.', cbCause: 'Cause (proposed)', cbCables: 'Cables', cbCom: 'Comment',
      cbI0: 'Production line', cbI1: 'Printing – machine', cbI2: 'Printing – operator', cbI3: 'Definition', cbI4: 'Blank', cbN: '{n} requests', cbN1: '1 request', cbNc: '{n} requests · {c} cables', cbCount: 'Count', cbReq: 'Requests', cbCab: 'Cables', cbCabNote: 'A request counts for the number of cables it asks for (one, when no cable is written).',
      cbF1c: 'Cables requested', cbF3c: 'Cables with a cause', cbF5c: 'Cables with an action', cbMonthC: 'Cables requested per month by imputation', cbSearch: 'Search', cbNone: 'No request for this choice.', cbClear: 'Clear all', cbCableChip: 'Cable {c}', cbQ: 'Q',
      ppTitle: 'Production: the volumes behind the rates', ppSub: 'How many MSN are built, planned and {DLV}, line by line and product by product; then how these figures feed the rates, the forecasts and the targets.',
      ppF1: 'MSN built in the period', ppF2: 'MSN planned in {YEAR} (year)', ppF3: 'products {DLV} in {PREV}', ppF4: 'NCs matched to the plan / all NCs',
      ppLines: 'By line', ppLinesS: 'Rate = NCs ÷ MSN built in the period. Target = {PREV} rate − {CUT}%; *: no {PREV}, {YEAR} rate − {CUT}%.', ppProds: 'By product', ppProdsS: 'The production plan’s products, line by line.',
      ppMonth: 'MSN planned, month by month', ppMonthS: '{YEAR} production plan by line.', ppLight: 'Lighter: months to come (forecast).', ppTipV: '{v} MSN', ppPlanned: 'planned', connOnly: 'Connection errors per MSN: A330 and A350 only. Pick one of these lines, or all.', vqOnly: 'Root causes {PREV} against {YEAR}: A330 and A350 only. Pick one of these lines, or all.', v2InclOut: 'of which {n} out of the plan (products with no planned volume)', ciMsn: '{e} MSN', ciDot: 'rate (NCs per MSN)', ciLine: '95% range',
      pinStatL: 'swaps with both pins written', pinAdjL: 'between two pins next to each other', pinRepL: 'pin pairs on more than one aircraft', pinNone: 'No swapped wires with both pins written in the selection.',
      pinAc1: '1 aircraft', pinAcN: '{n} aircraft', pinAc3: '3 aircraft or more', pinTip: 'Pins {a} ↔ {b}', pinNextY: 'two pins next to each other', pinNextN: 'pins apart',
      pinNo25: 'No {PREV} comparison: the {PREV} defect texts are not in the data.', pinCols: ['FIN', 'Pins', 'Next to each other', 'Aircraft'], pinY: 'yes', pinN: 'no', ppCurTip: '{p} counted as built at {d}, the rest planned', ppCurL: 'Running month ({m}): the share of its days gone at {d}, the rest lighter.',
      ppCur: 'The NCs run past what the plan gives as built: the month in progress counts for the share of its days gone, the rest of the month goes to the forecast. So that month’s NCs count everywhere, as on the Overview.',
      ppL: 'Line', ppP: 'Product', ppEq: 'MSN built {YEAR}', ppYr: 'MSN planned {YEAR}', ppD25: '{DLVC} {PREV}', ppNc25: 'NCs {PREV}', ppNc: 'NCs {YEAR}', ppRate: 'NCs per MSN {YEAR}', ppR25: '{PREV} rate', ppTgt: 'Target {YEAR} (NCs per MSN)', ppTgtY: 'Target {YEAR} (NCs)', pp25m: '{PREV} − {CUT}%',
      ppNone: 'The real production plan is not loaded.', slWait: 'Computing in Slate…', ppHowT: 'How these figures are made and used',
      ppH1t: 'Where the volumes come from', ppH1: '{YEAR}: the Tableau Avances / Retards. One MSN counts as 1, spread over the working days from its printing to its OTA: Monday to Friday, without public holidays and shutdowns; the holiday weeks around the summer shutdown count as half. July and August thus come to about 60% of a normal month.', ppH1s: '{PREV}: the Livraisons {PREV} sheet, products delivered per month.', ppH1p: '{PREV}: the same table, measured as {YEAR}: each product spread over the working days of its build.',
      ppH2t: 'How an NC is matched to a product', ppH2: 'The NC’s product (the pipeline’s Produit_auto) is linked to a product of the plan. {n} NCs have no product of the plan ({p}): they count in every total, but not in the per-MSN rates, the per-product forecasts or the line targets.',
      ppH3t: 'What they are used for', ppH3: 'NCs per MSN = a month’s NCs ÷ the MSN built that month. December forecast = the period rate × the MSN planned. A line’s target = its {PREV} rate (NCs per product {DLV}) − {CUT}%, × its {YEAR} output; all lines = the sum of the lines, plus {PREV}’s out-of-plan NCs − {CUT}%. Cost target: the same with the cost. A product with no {PREV} {DLVN1}{x} keeps its {YEAR} pace as its target.',
      ppH4t: 'Good to know', ppH4: 'A320: the products are small parts counted one by one ({a} {DLV} in {PREV}), so its rate per unit is very low; this is why the target is built line by line and not on a pooled rate. A400M: NC texts are redacted; an NC gets one defect from its title when the title names a known problem.',
      fbTitle: 'Filters', fSrc: 'Data source', fOrg: 'Origin (pipeline)', org_all: 'Both outputs', org_normal: 'Normal output', org_missing_ids: 'Missing IDs', src_all: 'All data', src_sky: 'Skywise only', src_man: 'Manual lists (GPS or Test)', src_gps: 'GPS register', src_test: 'Test list',
      fPlant: 'FTO2 plant only', fLiab: 'Liability', fCost: 'Cost', liab_f: 'FTO2', liab_s: 'Suppliers', liab_o: 'Others', liab_all: 'All', cost_fto2: 'FTO2 liable', cost_all: 'All NCs', fYes: 'Yes', fNo: 'No', fPlantOff: 'No effect here: this tab already shows FTO2 and customer returns apart.',
      fPhase: 'Production type', ph_all: 'All', ph_SERIE: 'Series', ph_REC: 'REC', ph_FTI: 'FTI', fLine: 'Aircraft', line_all: 'All aircraft',
      fPeriod: 'Period', pr_ytd: 'Year to date', pr_m1: 'Last 30 days', pr_mp: 'Last full month', pr_m3: 'Last 3 months', pr_m6: 'Last 6 months', pr_m12: 'Last 12 months', pr_all: 'All dates', pr_custom: 'Custom dates',
      fFrom: 'From', fTo: 'To', fReset: 'Reset', pkClear: 'Remove this filter', pk_wgrp: 'Found at', pk_age: 'Still open', pkAgeV: 'more than {n} days after creation', kmAgeMark: 'filter: open after {n} d', kmClick: 'Click: keep the {n} NCs still open after {d} days', pk_stcat: 'Station and category', pk_finmsn: 'FIN and aircraft', pk_dgrp: 'Decision', pk_lgrp: 'Decision', pk_open: 'Status', pkOpenV: 'still open', kmOpenN: 'Still open: {n}', pk_month: 'Month', pk_week: 'Week', pk_day: 'Day', pk_prod: 'Product', pk_pprod: 'Product', pk_msn: 'Aircraft (MSN)', pk_station: 'Station', pk_type: 'NC type', pk_ntype: 'NC type', pk_rule: 'Decision', pk_where: 'Found at', pk_nc: 'NC', pk_hour: 'Hour', pk_cat: 'NCs with a defect', pk_rca: 'NCs with the cause', pk_sub: 'NCs with the defect', pk_fin: 'NCs with a defect on', pk_code: 'NCs with the sub-code', fbSum: '{n} NCs · {d} defects in the selection', fbSumCli: '{n} customer-return NCs · {d} defects in the selection',
      foot5: 'Data source: every NC comes from Skywise; “GPS register” and “Test list”: the NCs also found in the GPS register or the Test list (Ext_Source field). Production type: the NC phase (Series, REC, FTI). Periods count up to the last NC of the extract.',
      paretoTitle: 'Defect Pareto', costTitle: 'Cost of non-quality Pareto',
      costSub: 'Each NC’s cost is shared among its defects; A400M NCs with no text form a row of their own.',
      kTotal: 'Cost of non-quality', kPerNc: 'Average cost per NC', kTop: 'Top root cause by cost', topCostSub: '{e} · {p}',
      tblCost: 'Defect and cost detail', cCost: 'Allocated cost', hCost: 'Cost', hDef: 'Defects', hNc: 'NCs', hCum: 'Cumulative', cShare: 'NC share', ncShareNote: 'NCs: each NC is shared among its defects (1 defect of an NC that has 35 = 1/35 of an NC).', cnqTitle: 'Cost of non-quality', clientTitle: 'Customer returns',
      clientSub: 'NCs raised outside FTO2 (assembly lines, customers) that FTO2 is liable for.',
      rcaTitle: 'Definitions: categories, root causes and sub-categories', rcaSub: 'Definition of each root cause, its sub-categories and official codes, figures and real examples.',
      figDefects: 'Defects', figNcs: 'NCs', figPerNc: 'Defects per NC (average)', figTopRca: 'Top root cause', topSub: '{n} defects · {p}',
      dCat: 'Category', dRca: 'Root cause (RCA)', dLine: 'Line', dMonth: 'Month created', dWhere: 'Where the NC was found', dRule: 'Decision', cableSubCnq: 'Defect lines where the cable itself has to be remade or resupplied, whatever the NC type: a cable defect found at test counts here, not in “Cable NCs”.', keyCable: 'Cable defects', keyOther: 'Other defects', cCab: 'Cable', ofWhichCable: '{n}, of which {c} cable', dPhase: 'Phase', dNat: 'Type of damage', dCode: 'Official sub-code', codeSub: 'Sub-codes of the official code sheet.', cCode: 'Sub-code',
      natOnly: '“Damaged item” defects.',
      paretoSub: 'Defects by category, most frequent first.', aside: 'Unclassified',
      hint: 'Click a bar to filter the other charts and the detail.', clearAll: 'Clear all', clear: 'Clear',
      tblWhere: 'NC detail: product, aircraft, station', tblWhereSub: 'Click a line, product, MSN or station to filter the whole page. Every NC of the selection, newest first.',
      wtProd: 'Product', wtMsn: 'MSN', wtSt: 'Station', wtType: 'Type', wtCost: 'Cost', wtTitle: 'Title',
      tblDefects: 'Defect detail', tblNc: 'NC and cost detail', tblClient: 'Customer return detail',
      tblClientSub: 'Click a row to read the NC text.',
      search: 'Search (NC, text, FIN…)', shown: '{n} of {t}', more: 'Show {n} more',
      cNc: 'NC', cDate: 'Date', cLine: 'Line', cCat: 'Category', cRca: 'Root cause (RCA)', cSub: 'Sub-category', cText: 'Defect', cWhy: 'Cause',
      lineLabel: 'Line', allLines: 'All', total: 'Total', cnqSub: 'Estimate from AEC process times: alert, writing, technical support, rework and check, costed defect by defect.',
      nKR: 'NCs per MSN', nKRs: 'NCs ÷ MSN built', ovMore: 'Other lists and charts', cnqMore: 'Other cost charts', parMore: 'Other charts', whereMore: 'Other charts',
      allLines: 'All lines', v2Tgt: 'Target', v2Above: 'Above target', v2Below: 'Below target', v2TgtPh: 'Target (placeholder)', v2Ph: 'placeholder',
      v2Ph25: '{PREV} placeholder (= {YEAR})', v2Y25b: '{PREV}, same filter', v2Y25c: '{PREV} at the same date', v2Y25at: '{PREV} at the same date: {v}', v2TgtCumR: 'Cumulative target ({PREV} − {CUT}%)', v2StTgtR: 'target for the year ({PREV} − {CUT}%)', v2StBudR: 'cost target for the year ({PREV} − {CUT}%)', v2StTgtL: 'target for the year, sum of the lines', v2StBudL: 'cost target for the year, sum of the lines', v2TgtCumL: 'Cumulative target, line by line', v2BudL: 'Cumulative cost target, line by line', v2TgtBar: 'Target', v2BudBar: 'Target', v2TgtN: '{a} NCs against a target of {t} NCs (sum of the lines)', v2Mix: '{PREV} rate at the {YEAR} mix: {v}', v2BudR: 'Pro-rata cost target ({PREV} cost − {CUT}%)', v2TgtR: 'Target: {PREV} rate − {CUT}%', v2NoCli25: '{PREV} without customer returns (not in the {PREV} extract)', v2Rate25: '{PREV}: {v} NCs per product {DLV}', v2Rate25s: '{PREV} rate', v2BudR2: 'target', v2MTgt: 'monthly target {v} (placeholder)', v2BudPh: 'Pro-rata cost target (placeholder)', v2Y25: '{PREV}', v2Y26: '{YEAR} forecast', v2Flat: 'Flat', 
      vpFc: 'Done and forecast', vpMsn: 'Per MSN', vpFcK: 'Volumes', vpFcT: 'NCs, defects and cost expected by December, product by product', vpFcS: 'Actual, then the forecast: the period’s volume per MSN × the MSN planned to December.', vpFcH: 'done → end of December', vpDec: 'Expected by end of December', xPartial: 'Running week not drawn (incomplete): {n} NCs', vpOutRow: 'Product not in the plan', vpOutL: 'Products not in the plan, {l}', vpNoFc: 'no forecast', vpOwnPace: 'at its own pace', vpOut: '{n} NCs with no production plan product, counted in the totals', dType: 'Cost split by NC type', typeSub: 'NC type, where it was found; “Cable NCs” = NCs of the Cables type; 100% = the cost of the selection.', ty_cab: 'Cable NCs', ty_fin: 'Final inspection', ty_test: 'Test', ty_int: 'Internal', ty_sup: 'Suppliers', ty_oth: 'Other', wlCh_prod: 'Products', wlCh_ac: 'Aircraft', wlCh_st: 'Stations', wlChs_prod: 'Rates, monthly map, precision, forecast and cost, product by product.', wlChs_ac: 'Cost per aircraft and FINs that come back.', wlChs_st: 'Defects by the station where the NC was written.',
      v2MonTgt: 'month target {v}', v2CurTip: 'running month, {d} of {n} days · target to date {v}', v2CurLeg: 'Running month: target pro-rated to the working days gone', v2CurPt: 'running month: data to {d} only', v2CurPtL: 'Running month (data to {d})', v2Cum: '{v} NCs to date', v2Fc: 'expected', v2TgtShort: 'target', v2Under: 'Month under its target', v2Over: 'Month above its target', v2CumLeg: 'Cumulative NCs', v2TgtCum: 'Cumulative target (placeholder)', v2MonthW: 'Each month counts by its planned working volume in the production plan.', v2PerMsnV: '{v} per MSN', v2StNow: 'NCs since the start of the period', v2StFc: 'expected by end of December', v2StTgt: 'target for the year (placeholder)', v2StCost: 'so far in the period', v2StBud: 'cost target for the year (placeholder)', v2QPer: 'Per MSN built: the August shutdown does not weigh.', v2Q25: '{PREV}: defects per product {DLV} (causes read by the parser); {YEAR}: per MSN built.', v2Avg25: '{PREV} average (per product {DLV})', v2QMonth: 'Monthly average.', v2PerMsn: 'per MSN', v2Ac: '{n} aircraft',
      scVol: 'Volume per month', scTot: 'Total', scRate: 'Per MSN, per month', scRateP: 'Per MSN', scLast3: 'Last 3 months', scNc: 'NCs', scDef: 'Defects', scCost: 'Cost',
      scNote: 'Per MSN: NCs, defects and cost of the products matched to the production file. Small figure: last 3 months against the period.',
      tabWhere: 'Location', whereTitle: 'NC location', whereSub: 'Products, lines, aircraft and stations, against the volume built where possible.', cxSum: 'Explain the calculation',
      cxStepsT: 'The steps of an NC, with their time and cost',
      cxStepsSub: 'Every NC goes through six steps. The cost is the sum of the minutes at the hourly rate, plus engineering and material. The last line of each step is its total over the selection.',
      cs_alert: 'Alert', cs_writing: 'Writing the NC', cs_support: 'Technical support', cs_setup: 'Setup', cs_hands: 'Hands-on work', cs_recheck: 'Re-check and closing',
      cu_alert: 'the operator reports the defect', cu_writing: '{x} min at final inspection', cu_support: 'check, estimate, work order',
      cu_setup: 'badging, fetching, setting up', cu_hands: 'minutes of each defect found', cu_recheck: 'check of the rework, then closing',
      cxModelH: 'Special rules of model {v}', cxR1: 'No alert for an NC found at test or final inspection; a customer return always has the alert.', cxR2: 'Connection errors: the first in an NC counts {a} min, each following one {b} min.', cxR3: 'Internal NCs: setup and hands-on work × {f}.', cxR4: 'Rejection with a rework order: the work is charged as for a rework, plus the value of the part.', cxR5: 'Rework order closed and planned: its planned time replaces setup and hands-on work (no connection rule, no × 2). {n} NCs in the selection.', cxR6: 'Quality aléa linked to the NC (same work order, NC created from {a} h before to {b} h after): its declared time lost replaces the {x}-min alert. {n} NCs in the selection.',
      cxPerNc: '{c} per NC', cxHandsV: 'depends on the defects', cxSel: 'Filtered NCs: {c} in total · {p} of the cost',
      cxSumH: 'What the {n} NCs of the selection cost', cxSteps6: 'The six steps', cxSteps6V: 'detailed above, step by step', cxShare: '{p} of the cost', cxPerDqn: 'per design query',
      cxEng: 'Engineering study', cxEngV: 'Design query: {h} h × {r} EUR/h = {c}', cxMat: 'Material', cxMatV: 'sum of the material of the defects', cxTot: 'Selection total', cxTotV: '{n} NCs',
      cxFormula: 'Cost = each step’s minutes ÷ 60 × the rate of who does it (production {p} EUR/h, quality {q} EUR/h, ME {m} EUR/h) + engineering + material. Setup and hands-on work: minimum {f} min.', cxAtRate: 'at {r} EUR/h',
      cxExample: 'Example, a rework with a single 10-minute defect: {a} + {b} + {c} + {d} + 10 + {e} = {m} min, which is {c2}.',
      cxRulesSum: 'See what is charged for each decision',
      cxRuleH: ['Decision', 'NCs', 'Alert', 'Writing', 'Support', 'Work and material', 'Re-check', 'Engineering', 'Part', 'Airbus standard', 'Basis'],
      bk_LOCAL: 'Process described by AEC', bk_RULE: 'AEC rule', bk_ASSUMED: 'Assumed', bk_OFFICIAL: 'Official Airbus', bk_TEAM: 'Team table', bk_BORROWED: 'Borrowed', bk_DERIVED: 'Team rule',
      cxNcT: 'The calculation on a real NC', cxNum: 'NC number', cxShow: 'Show', cxNone: 'No NC with that number in the data. Pick one from the list.',
      ex_one: 'Rework, one defect', ex_many: 'Rework, several defects', ex_final: 'Rework at final inspection', ex_noline: 'Rework, no defect line',
      ex_rej: 'Rejection', ex_rejrw: 'Rejection with a rework order', r_notaec: 'Not FTO2’s liability', r_notaec_how: 'FTO2 is not liable for this NC: it counts as an NC, its cost for FTO2 is 0', ex_order: 'Rework order time', fx_org: 'Origin', fx_order: 'Rework order', fx_mat: 'Material', n_logi: ' + {x} min of logistics (supplying the part)', os_used: 'planned time used', os_open: 'not closed yet: model time', os_no_time: 'closed with no planned time: model time', os_not_found: 'not in the operations available: model time', os_none: 'operations not loaded: model time', n_ordSetup: 'Planned time of the rework order’s preparation, inspection and closing operations', n_ordWork: 'Planned time of the rework order’s work and test operations, instead of the model', dl_ord: 'Model times, for information (the hands-on work charged is the rework order’s); the material is used above', ex_exc: 'Exchange', ex_dqn: 'Design query', ex_cli: 'Customer return',
      fx_nc: 'NC', fx_date: 'Created', fx_line: 'Line', fx_dec: 'Decision', fx_where: 'Found at', fx_lines: 'Defect lines',
      cxH: ['Step', 'How', 'Minutes', 'Cost (the step’s rate)'],
      n_once: '{x} min, once per NC', n_alea: 'time lost declared on quality aléa {a}, which led to the NC', ex_alea: 'Declared aléa time', n_noalert: 'no alert: NC found at test or final inspection', n_x2: '{s} · × {f} (internal NC)', n_plain: '{x} min', n_final: '{x} min because it was found at final inspection',
      n_floor: 'raised from {a} to {b} min so setup and hands-on work reach {f} min', n_noline: 'no defect line: flat {x} min',
      n_lines: '{n} defect line(s), listed below', n_off: 'not charged for this decision',
      r_eng: 'Engineering study', r_eng_how: '{h} h at {r} EUR/h', r_mat: 'Material', r_mat_how: 'sum of the material of the defect lines',
      r_part: 'Value of the part', r_part_how: 'material with no price in the price list: counted as 0 EUR', r_part_none: 'no material on the NC: counted as 0 EUR', r_part_list: 'price of the material (price list) × quantity', r_adj: 'Customer return: flat amount or real amount', r_tot: 'Total, level 3',
      x2_line: 'Level 2, global average: {m} min at average times, which is {c}.', x1_line: 'Level 1, Airbus standard: {c} for a “{l}” decision, whatever the number of defects.',
      d_lines: 'Show the {n} defect lines of this NC', dlH: ['#', 'What was written', 'Class (root cause)', 'Minutes', 'Material'],
      dl_on: 'Sum, used above as hands-on work and material', dl_off: 'Sum, not charged: this decision has no work',
      stripTotal: 'FTO2 total', stripSerie: 'Raised at FTO2', stripClient: 'Customer returns', stripDis: 'Beside it, quality aléas with no NC', disK: 'Beside the cost', disH: 'Quality aléas with no NC', disS: 'Time lost declared in MES on the quality aléas that led to no NC (same work order, from 2 h before to 72 h after). Shown beside the cost of non-quality, not added to it.', disEur: 'at {r} EUR/h', disHours: 'hours lost', disN: 'aléas', disLed: '{n} NCs in the selection start from a quality aléa: its declared time is in their cost, at the alert step.', disErma: '{n} aléas on the MIP / 1101VB left out ({h} h): an ERMA NC is possible, to check.', disMonth: 'Hours lost per month', disLine: 'By line', disList: 'The {n} aléas, one per row', disCols: ['Aléa', 'Opened', 'Line', 'Station', 'Minutes', 'What the operator wrote'], disNone: 'No quality aléa without an NC for this filter.', disPhase: 'The aléas are the shop floor’s (series): none for this phase.', disOut: 'out of the block (possible ERMA)', disMin: '{v} min',
      cTotal: 'Cost of non-quality', cNcs: 'NCs', cPerNc: 'Average cost per NC', cCable: 'Cost of cable defects, all NCs', cCableSub: '{p} of the cost',
      cWo: 'How the rework is costed', cWoSub: 'A closed rework order with planned times replaces the model’s minutes (setup and hands-on). NCs FTO2 is liable for.',
      woOrder: 'Planned time of the rework order', woModel: 'Model minutes per defect', woVal: '{n} NCs ({p}) · {c}', woStates: 'Costed by the model: {o} orders still open, {t} orders with no time, {f} with no order found.',
      cLevels: 'Costing methods compared', cLevelsSub: 'Airbus standard: flat cost per decision. AEC average: average times per NC. Per defect: AEC steps with the rework built for each defect (method used).',
      lvl1: 'Airbus standard', lvl2: 'AEC average', lvl3: 'Per defect',
      cByCat: 'Cost by defect category', cByCatSub: 'Each NC’s cost shared among its defects.', noLine: 'A400M NCs (no text)',
      cable: 'Cable', kNc: 'NC', kDate: 'Date', kLine: 'Line', kWhere: 'Found', kRule: 'Decision', kLines: 'Defects', kCable: 'Cable', kC3: 'Cost', kTitle: 'Title', yes: 'yes',
      rNcs: 'Customer-return NCs', rDamaged: 'Damaged item', rPhys: 'Physical damage', rCost: 'Cost of non-quality',
      nat_phys: 'Physical damage', nat_hs: 'Component failed', nat_recu: 'Received broken', nat_nc: 'Cause not written',
      hSnip: 'Defect', hLong: 'NC text', hInfo: 'Details', iTitle: 'Title', iPlant: 'Raised at', iLiab: 'Liability', iDet: 'Detection', iSym: 'Observed consequence', iNone: '—',
      rcaHowTitle: 'How a defect gets its root cause', rRca: 'Root cause (RCA)', rCat: 'Category', rDef: 'FTO2 defects', rShare: 'Share', rNc: 'NCs', rCostS: 'FTO2 cost', rCli: 'Customer returns',
      rcaHow1: 'Each defect gets a sub-category, which gives exactly one root cause (RCA), which gives exactly one Pareto category. Sub-categories group the official sub-codes of the code sheet.',
      rcaHow2: 'An official code written in the NC wins; otherwise the NC text decides. When the text describes a cause and its consequence, the defect is classified on the cause.',
      stepCode: 'official sub-codes', stepSub: 'sub-categories', stepRca: 'root causes (RCA)', stepCat: 'Pareto categories',
      subsTitle: 'Sub-categories and official codes', exTitle: 'Examples', minorTag: 'minor', noEx: 'No example over the period.',
      foot1: 'Source: Skywise SAP extract, NCs created {from} to {to}.',
      foot2: 'FTO2 NCs: plant FTO2 or FT02 (an NC of the GPS register or the Test list too, only if at that plant); all count, deleted ones included. Customer returns: the pipeline’s “NC Retour client” type with FTO2 in the liability. Cost: only where FTO2 is liable. Defects are classified by root cause from the full text of each NC. NC texts and sub-categories stay in French.',
      foot3: 'The {n} NCs with no readable defect line (A400M with no text, deleted NCs…) are counted as NCs and in the cost but not as defects. The {o} NCs FTO2 is not liable for count as NCs with a cost of 0 for FTO2 (their handling in the model: {oe}).',
      footPart0: 'the value of scrapped parts is not included', footPart1: 'the value of scrapped or exchanged parts is counted when their price is known',
      foot4: 'Shutdown weeks (under {sh}% of a normal working week, from the blackout days) are left out of weekly averages. Minor defects: a missing tyrap, frette, ficelle, cap, cerise or plug. Cost: each step at the rate of who does it (production {rp} €/h, quality {rq} €/h, ME {rm} €/h; engineering {re} €/h), process times estimated by the team; {pv}. Cost of cable defects: cost of the NCs concerned; when an NC also has other defects, its cost is shared among its defects.'
    }
  });
  var EN = {
    'MEO Facteur humain': 'Workmanship (human factor)', 'Erreur Branchement': 'Connection error', 'Élément Manquant': 'Missing item',
    'Élément Endommagé': 'Damaged item', 'Déverrouillage': 'Unlocked contact', 'Grounding/Bonding': 'Grounding/Bonding',
    'Kitting Factory': 'Kitting Factory', 'FOD': 'FOD', 'Autre': 'Other', 'Non classé': 'Not classified',
    'Inversion': 'Swapped wires', 'Mauvaise Borne': 'Wrong terminal', 'Non Connecté': 'Not connected',
    'Frettage Incorrect': 'Incorrect lacing', 'Serrage Incorrect': 'Incorrect tightening', 'Mauvais Cheminement': 'Incorrect routing',
    'MEO Gainage': 'Sleeving workmanship', 'Finition Inachevée': 'Incomplete finishing',
    'Défaut de Sertissage sur câble standard': 'Crimping defect, standard cable', 'Défaut de Sertissage sur câble spécifique': 'Crimping defect, special cable',
    'Erreur Fixation ou Protection': 'Wrong fastener or protection', 'Erreur Composant Électrique': 'Wrong electrical component',
    'Fixation ou Protection Manquante': 'Missing fastener or protection', 'Obturateur Manquant': 'Missing blanking plug',
    'Câble ou Élément Manquant': 'Missing cable or item', 'Identification Manquante': 'Missing identification',
    'Câble Endommagé': 'Damaged cable', 'Composant Endommagé': 'Damaged component', 'Protection Endommagée': 'Damaged protection',
    'Structure Endommagée': 'Damaged structure', 'Défaut de Métallisation': 'Bonding defect', "Défaut d'Impression": 'Printing defect',
    'Erreur Dossier': 'Documentation error'
  };
  var WHERE_FR = { 'Final inspection': 'Contrôle final', 'In-process (internal)': 'Interne', 'Cables': 'Câbles', 'Supplier': 'Fournisseur',
    'Customer return': 'Retour client', 'Design query request': 'Demande de DQN', 'Damage': 'Dommages', 'Breakage': 'Casse', 'Not recorded': 'Non renseigné',
    'TEST': 'Test', 'NC Retour client': 'Retour client', 'NC Interne': 'Interne', 'QUALITE': 'Qualité', 'NC Fournisseur': 'Fournisseur' };
  var WHERE_EN = { 'TEST': 'Test', 'In-process (internal)': 'Internal', 'NC Retour client': 'Customer return', 'NC Interne': 'Internal', 'QUALITE': 'Quality', 'NC Fournisseur': 'Supplier' };
  var RULE_FR = { 'Rework to drawing': 'Retouche', 'Exchange': 'Échange', 'Rejection': 'Rebut / rejet', 'Rejection with a rework order': 'Rejet avec ordre de retouche', 'Scrap': 'Rebut', 'Request for design change': 'Demande de DQN',
    'Accept as is': 'Accepté en l’état', 'Potential non-conformity': 'NC potentielle', 'No decision': 'Sans décision', 'Deleted NC': 'NC supprimée', 'Unknown decision code': 'Décision inconnue' };

  // Simple and Expert: the page holds both. Simple: Synthèse and Détail, a few charts; Expert: the full dashboard.
  // A switch in the header goes from one to the other
  var SIMPLE_TABS = ['syn', 'det'], EXPERT_TABS = ['ov', 'pareto', 'where', 'cnq', 'client', 'cbl', 'rca', 'pplan'];
  var h0 = ''; try { h0 = EMBED ? '' : (location.hash || '').replace('#', ''); } catch (e) {}
  var MODE = SIMPLE_TABS.indexOf(h0) >= 0 ? 'simple' : EXPERT_TABS.indexOf(h0) >= 0 ? 'expert'
    : (function () { var m = null; try { m = localStorage.getItem('fto2-dash-mode'); } catch (e) {} return m === 'expert' ? 'expert' : 'simple'; })();
  var TABS = MODE === 'simple' ? SIMPLE_TABS : EXPERT_TABS;
  var G = { lang: 'fr', minor: true, tab: TABS[0] };
  try { var s1 = localStorage.getItem('fto2-dash-lang'); if (s1 === 'fr' || s1 === 'en') G.lang = s1; } catch (e) {}
  if (TABS.indexOf(h0) >= 0) G.tab = h0;
  function tabsShow() {   // the tabs of the mode; the groups' gaps only in Expert
    document.querySelectorAll('#tabs [role="tab"]').forEach(function (b) { b.hidden = TABS.indexOf(b.getAttribute('data-tab')) < 0; });
    document.querySelectorAll('#tabs .gap').forEach(function (g) { g.hidden = MODE === 'simple'; });
  }
  tabsShow();

  function S(k, v) { var s = STR[G.lang][k]; if (s == null) return k; Object.keys(v || {}).forEach(function (x) { s = s.split('{' + x + '}').join(v[x]); }); return s; }
  function L(n) { return G.lang === 'en' && EN[n] ? EN[n] : n; }
  function loc() { return G.lang === 'fr' ? 'fr-FR' : 'en-GB'; }
  function num(n) { return Number(n).toLocaleString(loc()); }
  function eur(n) { return Math.round(n).toLocaleString(loc()) + (G.lang === 'fr' ? ' €' : ' EUR'); }
  function eurK(n) { return n >= 10000 ? (Math.round(n / 100) / 10).toLocaleString(loc()) + (G.lang === 'fr' ? ' k€' : 'k EUR') : eur(n); }
  function pct(x) { return (Math.round(x * 10) / 10).toLocaleString(loc()) + (G.lang === 'fr' ? ' %' : '%'); }
  function pct0(x) { return Math.round(x).toLocaleString(loc()) + (G.lang === 'fr' ? ' %' : '%'); }
  function day(iso, opts) { return new Date(iso + 'T12:00:00Z').toLocaleDateString(loc(), Object.assign({ timeZone: 'UTC' }, opts || { day: 'numeric', month: 'long', year: 'numeric' })); }
  function shortDay(iso) { return day(iso, { day: '2-digit', month: '2-digit', year: '2-digit' }); }
  function monthName(m) { return (G.lang === 'fr' ? MONTHS_FR : MONTHS_EN)[Number(m.slice(5, 7)) - 1]; }
  // a colour token blended with the card surface, as a plain rgb() any browser understands
  function hexRgb(x) { x = String(x || '').trim(); return /^#[0-9a-f]{6}$/i.test(x) ? [1, 3, 5].map(function (i) { return parseInt(x.slice(i, i + 2), 16); }) : null; }
  function tint(token, p) {
    var cs = getComputedStyle(document.getElementById('tabs')), a = hexRgb(cs.getPropertyValue(token)), b = hexRgb(cs.getPropertyValue('--surface'));
    if (!a || !b) return 'var(' + token + ')';
    p = Math.max(0, Math.min(100, p)) / 100;
    return 'rgb(' + [0, 1, 2].map(function (i) { return Math.round(a[i] * p + b[i] * (1 - p)); }).join(',') + ')';
  }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function tidy(s) { return String(s || '').replace(/\s*\*\s*/g, ' ').replace(/\s+([,.;:)])/g, '$1').replace(/\(\s+/g, '(').replace(/\s+/g, ' ').replace(/^[\s:–-]+/, '').trim(); }
  function whereName(w) { return G.lang === 'fr' ? (WHERE_FR[w] || w) : (WHERE_EN[w] || w); }
  function ruleName(r) { return G.lang === 'fr' ? (RULE_FR[r] || r) : r; }
  /* ===== MODEL START ===== */
  // ================================================================================================================
  // The calculations of the dashboard, with no drawing. The same code is in the page and in the three optional Slate
  // functions, so both compute the same. It reads D (the data from fto2FromTables), SET (the settings), GF (the filters) and
  // G (language, minor defects); it touches no page element.
  //
  //   1. helpers           read a defect line or an NC, group NC types, the categories
  //   2. selection         the filters: which NCs are shown (GF), the period, the responsibility ticks, a clicked value
  //   3. production        the production plan matched to the NCs of the selection: MSN built per product and month
  //   4. targets, forecast 2025 under the same filters, the target line by line, the forecast to December
  //   5. cost explanation  minutes and euros of each step of an NC, for "Expliquer le calcul"
  //   6. alarms            the bell's list (the statistics themselves are in the alarm engine, ALARM)
  //   7. results           what the Slate functions return: objectifs(), alarmes(), cout()
  //   8. requests          in a Slate function: the filters the page asks for, and the answer
  // ================================================================================================================

  // ---------------------------------------------------------------- 1. helpers
  function lineOrder(vals) { return ['A350', 'A330', 'A320', 'A400M', 'Autre'].filter(function (c) { return vals.indexOf(c) >= 0; }); }
  function dCat(r) { return r[11]; } function dRca(r) { return r[12]; } function dSub(r) { return r[13]; }
  function dMinor(r) { return r[14]; } function dCable(r) { return r[15]; } function dAlloc(r) { return r[17]; }
  function keepMinor(r) { return G.minor || !dMinor(r); }
  function dCode(r) { return r[22] || ''; }
  function dFin(r) { return r[23] || ''; }
  var NC = {}; D.ncs.forEach(function (n) { NC[n[0]] = n; });
  function isoDay(dt) { return dt.toISOString().slice(0, 10); }
  function sumA(a) { return a.reduce(function (s, v) { return s + v; }, 0); }
  var CAT_ORDER = SET.categories.map(function (c) { return c.nom; });   // config/2_categories.csv
  var ASIDE = { '__none': 1 }; SET.categories.forEach(function (c) { if (c.a_part) ASIDE[c.nom] = 1; });   // shown aside, no category colour
  var CATC = {}; SET.categories.forEach(function (c) { if (c.couleur) CATC[c.nom] = c.couleur; });   // colour 1-9 of each category (config/2_categories.csv)
  var MAIN_CATS = CAT_ORDER.filter(function (c) { return !ASIDE[c]; }).concat(['aside']);
  function catKey(c) { return ASIDE[c] ? 'aside' : c; }
  var NCTYPES = ['cab', 'fin', 'test', 'int', 'sup', 'oth'];
  function ncType(n) { var t = String(n[33] || '').toUpperCase(); return t === 'CABLES' ? 'cab' : t === 'CONTROLE FINAL' ? 'fin' : t === 'TEST' ? 'test' : /INTERNE/.test(t) ? 'int' : t === 'FOURNISSEUR' ? 'sup' : 'oth'; }
  function wGroup(w) { return w === 'Final inspection' ? 'fin' : w === 'TEST' ? 'test' : w === 'Cables' ? 'cab' : (w === 'In-process (internal)' || w === 'NC Interne') ? 'int' : 'oth'; }
  function dGroup(r) { return r === 'Rework to drawing' ? 'rw' : (r === 'Rejection' || r === 'Scrap') ? 'rej' : r === 'Exchange' ? 'exc' : 'oth'; }

  // ---------------------------------------------------------------- 2. selection
  // ---------------------------------------------------------------- global filters (bar under the title): every tab reads its NCs through them
  // every NC of the pipeline's selection counts (decided 20 Oct). [23] where it was raised: 'serie' = at FTO2, 'client' = customer return,
  // 'autre' = another plant; [39] data source: 'sky' Skywise only, 'gps' / 'test' also in that manual list
  var REP = D.ncs;
  var DMAX = D.meta.to, DMIN = REP.reduce(function (m, n) { return n[1] < m ? n[1] : m; }, DMAX);
  var LINES = lineOrder(REP.map(function (n) { return n[3]; }));
  var GF0 = { pick: null, src: 'all', org: '', fto2: true, liab: SET.defauts.liab, cost: 'fto2', phase: SET.defauts.phase, line: '', preset: SET.defauts.preset, from: '', to: '' }, GF = Object.assign({}, GF0);
  var PRESETS = ['ytd', 'm1', 'mp', 'm3', 'm6', 'm12', 'all', 'custom'];
  // the data source [39] (sky Skywise, gps the GPS register, test the Test list) and the pipeline output [41] (normal, missing_ids):
  // the ticks of one list on the page. GF.src: 'all', else the ticked sources joined by | ('man': both lists, as before 17 Nov);
  // GF.org: '' for both outputs, else the one ticked
  var SRCS = ['sky', 'gps', 'test'], ORGS = ['normal', 'missing_ids'];
  function srcOn(k) { return GF.src === 'all' || (GF.src === 'man' ? k !== 'sky' : GF.src.split('|').indexOf(k) >= 0); }
  function srcOk(n) { return srcOn(n[39]); }
  function orgOk(n) { return !GF.org || GF.org.split('|').indexOf(n[41] || 'normal') >= 0; }
  function plusDays(iso, k) { var d = new Date(iso + 'T12:00:00Z'); d.setUTCDate(d.getUTCDate() + k); return isoDay(d); }
  function minusMonths(iso, k) { var d = new Date(iso + 'T12:00:00Z'), dd = d.getUTCDate(); d.setUTCDate(1); d.setUTCMonth(d.getUTCMonth() - k); d.setUTCDate(Math.min(dd, new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 0)).getUTCDate())); return isoDay(d); }
  // presets end on the last NC of the extract; m1: the last 30 days; mp: the last full month (in November, all of October; the
  // month of the last NC itself once that NC is of its last day)
  function presetRange(p) {
    var k = { m3: 3, m6: 6, m12: 12 }[p];
    if (p === 'ytd') return [DMAX.slice(0, 4) + '-01-01', DMAX];
    if (p === 'm1') return [plusDays(DMAX, -29), DMAX];
    if (p === 'mp') { var end = plusDays(plusDays(DMAX, 1).slice(0, 8) + '01', -1) === DMAX ? DMAX : plusDays(DMAX.slice(0, 8) + '01', -1);
      return [end.slice(0, 8) + '01', end]; }
    if (k) return [plusDays(minusMonths(DMAX, k), 1), DMAX];
    return [DMIN, DMAX];
  }
  // who is liable, the three ticks of "Responsabilité": f FTO2 ([5], FTO2 in the liability), s a supplier (a code made
  // of digits only: 129 of the 133 SUPPLIER NCs of 2026), o anyone else (another Airbus site such as FFF1 or TO, other, blank)
  function liabCat(n) { if (n[5] === 1) return 'f'; var c = String(n[34] || '').replace(/[\[\]\s]/g, '').replace(/^0+/, ''); return /^\d+$/.test(c) ? 's' : 'o'; }
  var LIABS = ['f', 's', 'o'];
  // the cost of the NCs FTO2 is not liable for: 0 (FTO2's cost), or the cost of their work (REC only, "Toutes les NC", 3 Nov). The adapter
  // keeps both ([5] 0: the costs at 0, _w the cost of the work); select() puts in the ones asked for
  var COSTALL = false;
  function costed(n) { return n[5] === 1 || COSTALL; }
  function costMode() {
    var all = GF.cost === 'all' && GF.phase === 'REC'; if (all === COSTALL) return; COSTALL = all;
    D.ncs.forEach(function (n) { var w = n._w; if (n[5] === 1 || !w) return;
      [9, 10, 12, 13, 15, 17, 18, 46].forEach(function (k, j) { n[k] = all ? w[j] : 0; }); n[43] = all ? 0 : w[2]; });
    D.defects.forEach(function (r) { if (r._w != null) r[17] = all ? r._w : 0; });
  }
  function gNc(n, anyLine) {
    if (!n) return false;
    if (!srcOk(n) || !orgOk(n)) return false;
    if (GF.liab !== 'fso' && GF.liab.indexOf(liabCat(n)) < 0) return false;   // "Responsabilité" ticks (3 Nov): FTO2 only by default
    if (GF.pick && !pickNc(n)) return false;
    if (GF.phase && n[24] !== GF.phase) return false;
    if (GF.line && !anyLine && n[3] !== GF.line) return false;
    return n[1] >= GF.from && n[1] <= GF.to;
  }
  // a value clicked in a chart filters every tab: GF.pick = {k: field, v: value}. NC fields are tested on the NC; category, cause,
  // sub-category, FIN and sub-code mean "NCs with at least one such defect line" (PICK_NC, made when the pick changes)
  var PICK_DEF = { cat: function (r) { return dCat(r); }, rca: function (r) { return dRca(r); }, sub: function (r) { return dSub(r); }, fin: function (r) { return dFin(r); }, code: function (r) { return dCode(r); },
    stcat: function (r) { var n = NC[r[0]]; return ((n && n[27]) || '') + '§' + catKey(dCat(r)); }, finmsn: function (r) { var n = NC[r[0]]; return dFin(r) + '§' + ((n && n[25]) || ''); } };   // a cell: station and category, FIN and aircraft
  var PICK_NCF = { month: function (n) { return n[1].slice(0, 7); }, week: function (n) { return n[2]; }, day: function (n) { return n[1]; }, prod: function (n) { return n[26] || 'Other'; },
    pprod: function (n) { return D.eqmsn && D.eqmsn.map ? D.eqmsn.map[String(n[26] || '').toUpperCase()] || '' : ''; }, msn: function (n) { return n[25]; }, station: function (n) { return n[27]; },
    type: function (n) { return n[33]; }, ntype: function (n) { return ncType(n); }, rule: function (n) { return n[6]; }, where: function (n) { return n[8]; }, nc: function (n) { return String(n[0]); },
    hour: function (n) { return String(n[28]); }, wgrp: function (n) { return wGroup(n[8]); }, dgrp: function (n) { return dGroup(n[7]); },
    lgrp: function (n) { var g = dGroup(n[7]); return g === 'exc' ? 'oth' : g; }, open: function (n) { return n[30] ? '1' : '0'; } };
  var PICK_NC = null;
  function pickNc(n) { var p = GF.pick; if (PICK_DEF[p.k]) return !!(PICK_NC && PICK_NC[n[0]]); if (p.k === 'age') return ncAgeOver(n, +p.v); var f = PICK_NCF[p.k]; return !f || String(f(n)) === String(p.v); }
  // still open N days after creation (a click on the open-time chart): closed after more than N days, or still open and older than N days
  function ncAgeOver(n, d) { var t = n[29] != null ? n[29] : n[31]; return t != null && Math.round(t * 10) / 10 > d; }   // days to a tenth, as the chart
  function pickPrep() {
    PICK_NC = null; var p = GF.pick; if (!p || !PICK_DEF[p.k]) return;
    PICK_NC = {}; D.defects.forEach(function (r) { if (String(PICK_DEF[p.k](r)) === String(p.v)) PICK_NC[r[0]] = 1; });
  }
  function ours(n) { var p = String(n[42] || '').trim().toUpperCase(); return p === 'FTO2' || p === 'FT02'; }   // FTO2's NCs: [42] plant FTO2 / FT02 (as Type_NC_auto); on a GPS / Test list too only if at that plant
  function gScope(n) { return !GF.fto2 || ours(n); }   // FTO2 plant only: the plant column, nothing else
  // the selection: SEL follows every filter; SER = SEL's FTO2 NCs without the customer returns; CLI = the customer returns, whatever the switch (the tabs that show both apart)
  var SEL_NC = [], SER_NC = [], CLI_NC = [], SEL = {}, SER = {}, CLI = {};
  function ids(a) { var o = {}; a.forEach(function (n) { o[n[0]] = 1; }); return o; }
  function select() {
    if (GF.preset !== 'custom') { var r = presetRange(GF.preset); GF.from = r[0]; GF.to = r[1]; }
    costMode();
    SEL_NC = REP.filter(function (n) { return gNc(n) && gScope(n); });
    SER_NC = SEL_NC.filter(function (n) { return ours(n) && n[23] !== 'client'; });   // FTO2's, without the customer returns (shown apart, never counted twice)
    CLI_NC = REP.filter(function (n) { return n[23] === 'client' && gNc(n); });
    SEL = ids(SEL_NC); SER = ids(SER_NC); CLI = ids(CLI_NC);
  }
  function inSelAnyLine(r) { var n = NC[r[0]]; return gNc(n, true) && gScope(n); }
  select();

  // ---------------------------------------------------------------- 3. production
  var PR = { src: D.eqmsn ? 'real' : 'dummy', ver: D.eqmsn && D.eqmsn.wd ? 'wd' : 'std' }, PD = null, PA = null, PCOL = {};
  function pSrc() { return PR.src === 'real' && D.eqmsn ? D.eqmsn : null; }
  // the NCs of the selection matched to a product of the output table, months of the period that are not forecast. When the NCs
  // reach into the plan's forecast months (export of 7 Oct, NCs to mid-October), those months count as built up to the last NC
  // day: the month of the last NC with its planned volume × the share of its days gone (P.part), the rest of it goes to the
  // forecast. Before (20 Oct) October's NCs fell out of every per-MSN total: Localisation 930 NCs against 994 on the Overview.
  // the share of a month's working time gone at the end of a day ('AAAA-MM-JJ'): its working days so far ÷ the month's, the
  // blackout days and public holidays counting as they do in the volume (D.eqmsn.cal, config/1_calendrier_production.csv);
  // without them, its calendar days. On 14 August, 18 % of August is built, not 45 %.
  function dayShare(day) {
    var m = String(day).slice(0, 7), d = +String(day).slice(8, 10), W = D.eqmsn && D.eqmsn.cal && D.eqmsn.cal.days && D.eqmsn.cal.days[m];
    if (W && W.length) { var tot = sumA(W); if (tot > 0) return Math.min(1, sumA(W.slice(0, d)) / tot); }
    return Math.min(1, d / new Date(Date.UTC(+m.slice(0, 4), +m.slice(5, 7), 0)).getUTCDate());
  }
  function pData() {
    var E = pSrc(), real = E === D.eqmsn, P = { real: real, E: E, months: E.months, fc: E.months.indexOf(E.forecastFrom), prod: E[PR.ver] || E.std, line: E.line, ncs: [], defs: [], cli: [], miss: {}, total: 0, idx: {} };
    if (P.fc < 0) P.fc = P.months.length;
    P.part = P.months.map(function () { return 1; });
    var L = real ? P.months.indexOf(D.meta.to.slice(0, 7)) : -1;
    if (L >= P.fc) { P.part[L] = dayShare(D.meta.to); P.fc = L + 1; P.cur = L; }
    P.all = Object.keys(P.prod).sort(function (a, b) { return sumA(P.prod[b]) - sumA(P.prod[a]); });
    var cnt = {}; REP.map(function (n) { return E.map[String(n[26] || '').toUpperCase()]; }).forEach(function (p) { if (p) cnt[p] = (cnt[p] || 0) + 1; });
    PCOL = {}; P.all.slice().sort(function (a, b) { return (cnt[b] || 0) - (cnt[a] || 0) || sumA(P.prod[b]) - sumA(P.prod[a]); }).forEach(function (p, i) { PCOL[p] = i < 6 ? 'var(--c' + (i + 1) + ')' : 'var(--dim)'; });
    P.prods = P.all.filter(function (p) { return !real || !GF.line || P.line[p] === GF.line; });
    P.mask = P.months.map(function (m, i) { return i < P.fc && (!real || (m + '-31' >= GF.from && m + '-01' <= GF.to)); });
    function month(d) { var i = P.months.indexOf(d.slice(0, 7)); return i >= 0 && P.mask[i] ? i : -1; }
    if (real) {
      SEL_NC.forEach(function (n) {
        P.total++; var p = E.map[String(n[26] || '').toUpperCase()], m = month(n[1]);
        if (!p || P.prods.indexOf(p) < 0) { var lb = n[26] || '—'; P.miss[lb] = (P.miss[lb] || 0) + 1; return; }
        if (m < 0) return; P.idx[n[0]] = P.ncs.length; P.ncs.push({ id: n[0], m: m, p: p, cost: n[12], days: n[29], late: n[8] === 'Final inspection' || n[8] === 'TEST' });
      });
      D.defects.forEach(function (r) { var i = P.idx[r[0]]; if (i != null && keepMinor(r)) P.defs.push({ n: i, cat: dCat(r), rca: dRca(r), cost: dAlloc(r), cable: !!dCable(r) }); });
      CLI_NC.forEach(function (n) { var p = E.map[String(n[26] || '').toUpperCase()], m = month(n[1]); if (p && P.prods.indexOf(p) >= 0 && m >= 0) P.cli.push({ p: p, m: m }); });
    }
    return P;
  }
  function pAgg(P) {
    var z = function () { return P.months.map(function () { return 0; }); }, a = {};
    P.prods.forEach(function (p) { a[p] = { p: p, line: P.line[p] || '', eqm: P.prod[p].map(function (v, i) { return P.mask[i] ? v * P.part[i] : 0; }), nc: z(), def: z(), cost: z(), cab: z(), cli: z(), late: z(), connm: z(), conn: {}, cats: {}, catm: {}, rcas: {}, days: [] }; });
    P.ncs.forEach(function (x) { var o = a[x.p]; o.nc[x.m]++; o.cost[x.m] += x.cost; if (x.late) o.late[x.m]++; if (x.days != null) o.days.push(x.days); });
    P.defs.forEach(function (d) { var x = P.ncs[d.n], o = a[x.p]; o.def[x.m]++; if (d.cable) o.cab[x.m]++; if (d.cat === 'Erreur Branchement') { o.conn[d.rca] = (o.conn[d.rca] || 0) + 1; o.connm[x.m]++; } var c = catKey(d.cat); o.cats[c] = (o.cats[c] || 0) + 1; (o.catm[c] || (o.catm[c] = z()))[x.m]++; o.rcas[d.rca] = (o.rcas[d.rca] || 0) + 1; });
    P.cli.forEach(function (x) { a[x.p].cli[x.m]++; });
    P.prods.forEach(function (p) { var o = a[p]; o.EQ = sumA(o.eqm); o.NC = sumA(o.nc); o.DEF = sumA(o.def); o.COST = sumA(o.cost); o.CAB = sumA(o.cab); o.CLI = sumA(o.cli); o.LATE = sumA(o.late); o.r = o.EQ ? o.NC / o.EQ : null;
      o.FC = sumA(P.prod[p].slice(P.fc)) + (P.cur != null ? P.prod[p][P.cur] * (1 - P.part[P.cur]) : 0); });   // to come: the rest of the running month, then the months after
    return a;
  }
  function pOk() { return P_().filter(function (o) { return o.EQ >= EQMIN; }); }
  function P_() { return PD.prods.map(function (p) { return PA[p]; }); }

  // ---------------------------------------------------------------- 4. targets and forecast
  var V2CUT = SET.objectif_coef;   // target = 2025 rate x V2CUT (config/2_reglages_pages.csv: objectif_baisse)
  function v2Months() {
    var a = [], d = new Date(GF.from.slice(0, 7) + '-01T00:00:00Z'), end = (GF.to < D.meta.to ? GF.to : D.meta.to).slice(0, 7), fc = [];
    while (d.toISOString().slice(0, 7) <= end) { a.push(d.toISOString().slice(0, 7)); d.setUTCMonth(d.getUTCMonth() + 1); }
    if (GF.to >= D.meta.to) { var y = end.slice(0, 4); d = new Date(end + '-01T00:00:00Z'); d.setUTCMonth(d.getUTCMonth() + 1); while (d.toISOString().slice(0, 4) === y) { fc.push(d.toISOString().slice(0, 7)); d.setUTCMonth(d.getUTCMonth() + 1); } }
    return { act: a, fc: fc };
  }
  function v2Plan(m) { if (!PD) return null; var i = PD.months.indexOf(m); return i < 0 ? null : sumA(PD.prods.map(function (p) { return PD.prod[p][i] || 0; })); }
  // the forecast, the same on every chart (20 Oct): product by product, the product's value per MSN built in the period × its MSN planned
  // that month, plus the NCs out of the production plan at their own monthly pace (each month by its planned volume, v2W). A single overall pace over-
  // forecasts: A320's planned volume grows at the end of the year while A320 has few NCs per unit. null without the real production plan.
  function v2Fc(f, M) {
    var E = pSrc(); if (!PD || !PA || !E || E !== D.eqmsn) return null;
    var byP = {}, out = 0, w = v2W, K = v2OutK(M), C = K.cur;
    SEL_NC.forEach(function (n) { var v = f(n), p = v2InPlan(n); if (p) byP[p] = (byP[p] || 0) + v; else out += v; });
    var pace = K.a ? out / K.a : 0, res = {}, per = function (i, sh) { return sumA(Object.keys(byP).map(function (p) { return i < 0 ? 0 : byP[p] / PA[p].EQ * (PD.prod[p][i] || 0) * sh; })); };
    M.fc.forEach(function (m) { res[m] = per(PD.months.indexOf(m), 1) + pace * w(m); });
    if (C) res[M.fc[0]] += per(C.i, 1 - C.part) + pace * w(C.m) * (1 - C.part);   // the rest of the running month, with the first month to come
    return { m: res, out: out, outFc: pace * K.f };
  }
  // the product of the plan an NC is counted under (its product has ≥ 0.5 MSN built in the period and the NC is in the per-MSN
  // data), else null: the NC is out of the plan. One test for every total, so the rows always add up to the Overview.
  function v2InPlan(n) { var E = pSrc(), p = E && E.map && E.map[String(n[26] || '').toUpperCase()]; return p && PA && PA[p] && PA[p].EQ >= EQMIN && PD.idx[n[0]] != null ? p : null; }
  // weights of the months done (a) and to come (f) for the out-of-plan NCs, each month by its planned volume (v2W); the running month
  // (pData) counts in both, by the share of its days gone and left
  function v2OutK(M) {
    var w = v2W, C = PD && PD.cur != null && M.fc.length && M.act[M.act.length - 1] === PD.months[PD.cur] ? { m: PD.months[PD.cur], i: PD.cur, part: PD.part[PD.cur] } : null;
    var a = sumA(M.act.map(w)) - (C ? w(C.m) * (1 - C.part) : 0), f = sumA(M.fc.map(w)) + (C ? w(C.m) * (1 - C.part) : 0);
    return { a: a, f: f, k: a ? f / a : 0, cur: C };
  }
  // monthly sums of f over the selection; forecast months: v2Fc (else the period's value per planned MSN × the MSN planned that month, else the last 3 months' mean)
  function v2Series(f) {
    var M = v2Months(), by = {}; SEL_NC.forEach(function (n) { var m = n[1].slice(0, 7); by[m] = (by[m] || 0) + f(n); });
    var act = M.act.map(function (m) { return { m: m, v: by[m] || 0 }; }), pa = 0, va = 0;
    act.forEach(function (x) { var p = v2Plan(x.m); if (p) { pa += p; va += x.v; } });
    var l3 = act.slice(-3), m3 = l3.length ? sumA(l3.map(function (x) { return x.v; })) / l3.length : 0;
    var F = v2Fc(f, M), fc = M.fc.map(function (m) { var p = v2Plan(m); return { m: m, v: F ? F.m[m] : pa && p != null ? va / pa * p : m3, f: true }; });
    return { act: act, fc: fc, tot: sumA(act.map(function (x) { return x.v; })), ftot: sumA(fc.map(function (x) { return x.v; })) };
  }
  // 2025 under the same filters (plant switch, phase, line); null when there is no 2025 block, the data-source filter is on (the
  // 2025 extract is not split by manual list) or only the missing-ID NCs are shown. The 2025 extract holds no customer return.
  function y25Sel() {
    var Y = D.y25; if (!Y || !Y.rows || GF.src !== 'all' || GF.org === 'missing_ids') return null;
    var c = {}, P = GF.pick; Y.cols.forEach(function (k, i) { c[k] = i; });
    if (GF.liab !== 'fso' && c.liab == null) return null;   // the "Responsabilité" ticks: 2025 needs its liability column
    if (P && ['month', 'prod', 'pprod'].indexOf(P.k) < 0) return null;   // a pick the 2025 extract cannot follow: no 2025 comparison
    var pOk = !P ? null : P.k === 'month' ? function (r) { return String(r[c.month]).slice(5, 7) === P.v.slice(5, 7); } : P.k === 'prod' ? function (r) { return (r[c.product] || 'Other') === P.v; } :
      function (r) { return !!(D.eqmsn && D.eqmsn.map && D.eqmsn.map[String(r[c.product] || '').toUpperCase()] === P.v); };
    return Y.rows.filter(function (r) { return (r[c.scope] === 'serie' || !GF.fto2) && (GF.liab === 'fso' || GF.liab.indexOf(r[c.liab]) >= 0) && (!GF.phase || r[c.phase] === GF.phase) && (!GF.line || r[c.line] === GF.line) && (!pOk || pOk(r)); })
      .map(function (r) { return { m: r[c.month], line: r[c.line], p: r[c.product], nc: r[c.nc], def: G.minor ? r[c.def] : r[c.defMajor], cost: COSTALL && c.costAll != null ? r[c.costAll] : r[c.cost] }; });
  }
  // 2025 defects by cause (parser labels) under the same filters as y25Sel; picks on a category or a cause apply too
  function y25Rca() {
    var Y = D.y25; if (!Y || !Y.rca || GF.src !== 'all' || GF.org === 'missing_ids') return null;
    var c = {}, P = GF.pick; Y.rcaCols.forEach(function (k, i) { c[k] = i; });
    if (GF.liab !== 'fso' && c.liab == null) return null;
    if (P && ['month', 'prod', 'pprod', 'cat', 'rca'].indexOf(P.k) < 0) return null;
    var ok = !P ? null : P.k === 'month' ? function (r) { return String(r[c.month]).slice(5, 7) === P.v.slice(5, 7); } : P.k === 'prod' ? function (r) { return (r[c.product] || 'Other') === P.v; } :
      P.k === 'cat' ? function (r) { return r[c.cat] === P.v; } : P.k === 'rca' ? function (r) { return r[c.rca] === P.v; } :
      function (r) { return !!(D.eqmsn && D.eqmsn.map && D.eqmsn.map[String(r[c.product] || '').toUpperCase()] === P.v); };
    return Y.rca.filter(function (r) { return (r[c.scope] === 'serie' || !GF.fto2) && (GF.liab === 'fso' || GF.liab.indexOf(r[c.liab]) >= 0) && (!GF.phase || r[c.phase] === GF.phase) && (!GF.line || r[c.line] === GF.line) && (!ok || ok(r)); })
      .map(function (r) { return { m: r[c.month], p: r[c.product], cat: r[c.cat], rca: r[c.rca], d: G.minor ? r[c.def] : r[c.defMajor] }; });
  }
  // a 2025 rate per product delivered, on the production plan's products that had 2025 deliveries (as the line targets): f summed ÷ deliveries
  function y25Rate(rows, f, keep) {   // keep(p): only these products of the plan (connection errors: A330 and A350)
    var L = D.y25 && D.y25.prod, E = pSrc(); if (!rows || !L || !PD || E !== D.eqmsn) return null;
    var has = function (p) { return L[p] && sumA(L[p]) > 0 && PD.prods.indexOf(p) >= 0 && (!keep || keep(p)); }, del = 0, v = 0;
    PD.prods.forEach(function (p) { if (has(p)) del += sumA(L[p]); });
    rows.forEach(function (x) { var p = E.map[String(x.p || '').toUpperCase()]; if (p && has(p)) v += f(x); });
    return del > 0 ? { v: v, del: del, r: v / del } : null;
  }
  // a 2025 sum by month of the year ('01'..'12'), and its running total over the months shown (actual + forecast, 'YYYY-MM')
  function y25Cum(Y, f, months) { var by = {}, c = 0; Y.forEach(function (x) { var k = x.m.slice(5, 7); by[k] = (by[k] || 0) + f(x); }); return [0].concat(months.map(function (m) { c += by[m.slice(5, 7)] || 0; return c; })); }
  // 2025 NCs per product delivered, per line, on the products of the 2025 deliveries (Livraisons 2025) mapped as the 2026 production plan
  function y25Lines() {
    var Y = y25Sel(), L = D.y25 && D.y25.prod, E = pSrc(); if (!Y || !L || !PD || E !== D.eqmsn) return null;
    var out = {}, has = function (p) { return L[p] && sumA(L[p]) > 0 && PD.prods.indexOf(p) >= 0; };
    PD.prods.forEach(function (p) { if (!has(p)) return; var l = PD.line[p] || '—', a = out[l] || (out[l] = { nc: 0, eq: 0 }); a.eq += sumA(L[p]); });
    Y.forEach(function (x) { var p = E.map[String(x.p || '').toUpperCase()]; if (p && has(p) && out[PD.line[p] || '—']) out[PD.line[p] || '—'].nc += x.nc; });
    return out;
  }
  // the weight of a month for the NCs out of the production plan and for a monthly target with no plan line by line: its share of
  // the year's planned volume (the plan's volume counts the working days, holidays and shutdowns), over the products of the lines
  // shown, scaled so that an average month weighs 1. Without a planned volume: 1 for every month.
  function v2W(m) {
    if (!PD) return 1;
    if (!PD.w) {   // once per production data (pData)
      var vol = PD.months.map(function (x, i) { return sumA(PD.prods.map(function (p) { return (PD.prod[p] || [])[i] || 0; })); }), tot = sumA(vol);
      PD.w = vol.map(function (v) { return tot > 0 ? v / (tot / vol.length) : 1; });
    }
    var i = PD.months.indexOf(m); return i < 0 ? 1 : PD.w[i];
  }
  // the year's target line by line: each line's 2025 rate per product delivered - 25 %, times the line's 2026
  // volume month by month, summed over the lines; the NCs whose product is not in the production plan (no volume) keep their 2025
  // value - 25 %, spread over the months like a normal year. f25 / f26: the measure of a 2025 row / of a 2026 product (NCs or cost).
  // null without 2025 under the filters or without the real production plan (the charts then keep their former target).
  function v2Tgt(f25, f26) {
    var Y = y25Sel(), L = D.y25 && D.y25.prod, E = pSrc(); if (!Y || !L || !PD || !PA || E !== D.eqmsn) return null;
    var has = function (p) { return L[p] && sumA(L[p]) > 0; }, by = {}, out = 0, z = function () { return PD.months.map(function () { return 0; }); };
    // a product with no 2025 delivery (MDCD) does not take its line's 2025 rate: its target is its own 2026 pace × its planned
    // volume, with no cut; its 2025 NCs show in the 2025 bar only
    PD.prods.forEach(function (p) { var l = PD.line[p] || '—', a = by[l] || (by[l] = { l: l, v25: 0, n25o: 0, del: 0, vol: z(), own: z(), v26: 0, eq26: 0 });
      if (has(p)) { a.del += sumA(L[p]); PD.prod[p].forEach(function (v, i) { a.vol[i] += v || 0; }); a.v26 += f26(PA[p]); a.eq26 += PA[p].EQ; }
      else { var r = PA[p] && PA[p].EQ > 0 ? f26(PA[p]) / PA[p].EQ : 0; PD.prod[p].forEach(function (v, i) { a.own[i] += r * (v || 0); }); } });
    Y.forEach(function (x) { var p = E.map[String(x.p || '').toUpperCase()], a = p && has(p) && by[PD.line[p] || '—'];
      if (a) { a.v25 += f25(x); return; }
      if (p && by[PD.line[p] || '—']) { by[PD.line[p] || '—'].n25o += f25(x); return; }   // in the plan, not delivered in 2025
      out += f25(x);   // out of the plan: kept with its plane type (x25), for the bars by plane type
      var l = x.line || '—', b = by[l] || (by[l] = { l: l, v25: 0, del: 0, vol: z(), v26: 0, eq26: 0, noPlan: true }); b.x25 = (b.x25 || 0) + f25(x); });
    var lines = lineOrder(Object.keys(by)).map(function (l) { var a = by[l]; a.r25 = a.del > 0 && a.v25 > 0 ? a.v25 / a.del : null; a.x25 = a.x25 || 0; a.xT = a.x25 * V2CUT;
      a.rt = (a.r25 != null ? a.r25 : a.eq26 ? a.v26 / a.eq26 : 0) * V2CUT; a.ph = a.r25 == null && !a.noPlan && sumA(a.vol) > 0; a.own = a.own || z(); a.n25o = a.n25o || 0; a.year = a.rt * sumA(a.vol) + sumA(a.own); return a; });   // no 2025 for a line: its 2026 rate - 25 %
    var wsum = sumA(PD.months.map(v2W));
    return { lines: lines, out25: out, outT: out * V2CUT,
      tm: function (m) { var i = PD.months.indexOf(m); return sumA(lines.map(function (a) { return i < 0 ? 0 : a.rt * a.vol[i] + a.own[i]; })) + out * V2CUT * v2W(m) / wsum; },
      year: sumA(lines.map(function (a) { return a.year; })) + out * V2CUT };
  }

  // ---------------------------------------------------------------- 5. cost explanation
  var CXP = D.cnqp || null;   // the cost model's settings (config/2_cout_*.csv, 3_cout_*.csv), from the backend
  var CX_STEPS = [['alert', 'alert'], ['writing', 'write'], ['support', 'support'], ['setup', 'work'], ['hands', 'work'], ['recheck', 'recheck']];
  var CX_RF = { alert: 0, write: 1, support: 2, work: 3, recheck: 4, eng: 5, part: 6, label: 7, basis: 8 };
  function cxSteps(n) { return n[40] || [0, 0, 0, 0, 0, 0, 0, 0]; }
  // EUR per hour of a step, by who does it (production, quality, ME); one rate before 20 Oct
  function cxRate(k) { var P = CXP.p, R = P.rates || {}; return R[k] != null ? R[k] : P.rate; }
  function cxEur(st) { return CX_STEPS.reduce(function (a, s2, j) { return a + (st[j] || 0) / 60 * cxRate(s2[0]); }, 0); }
  function cxRule(n) { return CXP.rules[n[6]] || null; }
  function cxAdj(n) {   // customer return: the flat extra or the real amount, i.e. what the level-3 cost holds beyond the steps, the material and the part (0 today)
    var f = cxRule(n), st = cxSteps(n); if (!f || !costed(n)) return 0;   // not FTO2's liability: cost 0, shown as its own line
    var on = [f[0], f[1], f[2], f[3], f[3], f[4]], e = CX_STEPS.reduce(function (a, s2, j) { return a + (on[j] ? st[j] / 60 * cxRate(s2[0]) : 0); }, 0), d = n[12] - (e + n[18] + n[17] + (n[46] || 0));
    return Math.abs(d) >= 0.05 ? d : 0;
  }
  function cxLines(nc) { return D.defects.filter(function (r) { return r[0] === nc; }).sort(function (a, b2) { return a[1] - b2[1]; }); }
  // minutes and material of one defect line, from its class (root-cause labelling, the one behind the figures); seen counts the
  // connection errors met so far in the NC: only the first takes its class time, each following one P.connNext
  function cxLine(r, seen) {
    var P = CXP.p, c = CXP.cls[dSub(r)], q = CXP.qty[r[0] + '|' + r[1]] || 1, per = c ? c[0] : P.defDefault, m = per * q;
    if (seen && P.connCls && P.connCls.indexOf(dSub(r)) >= 0) { var first = Math.max(0, Math.min(q, 1 - seen.n)); seen.n += q; m = per * first + P.connNext * (q - first); }
    return { m: m, a: (c ? c[1] : 0) * q, cls: dSub(r) && G.lang === 'en' && c ? c[2] : (dSub(r) || '—') };
  }
  function cxFactor(n) { var P = CXP.p, t = String(n[33] || '').toUpperCase(); return (P.intTypes || []).some(function (x) { return String(x).toUpperCase() === t; }) ? (P.intFactor || 1) : 1; }

  // ---------------------------------------------------------------- 6. alarms
  var ALC = { sigK: '', res: null, first: 0, last: -1 };   // the last computation: its key, the alarms, the weeks it covers
  // a sub-code that only says the defect has none yet: "T04 (non précisé)" (a new line not yet labelled by the AI pass), "Non codé".
  // New lines all land there until they are labelled, which looks like a rise: no alarm on them (3 Nov)
  var PLACEHOLDER = new RegExp(window.FTO2_PLACEHOLDER);   // sub-codes "not specified": no alarm on them (config/2_reglages_pages.csv)
  function alNc(n) { return ours(n) && n[23] !== 'client' && (!GF.phase || n[24] === GF.phase) && srcOk(n) && orgOk(n) && (GF.liab === 'fso' || GF.liab.indexOf(liabCat(n)) >= 0); }
  function alCompute(at) {   // at: a week index instead of the period's end (checks)
    var E = D.eqmsn && D.eqmsn.wdw; if (!E) return null;
    var last = at != null ? at : ALARM.lastDone(GF.to < D.meta.to ? GF.to : D.meta.to), k = [GF.phase, GF.src, GF.org, GF.liab, last, G.lang].join('|');
    if (k === ALC.sigK) return ALC.res;
    var items = {}, planes = {}, cnt = { rca: {}, code: {} }, z = function () { var a = []; for (var i = 0; i < 53; i++) a.push(0); return a; }, w0 = 53, PM = D.eqmsn.msn || {};
    function it(line, lv, v, e, hist) { var key = line + '|' + lv + '|' + v; return items[key] || (items[key] = { key: key, line: line, lv: lv, v: v, w: z(), e: e, n: [], d: [], hist: !!hist }); }
    function add(o, i, id, dk) { o.w[i]++; (o.n[i] || (o.n[i] = [])).push(id); if (dk) (o.d[i] || (o.d[i] = [])).push(dk); if (i < w0) w0 = i; }
    function tally(m, k2, v) { var q = m[k2] || (m[k2] = {}); q[v] = (q[v] || 0) + 1; }
    D.defects.forEach(function (r) {
      var n = NC[r[0]]; if (!n || !alNc(n)) return;
      var l = n[3], e = E.line[l], i = ALARM.week(n[1]), dk = r[0] + '|' + r[1]; if (!e || i < 0) return;
      var c = dCat(r), ca = dRca(r), co = dCode(r);
      add(it(l, 'all', '', e), i, n[0], dk);
      if (c) add(it(l, 'cat', c, e), i, n[0], dk);
      if (ca) { add(it(l, 'rca', ca, e), i, n[0], dk); tally(cnt.rca, l + '|' + ca, c); }
      if (co && !PLACEHOLDER.test(co)) { add(it(l, 'code', co, e), i, n[0], dk); tally(cnt.code, l + '|' + co, ca); }   // no alarm on a placeholder sub-code (3 Nov)
      if (n[27]) add(it(l, 'station', n[27], e, true), i, n[0], dk);
      if (n[8]) add(it(l, 'where', n[8], e, true), i, n[0], dk);
    });
    D.ncs.forEach(function (n) {   // products: NCs per MSN of the product; aircraft: NCs per aircraft and product
      if (!alNc(n) || !E.prod || !D.eqmsn.map) return;
      var p = D.eqmsn.map[String(n[26] || '').toUpperCase()], i = ALARM.week(n[1]); if (!p || i < 0) return;
      if (E.prod[p]) add(it(n[3], 'prod', p, E.prod[p]), i, n[0]);
      var m = String(n[25] || ''), pm = PM[n[3] + '|' + m.replace(/^0+/, '')]; if (!m || !pm) return;
      var pk2 = n[3] + '|' + m + '|' + p, o = planes[pk2], end = ALARM.week(pm[1]);
      if (!o) o = planes[pk2] = { key: pk2, line: n[3], msn: m, prod: p, w: z(), n: [], end: end < 0 ? 99 : end };
      o.w[i]++; (o.n[i] || (o.n[i] = [])).push(n[0]);
    });
    (D.cables || []).forEach(function (a) {   // cable requests per MSN of the line
      var l = a[4] === 'A321' ? 'A320' : a[4], e = E.line[l], i = ALARM.week(a[2]); if (!e || i < 0) return;
      add(it(l, 'cimp', a[7], e), i, a[3]); add(it(l, 'cmot', a[6], e), i, a[3]);
    });
    // the actions in progress (MFT trackers): the NCs of their problem, to say that one already covers an alarm
    var AF = { cat: dCat, rca: dRca, sub: dSub, code: dCode }, acts = (D.actions || []).filter(function (a) { return a[6] && !/CLOS|TERMIN|ABANDON/i.test(a[7] || ''); }).map(function (a) {
      var vals = {}, o = { line: a[0], title: a[G.lang === 'fr' ? 1 : 2], start: ALARM.week(a[6] + '-01'), defs: {} };
      (a[4] || []).forEach(function (v) { vals[v] = 1; });
      D.defects.forEach(function (r) { var n = NC[r[0]]; if (!n || n[3] !== a[0] || !alNc(n)) return; var v = a[3] === 'where' ? n[8] : AF[a[3]] ? AF[a[3]](r) : null; if (v != null && vals[v]) o.defs[r[0] + '|' + r[1]] = 1; });
      return o;
    });
    var dom = function (m) { m = m || {}; return Object.keys(m).sort(function (a, b) { return m[b] - m[a]; })[0] || ''; };
    var first = w0 + ALARM.P.recent + ALARM.P.base - 1;
    ALC.first = first; ALC.last = last; ALC.sigK = k;
    ALC.res = last < first ? [] : ALARM.run(Object.keys(items).map(function (x) { return items[x]; }), first, last, function (a) {
      return a.lv === 'cat' ? a.line + '|all|' : a.lv === 'rca' ? a.line + '|cat|' + dom(cnt.rca[a.line + '|' + a.v]) : a.lv === 'code' ? a.line + '|rca|' + dom(cnt.code[a.line + '|' + a.v]) : ''; },
      Object.keys(planes).map(function (x) { return planes[x]; }), acts);
    return ALC.res;
  }

  // ---------------------------------------------------------------- 7. results (what the Slate functions return)
  // Each result is plain data (no function inside), so that a Slate function can hand it to the page. The page computes the
  // same results itself when no Slate function is used.

  // the measures the targets are computed for: [value of a 2026 NC, value of a 2025 row, value of a 2026 product]
  var MEASURES = {
    nc: [function () { return 1; }, function (x) { return x.nc; }, function (o) { return o.NC; }],
    cost: [function (n) { return n[12]; }, function (x) { return x.cost; }, function (o) { return o.COST; }]
  };
  // the targets and the forecast for the current filters: per measure, the months (done and to come) and the target line by line
  function objectifs() {
    var out = { months: v2Months() }, all = out.months.act.concat(out.months.fc);
    Object.keys(MEASURES).forEach(function (k) {
      var m = MEASURES[k], S2 = v2Series(m[0]), T = v2Tgt(m[1], m[2]);
      if (T) {   // the target of each month as a table: tm(m) is a function, which a Slate function cannot hand over
        var tmm = {}; all.concat(PD ? PD.months : []).forEach(function (mm) { tmm[mm] = T.tm(mm); });
        T = { lines: T.lines, out25: T.out25, outT: T.outT, year: T.year, tmm: tmm };
      }
      out[k] = { S2: S2, T: T };
    });
    out.lines = lineTargets();
    out.outK = PD ? v2OutK(out.months).k : 0;   // the NCs out of the production plan: months to come against months done
    return out;
  }
  // each line's NCs per MSN against its target: 2026 rate (v), 2025 rate (b), target (t = b x V2CUT, or v x V2CUT as a placeholder (ph)
  // when the line has no 2025); lines with less than EQMIN MSN built are left out
  function lineTargets() {
    if (!PD || !PA) return null;
    var by = {}; P_().forEach(function (o) { var l = o.line || '—', a = by[l] || (by[l] = { l: l, nc: 0, eq: 0 }); a.nc += o.NC; a.eq += o.EQ; });
    var B = y25Lines();
    return lineOrder(Object.keys(by)).map(function (l) { return by[l]; }).filter(function (a) { return a.eq >= EQMIN; }).map(function (r) {
      var b = B && B[r.l]; r.v = r.nc / r.eq;
      if (b && b.eq >= EQMIN && b.nc > 0) { r.b = b.nc / b.eq; r.t = r.b * V2CUT; } else { r.t = r.v * V2CUT; r.ph = true; }
      return r;
    });
  }
  // the bell's list for the current filters: the alarms and the weeks they cover
  function alarmes() { var res = alCompute(); return { res: res, first: ALC.first, last: ALC.last }; }
  // "Expliquer le calcul" for one NC: euros of each step, work factor, adjustment (customer return: what the cost holds beyond the
  // steps; for the current cost mode) and each defect line [seq, minutes, material EUR, class in French, class in English]
  function coutNc(n, lines) {   // lines: the NC's defect lines in order (cxLines), when already at hand
    var st = cxSteps(n), seen = { n: 0 };
    return { eur: CX_STEPS.map(function (s2, j) { return (st[j] || 0) / 60 * cxRate(s2[0]); }), factor: cxFactor(n), adj: cxAdj(n),
      lines: (lines || cxLines(n[0])).map(function (r) { var c = cxLine(r, seen), sub = dSub(r), k = CXP.cls[sub]; return [r[1], c.m, c.a, sub || '—', sub && k ? k[2] : sub || '—']; }) };
  }
  // every NC, for the Slate function: the adjustment for FTO2's cost (adj) and for the cost of every NC (adjAll: REC phase, "Toutes les NC")
  function cout() {
    if (!CXP) return null;
    var out = {}, keep = [GF.cost, GF.phase], by = {};
    D.defects.forEach(function (r) { (by[r[0]] || (by[r[0]] = [])).push(r); });   // each NC's lines, in the order of cxLines
    D.ncs.forEach(function (n) { out[n[0]] = coutNc(n, (by[n[0]] || []).sort(function (a, b2) { return a[1] - b2[1]; })); });
    GF.cost = 'all'; GF.phase = 'REC'; costMode();   // only the adjustment changes with the cost mode
    D.ncs.forEach(function (n) { out[n[0]].adjAll = cxAdj(n); });
    GF.cost = keep[0]; GF.phase = keep[1]; costMode();
    return out;
  }

  // ---------------------------------------------------------------- 8. in a Slate function: the filters the page asks for
  // The page sends a list of requests through the Slate variable v_fto2_filtres: {n: calculation, k: its key, f: the filters,
  // with f.coef the target's cut the page uses}.
  // Each function computes the requests for its own calculation, for each set of filters, and answers {results: {key: result}}.
  function appliquer(f) {   // put the page's filters in place, then the selection and the production that follow from them
    var g = f.gf || {}; Object.keys(g).forEach(function (k) { GF[k] = g[k]; }); GF.preset = 'custom';
    G.minor = f.minor !== false; G.lang = f.lang === 'en' ? 'en' : 'fr';
    if (typeof f.coef === 'number' && f.coef >= 0 && f.coef <= 1) V2CUT = f.coef;   // the page's target cut (it may come from the Fusion sheet)
    if (f.pr) { PR.src = f.pr[0]; PR.ver = f.pr[1]; }
    pickPrep(); select(); PD = pSrc() ? pData() : null; PA = PD ? pAgg(PD) : null;
  }
  function repondre(name, requests) {
    var run = { objectifs: objectifs, alarmes: alarmes }[name], out = {};
    (requests || []).forEach(function (q) { if (q && q.n === name && !(q.k in out)) { appliquer(q.f || {}); out[q.k] = run(); } });
    return { results: out };
  }
  /* ===== MODEL END ===== */

  // ---------------------------------------------------------------- the calculations: here, or in Slate
  // The targets and forecast (objectifs), the bell's alarms (alarmes) and the cost explanation (cout) come from the code just
  // above (MODEL). Each can also run as a Slate function instead: the page asks Slate for the filters of each chart that needs it, the chart says "Calcul dans Slate…" meanwhile,
  // and the page draws again when the answer comes. Without the functions the page computes
  // them itself, as it does when a function fails or gives no answer within 15 s. The cost explanation can also come from the
  // notebook's table fto2_dash_cout (D.cx).
  var SL = window.FTO2_SLATE || null;   // set by the Skywise glue: {use: {name: true}, ask(requests), show(waiting, failed), latest}
  var CALC = { res: { objectifs: {}, alarmes: {}, cout: {} }, wait: {}, down: {}, timer: null, live: false };   // live: the page has drawn once
  var CALC_KEY = {   // what a result depends on: one answer per value
    objectifs: function () { return JSON.stringify([GF.from, GF.to, GF.src, GF.org, GF.fto2, GF.liab, GF.cost, GF.phase, GF.line, GF.pick, G.minor, PR.src, PR.ver]); },
    alarmes: function () { return JSON.stringify([GF.phase, GF.src, GF.org, GF.liab, GF.to < D.meta.to ? GF.to : D.meta.to, G.lang]); },
    cout: function () { return 'all'; }   // every NC at once, whatever the filters
  };
  function inSlate(name) { return !!(SL && SL.use && SL.use[name] && !CALC.down[name]); }
  // a result computed in Slate for the current filters; null while Slate computes it (the page asks for it)
  function calcSlate(name) {
    var k = CALC_KEY[name](), c = CALC.res[name];
    if (Object.prototype.hasOwnProperty.call(c, k)) return c[k];
    if (!CALC.wait[name + k]) {   // coef: the target's cut this page uses (it may come from the Fusion sheet), so that Slate uses the same
      CALC.wait[name + k] = { n: name, k: k, at: Date.now(), f: { gf: { from: GF.from, to: GF.to, src: GF.src, org: GF.org, fto2: GF.fto2, liab: GF.liab, cost: GF.cost, phase: GF.phase, line: GF.line, pick: GF.pick }, minor: G.minor, lang: G.lang, pr: [PR.src, PR.ver], coef: V2CUT } };
      calcSend();
    }
    return null;
  }
  // once per round of drawing: the requests still waiting go to Slate (the cost explanation is computed once, with no request)
  function calcSend() {
    if (CALC.timer) return;
    CALC.timer = setTimeout(function () {
      CALC.timer = null;
      var all = Object.keys(CALC.wait).map(function (x) { return CALC.wait[x]; }), ask = all.filter(function (w) { return w.n !== 'cout'; }).slice(-8);
      calcShow();
      if (ask.length) try { SL.ask(ask.map(function (w) { return { n: w.n, k: w.k, f: w.f }; })); } catch (e) { calcDown(ask[0].n, (e && e.message) || String(e)); return; }
      setTimeout(calcLate, 15000);
    }, 0);
  }
  function calcLate() { var now = Date.now(), late = {}; Object.keys(CALC.wait).forEach(function (x) { if (now - CALC.wait[x].at >= 14900) late[CALC.wait[x].n] = 1; }); Object.keys(late).forEach(function (n) { calcDown(n, 'late'); }); }
  // a function that failed or did not answer: computed here from now on (until the page is opened again), with a note
  function calcDown(name, why) {
    CALC.down[name] = why || 'error';
    Object.keys(CALC.wait).forEach(function (x) { if (CALC.wait[x].n === name) delete CALC.wait[x]; });
    calcShow(); if (CALC.live) renderAll();
  }
  function calcShow() {
    if (!SL || !SL.show) return;
    var w = {}; Object.keys(CALC.wait).forEach(function (x) { w[CALC.wait[x].n] = 1; });
    SL.show(Object.keys(w), CALC.down);
  }
  // an answer of a Slate function, handed over by the Skywise glue: {results: {key: result}} or {error: text}
  function calcTake(name, v) {
    if (!v || !CALC.res[name]) return;
    if (v.error) { calcDown(name, v.error); return; }
    var got = 0;
    Object.keys(v.results || {}).forEach(function (k) { CALC.res[name][k] = v.results[k]; if (CALC.wait[name + k]) { delete CALC.wait[name + k]; got++; } });
    if (got) { calcShow(); if (CALC.live) renderAll(); }
  }
  // the targets and forecast of one measure ('nc' or 'cost'): S2 the months done and to come, T the target line by line
  // (T.tm(m): the target of month m); null while Slate computes them
  function objectif(k) {
    var m = MEASURES[k];
    if (!inSlate('objectifs')) return { S2: v2Series(m[0]), T: v2Tgt(m[1], m[2]) };
    var o = calcSlate('objectifs'); if (!o) return null;
    var T = o[k].T; if (T && !T.tm) T.tm = function (mm) { return T.tmm[mm] || 0; };
    return { S2: o[k].S2, T: T };
  }
  // each line's NCs per MSN against its target (lineTargets in model.js); null while Slate computes them
  function lignes() { if (!inSlate('objectifs')) return lineTargets() || []; var o = calcSlate('objectifs'); return o ? o.lines || [] : null; }
  // the NCs out of the production plan: months to come against months done (v2OutK in model.js); null while Slate computes it
  function horsPlanK() { if (!inSlate('objectifs')) return v2OutK(v2Months()).k; var o = calcSlate('objectifs'); return o ? o.outK : null; }
  // the bell's list: {res, first, last}; null while Slate computes it
  function alarmesNow() { return inSlate('alarmes') ? calcSlate('alarmes') : alarmes(); }
  // the cost explanation of one NC (coutNc in model.js): from the Slate function, the notebook's table, else worked out here;
  // null while Slate computes it
  function cxOf(n) {
    var c = null;
    if (inSlate('cout')) { var all = calcSlate('cout'); if (!all) return null; c = all[n[0]]; }
    else if (D.cx) c = D.cx[n[0]];
    if (!c) return coutNc(n);
    return COSTALL && c.adjAll != null ? Object.assign({}, c, { adj: c.adjAll }) : c;
  }
  function cxAdjOf(n) { if (!inSlate('cout') && !D.cx) return cxAdj(n); var c = cxOf(n); return c ? c.adj : 0; }
  // for the Skywise glue: take() hands over an answer, waiting() says how many answers the page still waits for
  if (SL) { SL.take = calcTake; SL.waiting = function () { return Object.keys(CALC.wait).length; }; Object.keys(SL.latest || {}).forEach(function (k) { calcTake(k, SL.latest[k]); }); }
  function phaseOrder(v) { return ['SERIE', 'REC', 'FTI'].filter(function (c) { return v.indexOf(c) >= 0; }).concat(v.filter(function (c) { return ['SERIE', 'REC', 'FTI'].indexOf(c) < 0; })); }
  function catOrder(vals) { return CAT_ORDER.filter(function (c) { return vals.indexOf(c) >= 0; }); }
  function codeDesc(c) { var x = D.codes[c]; return x ? x[G.lang === 'fr' ? 1 : 0] : ''; }
  function codeName(c) { var x = codeDesc(c); return x ? c + ' · ' + x : c; }

  function pk(k, v) { return v == null || v === '' ? '' : ' data-pick="' + esc(k + '|' + v) + '"'; }
  function ppk(k, v) { return D.eqmsn && pSrc() === D.eqmsn ? pk(k, v) : ''; }   // NC-rate charts: only on the real production plan
  function pickLabel(p) {
    var v = p.k === 'month' ? monthName(p.v) + ' ' + p.v.slice(0, 4) : p.k === 'day' ? shortDay(p.v) : p.k === 'cat' ? L(p.v) : p.k === 'prod' ? prodName(p.v) : p.k === 'ntype' ? S('ty_' + p.v) : p.k === 'rule' ? ruleName(p.v) : p.k === 'where' ? whereName(p.v) : p.k === 'wgrp' ? S('w_' + p.v) : p.k === 'dgrp' ? S('d_' + p.v) : p.k === 'lgrp' ? S('g_' + p.v) : p.k === 'open' ? S('pkOpenV') : p.k === 'stcat' ? p.v.split('§')[0] + ' · ' + catLabel(p.v.split('§')[1]) : p.k === 'finmsn' ? p.v.split('§')[0] + ' · MSN ' + p.v.split('§')[1] : p.k === 'age' ? S('pkAgeV', { n: num(+p.v) }) : p.v;
    return S('pk_' + p.k) + ' : ' + v;
  }
  function pickSet(k, v) {
    if (k === 'line') { setGF({ line: GF.line === v ? '' : v }); return; }   // the line has its own filter
    var same = GF.pick && GF.pick.k === k && String(GF.pick.v) === String(v);
    var keep = k === 'msn' && !same && A.msn && A.msn.slice(A.msn.indexOf('|') + 1) === String(v) ? A.msn : null;   // the MSN chart keeps that MSN's NC list open
    GF.pick = same ? null : { k: k, v: v }; pickPrep(); hideTip(); setGF({});
    if (keep) { A.msn = keep; rvDraw('A:msn'); }
  }
  document.addEventListener('click', function (e) {   // the open-time chart: a click at day N keeps the NCs still open after N days
    if (!(e.target.getAttribute && e.target.getAttribute('data-km')) || !A.km) return;
    var kb = e.target.ownerSVGElement.getBoundingClientRect(), d = Math.round(Math.max(0, Math.min(1, (e.clientX - kb.left - A.km.ml) / A.km.pw)) * A.km.XM);
    if (d > 0) pickSet('age', String(d));
  });
  document.addEventListener('click', function (e) {
    var el = e.target.closest && e.target.closest('[data-pick]'); if (!el) return;
    var s2 = el.getAttribute('data-pick'), i = s2.indexOf('|'); pickSet(s2.slice(0, i), s2.slice(i + 1));
  });

  // ---------------------------------------------------------------- weeks
  function isoMonday(wk) { var y = +wk.slice(0, 4), w = +wk.slice(6), j4 = new Date(Date.UTC(y, 0, 4)), dow = (j4.getUTCDay() + 6) % 7, mon = new Date(j4); mon.setUTCDate(j4.getUTCDate() - dow + (w - 1) * 7); return mon; }
  function isoWeekOf(dt) { var th = new Date(dt); th.setUTCDate(th.getUTCDate() + 3); var y = th.getUTCFullYear(), j4 = new Date(Date.UTC(y, 0, 4)), dow = (j4.getUTCDay() + 6) % 7, m1 = new Date(j4); m1.setUTCDate(j4.getUTCDate() - dow); return y + '-W' + String(Math.floor((dt - m1) / 604800000) + 1).padStart(2, '0'); }
  var WEEKS = (function () {
    var ws = REP.filter(ours).map(function (n) { return n[2]; }).filter(function (w) { return w >= D.meta.from.slice(0, 4); }).sort(), out = [];
    if (!ws.length) return out;
    var cur = isoMonday(ws[0]), last = isoMonday(ws[ws.length - 1]);
    while (cur <= last) { out.push(isoWeekOf(new Date(cur))); cur.setUTCDate(cur.getUTCDate() + 7); }
    return out;
  })();
  function weekEnd(wk) { var d = isoMonday(wk); d.setUTCDate(d.getUTCDate() + 6); return isoDay(d); }
  function isPartial(wk) { return weekEnd(wk) > D.meta.to; }
  function weekLong(wk) { return (G.lang === 'fr' ? 'Semaine ' : 'Week ') + +wk.slice(6) + ' · ' + wk.slice(0, 4); }

  // ---------------------------------------------------------------- generic board: breakdown cards that filter each other + a table
  function Board(o) {
    var b = { o: o, f: {}, q: '', limit: 100, open: {} };
    var grid = document.getElementById(o.grid), fold = o.fold ? document.getElementById(o.fold) : null;
    o.dims.forEach(function (d) {
      // one band per breakdown: name, reading guide and legend on the left, the chart on the right; o.mag: cards in a grid, only the d.wide ones across
      var c = document.createElement('div'); c.className = 'card' + (!o.mag || d.wide || d.fold ? ' wide' : ''); c.setAttribute('data-card', d.k);
      c.innerHTML = '<div class="bhead">' + (o.kicker ? '<span class="kicker" data-t="' + o.kicker + '"></span>' : '') +
        '<div class="card-head"><h3 data-t="' + d.t + '"></h3><button type="button" class="clear-one" data-dim="' + d.k + '" hidden></button></div>' +
        (d.sub ? '<p class="sub" data-t="' + d.sub + '"></p>' : '') + (d.split && !d.nokey ? '<div class="key" data-key="1"></div>' : '') + ((d.stack || d.catKey) && !(d.fold && !d.wide) ? '<div class="key" data-ckey="1"></div>' : '') + '</div>' +
        (d.cols ? '<div class="cols-wrap"><div class="cols" id="' + o.grid + '-' + d.k + '"></div></div>' : d.custom ? '<div class="custom" id="' + o.grid + '-' + d.k + '"></div>' :
          '<div class="bars' + (d.pareto ? ' pareto' : '') + (d.longName ? ' longname' : '') + (o.money ? ' money' : '') + (o.extras ? ' x' + o.extras.length : '') + '" id="' + o.grid + '-' + d.k + '"></div>');
      (d.fold && fold ? fold : grid).appendChild(c);
    });
    var onPick = function (e) {
      var cl = e.target.closest('.clear-one'); if (cl) { delete b.f[cl.getAttribute('data-dim')]; b.limit = 100; b.render(); return; }
      var x = e.target.closest('[data-v]'); if (!x) return;
      var k = x.getAttribute('data-dim'), v = x.getAttribute('data-v');
      if (b.f[k] === v) delete b.f[k]; else b.f[k] = v;
      b.limit = 100; b.render();
    };
    grid.addEventListener('click', onPick); if (fold) fold.addEventListener('click', onPick);
    b.watch = function (el) { el.addEventListener('click', onPick); };   // a card moved out of the board keeps its click filter
    var chips = document.getElementById(o.chips);
    chips.addEventListener('click', function (e) {
      if (e.target.closest('.reset')) { b.f = {}; b.limit = 100; b.render(); return; }
      var c = e.target.closest('[data-k]'); if (c) { delete b.f[c.getAttribute('data-k')]; b.limit = 100; b.render(); }
    });
    var q = document.getElementById(o.search), qt;
    q.addEventListener('input', function () { clearTimeout(qt); qt = setTimeout(function () { b.q = q.value.trim().toLowerCase(); b.limit = 100; b.render(); }, 120); });
    document.getElementById(o.more).addEventListener('click', function () { b.limit += 200; b.renderTable(); });
    if (o.expand) {
      var tb0 = document.getElementById(o.tbody);
      var tog = function (tr) { var k = tr.getAttribute('data-key'); if (b.open[k]) delete b.open[k]; else b.open[k] = 1; b.renderTable(); var a = tb0.querySelector('[data-key="' + k + '"]'); if (a) a.focus(); };
      tb0.addEventListener('click', function (e) { var tr = e.target.closest('tr.open-row'); if (tr) tog(tr); });
      tb0.addEventListener('keydown', function (e) { var tr = e.target.closest('tr.open-row'); if (tr && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); tog(tr); } });
    }
    var DIM = {}; o.dims.forEach(function (d) { DIM[d.k] = d; });
    b.base = function () { return o.rows(); };
    b.match = function (r, except) {
      for (var k in b.f) { if (k !== except && String(DIM[k].get(r)) !== b.f[k]) return false; }
      if (b.q) { var h = o.text(r).toLowerCase(); if (!b.q.split(/\s+/).every(function (w) { return h.indexOf(w) >= 0; })) return false; }
      return true;
    };
    b.filtered = function (except) { return b.base().filter(function (r) { return b.match(r, except); }); };
    function measure(r) { return o.measure ? o.measure(r) : 1; }
    function fmt(n) { return o.money ? eurK(n) : num(n); }
    b.renderDim = function (d) {
      var all = b.base(), rs = b.filtered(d.k), m = {}, base = {}, sp = d.split && (!d.splitIf || d.splitIf()) ? d.split : null;   // splitIf: the shading can be switched off
      all.forEach(function (r) { var v = d.get(r); if (v != null && v !== '') base[v] = 1; });
      var m2 = {}, ex = (o.extras || []).map(function () { return {}; }), stk = !sp && d.stack ? d.stack : null, m3 = {};   // stack: the bar cut by defect category (off with the cable shading)
      rs.forEach(function (r) { var v = d.get(r); if (v != null && v !== '') { m[v] = (m[v] || 0) + measure(r); if (sp && sp(r)) m2[v] = (m2[v] || 0) + measure(r);
        if (stk) { var sk = stk(r), q = m3[v] || (m3[v] = {}); q[sk] = (q[sk] || 0) + measure(r); }
        (o.extras || []).forEach(function (x, i) { ex[i][v] = (ex[i][v] || 0) + x.f(r); }); } });
      var vals = Object.keys(base);
      vals = d.order ? d.order(vals) : vals.sort(function (x, y) { return (m[y] || 0) - (m[x] || 0) || (x < y ? -1 : 1); });
      if (d.pareto) { var main = vals.filter(function (v) { return !ASIDE[v]; }).sort(function (x, y) { return (m[y] || 0) - (m[x] || 0); }), side = vals.filter(function (v) { return ASIDE[v]; }); vals = main.concat(side); }
      if (d.top) vals = vals.slice(0, d.top);
      var ref = d.ref ? d.ref() : null;
      var max = Math.max.apply(null, vals.map(function (v) { return Math.max(m[v] || 0, ref ? ref[v] || 0 : 0); }).concat([1e-9]));
      var el = document.getElementById(o.grid + '-' + d.k), act = d.k in b.f, card = el.closest('.card');
      el.classList.toggle('active', act);
      var keyEl = card.querySelector('[data-key]');
      var kk = d.keys || ['keyOther', 'keyCable'], sc = d.splitCls ? ' ' + d.splitCls : '';
      if (keyEl) keyEl.hidden = !sp;
      if (keyEl) keyEl.innerHTML = '<span><i></i>' + esc(S(kk[0])) + '</span><span><i class="c' + sc + '"></i>' + esc(S(kk[1])) + '</span>';
      var ckEl = card.querySelector('[data-ckey]');   // the categories in the colours of the bars
      if (ckEl) { var cin = {}; vals.forEach(function (v) { var c = stk ? Object.keys(m3[v] || {}) : [d.catKey(v)]; c.forEach(function (x) { cin[x] = 1; }); });
        ckEl.hidden = !!sp; ckEl.innerHTML = MAIN_CATS.filter(function (c) { return cin[c]; }).map(function (c) { return '<span><i style="background:' + catFill(c) + '"></i>' + esc(catLabel(c)) + '</span>'; }).join(''); }
      if (!vals.length) { el.innerHTML = '<p class="empty">—</p>'; }
      else if (d.custom) { el.innerHTML = d.custom(vals, m, rs, b, el); }
      else if (d.cols) {
        el.innerHTML = vals.map(function (v) {
          var n = m[v] || 0, on = b.f[d.k] === v, lab = esc(d.show(v));
          return '<button type="button" class="col" data-dim="' + d.k + '" data-v="' + esc(v) + '" aria-pressed="' + on + '" aria-label="' + lab + ': ' + fmt(n) + '"><span class="v">' + (o.money ? '' : fmt(n)) + '</span><span class="stick" style="height:' + (n / max * 100) + '%"></span><span class="m">' + lab + '</span></button>';
        }).join('');
      } else {
        var totMain = 0; if (d.pareto) vals.forEach(function (v) { if (!ASIDE[v]) totMain += m[v] || 0; });
        var cum = 0, sepDone = false;
        var hd = o.extras ? '<div class="barhead" aria-hidden="true"><span></span><span></span><span>' + esc(S(o.valueHead || 'hCost')) + '</span>' + o.extras.map(function (x) { return '<span>' + esc(S(x.t)) + '</span>'; }).join('') + (d.pareto ? '<span class="cumh">' + esc(S('hCum')) + '</span>' : '') + '</div>' : '';
        el.innerHTML = hd + vals.map(function (v) {
          var n = m[v] || 0, on = b.f[d.k] === v, lab = esc(d.show(v)), aside = d.pareto && ASIDE[v], head = '';
          if (aside && !sepDone) { sepDone = true; head = '<div class="sep">' + esc(S('aside')) + '</div>'; }
          if (d.pareto && !aside) cum += n;
          var tick = ref && ref[v] != null ? '<span class="tick" style="left:calc(' + (ref[v] / max * 100) + '% - 1px)"></span>' : '';
          var c2 = sp ? m2[v] || 0 : 0, cab = c2 && n ? '<span class="cab' + sc + '" style="width:' + (c2 / n * 100) + '%"></span>' : '';
          var tip = sp ? lab + ' : ' + S(d.splitTip || 'ofWhichCable', { n: fmt(n), c: fmt(c2) }) : lab;
          return head + '<button type="button" class="bar' + (n ? '' : ' zero') + (aside ? ' aside' : '') + '" data-dim="' + d.k + '" data-v="' + esc(v) + '" aria-pressed="' + on + '" title="' + tip + '" aria-label="' + tip + '">' +
            '<span class="name">' + lab + '</span><span class="track"><span class="fill' + (stk ? ' stk' : '') + '" style="width:' + (n / max * 100) + '%' + (d.color && !sp ? ';--bc:' + d.color(v) : '') + '">' + cab +
            (stk && n ? MAIN_CATS.filter(function (c) { return m3[v] && m3[v][c]; }).map(function (c) { return '<span class="sg" style="width:' + (m3[v][c] / n * 100) + '%;background:' + catFill(c) + '" title="' + esc(lab + ' · ' + catLabel(c) + ' : ' + fmt(m3[v][c])) + '"></span>'; }).join('') : '') +
            '</span>' + tick + '</span><span class="val">' + fmt(n) + '</span>' +
            (o.extras || []).map(function (x, i) { return '<span class="ext">' + x.fmt(ex[i][v] || 0) + '</span>'; }).join('') +
            (d.pareto ? '<span class="cum">' + (aside || !totMain ? '' : pct0(cum / totMain * 100)) + '</span>' : '') + '</button>';
        }).join('');
      }
      var cl = card.querySelector('.clear-one'); cl.hidden = !act; cl.textContent = S('clear');
    };
    b.renderChips = function () {
      var keys = Object.keys(b.f);
      chips.innerHTML = keys.length ? keys.map(function (k) {
        return '<button type="button" class="chip" data-k="' + k + '"><i>' + esc(S(DIM[k].t)) + '</i>' + esc(DIM[k].show(b.f[k])) + ' <span aria-hidden="true">×</span></button>';
      }).join('') + '<button type="button" class="chip reset">' + esc(S('clearAll')) + '</button>' : '<span class="hint">' + esc(S('hint')) + '</span>';
    };
    b.renderTable = function () {
      var rs = b.filtered(null); if (o.sort) rs.sort(o.sort);
      var shown = o.tableRows ? o.tableRows(rs) : rs;
      document.getElementById(o.count).textContent = '· ' + S('shown', { n: num(shown.length), t: num((o.tableRows ? o.tableRows(b.base()) : b.base()).length) });
      document.getElementById(o.thead).innerHTML = o.head();
      var tb = document.getElementById(o.tbody);
      tb.innerHTML = shown.length ? shown.slice(0, b.limit).map(function (r) { return o.row(r, b); }).join('') : '<tr><td colspan="12" class="empty">—</td></tr>';
      var more = document.getElementById(o.more), rest = shown.length - b.limit;
      more.hidden = rest <= 0; if (rest > 0) more.textContent = S('more', { n: num(Math.min(200, rest)) });
    };
    b.render = function () { b.renderChips(); o.dims.forEach(b.renderDim); b.renderTable(); if (o.after) o.after(b); };
    return b;
  }

  function defectHead() { return ['cNc', 'cDate', 'cLine', 'cCat', 'cRca', 'cSub', 'cCode', 'cFin', 'cCab', 'cText'].map(function (k) { return '<th scope="col">' + esc(S(k)) + '</th>'; }).join(''); }
  function defectRow(r) {
    return '<tr><td class="nc">' + esc(r[0]) + (r[1] > 1 ? ' · ' + r[1] : '') + '</td><td class="num">' + esc(shortDay(r[2])) + '</td><td>' + esc(r[4]) + '</td><td>' + esc(L(dCat(r))) + '</td><td>' + esc(L(dRca(r))) + '</td><td>' + esc(dSub(r)) + '</td><td class="nc" title="' + esc(codeDesc(dCode(r))) + '">' + esc(dCode(r)) + '</td><td class="nc">' + esc(dFin(r)) + '</td><td>' + (dCable(r) ? '<span class="tag">' + esc(S('yes')) + '</span>' : '') + '</td><td class="txt">' + esc(tidy(r[18])) + '</td></tr>';
  }
  function defectText(r) { return r[0] + ' ' + r[18] + ' ' + dFin(r) + ' ' + dCode(r) + ' ' + codeDesc(dCode(r)) + ' ' + dSub(r) + ' ' + dRca(r) + ' ' + L(dRca(r)) + ' ' + dCat(r) + ' ' + L(dCat(r)); }
  function byDate(a, b2) { return a[2] < b2[2] ? 1 : a[2] > b2[2] ? -1 : (a[0] < b2[0] ? 1 : a[0] > b2[0] ? -1 : a[1] - b2[1]); }
  function topOf(m) { return Object.keys(m).sort(function (x, y) { return m[y] - m[x]; })[0]; }

  // ---------------------------------------------------------------- 1. Overview: headline figures, each chart counts NCs of the selection
  // NC row extras: [32] closure date, [33] NC type, [34] liability, [35] SAP defect code, [36] SAP cause group, [37] SAP cause, [38] status
  var PROG_COL = {}; Object.keys(SET.lignes).forEach(function (l) { PROG_COL[l] = 'var(--l' + SET.lignes[l] + ')'; });   // line colours (config/2_lignes.csv)
  function lineCol(l) { return PROG_COL[l] || 'var(--dim)'; }   // one colour per line on every chart
  // a product takes the colour of its line (the line of most of its NCs), as on Localisation; 'Other' stays grey (29 Oct)
  var PROD_LINE = (function () { var c = {}, r = {}; D.ncs.forEach(function (n) { var p = n[26] || 'Other', o = c[p] || (c[p] = {}); o[n[3]] = (o[n[3]] || 0) + 1; });
    Object.keys(c).forEach(function (p) { var b = '', bv = 0; Object.keys(c[p]).forEach(function (l) { if (c[p][l] > bv) { bv = c[p][l]; b = l; } }); r[p] = b; }); return r; })();
  function prodCol(p) { return p === 'Other' ? 'var(--dim)' : lineCol(PROD_LINE[p]); }
  function typeName(t) { return STR[G.lang]['ty_' + t] || t; }
  function stName(s) { return STR[G.lang]['st_' + s] || s || '—'; }
  // donut with a legend; slices and legend rows filter like bars
  function pie(vals, m, rs, b) {
    var d = this, tot = 0; vals.forEach(function (v) { tot += m[v] || 0; });
    if (!tot) return '<p class="empty">—</p>';
    var R = 84, r0 = 52, a = -Math.PI / 2, gl = d.pickLine, act = gl ? !!GF.line : d.k in b.f, shapes = '', leg = '';   // pickLine: a click is the global line filter
    function pt(r, t) { return (90 + r * Math.cos(t)).toFixed(1) + ',' + (90 + r * Math.sin(t)).toFixed(1); }
    vals.forEach(function (v, i) {
      var n = m[v] || 0, on = gl ? GF.line === v : b.f[d.k] === v, col = d.color(v, i), fade = act && !on ? ' opacity=".3"' : '', lab = d.show(v), tip = lab + ' : ' + num(n) + ' (' + pct0(n / tot * 100) + ')';
      var hit = gl ? (v === 'Autre' ? '' : pk('line', v)) : ' data-dim="' + d.k + '" data-v="' + esc(v) + '"', attrs = hit + fade + '><title>' + esc(tip) + '</title>';
      if (n === tot) shapes += '<circle cx="90" cy="90" r="' + (R + r0) / 2 + '" fill="none" stroke="' + col + '" stroke-width="' + (R - r0) + '"' + attrs + '</circle>';
      else if (n) { var a1 = a + n / tot * 2 * Math.PI, big = a1 - a > Math.PI ? 1 : 0;
        shapes += '<path d="M' + pt(R, a) + 'A' + R + ',' + R + ' 0 ' + big + ' 1 ' + pt(R, a1) + 'L' + pt(r0, a1) + 'A' + r0 + ',' + r0 + ' 0 ' + big + ' 0 ' + pt(r0, a) + 'Z" fill="' + col + '" stroke="var(--surface)" stroke-width="2"' + attrs + '</path>';
        a = a1; }
      leg += '<button type="button" class="pleg"' + hit + ' aria-pressed="' + on + '"><i style="background:' + col + '"></i><span class="name">' + esc(lab) + '</span><span class="val">' + num(n) + '</span><span class="cum">' + pct0(n / tot * 100) + '</span></button>';
    });
    return '<div class="piewrap"><svg class="viz" viewBox="0 0 180 180" width="180" height="180" role="img" aria-label="' + esc(S(d.t)) + '">' + shapes +
      '<text x="90" y="92" text-anchor="middle" class="ink b" style="font-size:20px">' + num(tot) + '</text><text x="90" y="110" text-anchor="middle" class="mu">' + esc(S('nK1')) + '</text></svg><div class="pielegend">' + leg + '</div></div>';
  }
  // two lines per month: NCs created, NCs closed; a month click keeps the NCs created that month
  // cost of non-quality split by NC type, one 100 % bar; NC Interne and Casse interne count as Interne
  function cnqSplit(vals, m, rs, b) {
    var d = this, tot = sumA(vals.map(function (v) { return m[v] || 0; })) || 1e-9, sh = { cab: 100, fin: 78, test: 58, int: 40, sup: 24 };
    var fill = function (v) { return v === 'oth' ? 'var(--dim)' : sh[v] === 100 ? 'var(--s1)' : tint('--s1', sh[v]); };
    var bar = vals.map(function (v) { var n = m[v] || 0, p = n / tot * 100;
      return '<button type="button" class="sp-part' + (sh[v] >= 58 ? ' dk' : '') + '" data-dim="' + d.k + '" data-v="' + v + '" aria-pressed="' + (b.f[d.k] === v) + '" style="flex-grow:' + r1(Math.max(p, 0.5)) + ';background:' + fill(v) + '" title="' + esc(d.show(v) + ' : ' + pct(p) + ' · ' + eurK(n)) + '">' +
        (p >= 8 ? '<b>' + esc(pct(p)) + '</b><span>' + esc(d.show(v)) + '</span>' : '') + '</button>'; }).join('');
    var key = vals.map(function (v) { var n = m[v] || 0;
      return '<button type="button" class="sp-key" data-dim="' + d.k + '" data-v="' + v + '" aria-pressed="' + (b.f[d.k] === v) + '"><i style="background:' + fill(v) + '"></i><span>' + esc(d.show(v)) + '</span><b>' + esc(pct(n / tot * 100)) + '</b><small>' + esc(eurK(n)) + '</small></button>'; }).join('');
    return '<div class="sp' + (d.k in b.f ? ' active' : '') + '"><div class="sp-bar">' + bar + '</div><div class="sp-keys">' + key + '</div></div>';
  }
  function ncMonthLines(vals, m, rs, b, el) {
    var d = this, op = {}, cl = {}, all = {};
    b.base().forEach(function (n) { all[n[1].slice(0, 7)] = 1; if (n[32]) all[n[32].slice(0, 7)] = 1; });
    rs.forEach(function (n) { var k = n[1].slice(0, 7); op[k] = (op[k] || 0) + 1; if (n[32]) { var c2 = n[32].slice(0, 7); cl[c2] = (cl[c2] || 0) + 1; } });
    var months = Object.keys(all).sort();
    if (!months.length) return '<p class="empty">—</p>';
    var W = Math.max(el.clientWidth || 0, 340), H = 230, ml = 40, mr = 18, mt = 16, mb = 28, pw = W - ml - mr, ph = H - mt - mb, mx = 1;
    months.forEach(function (k) { mx = Math.max(mx, op[k] || 0, cl[k] || 0); });
    var step = mx > 200 ? 100 : mx > 80 ? 50 : mx > 30 ? 20 : mx > 10 ? 5 : 2, top = Math.ceil(mx / step) * step, sx = months.length > 1 ? pw / (months.length - 1) : 0, hw = Math.max(sx, 22);
    function X(i) { return ml + (months.length > 1 ? i * sx : pw / 2); } function Y(v) { return mt + ph - v / top * ph; }
    var g = '<line x1="' + ml + '" x2="' + (ml + pw) + '" y1="' + Y(0) + '" y2="' + Y(0) + '" stroke="var(--grid)"/>';
    [0, top / 2, top].forEach(function (t) { g += '<text x="' + (ml - 8) + '" y="' + (Y(t) + 4).toFixed(1) + '" text-anchor="end" class="mu">' + num(t) + '</text>'; });
    months.forEach(function (k, i) { var on = b.f[d.k] === k;
      g += '<rect x="' + (X(i) - hw / 2).toFixed(1) + '" y="' + mt + '" width="' + hw.toFixed(1) + '" height="' + ph + '" fill="' + (on ? 'var(--s1-soft)' : 'transparent') + '" data-dim="' + d.k + '" data-v="' + k + '" style="cursor:pointer"><title>' +
        esc(monthName(k) + ' ' + k.slice(0, 4) + ' · ' + S('lnOpened') + ' ' + num(op[k] || 0) + ' · ' + S('lnClosed') + ' ' + num(cl[k] || 0)) + '</title></rect>';
      if (months.length <= 14 || i % 2 === 0) g += '<text x="' + X(i).toFixed(1) + '" y="' + (H - 8) + '" text-anchor="middle" class="mu">' + esc(monthName(k)) + '</text>'; });
    [[op, 'var(--s1)', ''], [cl, 'var(--ink-2)', ' stroke-dasharray="5 4"']].forEach(function (s) {
      g += '<path d="' + months.map(function (k, i) { return (i ? 'L' : 'M') + X(i).toFixed(1) + ',' + Y(s[0][k] || 0).toFixed(1); }).join('') + '" fill="none" stroke="' + s[1] + '" stroke-width="2"' + s[2] + ' pointer-events="none"/>';
      months.forEach(function (k, i) { g += '<circle cx="' + X(i).toFixed(1) + '" cy="' + Y(s[0][k] || 0).toFixed(1) + '" r="3.5" fill="' + s[1] + '" stroke="var(--surface)" stroke-width="2" pointer-events="none"/>'; });
    });
    return '<div class="key"><span><i class="ln" style="background:var(--s1)"></i>' + esc(S('lnOpened')) + '</span><span><i class="ln dash"></i>' + esc(S('lnClosed')) + '</span></div>' +
      '<svg class="viz" width="' + W + '" height="' + H + '" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="' + esc(S(d.t)) + '">' + g + '</svg>';
  }
  // decision split into closed and open NCs, both counts written
  function statusBars(vals, m, rs, b) {
    var d = this, op = {}, cl = {}, mx = 1, act = d.k in b.f;
    rs.forEach(function (n) { var v = d.get(n); if (n[38] === 'open') op[v] = (op[v] || 0) + 1; else cl[v] = (cl[v] || 0) + 1; });
    vals.forEach(function (v) { mx = Math.max(mx, (op[v] || 0) + (cl[v] || 0)); });
    return '<div class="key"><span><i></i>' + esc(S('keyClosed')) + '</span><span><i class="c alt"></i>' + esc(S('keyOpen')) + '</span></div><div class="bars st' + (act ? ' active' : '') + '">' + vals.map(function (v) {
      var c = cl[v] || 0, o = op[v] || 0, on = b.f[d.k] === v, lab = d.show(v), tip = lab + ' : ' + S('stTip', { c: num(c), o: num(o) });
      return '<button type="button" class="bar' + (c + o ? '' : ' zero') + '" data-dim="' + d.k + '" data-v="' + esc(v) + '" aria-pressed="' + on + '" title="' + esc(tip) + '" aria-label="' + esc(tip) + '"><span class="name">' + esc(lab) +
        '</span><span class="track"><span class="fill" style="width:' + (c / mx * 100) + '%"></span><span class="fill2" style="width:' + (o / mx * 100) + '%"></span></span><span class="val">' + num(c) + ' | ' + num(o) + '</span></button>';
    }).join('') + '</div>';
  }
  var ncBoard = Board({
    grid: 'ng', fold: 'ngx', chips: 'ncChips', search: 'nq', count: 'nn', thead: 'nth', tbody: 'ntb', more: 'nm', kicker: 'kmNc',
    rows: function () { return SEL_NC; },
    dims: [
      { fold: true, k: 'prog', t: 'dProg', custom: pie, pickLine: true, color: function (v) { return PROG_COL[v] || 'var(--dim)'; }, get: function (n) { return n[3] || 'Autre'; }, show: function (v) { return v === 'Autre' ? L('Autre') : v; } },
      { fold: true, k: 'prod', t: 'dProd', sub: 'dProdSub', top: 15, color: prodCol, get: function (n) { return n[26] || 'Other'; }, show: prodName },
      { fold: true, k: 'status', t: 'dStatus', custom: statusBars, get: function (n) { return n[7]; }, show: ruleName },
      { fold: true, k: 'month', t: 'dMonthNc', sub: 'monthNcSub', wide: true, custom: ncMonthLines, get: function (n) { return n[1].slice(0, 7); }, show: function (v) { return monthName(v) + ' ' + v.slice(0, 4); }, order: function (v) { return v.sort(); } },
      { fold: true, k: 'type', t: 'dType', sub: 'typeSub', get: function (n) { return ncType(n) || null; }, show: typeName },
      { fold: true, k: 'liab', t: 'dLiab', sub: 'liabSub', top: 15, get: function (n) { return n[34] || null; }, show: function (v) { return v; } },
      { fold: true, k: 'sapdef', t: 'dSapDef', sub: 'sapDefSub', top: 10, get: function (n) { return n[35] || null; }, show: function (v) { return v; } },
      { fold: true, k: 'sapcause', t: 'dSapCause', sub: 'sapCauseSub', top: 20, wide: true, longName: true, get: function (n) { return n[37] || null; }, show: function (v) { return v; } }
    ],
    text: function (n) { return [n[0], n[22], n[26], n[27], n[3], ncType(n), typeName(ncType(n)), n[35], n[37]].join(' '); },
    sort: function (a, b2) { return a[1] < b2[1] ? 1 : a[1] > b2[1] ? -1 : 0; },
    head: function () { return ['cNc', 'cDate', 'cLine', 'hProd', 'nType', 'kRule', 'nStatus', 'hStation', 'kTitle'].map(function (k) { return '<th scope="col">' + esc(S(k)) + '</th>'; }).join(''); },
    row: function (n) {
      return '<tr><td class="nc">' + esc(n[0]) + '</td><td class="num">' + esc(shortDay(n[1])) + '</td><td>' + esc(n[3]) + '</td><td>' + esc(prodName(n[26])) + '</td><td>' + esc(typeName(ncType(n))) +
        '</td><td>' + esc(ruleName(n[7])) + '</td><td>' + esc(stName(n[38])) + '</td><td>' + esc(n[27]) + '</td><td class="txt">' + esc(n[22]) + '</td></tr>';
    },
    after: function (b) {
      var rs = b.base();   // the global selection, as every chart of the Overview (20 Oct: the folded lists' clicks moved the figures and not the charts)
      var nd = sum(rs, function (n) { return NLINES[n[0]] || 0; }), nw = rs.filter(function (n) { return NLINES[n[0]]; }).length;
      document.getElementById('nf1').textContent = num(rs.length);
      document.getElementById('nfD').textContent = num(nd);
      document.getElementById('nfDP').textContent = nw ? (Math.round(nd / nw * 10) / 10).toLocaleString(loc()) : '—';
      document.getElementById('nfC').textContent = eurK(sum(rs, function (n) { return n[12]; }));
      var pd = pSrc() ? pAgg(pData()) : null, pe = 0, pn = 0;   // NCs per MSN: the NCs matched to a product of the production file
      if (pd) Object.keys(pd).forEach(function (p) { if (pd[p].EQ > 0 && grpOk(pd[p])) { pe += pd[p].EQ; pn += pd[p].NC; } });
      document.getElementById('nfR').textContent = pe ? f2(pn / pe) : '—';
      var gs = document.getElementById('nfRg'); if (gs) gs.innerHTML = grpSeg();
    }
  });

  // ---------------------------------------------------------------- 2. Pareto (selection)
  function ncShareFmt(n) { return (Math.round(n * 10) / 10).toLocaleString(loc(), { minimumFractionDigits: n > 0 && n < 100 ? 1 : 0, maximumFractionDigits: 1 }); }
  var pareto = Board({
    grid: 'pg', fold: 'pgl', chips: 'pc', search: 'pq', count: 'pn', thead: 'pth', tbody: 'ptb', more: 'pm', valueHead: 'hDef', kicker: 'kmDef', mag: true,
    rows: function () { return D.defects.filter(function (r) { return SEL[r[0]] && keepMinor(r); }); },
    extras: [{ t: 'hNc', f: function (r) { return 1 / NLINES[r[0]]; }, fmt: ncShareFmt }],
    dims: [
      { k: 'cat', t: 'dCat', sub: 'paretoSub', wide: true, pareto: true, split: dCable, splitIf: cabOn, color: catFill, get: dCat, show: L },
      { fold: true, k: 'rca', t: 'dRca', top: 15, split: dCable, splitIf: cabOn, color: rcaCol, catKey: rcaCat, get: dRca, show: L },
      { fold: true, k: 'line', t: 'dLine', stack: function (r) { return catKey(dCat(r)); }, get: function (r) { return r[4]; }, show: function (v) { return v; }, order: lineOrder },
      { fold: true, k: 'code', t: 'dCode', sub: 'codeSub', top: 15, wide: true, longName: true, split: dCable, splitIf: cabOn, nokey: true, color: codeCol, catKey: codeCat, get: dCode, show: codeName },
      { fold: true, k: 'fin', t: 'dFin', sub: 'finSub', top: 10, split: dCable, splitIf: cabOn, nokey: true, stack: function (r) { return catKey(dCat(r)); }, get: function (r) { return finReal(r) || null; }, show: function (v) { return v; } }
    ],
    text: defectText, head: defectHead, row: defectRow, sort: byDate,
    after: function (b) {
      var rs = b.filtered(null), m = {};
      rs.forEach(function (r) { var c = dCat(r); if (!ASIDE[c]) m[c] = (m[c] || 0) + 1; });
      var top = topOf(m);
      document.getElementById('pf1').textContent = num(rs.length);
      document.getElementById('pf2').textContent = top ? L(top) : '—';
      document.getElementById('pf2s').textContent = top ? S('topSub', { n: num(m[top]), p: pct(m[top] / rs.length * 100) }) : '';
    }
  });

  // ---------------------------------------------------------------- 2b. Cost Pareto: the Pareto measured in euros
  // cost units: each defect line of an NC (its share of the NC cost), plus each NC with no defect line (A400M); shared with the CNQ tab
  var UNITS = (function () {
    var out = [], has = {};
    D.defects.forEach(function (r) { var n = NC[r[0]]; if (n) { has[r[0]] = 1; out.push({ d: r, n: n }); } });
    REP.forEach(function (n) { if (!has[n[0]]) out.push({ d: null, n: n }); });
    return out;
  })();
  function selUnits() { return UNITS.filter(function (u) { return SEL[u.n[0]]; }); }
  function kCost(u) { return u.d ? dAlloc(u.d) : u.n[12]; }
  function kCab(u) { return !!(u.d && dCable(u.d)); }
  // NC share: each NC counts once, shared equally among its defect lines (1/35 for an NC with 35 defects)
  var NLINES = {}; D.defects.forEach(function (r) { NLINES[r[0]] = (NLINES[r[0]] || 0) + 1; });
  function kShare(u) { return u.d ? 1 / NLINES[u.d[0]] : 1; }
  var costPareto = Board({
    grid: 'kg', fold: 'kgl', chips: 'kc', search: 'kq', count: 'kn', thead: 'kth', tbody: 'ktb', more: 'km', money: true, kicker: 'kmEur', mag: true,
    rows: function () { return UNITS.filter(function (u) { return SEL[u.n[0]] && (!u.d || keepMinor(u.d)); }); }, measure: kCost,
    extras: [{ t: 'hDef', f: function (u) { return u.d ? 1 : 0; }, fmt: function (n) { return num(n); } },
             { t: 'hNc', f: kShare, fmt: ncShareFmt }],
    dims: [
      { k: 'cat', t: 'dCat', sub: 'ncShareNote', wide: true, pareto: true, split: kCab, splitIf: cabOn, color: catFill, get: function (u) { return u.d ? dCat(u.d) : '__none'; }, show: function (v) { return v === '__none' ? S('noLine') : L(v); } },
      { fold: true, k: 'rca', t: 'dRca', top: 15, split: kCab, splitIf: cabOn, color: rcaCol, catKey: rcaCat, get: function (u) { return u.d ? dRca(u.d) : null; }, show: L },
      { fold: true, k: 'line', t: 'dLine', stack: function (u) { return u.d ? catKey(dCat(u.d)) : '__none'; }, get: function (u) { return u.n[3]; }, show: function (v) { return v; }, order: lineOrder },
      { fold: true, k: 'code', t: 'dCode', sub: 'codeSub', top: 15, wide: true, longName: true, split: kCab, splitIf: cabOn, nokey: true, color: codeCol, catKey: codeCat, get: function (u) { return u.d ? dCode(u.d) : null; }, show: codeName },
      { fold: true, k: 'fin', t: 'dFin', sub: 'finSub', top: 10, split: kCab, splitIf: cabOn, nokey: true, stack: function (u) { return u.d ? catKey(dCat(u.d)) : '__none'; }, get: function (u) { return u.d ? finReal(u.d) || null : null; }, show: function (v) { return v; } }
    ],
    text: function (u) { return u.n[0] + ' ' + u.n[22] + ' ' + (u.d ? defectText(u.d) : ''); },
    sort: function (a, b2) { return kCost(b2) - kCost(a); },
    head: function () { return [['cNc'], ['cDate'], ['cLine'], ['cCat'], ['cRca'], ['cCode'], ['cCab'], ['cCost', 'r'], ['cShare', 'r'], ['cText']].map(function (p) { return '<th scope="col"' + (p[1] ? ' class="r"' : '') + '>' + esc(S(p[0])) + '</th>'; }).join(''); },
    row: function (u) {
      var r = u.d;
      if (!r) return '<tr><td class="nc">' + esc(u.n[0]) + '</td><td class="num">' + esc(shortDay(u.n[1])) + '</td><td>' + esc(u.n[3]) + '</td><td colspan="4">' + esc(S('noLine')) + '</td><td class="num r">' + eur(kCost(u)) + '</td><td class="num r">1</td><td class="txt">' + esc(u.n[22]) + '</td></tr>';
      return '<tr><td class="nc">' + esc(r[0]) + (r[1] > 1 ? ' · ' + r[1] : '') + '</td><td class="num">' + esc(shortDay(r[2])) + '</td><td>' + esc(r[4]) + '</td><td>' + esc(L(dCat(r))) + '</td><td>' + esc(L(dRca(r))) + '</td><td class="nc" title="' + esc(codeDesc(dCode(r))) + '">' + esc(dCode(r)) + '</td><td>' + (dCable(r) ? '<span class="tag">' + esc(S('yes')) + '</span>' : '') + '</td><td class="num r">' + eur(kCost(u)) + '</td><td class="num r">' + (NLINES[r[0]] > 1 ? '1/' + NLINES[r[0]] : '1') + '</td><td class="txt">' + esc(tidy(r[18])) + '</td></tr>';
    },
    after: function (b) {
      var rs = b.filtered(null), tot = 0, m = {};
      rs.forEach(function (u) { var c = kCost(u); tot += c; if (u.d && !ASIDE[dCat(u.d)]) m[dCat(u.d)] = (m[dCat(u.d)] || 0) + c; });
      var top = topOf(m);
      document.getElementById('kf1').textContent = eur(tot);
      document.getElementById('kf2').textContent = top ? L(top) : '—';
      document.getElementById('kf2s').textContent = top ? S('topCostSub', { e: eur(m[top]), p: pct(m[top] / tot * 100) }) : '';
    }
  });
  // volume or cost: the filters follow from one to the other
  var PMODE = 'cost';
  function cabOn() { return !!G.cab; }   // the cable shading in the Pareto bars, off by default
  function renderPMode() {
    document.getElementById('pMode').innerHTML = segHtml([['vol', S('mVol')], ['cost', S('mCost')]], PMODE, 'data-pmode');
    document.getElementById('pCab').innerHTML = segHtml([['0', S('cabHide')], ['1', S('cabShow')]], G.cab ? '1' : '0', 'data-pcab');
    document.getElementById('pVol').hidden = PMODE !== 'vol'; document.getElementById('pCost').hidden = PMODE !== 'cost';
  }
  document.getElementById('pCab').addEventListener('click', function (e) {
    var c = e.target.closest('[data-pcab]'); if (!c) return; G.cab = c.getAttribute('data-pcab') === '1'; renderPMode(); pareto.render(); costPareto.render();
  });
  document.getElementById('pMode').addEventListener('click', function (e) {
    var c = e.target.closest('[data-pmode]'); if (!c || c.getAttribute('data-pmode') === PMODE) return;
    var from = PMODE === 'vol' ? pareto : costPareto, to = PMODE === 'vol' ? costPareto : pareto;
    to.f = {}; Object.keys(from.f).forEach(function (k) { if (from.f[k] !== '__none') to.f[k] = from.f[k]; });
    to.q = ''; PMODE = c.getAttribute('data-pmode'); renderPMode(); to.render(); v2Render();
  });

  // a week's working time (config/1_calendrier_production.csv: weekends, public holidays, closures), 1 = a normal week; weeks of
  // a year with no calendar (before the comparison year) count as normal
  function calW(w) { var P = SET.semaines_poids || {}, y = String(w).slice(0, 4), n = +String(w).slice(6), L = Array.isArray(P) ? (y === String(YEAR) ? P : null) : P[y];
    return L && L[n - 1] != null ? L[n - 1] : 1; }
  function segHtml(items, cur, attr) { return items.map(function (p) { return '<button type="button" ' + attr + '="' + p[0] + '" aria-pressed="' + (String(cur) === String(p[0])) + '">' + esc(p[1]) + '</button>'; }).join(''); }

  // ---------------------------------------------------------------- 4. Cost of non-quality (selection; the strip shows FTO2 and customer returns apart)
  function uCost(u) { return u.d ? dAlloc(u.d) : u.n[12]; }
  function sum(arr, f) { return arr.reduce(function (s, x) { return s + f(x); }, 0); }
  var cnq = Board({
    grid: 'cg', fold: 'cgx', chips: 'cc', search: 'cq', count: 'cn', thead: 'cth', tbody: 'ctb', more: 'cm', money: true, kicker: 'kmEur', mag: true,
    rows: selUnits, measure: uCost,
    dims: [
      { k: 'type', t: 'dType', sub: 'typeSub', custom: cnqSplit, get: function (u) { return ncType(u.n); }, show: function (v) { return S('ty_' + v); }, order: function (v) { return NCTYPES.filter(function (t) { return v.indexOf(t) >= 0; }); } },
      { k: 'rule', t: 'dRule', get: function (u) { return u.n[7]; }, show: ruleName },
      { k: 'line', t: 'dLine', color: lineCol, get: function (u) { return u.n[3]; }, show: function (v) { return v; }, order: lineOrder },
      { k: 'prod', t: 'dProdC', sub: 'dProdCSub', top: 10, color: prodCol, get: function (u) { return u.n[26] || 'Other'; }, show: prodName },
      { k: 'month', t: 'dMonth', cols: true, get: function (u) { return u.n[1].slice(0, 7); }, show: monthName, order: function (v) { return v.sort(); } }
    ],
    text: function (u) { return u.n[0] + ' ' + u.n[22] + ' ' + (u.d ? defectText(u.d) : ''); },
    tableRows: function (units) { var seen = {}, out = []; units.forEach(function (u) { if (!seen[u.n[0]]) { seen[u.n[0]] = 1; out.push(u.n); } }); out.sort(function (a, b2) { return b2[12] - a[12]; }); return out; },
    head: function () { return [['kNc'], ['kDate'], ['kLine'], ['kWhere'], ['kRule'], ['kLines', 'r'], ['kCable'], ['kC3', 'r'], ['kTitle']].map(function (p) { return '<th scope="col"' + (p[1] ? ' class="r"' : '') + '>' + esc(S(p[0])) + '</th>'; }).join(''); },
    row: function (n) {
      return '<tr><td class="nc">' + esc(n[0]) + '</td><td class="num">' + esc(shortDay(n[1])) + '</td><td>' + esc(n[3]) + '</td><td>' + esc(whereName(n[8])) + '</td><td>' + esc(ruleName(n[7])) + '</td><td class="num r">' + num(n[21]) + '</td><td>' + (n[20] ? '<span class="tag">' + esc(S('yes')) + '</span>' : '') + '</td><td class="num r">' + eur(n[12]) + '</td><td class="txt">' + esc(n[22]) + '</td></tr>';
    },
    after: function (b) {
      var t3 = sum(SEL_NC, function (n) { return n[12]; }), t1 = sum(SEL_NC, function (n) { return n[9]; }), t2 = sum(SEL_NC, function (n) { return n[10]; });
      var ts = sum(SER_NC, function (n) { return n[12]; }), tc = sum(CLI_NC, function (n) { return n[12]; });
      var dk = (disSel() || []).filter(function (a) { return a[6] === 1; });
      document.getElementById('cStrip').innerHTML = '<span>' + esc(S('stripTotal')) + ' <b>' + eur(ts + tc) + '</b></span><span>' + esc(S('stripSerie')) + ' <b>' + eur(ts) + '</b> · ' + num(SER_NC.length) + ' NC</span><span>' + esc(S('stripClient')) + ' <b>' + eur(tc) + '</b> · ' + num(CLI_NC.length) + ' NC</span>' +
        (D.dis ? '<span class="mu">' + esc(S('stripDis')) + ' <b>' + eur(sumA(dk.map(function (a) { return a[5]; })) / 60 * disRate()) + '</b> · ' + num(dk.length) + ' ' + esc(S('disN')) + '</span>' : '');
      document.getElementById('cf1').textContent = eur(t3);
      document.getElementById('cf2').textContent = num(SEL_NC.length);
      document.getElementById('cf3').textContent = SEL_NC.length ? eur(t3 / SEL_NC.length) : '—';
      // how the rework is costed (replaces the costing methods card): from the planned time of the NC's closed rework
      // order, or from the model's minutes per defect; FTO2-liable NCs only (the others cost 0)
      var lia = SEL_NC.filter(costed), byO = lia.filter(function (n) { return cxSteps(n)[8] === 'order'; }), byM = lia.filter(function (n) { return cxSteps(n)[8] !== 'order'; });
      var oc = sum(byO, function (n) { return n[12]; }), mc = sum(byM, function (n) { return n[12]; }), wm = Math.max(byO.length, byM.length, 1);
      document.getElementById('cWo').innerHTML = [[S('woOrder'), byO, oc, true], [S('woModel'), byM, mc, false]].map(function (l) { return '<div class="level' + (l[3] ? ' main' : '') + '"><span class="name">' + esc(l[0]) +
        '</span><span class="track"><span class="fill" style="width:' + (l[1].length / wm * 100) + '%"></span></span><span class="val">' + esc(S('woVal', { n: num(l[1].length), p: lia.length ? pct0(l[1].length / lia.length * 100) : '—', c: eur(l[2]) })) + '</span></div>'; }).join('');
      var st = {}; byM.forEach(function (n) { var k = cxSteps(n)[9]; if (k) st[k] = (st[k] || 0) + 1; });
      document.getElementById('cWoNote').textContent = S('woStates', { o: num(st.open || 0), t: num(st.no_time || 0), f: num(st.not_found || 0) });
      var lv = [[S('lvl1'), t1, false], [S('lvl2'), t2, false], [S('lvl3'), t3, true]], mx = Math.max(t1, t2, t3, 1e-9), lvEl = document.getElementById('cLevels');
      if (lvEl) lvEl.innerHTML = lv.map(function (l) { return '<div class="level' + (l[2] ? ' main' : '') + '"><span class="name">' + esc(l[0]) + '</span><span class="track"><span class="fill" style="width:' + (l[1] / mx * 100) + '%"></span></span><span class="val">' + eur(l[1]) + '</span></div>'; }).join('');
    }
  });

  // ---------------------------------------------------------------- 4b. Explain the calculation (folded by default): the steps with their
  // time and cost per NC and over the selection, then one real NC worked out step by step. Every figure comes from the pipeline:
  // NC row [40] = the model's minutes [alert, writing, support, setup, hands-on, re-check], engineering hours, final-inspection flag,
  // then where setup and hands-on come from ('order': planned time of the rework orders, 'model', '' no work), the orders' state, their numbers,
  // where the alert time comes from ('alea': declared on the quality aléas that led to the NC, 'flat', '' not charged) and those aléas.
  var CX = { nc: null, lines: false };   // the NC shown in "Expliquer le calcul"
  function eur2(x) { return (+x).toLocaleString(loc(), { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + (G.lang === 'fr' ? ' €' : ' EUR'); }
  function dec(x) { return (+x).toLocaleString(loc(), { maximumFractionDigits: 2 }); }
  function mn(x) { return (Math.round(x * 10) / 10).toLocaleString(loc()) + ' min'; }
  // example NCs, picked from the selection: the most recent NC of each kind
  var CX_EX = [
    ['ex_one', function (n) { return n[6] === 'RWK' && n[21] === 1 && !cxSteps(n)[7]; }],
    ['ex_many', function (n) { return n[6] === 'RWK' && n[21] >= 5 && !cxSteps(n)[7]; }],
    ['ex_final', function (n) { return n[6] === 'RWK' && n[21] >= 2 && cxSteps(n)[7]; }],
    ['ex_noline', function (n) { return n[6] === 'RWK' && n[21] === 0; }],
    ['ex_rej', function (n) { return n[6] === 'REJ'; }],
    ['ex_rejrw', function (n) { return n[6] === 'REJ_RW'; }],
    ['ex_order', function (n) { return cxSteps(n)[8] === 'order'; }],
    ['ex_alea', function (n) { return cxSteps(n)[11] === 'alea'; }],
    ['ex_exc', function (n) { return n[6] === 'EXC'; }],
    ['ex_dqn', function (n) { return n[6] === 'DQN'; }],
    ['ex_cli', function (n) { return n[23] === 'client'; }]
  ];
  function cxExamples() {
    var sorted = SEL_NC.slice().sort(function (a, b2) { return a[1] < b2[1] ? 1 : a[1] > b2[1] ? -1 : String(b2[0]).localeCompare(String(a[0])); });
    return CX_EX.map(function (e) { var n = sorted.find(e[1]); return n ? [e[0], n[0]] : null; }).filter(Boolean);
  }
  function renderCx() {
    var box = document.getElementById('cx'); if (!box) return;
    box.hidden = !CXP; if (!CXP) return;
    var P = CXP.p, tot = sum(SEL_NC, function (n) { return n[12]; }) || 0;
    var stepTot = CX_STEPS.map(function (st, j) { return sum(SEL_NC, function (n) { return costed(n) ? cxSteps(n)[j] : 0; }) / 60 * cxRate(st[0]); });   // FTO2's cost only
    var engTot = sum(SEL_NC, function (n) { return n[18]; }), matTot = sum(SEL_NC, function (n) { return n[17]; });
    var shr = function (v) { return tot ? pct(v / tot * 100) : '—'; };
    var vals = { alert: P.alert, writing: P.write, support: P.support, setup: P.setup, recheck: P.recheck };
    var subs = { alert: S('cu_alert'), writing: S('cu_writing', { x: P.writeFinal }), support: S('cu_support'), setup: S('cu_setup'), hands: S('cu_hands'), recheck: S('cu_recheck') };
    document.getElementById('cxChain').innerHTML = CX_STEPS.map(function (st, j) {
      var k = st[0], v = vals[k];
      return '<li' + (k === 'hands' ? ' class="var"' : '') + '><div class="cn">' + esc(S('cs_' + k)) + '</div><div class="cv">' + (v != null ? esc(num(v)) + ' min' : 'Σ') + '</div>' +
        '<div class="ce">' + esc(v != null ? '= ' + S('cxPerNc', { c: eur2(v / 60 * cxRate(k)) }) : S('cxHandsV')) + ' · ' + esc(S('cxAtRate', { r: dec(cxRate(k)) })) + '</div><div class="cs">' + esc(subs[k]) + '</div>' +
        '<div class="sel">' + S('cxSel', { c: '<b>' + esc(eur(stepTot[j])) + '</b>', p: esc(shr(stepTot[j])) }) + '</div></li>';
    }).join('');
    var cw = inSlate('cout') && !calcSlate('cout');   // the cost explanation still computing in Slate
    var dqn = CXP.rules.DQN, eh = dqn ? dqn[CX_RF.eng] : 0, stepsAll = sumA(stepTot);
    var partTot = sum(SEL_NC, function (n) { return n[46] || 0; }), other = cw ? 0 : sum(SEL_NC, cxAdjOf);   // the parts' value (price list), then what is left: customer returns
    var part = function (cls, name, v, how) { return '<div class="cxp' + cls + '"><span class="cn">' + esc(name) + '</span><span class="cv">' + esc(eur(v)) + '</span><span class="cs">' + esc(how) + '</span></div>'; }, op = function (o) { return '<span class="cxop" aria-hidden="true">' + o + '</span>'; };
    document.getElementById('cxPlus').innerHTML = '<h4>' + esc(S('cxSumH', { n: num(SEL_NC.length) })) + '</h4><div class="cxeq">' +
      part('', S('cxSteps6'), stepsAll, S('cxShare', { p: shr(stepsAll) }) + ' · ' + S('cxSteps6V')) + op('+') +
      part(' eng', S('cxEng'), engTot, S('cxShare', { p: shr(engTot) }) + ' · ' + S('cxEngV', { h: dec(eh), r: dec(P.rateEng), c: eur2(eh * P.rateEng) }) + ' ' + S('cxPerDqn')) + op('+') +
      part(' mat', S('cxMat'), matTot, S('cxShare', { p: shr(matTot) }) + ' · ' + S('cxMatV')) +
      (partTot >= 0.5 ? op('+') + part(' adj', S('r_part'), partTot, S('cxShare', { p: shr(partTot) }) + ' · ' + S('r_part_list')) : '') +
      (Math.abs(other) >= 0.5 ? op(other < 0 ? '−' : '+') + part(' adj', S('r_adj'), Math.abs(other), S('cxShare', { p: shr(Math.abs(other)) })) : '') + op('=') +
      part(' tot', S('cxTot'), tot, S('cxTotV', { n: num(SEL_NC.length) })) + '</div>' + (cw ? '<p class="sub">' + esc(S('slWait')) + '</p>' : '');
    document.getElementById('cxFormula').textContent = S('cxFormula', { p: dec(cxRate('hands')), q: dec(cxRate('writing')), m: dec(cxRate('support')), f: num(P.floor) });
    var nOrd = SEL_NC.filter(function (n) { return cxSteps(n)[8] === 'order'; }).length, nAlea = SEL_NC.filter(function (n) { return cxSteps(n)[11] === 'alea'; }).length;
    var rules = [S('cxR1'), S('cxR2', { a: num((CXP.cls[(P.connCls || [])[0]] || [P.defDefault])[0]), b: num(P.connNext || 0) }), S('cxR3', { f: dec(P.intFactor || 1) }), S('cxR4')]
      .concat(P.orderTime ? [S('cxR5', { n: num(nOrd) })] : []).concat(P.aleaTime ? [S('cxR6', { a: num(-(P.aleaHours || [-2])[0]), b: num((P.aleaHours || [0, 72])[1]), x: num(P.alert), n: num(nAlea) })] : []);
    var mb = document.getElementById('cxModel'), wasOpen = !!(mb.firstChild && mb.firstChild.open);   // shown on a click (20 Oct); stays open across the filters
    mb.innerHTML = '<details class="vdata"' + (wasOpen ? ' open' : '') + '><summary>' + esc(S('cxModelH', { v: P.version || '' })) + ' (' + rules.length + ')</summary><ul>' + rules.map(function (t) { return '<li>' + esc(t) + '</li>'; }).join('') + '</ul></details>';
    var setup = Math.max(P.setup, P.floor - 10), m = P.alert + P.write + P.support + setup + 10 + P.recheck;
    document.getElementById('cxExample').textContent = S('cxExample', { a: P.alert, b: P.write, c: P.support, d: setup, e: P.recheck, m: num(m), c2: eur2(cxEur([P.alert, P.write, P.support, setup, 10, P.recheck])) });
    // what each decision charges
    var cnt = {}; SEL_NC.forEach(function (n) { cnt[n[6]] = (cnt[n[6]] || 0) + 1; });
    var yn = function (v) { return v ? '<span class="cx-yes">✓</span>' : '<span class="cx-no">–</span>'; }, H = S('cxRuleH');
    document.getElementById('cxRules').innerHTML = '<table class="cxt"><thead><tr>' + H.map(function (h, j) { return '<th scope="col"' + (j === 1 || j === 9 ? ' class="r"' : '') + '>' + esc(h) + '</th>'; }).join('') + '</tr></thead><tbody>' +
      Object.keys(CXP.rules).sort(function (a, b2) { return (cnt[b2] || 0) - (cnt[a] || 0); }).map(function (k) {
        var f = CXP.rules[k];
        return '<tr' + (cnt[k] ? '' : ' class="off"') + '><td>' + esc(ruleName(f[CX_RF.label])) + '</td><td class="r">' + num(cnt[k] || 0) + '</td><td>' + yn(f[0]) + '</td><td>' + yn(f[1]) + '</td><td>' + yn(f[2]) + '</td><td>' + yn(f[3]) + '</td><td>' + yn(f[4]) +
          '</td><td>' + (f[5] ? esc(dec(f[5])) + ' h' : yn(0)) + '</td><td>' + yn(f[6]) + '</td><td class="r">' + esc(eur2(CXP.airbus[k] || 0)) + '</td><td><span class="tag">' + esc(S('bk_' + f[CX_RF.basis])) + '</span></td></tr>';
      }).join('') + '</tbody></table>';
    // the NC picker: list of the selection, example buttons, then the NC itself
    document.getElementById('cxList').innerHTML = SEL_NC.map(function (n) { return '<option value="' + esc(n[0]) + '">'; }).join('');
    var ex = cxExamples();
    if (CX.nc == null || !NC[CX.nc]) { var f0 = ex.find(function (e) { return e[0] === 'ex_final'; }) || ex[0]; CX.nc = f0 ? f0[1] : null; }
    document.getElementById('cxEx').innerHTML = ex.map(function (e) { return '<button type="button" class="cxb" data-cxnc="' + esc(e[1]) + '" aria-pressed="' + (String(e[1]) === String(CX.nc)) + '">' + esc(S(e[0])) + '</button>'; }).join('');
    document.getElementById('cxNum').setAttribute('placeholder', CX.nc || '');
    renderCxNc();
  }
  function renderCxNc() {
    var out = document.getElementById('cxOut'), n = CX.nc != null ? NC[CX.nc] : null;
    if (!n) { out.innerHTML = CX.nc != null ? '<p class="sub">' + esc(S('cxNone')) + '</p>' : ''; return; }
    var C = cxOf(n); if (!C) { out.innerHTML = '<p class="sub">' + esc(S('slWait')) + '</p>'; return; }   // euros of each step, work factor, adjustment, each line
    var P = CXP.p, f = cxRule(n) || [0, 0, 0, 0, 0, 0, 0, n[7], ''], st = cxSteps(n), fin = st[7], lines = cxLines(n[0]), sep = G.lang === 'fr' ? ' : ' : ': ';
    var fact = function (k, v) { return '<span>' + esc(S(k)) + sep + '<b>' + esc(v) + '</b></span>'; };
    var h = '<div class="cx-facts">' + fact('fx_nc', n[0]) + fact('fx_date', shortDay(n[1])) + fact('fx_line', n[3] || '—') + fact('fx_dec', ruleName(n[7])) + fact('fx_where', whereName(n[8])) + fact('fx_lines', num(lines.length)) + '</div>';
    var ord = st[8] === 'order', fx = ord ? 1 : C.factor, x2 = function (t) { return fx !== 1 ? S('n_x2', { s: t, f: dec(fx) }) : t; }, base = st[3] / fx;
    if (st[10]) h = h.replace('</div>', fact('fx_order', st[10] + ' · ' + S('os_' + (st[9] || 'none'))) + '</div>');
    if (n[44]) h = h.replace('</div>', fact('fx_mat', n[44] + (n[45] ? ' · ' + n[45] : '')) + '</div>');
    if (n[41] === 'missing_ids') h = h.replace('</div>', fact('fx_org', S('org_missing_ids')) + '</div>');
    var notes = {
      alert: st[11] === 'alea' ? S('n_alea', { a: st[12] }) : f[0] && !st[0] ? S('n_noalert') : S('n_once', { x: P.alert }), writing: fin ? S('n_final', { x: P.writeFinal }) : S('n_plain', { x: P.write }), support: S('n_once', { x: P.support }),
      setup: ord ? S('n_ordSetup') + (st[13] ? S('n_logi', { x: num(st[13]) }) : '') : x2(base > P.setup + 1e-6 ? S('n_floor', { a: P.setup, b: dec(base), f: P.floor }) : S('n_once', { x: P.setup })),
      hands: ord ? S('n_ordWork') : x2(!lines.length ? S('n_noline', { x: P.noDefect }) : S('n_lines', { n: num(lines.length) })), recheck: S('n_once', { x: P.recheck })
    };
    var H = S('cxH'), totMin = 0, totEur = 0;
    var tb = '<div class="table-wrap"><table class="cxt"><thead><tr><th scope="col">' + esc(H[0]) + '</th><th scope="col">' + esc(H[1]) + '</th><th scope="col" class="r">' + esc(H[2]) + '</th><th scope="col" class="r">' + esc(H[3]) + '</th></tr></thead><tbody>';
    CX_STEPS.forEach(function (s2, j) {
      var on = !!f[CX_RF[s2[1]]], m = st[j]; if (on) { totMin += m; totEur += C.eur[j]; }
      tb += '<tr' + (on ? '' : ' class="off"') + '><td>' + esc(S('cs_' + s2[0])) + '</td><td>' + esc(on ? notes[s2[0]] : S('n_off')) + '</td><td class="r">' + (on ? esc(mn(m)) : '–') + '</td><td class="r">' + (on ? esc(eur2(C.eur[j])) : '–') + '</td></tr>';
    });
    if (st[6]) tb += '<tr><td>' + esc(S('r_eng')) + '</td><td>' + esc(S('r_eng_how', { h: dec(st[6]), r: dec(P.rateEng) })) + '</td><td class="r">–</td><td class="r">' + esc(eur2(n[18])) + '</td></tr>';
    if (f[3]) tb += '<tr><td>' + esc(S('r_mat')) + '</td><td>' + esc(S('r_mat_how')) + '</td><td class="r">–</td><td class="r">' + esc(eur2(n[17])) + '</td></tr>';
    var adj = C.adj, pv = n[46] || 0;   // the part's value: the price of the NC's material (price list) x its quantity
    if (f[6]) tb += '<tr><td>' + esc(S('r_part')) + '</td><td>' + esc(pv ? S('r_part_list') : S(n[44] ? 'r_part_how' : 'r_part_none')) + '</td><td class="r">–</td><td class="r">' + esc(eur2(pv)) + '</td></tr>';
    if (adj) tb += '<tr><td>' + esc(S('r_adj')) + '</td><td></td><td class="r">–</td><td class="r">' + esc(eur2(adj)) + '</td></tr>';
    if (!costed(n) && totMin) tb += '<tr><td>' + esc(S('r_notaec')) + '</td><td>' + esc(S('r_notaec_how')) + '</td><td class="r">–</td><td class="r">' + esc(eur2(-totEur)) + '</td></tr>';
    tb += '<tr class="total"><td>' + esc(S('r_tot')) + '</td><td></td><td class="r">' + esc(mn(totMin)) + '</td><td class="r">' + esc(eur2(n[12])) + '</td></tr></tbody></table></div>';
    var m2 = (f[0] && st[0] ? P.alert : 0) + f[1] * P.writeGlobal + f[2] * P.support + f[3] * P.workGlobal + f[4] * P.recheck;
    var lv = '<div class="cx-lv"><div>' + esc(S('x2_line', { m: num(m2), c: '\u0001' })).replace('\u0001', '<b>' + esc(eur2(n[10])) + '</b>') + '</div><div>' +
      esc(S('x1_line', { c: '\u0001', l: ruleName(n[7]) })).replace('\u0001', '<b>' + esc(eur2(n[9])) + '</b>') + '</div></div>';
    var dl = '';
    if (lines.length) {
      var D2 = S('dlH'), sm = 0, sa = 0;
      dl = '<details class="vdata" id="cxLines"' + (CX.lines ? ' open' : '') + '><summary>' + esc(S('d_lines', { n: num(lines.length) })) + '</summary><div class="table-wrap"><table class="cxt"><thead><tr>' +
        D2.map(function (x, j) { return '<th scope="col"' + (j >= 3 ? ' class="r"' : '') + '>' + esc(x) + '</th>'; }).join('') + '</tr></thead><tbody>' +
        lines.map(function (ln, j) { var c = C.lines[j]; sm += c[1]; sa += c[2]; return '<tr><td>' + (j + 1) + '</td><td class="txt">' + esc(tidy(ln[18])) + '</td><td>' + esc(G.lang === 'en' ? c[4] : c[3]) + '</td><td class="r">' + esc(mn(c[1])) + '</td><td class="r">' + esc(eur2(c[2])) + '</td></tr>'; }).join('') +
        '<tr class="total"><td></td><td>' + esc(f[3] ? (ord ? S('dl_ord') : x2(S('dl_on'))) : S('dl_off')) + '</td><td></td><td class="r">' + esc(mn(sm)) + '</td><td class="r">' + esc(eur2(sa)) + '</td></tr></tbody></table></div></details>';
    }
    out.innerHTML = h + tb + lv + dl;
  }
  function cxPick(v) {
    v = String(v || '').trim(); if (!v) return;
    CX.nc = NC[v] ? v : (NC[+v] ? +v : v);
    document.querySelectorAll('#cxEx .cxb').forEach(function (b2) { b2.setAttribute('aria-pressed', String(b2.getAttribute('data-cxnc') === String(CX.nc))); });
    renderCxNc();
  }
  document.getElementById('cxGo').addEventListener('click', function () { cxPick(document.getElementById('cxNum').value); });
  document.getElementById('cxNum').addEventListener('keydown', function (e) { if (e.key === 'Enter') cxPick(e.target.value); });
  document.getElementById('cxEx').addEventListener('click', function (e) { var b2 = e.target.closest('[data-cxnc]'); if (b2) { document.getElementById('cxNum').value = ''; cxPick(b2.getAttribute('data-cxnc')); } });
  document.getElementById('cxOut').addEventListener('toggle', function (e) { if (e.target.id === 'cxLines') CX.lines = e.target.open; }, true);

  // ---------------------------------------------------------------- 4c. The disruption block, beside the cost: quality aléas that led to no NC (MES).
  // D.dis rows [id, opened, line, station, work order, minutes, in block, reason, status, comment]; the dates and the line follow the filters.
  // The aléas are the shop floor's: none for REC or FTI. Never added to the cost of non-quality.
  function disSel() {
    if (!D.dis) return null;
    if (GF.phase && GF.phase !== 'SERIE') return [];
    var P = GF.pick, f = !P ? null : P.k === 'month' ? function (a) { return a[1].slice(0, 7) === P.v; } : P.k === 'day' ? function (a) { return a[1].slice(0, 10) === P.v; } :
      P.k === 'week' ? function (a) { return isoWeekOf(new Date(a[1].slice(0, 10) + 'T00:00:00Z')) === P.v; } : P.k === 'station' ? function (a) { return a[3] === P.v; } : null;   // other picks (category, product…) do not apply to an aléa
    return D.dis.filter(function (a) { return a[1] >= GF.from && a[1] <= GF.to && (!GF.line || a[2] === GF.line) && (!f || f(a)); });
  }
  function disRate() { return (CXP && (CXP.p.rateProd || CXP.p.rate)) || 50; }   // time lost on the line: the production rate
  var DIS_WIRED = false;
  function renderDis() {
    var box = document.getElementById('cDis'); if (!box) return;
    var all = disSel(); box.hidden = !all; if (!all) return;
    if (!DIS_WIRED) { v2Wire(box); DIS_WIRED = true; }
    var kept = all.filter(function (a) { return a[6] === 1; }), out = all.filter(function (a) { return a[6] !== 1; }), rate = disRate();
    var mins = sumA(kept.map(function (a) { return a[5]; })), led = SEL_NC.filter(function (n) { return (n[40] || [])[11] === 'alea'; }).length;
    document.getElementById('disFigs').innerHTML = '<div><b>' + esc(eur(mins / 60 * rate)) + '</b><span>' + esc(S('disEur', { r: num(rate) })) + '</span></div>' +
      '<div><b>' + esc(f1(mins / 60)) + '</b><span>' + esc(S('disHours')) + '</span></div><div><b>' + esc(num(kept.length)) + '</b><span>' + esc(S('disN')) + '</span></div>';
    var notes = [];
    if (led) notes.push(S('disLed', { n: num(led) }));
    if (out.length) notes.push(S('disErma', { n: num(out.length), h: f1(sumA(out.map(function (a) { return a[5]; })) / 60) }));
    if (GF.phase && GF.phase !== 'SERIE') notes.push(S('disPhase')); else if (!kept.length) notes.push(S('disNone'));
    document.getElementById('disNotes').innerHTML = notes.map(function (t) { return '<p>' + esc(t) + '</p>'; }).join('');
    // hours per month: one column per month of the period
    var M = [], d = new Date(GF.from.slice(0, 7) + '-01T00:00:00Z'), end = GF.to.slice(0, 7);
    while (d.toISOString().slice(0, 7) <= end && M.length < 36) { M.push(d.toISOString().slice(0, 7)); d.setUTCMonth(d.getUTCMonth() + 1); }
    var by = {}, nb = {}; kept.forEach(function (a) { var m = a[1].slice(0, 7); by[m] = (by[m] || 0) + a[5] / 60; nb[m] = (nb[m] || 0) + 1; });
    var mc = document.getElementById('disMonth'), W = Math.max(220, (mc.clientWidth || 360)), H = 150, mb = 20, mt = 16, n = Math.max(1, M.length), bw = W / n;
    var mx = Math.max.apply(null, M.map(function (m) { return by[m] || 0; }).concat([1e-9])), g = '';
    M.forEach(function (m, i) {
      var v = by[m] || 0, h = v / mx * (H - mb - mt), x = i * bw + bw * 0.18;
      g += '<rect x="' + r1(x) + '" y="' + r1(H - mb - h) + '" width="' + r1(bw * 0.64) + '" height="' + r1(Math.max(v ? 1.5 : 0, h)) + '" rx="2" fill="var(--ink-2)"' +
        pk('month', m) + tip(monthName(m) + ' ' + m.slice(0, 4), [f1(v) + ' h · ' + num(nb[m] || 0) + ' ' + S('disN'), eur(v * rate)]) + '/>';
      if (v && bw >= 26) g += tx(x + bw * 0.32, H - mb - h - 4, f1(v), 'mu', 'middle');
      g += tx(i * bw + bw / 2, H - 5, v2Mo(m, bw, i), 'mu', 'middle');
    });
    mc.innerHTML = svg(W, H, '<line x1="0" x2="' + W + '" y1="' + (H - mb) + '" y2="' + (H - mb) + '" stroke="var(--grid)"/>' + g, S('disMonth'));
    // by line
    var bl = {}; kept.forEach(function (a) { bl[a[2] || '—'] = (bl[a[2] || '—'] || 0) + a[5] / 60; });
    var ls = lineOrder(Object.keys(bl)), lc = document.getElementById('disLines'), LW = Math.max(200, (lc.clientWidth || 260)), rh = 26, lmx = Math.max.apply(null, ls.map(function (l) { return bl[l]; }).concat([1e-9])), lg = '';
    ls.forEach(function (l, i) {
      var y = i * rh + 4, w = bl[l] / lmx * (LW - 120);
      lg += tx(0, y + 13, l, 'ink') + '<rect x="56" y="' + (y + 4) + '" width="' + r1(Math.max(2, w)) + '" height="10" rx="3" fill="' + lineCol(l) + '"' + (l === '—' ? '' : pk('line', l)) + tip(l, [f1(bl[l]) + ' h', eur(bl[l] * rate)]) + '/>' + tx(62 + w, y + 13, f1(bl[l]) + ' h', 'mu');
    });
    lc.innerHTML = ls.length ? svg(LW, ls.length * rh + 6, lg, S('disLine')) : '';
    // the list
    var H2 = S('disCols'), list = all.slice().sort(function (a, b2) { return a[1] < b2[1] ? 1 : a[1] > b2[1] ? -1 : 0; });
    document.getElementById('disListSum').textContent = S('disList', { n: num(all.length) });
    document.getElementById('disList').innerHTML = '<table class="cxt"><thead><tr>' + H2.map(function (h, j) { return '<th scope="col"' + (j === 4 ? ' class="r"' : '') + '>' + esc(h) + '</th>'; }).join('') + '</tr></thead><tbody>' +
      list.map(function (a) { return '<tr' + (a[6] === 1 ? '' : ' class="off"') + '><td class="nc">' + esc(a[0]) + '</td><td class="num">' + esc(shortDay(a[1])) + '</td><td>' + esc(a[2]) + '</td><td>' + esc(a[3]) +
        '</td><td class="num r">' + esc(num(a[5])) + '</td><td class="txt">' + esc(a[9]) + '' + '</td></tr>'; }).join('') + '</tbody></table>';
  }

  // ---------------------------------------------------------------- 4d. Localisation: every NC of the selection, newest first; line, product, MSN and station cells filter the page
  var WT = { lim: 60 };
  function renderWhereTbl() {
    var tb = document.getElementById('whTb'); if (!tb) return;
    var q = (document.getElementById('whQ').value || '').trim().toLowerCase();
    var rs = SEL_NC.filter(function (n) { return !q || [n[0], n[3], n[22], n[25], n[26], n[27], n[33]].join(' ').toLowerCase().indexOf(q) >= 0; })
      .sort(function (a, b) { return a[1] < b[1] ? 1 : a[1] > b[1] ? -1 : (b[0] > a[0] ? 1 : -1); });
    document.getElementById('whN').textContent = num(rs.length);
    document.getElementById('whTh').innerHTML = ['cNc', 'cDate', 'cLine', 'wtProd', 'wtMsn', 'wtSt', 'wtType', 'wtCost', 'wtTitle'].map(function (k, j) { return '<th scope="col"' + (j === 7 ? ' class="r"' : '') + '>' + esc(S(k)) + '</th>'; }).join('');
    var cell = function (k, v, show) { return '<td' + (v ? pk(k, v) + ' class="pickc"' : '') + '>' + esc(show == null ? v || '—' : show) + '</td>'; };
    tb.innerHTML = rs.slice(0, WT.lim).map(function (n) {
      return '<tr><td class="nc"' + pk('nc', n[0]) + '>' + esc(n[0]) + '</td><td class="num">' + esc(shortDay(n[1])) + '</td>' + cell('line', n[3]) + cell('prod', n[26] || 'Other', prodName(n[26] || 'Other')) +
        cell('msn', n[25]) + cell('station', n[27]) + cell('ntype', ncType(n), S('ty_' + ncType(n))) + '<td class="num r">' + esc(eur(n[12])) + '</td><td class="txt">' + esc(n[22] || '') + '</td></tr>';
    }).join('');
    var more = document.getElementById('whM'), rest = rs.length - WT.lim;
    more.hidden = rest <= 0; if (rest > 0) more.textContent = S('more', { n: num(Math.min(200, rest)) });
  }
  document.getElementById('whQ').addEventListener('input', function () { WT.lim = 60; renderWhereTbl(); });
  document.getElementById('whM').addEventListener('click', function () { WT.lim += 200; renderWhereTbl(); });

  // ---------------------------------------------------------------- 4e. Production: per line and per product, the volume built, planned and delivered in 2025,
  // the NCs and the rates and targets made from them; the monthly plan by line; then how these numbers are made and used
  /* ===== ALARM ENGINE START ===== */
  // Alarms: the bell lists what to look at, few lines, nothing raised by a single bad week. One rule for the
  // dashboard and the MFT page (the MFT page has a copy of this block). Four ways something goes wrong, each tested on
  // 2026 against a year where nothing changes:
  //  - rise ("en hausse"): an item of a line (all its defects, a category, a cause, a sub-code, a station, where they are found, a
  //    product, a cable imputation or reason), last 4 finished weeks against the 12 before, per MSN built (working days), binomial
  //    test read in σ. Minor 2.5 σ and still 1.5 σ with the biggest week set aside; major 3 σ, still 2 σ without it and 10 more
  //    defects than usual over the 4 weeks, also without it. Open until 4 weeks under 1 σ, off the list once back under 1 σ;
  //  - several lines ("sur A350 + A330"): a category or cause rising on two lines or more at once, each below the bar on its own
  //    and none carrying 70 % of the rise (a cause they share: a machine, a supplier, a training). 2026: printing defects in
  //    week 39; chance: about 0.2 in 23 weeks;
  //  - slow creep ("en hausse lente"): three blocks of 8 weeks, each 10 % above the one before, the last 3 σ above the first and
  //    still 2 σ without its biggest week, with no rise alarm on it in those last 8 weeks (the weekly view hides it). 2026: A330
  //    Structure Endommagée; chance: about 0.3 in 23 weeks;
  //  - an aircraft far above its siblings: its NCs above both 2.5 times the median and the 90th percentile + 3 of the finished
  //    aircraft of its product, while it still gets NCs. 2026: MSN 851 (14 NCs, a MIP usually ends with 5).
  // Tried and left out: a FIN coming back on several aircraft (as frequent in 2026 as in shuffled data: chance), a new sub-code on
  // 2 aircraft (mostly one-week bursts). Then one line per problem: a sub-code with the same weeks as its cause shows with it
  // ("Inversion (T04)"), a parent gives way to the child carrying 60 % of its rise, stations / places / products / cables join the
  // problem sharing more than half of their NCs; a problem an action covers says so. Weeks: 0 = ISO week 1 of the year followed.
  var ALARM = (function () {
    var P = window.FTO2_ALARM_P;   // the alarm settings (config/3_alarmes.csv), set by the page before this block
    var YEAR = +window.FTO2_YEAR;   // the year followed (config/2_parametres.csv, annee), set by the page before this block
    var LF = [0];
    function lf(n) { for (var i = LF.length; i <= n; i++) LF[i] = LF[i - 1] + Math.log(i); return LF[n]; }
    function tail(x, n, p) {   // P(K >= x) for K binomial (n, p)
      if (x <= 0 || p >= 1) return 1;
      if (p <= 0 || x > n) return 0;
      var lp = Math.log(p), lq = Math.log(1 - p), t = [], m = -Infinity, s = 0, k, v;
      for (k = x; k <= n; k++) { v = lf(n) - lf(k) - lf(n - k) + k * lp + (n - k) * lq; t.push(v); if (v > m) m = v; }
      for (k = 0; k < t.length; k++) s += Math.exp(t[k] - m);
      return Math.min(1, Math.exp(m) * s);
    }
    function invN(p) {   // inverse of the standard normal distribution (Acklam)
      var a = [-39.69683028665376, 220.9460984245205, -275.9285104469687, 138.357751867269, -30.66479806614716, 2.506628277459239],
        b = [-54.47609879822406, 161.5858368580409, -155.6989798598866, 66.80131188771972, -13.28068155288572],
        c = [-0.007784894002430293, -0.3223964580411365, -2.400758277161838, -2.549732539343734, 4.374664141464968, 2.938163982698783],
        d = [0.007784695709041462, 0.3224671290700398, 2.445134137142996, 3.754408661907416], q, r;
      if (p < 0.02425) { q = Math.sqrt(-2 * Math.log(p)); return (((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1); }
      if (p > 1 - 0.02425) { q = Math.sqrt(-2 * Math.log(1 - p)); return -(((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1); }
      q = p - 0.5; r = q * q; return (((((a[0] * r + a[1]) * r + a[2]) * r + a[3]) * r + a[4]) * r + a[5]) * q / (((((b[0] * r + b[1]) * r + b[2]) * r + b[3]) * r + b[4]) * r + 1);
    }
    function sig(x, er, b, eb) {   // how many σ x events over the exposure er stand above b events over eb (0 under 3 events)
      if (x < P.minX || er <= 0 || eb <= 0) return 0;
      return invN(1 - Math.min(Math.max(tail(x, x + b, er / (er + eb)), 1e-12), 1 - 1e-12));
    }
    function week(iso) {   // '2026-05-14' -> its ISO week in the year followed, 0 for week 1; -1 outside that year
      var d = new Date(String(iso).slice(0, 10) + 'T00:00:00Z'), dow = (d.getUTCDay() + 6) % 7;
      if (isNaN(d)) return -1;
      d.setUTCDate(d.getUTCDate() - dow + 3);   // the Thursday of the week decides the year
      if (d.getUTCFullYear() !== YEAR) return -1;
      return Math.floor((d - Date.UTC(YEAR, 0, 1)) / 6048e5);   // week 1 holds the year's first Thursday
    }
    function lastDone(iso) {   // the last finished week up to that day: its own week if it is a Sunday, else the week before
      var d = new Date(String(iso).slice(0, 10) + 'T00:00:00Z');
      if (d.getUTCDay() !== 0) d.setUTCDate(d.getUTCDate() - (d.getUTCDay() + 6) % 7 - 1);
      return week(d.toISOString());
    }
    function sum(it, a, b) {   // counts and MSN over weeks a..b, with the biggest week of them
      var o = { x: 0, e: 0, big: 0, bigE: 0 };
      for (var j = Math.max(0, a); j <= b; j++) { var v = it.w[j] || 0; o.x += v; o.e += it.e ? it.e[j] || 0 : 0; if (v > o.big) { o.big = v; o.bigE = it.e ? it.e[j] || 0 : 0; } }
      return o;
    }
    function ids(it, a, b) { var o = {}; for (var j = Math.max(0, a); j <= b; j++) (it.n[j] || []).forEach(function (id) { o[id] = 1; }); return o; }
    // the rise test of one item at week i: {z, zg (without the biggest week), ex (extra over the 4 weeks, without it), lvl}
    function test(it, i) {
      var R = P.recent, B = P.base, r = sum(it, i - R + 1, i), b = sum(it, i - R - B + 1, i - R);
      var zf = sig(r.x, r.e, b.x, b.e), eg = r.e - r.bigE, zg = sig(r.x - r.big, eg, b.x, b.e);
      var ex = b.e > 0 && eg > 0 ? (r.x - r.big - b.x * eg / b.e) * r.e / eg : 0;
      var lvl = it.hist && !(it.f <= i - R - B + 1 && b.x >= P.hist) ? 0 : zf >= P.zMaj && zg >= P.gMaj && ex >= P.exMaj ? 2 : zf >= P.zMin && zg >= P.gMin ? 1 : 0;
      return { z: zf, zg: zg, ex: ex, lvl: lvl, usual: b.e > 0 ? b.x / b.e * r.e / R : 0 };
    }
    // one item week by week, from `first` to `last`: the alarm open at `last` (null if none) and the last week one was open
    function scan(it, first, last) {
      var o = null, seen = -1, ow = [];
      if (it.hist && it.f == null) { it.f = 0; while (it.f < it.w.length && !it.w[it.f]) it.f++; }   // its first week
      for (var i = Math.max(first, P.recent + P.base - 1); i <= last; i++) {
        var t = test(it, i);
        if (o) {
          o.quiet = t.z < 1 ? o.quiet + 1 : 0;
          if (o.quiet >= P.quiet) { o = null; continue; }
          if (t.lvl > o.lvl) o.lvl = t.lvl;
        } else if (t.lvl) o = { lvl: t.lvl, since: i, quiet: 0 };
        if (o) { seen = i; ow[i] = 1; if (i === last) { o.z = t.z; o.zg = t.zg; o.ex = t.ex; o.usual = t.usual; } }
      }
      return { o: o, seen: seen, ow: ow };
    }
    function creepAt(it, i) {   // three 8-week blocks up to week i, each 10 % above the one before, the last well above the first
      var K = P.block, s3 = i - K + 1, s2 = s3 - K, s1 = s2 - K; if (s1 < 0) return null;
      var b1 = sum(it, s1, s2 - 1), b2 = sum(it, s2, s3 - 1), b3 = sum(it, s3, i);
      if (!(b1.e > 0 && b2.e > 0 && b3.e > 0)) return null;
      var r1 = b1.x / b1.e, r2 = b2.x / b2.e, r3 = b3.x / b3.e;
      if (!(r2 > r1 * P.step && r3 > r2 * P.step)) return null;
      var z = sig(b3.x, b3.e, b1.x, b1.e), g = sig(b3.x - b3.big, b3.e - b3.bigE, b1.x, b1.e);
      return z >= P.creepZ && g >= P.creepG ? { since: s2, ref: b1 } : null;
    }
    // the creep week by week: it opens when nothing in its family had an alarm in those 8 weeks (famOpen) and stays while the last
    // 8 weeks are still 1 σ above the block it started from
    function creep(it, first, last, famOpen) {
      var K = P.block, c = null;
      for (var i = Math.max(first, 3 * K - 1); i <= last; i++) {
        var b3 = sum(it, i - K + 1, i);
        if (c) { c.z = sig(b3.x, b3.e, c.ref.x, c.ref.e); if (c.z < 1) c = null; }
        else { var n = creepAt(it, i); if (n && !famOpen(i - K + 1, i)) c = { lvl: 1, since: n.since, ref: n.ref, z: sig(b3.x, b3.e, n.ref.x, n.ref.e) }; }
        if (c && i === last) c.ex = b3.x - c.ref.x / c.ref.e * b3.e;
      }
      return c;
    }
    var RANK = { all: 0, cat: 0, rca: 0, code: 0, where: 1, station: 2, prod: 3, cimp: 4, cmot: 4 };
    function fam(a) { return RANK[a.lv] === 0; }
    // what is wrong at week `last`, one line per problem, the most important first.
    //  items: [{key, line, lv, v, w: [count per week], e: [MSN per week], n: [[NC ids] per week], hist}]; parentOf(item) -> the key of
    //  its parent ('' for none): line|all| <- line|cat|c <- line|rca|r <- line|code|s;
    //  planes: [{key, line, msn, prod, w: [NCs per week], end: week its build ended (99 if not yet), n}];
    //  acts: [{line, title, start: week, defs: {defect key: 1}}], the actions in progress, their problem's defect lines (items carry
    //  theirs per week in d), to say that one covers a problem
    function run(items, first, last, parentOf, planes, acts) {
      var al = [], by = {}, gone = {}, open = {}, sc = {}, kidsOf = {};
      items.forEach(function (it) { sc[it.key] = scan(it, first, last); var p = parentOf(it); if (p) (kidsOf[p] || (kidsOf[p] = [])).push(it.key); });
      var famOpen = function (key) {   // weeks a..b: was an alarm open on the item, its parents or its children?
        var keys = [key], up = function (k) { var it2 = by0[k], p = it2 ? parentOf(it2) : ''; if (p && sc[p]) { keys.push(p); up(p); } },
          down = function (k) { (kidsOf[k] || []).forEach(function (c) { keys.push(c); down(c); }); };
        up(key); down(key);
        return function (a, b) { return keys.some(function (k) { for (var j = a; j <= b; j++) if (sc[k].ow[j]) return true; return false; }); };
      }, by0 = {};
      items.forEach(function (it) { by0[it.key] = it; });
      items.forEach(function (it) {
        var s = sc[it.key], o = s.o;
        if (o) open[it.key] = 1;
        if (o && o.z >= 1) al.push(Object.assign(o, { kind: 'rise', key: it.key, line: it.line, lv: it.lv, v: it.v, it: it, ncs: ids(it, last - P.recent + 1, last) }));
        else if (!o && (it.lv === 'all' || it.lv === 'cat' || it.lv === 'rca')) {
          var c = creep(it, first, last, famOpen(it.key));
          if (c) al.push(Object.assign(c, { kind: 'creep', key: 'C|' + it.key, line: it.line, lv: it.lv, v: it.v, it: it, ncs: ids(it, last - P.block + 1, last) }));
        }
      });
      // several lines: a category or a cause rising on two lines or more at once, none alarming alone
      var grp = {};
      items.forEach(function (it) { if (it.lv === 'cat' || it.lv === 'rca') (grp[it.lv + '|' + it.v] || (grp[it.lv + '|' + it.v] = [])).push(it); });
      Object.keys(grp).forEach(function (k) {
        var its = grp[k]; if (its.length < 2 || its.some(function (it) { return open[it.key]; })) return;
        var pool = { w: [], e: [], n: [] };
        pool.d = [];
        for (var j = 0; j <= last; j++) { pool.w[j] = 0; pool.e[j] = 0; its.forEach(function (it) { pool.w[j] += it.w[j] || 0; pool.e[j] += it.e[j] || 0; if (it.n[j]) pool.n[j] = (pool.n[j] || []).concat(it.n[j]); if (it.d && it.d[j]) pool.d[j] = (pool.d[j] || []).concat(it.d[j]); }); }
        var s = scan(pool, first, last).o; if (!s || s.z < 1) return;
        var up = [], ex = [];
        its.forEach(function (it) { var t = test(it, last); if (t.z >= 1) up.push(it.line); ex.push(Math.max(0, sum(it, last - P.recent + 1, last).x - (t.usual * P.recent))); });
        var tot = ex.reduce(function (a, b) { return a + b; }, 0);
        if (up.length < 2 || Math.max.apply(null, ex) >= P.crossCarry * tot) return;
        al.push(Object.assign(s, { kind: 'cross', key: 'X|' + k, line: up.join(' + '), lines: up, lv: its[0].lv, v: its[0].v, it: pool, ncs: ids(pool, last - P.recent + 1, last) }));
      });
      // one line per problem: the family of a line (and the several-lines alarms among themselves)
      al.forEach(function (a) { by[a.key] = a; });
      var par = function (a) {   // the key of an alarm's parent alarm, of the same kind
        if (a.kind === 'cross') { var q = parentOf({ line: a.lines[0], lv: a.lv, v: a.v }); return q ? 'X|' + q.split('|').slice(1).join('|') : ''; }
        var p = parentOf(a); return a.kind === 'creep' ? (p ? 'C|' + p : '') : p;
      };
      al.forEach(function (a) { var p = by[par(a)]; if (p && sum(p.it, last - P.recent + 1, last).x === sum(a.it, last - P.recent + 1, last).x && p.kind === a.kind) { p.child = a.v; gone[a.key] = 1; } });
      ['all', 'cat', 'rca'].forEach(function (lv) {
        al.forEach(function (a) {
          if (a.lv !== lv || gone[a.key]) return;
          var kids = al.filter(function (b) { return !gone[b.key] && b.kind === a.kind && par(b) === a.key; });
          if (!kids.length) return;
          if (Math.max.apply(null, kids.map(function (b) { return b.ex; })) >= 0.6 * a.ex) gone[a.key] = 1;   // one child carries the rise
          else { a.kids = kids.map(function (b) { return b.v; }); kids.forEach(function (b) { gone[b.key] = 1; if (b.lvl > a.lvl) a.lvl = b.lvl; if (b.since < a.since) a.since = b.since; }); }
        });
      });
      // the other items join the family problem of their line that shares most of their NCs (more than half of the smaller)
      var out = [];
      al.filter(function (a) { return !gone[a.key]; }).sort(function (a, b) { return (fam(b) ? 1 : 0) - (fam(a) ? 1 : 0) || RANK[a.lv] - RANK[b.lv] || b.lvl - a.lvl || b.ex - a.ex; }).forEach(function (a) {
        var idl = Object.keys(a.ncs), best = null, bs = 0;
        if (!fam(a) && a.kind === 'rise') out.forEach(function (g) {
          if (g.line !== a.line) return;
          var n = 0, m = Object.keys(g.head.ncs).length; idl.forEach(function (id) { if (g.head.ncs[id]) n++; });
          var sh = n / Math.max(1, Math.min(idl.length, m)); if (sh > P.share && sh > bs) { best = g; bs = sh; }
        });
        if (best) { best.also.push(a); if (a.lvl > best.lvl) best.lvl = a.lvl; if (a.since < best.since) best.since = a.since; }
        else out.push({ key: a.key, kind: a.kind, line: a.line, head: a, also: [], lvl: a.lvl, since: a.since, ex: a.ex });
      });
      // aircraft far above the finished aircraft of their product, while they still get NCs
      var bp = {};
      (planes || []).forEach(function (p) { (bp[p.prod] || (bp[p.prod] = [])).push(p); });
      Object.keys(bp).forEach(function (prod) {
        var cum = function (p) { var s = 0; for (var j = 0; j <= last; j++) s += p.w[j] || 0; return s; };
        var done = bp[prod].filter(function (p) { return p.end <= last; }).map(cum).sort(function (a, b) { return a - b; });
        if (done.length < P.planeMin) return;
        var med = done[Math.floor(done.length / 2)], q90 = done[Math.floor(0.9 * (done.length - 1))], lim = Math.max(P.planeK * med, q90 + P.planePlus);
        bp[prod].forEach(function (p) {
          var c = cum(p), r = sum(p, last - P.recent + 1, last).x; if (c <= lim || !r) return;
          var s = 0, since = 0; for (var j = 0; j <= last; j++) { s += p.w[j] || 0; if (s > lim) { since = j; break; } }
          out.push({ key: 'M|' + p.key, kind: 'plane', line: p.line, head: { kind: 'plane', lv: 'msn', v: p.msn, prod: prod, n: c, med: med, it: p, ncs: ids(p, 0, last) }, also: [], lvl: 1, since: since, ex: c - med });
        });
      });
      // a problem an action in progress already covers (more than half of its defect lines): the action is named with it
      (acts || []).forEach(function (ac) {
        out.forEach(function (g) {
          var it = g.head.it; if (g.act || !it || !it.d || g.line.split(' + ').indexOf(ac.line) < 0 || ac.start > last) return;
          var k = 0, n = 0; for (var j = last - (g.kind === 'creep' ? P.block : P.recent) + 1; j <= last; j++) (it.d[j] || []).forEach(function (dk) { n++; if (ac.defs[dk]) k++; });
          if (n && k / n > P.share) g.act = ac;
        });
      });
      var KIND = { rise: 0, cross: 1, creep: 2, plane: 3 };
      return out.sort(function (a, b) { return b.lvl - a.lvl || KIND[a.kind] - KIND[b.kind] || b.ex - a.ex; });
    }
    // a problem marked as seen stays out of the list unless it got worse since: a higher level, half again as many extra defects
    // (5 at least), or it closed and opened again
    function seen(g, m) { return !!m && m.since === g.since && g.lvl <= (m.lvl || 0) && !(g.ex >= 1.5 * (m.ex || 0) && g.ex >= (m.ex || 0) + 5); }
    function docId(key) { var h = 5381; for (var i = 0; i < key.length; i++) h = ((h * 33) ^ key.charCodeAt(i)) >>> 0; return 'a' + h.toString(36) + '-' + key.length; }
    // the last 16 weeks of a problem, per MSN built (counts for an aircraft), as a small line: the last 4 weeks stand out
    function spark(g, last, col) {
      var it = g.head.it, W = 56, H = 18, n = 16, pts = [], mx = 0, i, v;
      for (i = last - n + 1; i <= last; i++) { v = it.e ? (it.e[i] > 0 ? (it.w[i] || 0) / it.e[i] : null) : it.w[i] || 0; pts.push(v); if (v != null && v > mx) mx = v; }
      if (!mx) return '';
      var xy = function (k) { return (2 + k / (n - 1) * (W - 4)).toFixed(1) + ',' + (H - 2 - pts[k] / mx * (H - 4)).toFixed(1); }, a = '', b = '';
      for (i = 0; i < n; i++) if (pts[i] != null) { var s = xy(i); if (i <= n - P.recent) a += (a ? 'L' : 'M') + s; if (i >= n - P.recent) b += (b ? 'L' : 'M') + s; }
      return '<svg class="al-sp" width="' + W + '" height="' + H + '" viewBox="0 0 ' + W + ' ' + H + '" aria-hidden="true"><path d="' + a + '" fill="none" stroke="var(--dim)" stroke-width="1.5"/><path d="' + b + '" fill="none" stroke="' + col + '" stroke-width="2"/></svg>';
    }
    return { P: P, run: run, seen: seen, week: week, lastDone: lastDone, docId: docId, sig: sig, spark: spark };
  })();
  /* ===== ALARM ENGINE END ===== */
  // the bell: what to look at, for the selection's production type, plant and data source, on the lines of the
  // aircraft filter (the other lines counted below), as of the last finished week of the period; five lines at most, the others
  // folded. A problem can be marked as seen (the page's store, collection 'alarmes'; not in Slate): it leaves the list for
  // everyone and comes back if it gets worse.
  var AL = { db: null, uid: null, marks: {}, open: false, more: false };   // the bell's own state; the alarms themselves: ALC (model.js)
  function alName(a) {
    var v = a.v, cd = a.lv === 'code' ? codeDesc(v).split(' (')[0] : '';
    var s = a.lv === 'all' ? S('alAll') : a.lv === 'cat' || a.lv === 'rca' ? L(v) : a.lv === 'code' ? v + (cd ? ' · ' + cd : '') : a.lv === 'where' ? whereName(v) :
      a.lv === 'station' ? S('alSt', { v: v }) : a.lv === 'prod' ? prodName(v) : a.lv === 'cimp' || a.lv === 'cmot' ? S('alCab', { v: cbLab(v) }) : v;
    return s + (a.child ? ' (' + (a.lv === 'cat' ? L(a.child) : a.child) + ')' : '');
  }
  function alTab(a) { return a.kind === 'plane' || a.lv === 'where' || a.lv === 'station' || a.lv === 'prod' ? 'where' : a.lv === 'cimp' || a.lv === 'cmot' ? 'cbl' : 'pareto'; }
  function alWk(i) { return S('alWk', { n: i + 1 }); }
  function alText(g) {
    var a = g.head, s = alWk(g.since);
    if (g.kind === 'plane') return S('alPlane', { m: a.v, n: a.n, p: a.prod, d: a.med });
    return S(g.kind === 'cross' ? 'alCross' : g.kind === 'creep' ? 'alCreep' : 'alUp', { w: alName(a), s: s });
  }
  function alRender() {
    var btn = document.getElementById('alBtn'), pop = document.getElementById('alPop'); if (!btn) return;
    var A2 = alarmesNow(), res = A2 && A2.res; btn.hidden = !res; if (!res) { pop.hidden = true; return; }   // null while Slate computes them
    var onLine = function (g) { return !GF.line || g.line.split(' + ').indexOf(GF.line) >= 0; };
    var mine = res.filter(onLine), other = res.length - mine.length;
    var show = mine.filter(function (g) { return !ALARM.seen(g, AL.marks[g.key]); }), hid = mine.filter(function (g) { return ALARM.seen(g, AL.marks[g.key]); });
    var maj = show.some(function (g) { return g.lvl === 2; }), nEl = document.getElementById('alN');
    btn.classList.toggle('maj', maj); nEl.hidden = !show.length; nEl.textContent = show.length;
    btn.setAttribute('aria-expanded', String(AL.open)); btn.title = S('alBtn') + (show.length ? ' · ' + show.length : '');
    pop.hidden = !AL.open; if (!AL.open) return;
    // kept on screen: under the bell, inside the page's width (on a phone the bell is not at the right edge)
    var wr = document.getElementById('alWrap').getBoundingClientRect(), PW = document.documentElement.clientWidth, pw = Math.min(460, PW - 32), px = Math.max(16, Math.min(wr.right - pw, PW - pw - 16));
    pop.style.width = pw + 'px'; pop.style.left = Math.round(px - wr.left) + 'px'; pop.style.right = 'auto';
    var can = !!AL.db, row = function (g, isSeen) {
      var a = g.head, sub = [], also = g.also.filter(function (x) { return x.lv !== 'prod'; });   // the product is the line's, it adds nothing
      if (a.kids) sub.push(S('alDont', { l: a.kids.map(function (v) { return alName({ lv: a.lv === 'all' ? 'cat' : a.lv === 'cat' ? 'rca' : 'code', v: v }); }).join(', ') }));
      if (also.length) sub.push(S('alAlso', { l: also.map(alName).join(', ') }));
      if (g.act) sub.push(S('alAct', { t: g.act.title }));
      return '<div class="al-row"><button type="button" class="al-go" data-algo="' + esc(g.key) + '"><i class="al-dot ' + (g.lvl === 2 ? 'maj' : 'min') + '" title="' + esc(S(g.lvl === 2 ? 'alMaj' : 'alMin')) + '"></i>' +
        '<span class="al-what"><b>' + esc(g.line) + '</b> · ' + esc(alText(g)) + '</span>' + (sub.length ? '<span class="al-sub">' + esc(sub.join(' · ')) + '</span>' : '') +
        '<span class="al-sub">→ ' + esc(S({ pareto: 'tabPareto', where: 'tabWhere', cbl: 'tabCbl', det: 'tabDet' }[alTab(g.head.kind === 'plane' ? g.head : Object.assign({ kind: g.kind }, g.head))])) + '</span></button>' +
        '<span class="al-ops">' + ALARM.spark(g, A2.last, g.lvl === 2 ? 'var(--up)' : 'var(--ink-2)') + (can ? '<button type="button" class="al-vu" data-al' + (isSeen ? 'un' : 'vu') + '="' + esc(g.key) + '">' + esc(S(isSeen ? 'alBack' : 'alSeen')) + '</button>' : '') + '</span></div>';
    };
    var top = show.slice(0, ALARM.P.show), rest = show.slice(ALARM.P.show);
    pop.innerHTML = '<div class="al-head"><h3 id="alT">' + esc(S('alT', { w: alWk(A2.last) })) + '</h3><button type="button" class="al-x" id="alX" aria-label="' + esc(S('alClose')) + '">✕</button></div>' +
      (A2.last < A2.first ? '<p class="mu">' + esc(S('alShort')) + '</p>' : top.length ? top.map(function (g) { return row(g, false); }).join('') : '<p class="mu">' + esc(S('alNone')) + '</p>') +
      (rest.length ? '<details class="al-seen"' + (AL.more ? ' open' : '') + ' id="alMore"><summary>' + esc(S('alMore', { n: rest.length })) + '</summary>' + rest.map(function (g) { return row(g, false); }).join('') + '</details>' : '') +
      (other ? '<p class="mu al-other">' + esc(S('alOther', { n: other })) + '</p>' : '') +
      (hid.length ? '<details class="al-seen"><summary>' + esc(S('alSeenL', { n: hid.length })) + '</summary>' + hid.map(function (g) { return row(g, true); }).join('') + '</details>' : '');
    var mo = document.getElementById('alMore'); if (mo) mo.addEventListener('toggle', function () { AL.more = mo.open; });
  }
  function alGo(key) {
    var g = ((alarmesNow() || {}).res || []).filter(function (x) { return x.key === key; })[0]; if (!g) return;
    var a = g.head, tab = alTab(g.kind === 'plane' ? a : Object.assign({ kind: g.kind }, a));
    AL.open = false; GF.line = g.kind === 'cross' ? '' : g.line;
    if (tab === 'cbl') { GF.pick = null; CBF = { origine: a.lv === 'cimp' ? a.v : '', motif: a.lv === 'cmot' ? a.v : '', cause: '', cable: '' }; }
    else { var k = { cat: 'cat', rca: 'rca', code: 'code', station: 'station', where: 'where', prod: 'pprod', msn: 'msn' }[a.lv]; GF.pick = k ? { k: k, v: a.v } : null; }
    pickPrep(); setGF({}); setTab(tab);
    var p = document.getElementById('p-' + tab); if (p && p.scrollIntoView) p.scrollIntoView({ block: 'start' });
  }
  function alMark(key, on) {
    var g = ((alarmesNow() || {}).res || []).filter(function (x) { return x.key === key; })[0]; if (!AL.db || !g) return;
    var ref = AL.db.collection('alarmes').doc(ALARM.docId(key));
    (on ? ref.set({ key: key, line: g.line, since: g.since, lvl: g.lvl, ex: Math.round(g.ex * 10) / 10, at: new Date().toISOString().slice(0, 10), by: AL.uid || '' }) : ref.delete()).catch(function () {});
  }
  (function () {
    var w = document.getElementById('alWrap'); if (!w) return;
    if (window.FTO2_PREVIEW && window.FTO2_PREVIEW.al) window.FTO2_AL = { compute: alCompute, name: alName, text: alText };   // checks only
    w.addEventListener('click', function (e) {
      var t = e.target.closest('button'); if (!t) return;
      if (t.id === 'alBtn') { AL.open = !AL.open; alRender(); return; }
      if (t.id === 'alX') { AL.open = false; alRender(); document.getElementById('alBtn').focus(); return; }
      if (t.hasAttribute('data-algo')) { alGo(t.getAttribute('data-algo')); return; }
      if (t.hasAttribute('data-alvu')) { alMark(t.getAttribute('data-alvu'), true); return; }
      if (t.hasAttribute('data-alun')) alMark(t.getAttribute('data-alun'), false);
    });
    document.addEventListener('click', function (e) { if (AL.open && !w.contains(e.target)) { AL.open = false; alRender(); } });
    document.addEventListener('keydown', function (e) { if (AL.open && e.key === 'Escape') { AL.open = false; alRender(); document.getElementById('alBtn').focus(); } });
    // the page's store (window.FTO2_STORE, the MFT page's calls), when one is given: none is today, so the bell keeps no mark
    if (EMBED || !window.FTO2_STORE || typeof window.FTO2_STORE.use !== 'function') return;
    window.FTO2_STORE.use('user').then(function (u) { if (u && u.id) return u.id().then(function (id) { AL.uid = id; }); }).catch(function () {});
    window.FTO2_STORE.use('db').then(function (db) {
      if (!db) return; AL.db = db;
      db.collection('alarmes').onSnapshot(function (snap) {
        var m = {}; snap.docs.forEach(function (d) { var x = d.data(); if (x && x.key) m[x.key] = x; }); AL.marks = m; alRender();
      }, function () {});
      alRender();
    }).catch(function () {});
  })();
  // Câbles: the cable team's requests for new cables, as on the "Suivi NC câbles" page (D.cables, one row per
  // request: [row, week, date, NC, programme, MSN, reason, imputation, proposed cause, cables, cable type, comment, has an action]),
  // under the filter bar's aircraft and period. A reason, an imputation, a cause or a cable clicked filters the list of requests
  // (chips at the top); the other cards only mark it. Imputation colours: teal, amber, plum (checked for colour blindness), greys.
  var CB_IMP = ['Production ligne', 'Impression – machine', 'Impression – opérateur', 'Définition (BE / ME)', 'Autre / non renseigné'],
    CB_COL = ['var(--c7)', 'var(--c3)', 'var(--c9)', 'var(--muted)', 'var(--dim)'], CB_UNK = 'Inconnu – à analyser',
    CBF = { origine: '', motif: '', cause: '', cable: '' }, CB_Q = '', CB_M = 'req';   // CB_M: count the requests (req) or the cables asked for (cab)
  var CB_EN = { 'Câble court': 'Short cable', 'Câble abimé': 'Damaged cable', 'Câble manquant': 'Missing cable', 'Câble coupé': 'Cut cable',
    'Câble non conforme': 'Non-conforming cable', 'Rail abimé': 'Damaged rail', 'Production ligne': 'Production line', 'Impression – machine': 'Printing – machine',
    'Impression – opérateur': 'Printing – operator', 'Définition (BE / ME)': 'Definition (design office / ME)', 'Autre / non renseigné': 'Other / blank',
    'Inconnu – à analyser': 'Unknown – to analyse', 'Coupé en production (geste à préciser)': 'Cut in production (how not stated)', 'Mauvais cheminement': 'Wrong routing',
    'Mauvaise mise en œuvre (sertissage, buscan…)': 'Poor installation (crimping, buscan…)', 'Oubli dans le lot': 'Left out of the batch', 'Mauvaise jauge / type': 'Wrong gauge / type',
    'Longueur machine (réglage / isolant)': 'Machine length (setting / insulation)', 'Marquage laser absent ou illisible': 'Laser marking missing or unreadable',
    'Longueur trop courte à la def': 'Too short in the drawing', 'Mauvais numéro': 'Wrong number', 'Pincé / écrasé': 'Pinched / crushed',
    'Défaut isolant (bobine)': 'Insulation defect (reel)', 'Entaillé / isolant abîmé': 'Nicked / insulation damaged', 'Coupe à la main': 'Cut by hand' };
  function cbLab(v) { return G.lang === 'en' && CB_EN[v] ? CB_EN[v] : v; }
  function cbI(o) { var i = CB_IMP.indexOf(o); return i < 0 ? 4 : i; }
  function cbQn(r) { return 'T' + Math.ceil(+r.d.slice(5, 7) / 3); }
  function cbRows() {
    return (D.cables || []).map(function (a) { return { k: a[0], wk: a[1], d: a[2], nc: a[3], prog: a[4], msn: a[5], motif: a[6], imp: a[7], cause: a[8], cables: String(a[9] || '').split(' ').filter(Boolean), type: a[10], com: a[11], act: a[12] }; })
      .filter(function (r) { return (!GF.line || (r.prog === 'A321' ? 'A320' : r.prog) === GF.line) && r.d >= GF.from && r.d <= GF.to; });
  }
  // what a request counts for: 1, or the number of cables it asks for (the cables written, one when none is written)
  function cbW(r) { return CB_M === 'cab' ? Math.max(1, r.cables.length) : 1; }
  function cbSum(rs) { return rs.reduce(function (a, r) { return a + cbW(r); }, 0); }
  function cbAttr(k, v, extra) { return ' data-cb="' + k + '" data-v="' + esc(v) + '"' + (extra || ''); }
  function renderCbl() {
    if (G.tab !== 'cbl') return;
    var body = document.getElementById('cbBody'); if (!body) return;
    if (!D.cables || !D.cables.length) { body.innerHTML = '<p class="empty">' + esc(S('cbNoData')) + '</p>'; return; }
    var R = cbRows(), ms = Object.keys(R.reduce(function (o, r) { o[r.d.slice(0, 7)] = 1; return o; }, {})).sort(), qs = ['T1', 'T2', 'T3', 'T4'].filter(function (q) { return R.some(function (r) { return cbQn(r) === q; }); });
    var qn = function (q) { return S('cbQ') + q.slice(1); }, imp = function (q) { var x = R.filter(function (r) { return cbQn(r) === q; }); return x.length ? 100 * cbSum(x.filter(function (r) { return r.imp.indexOf('Impression') === 0; })) / cbSum(x) : null; };
    var cab = CB_M === 'cab';
    document.getElementById('cbMode').innerHTML = segHtml([['req', S('cbReq')], ['cab', S('cbCab')]], CB_M, 'data-cbm');
    document.getElementById('cbModeN').textContent = cab ? S('cbCabNote') : '';
    document.getElementById('cbMonthH').textContent = S(cab ? 'cbMonthC' : 'cbMonth');
    var ml = function (m) { return day(m + '-15', { month: 'long' }); };
    document.getElementById('cbPer').textContent = ms.length ? ml(ms[0]) + ' – ' + ml(ms[ms.length - 1]) + ' ' + ms[ms.length - 1].slice(0, 4) : '—';
    document.getElementById('cbQ').placeholder = S('cbSearch');
    // chips: what filters the list of requests
    var ch = []; [['origine', function (v) { return cbLab(v); }], ['motif', cbLab], ['cause', cbLab], ['cable', function (v) { return S('cbCableChip', { c: v }); }]].forEach(function (x) {
      if (CBF[x[0]]) ch.push('<button type="button" class="chip" data-cbx="' + x[0] + '">' + esc(x[1](CBF[x[0]])) + ' ×</button>'); });
    if (ch.length > 1) ch.push('<button type="button" class="chip" data-cbx="all">' + esc(S('cbClear')) + '</button>');
    document.getElementById('cbChips').innerHTML = ch.join('');
    // cables written in two NCs or more
    var by = {}; R.forEach(function (r) { r.cables.forEach(function (c) { var b = by[c] || (by[c] = { nc: {}, msn: {}, motif: {}, imp: {} }); b.nc[r.nc] = 1; b.msn[r.msn] = 1; b.motif[r.motif] = 1; b.imp[r.imp] = 1; }); });
    var rec = Object.keys(by).filter(function (c) { return Object.keys(by[c].nc).length >= 2; }).map(function (c) { var b = by[c]; return { c: c, n: Object.keys(b.nc).length, m: Object.keys(b.msn).length, motifs: Object.keys(b.motif), imps: Object.keys(b.imp) }; })
      .sort(function (a, b) { return b.n - a.n || b.m - a.m || a.c.localeCompare(b.c); });
    var withCause = cbSum(R.filter(function (r) { return r.cause !== CB_UNK; })), qL = qs[qs.length - 1];
    document.getElementById('cbFigs').innerHTML = [[num(cbSum(R)), S(cab ? 'cbF1c' : 'cbF1')], [qL && imp(qL) != null ? pct0(imp(qL)) : '—', S('cbF2', { q: qL ? qn(qL) : '' })], [R.length ? pct0(100 * withCause / cbSum(R)) : '—', S(cab ? 'cbF3c' : 'cbF3')], [num(rec.length), S('cbF4')], [num(cbSum(R.filter(function (r) { return r.act; }))), S(cab ? 'cbF5c' : 'cbF5')]]
      .map(function (x) { return '<div class="fig"><b>' + esc(x[0]) + '</b><span>' + esc(x[1]) + '</span></div>'; }).join('');
    document.getElementById('cbShare').textContent = S('cbShare', { v: qs.map(function (q) { var v = imp(q); return qn(q) + ' ' + (v == null ? '—' : pct0(v)); }).join(' · ') });
    // requests per month, stacked by imputation
    var imps = CB_IMP.filter(function (o) { return R.some(function (r) { return r.imp === o; }); }), mc = document.getElementById('cbMonthC');
    document.getElementById('cbLeg').innerHTML = imps.map(function (o) { return '<button type="button" class="cb-leg"' + cbAttr('origine', o, ' aria-pressed="' + (!CBF.origine || CBF.origine === o) + '"') + '><i class="sw" style="background:' + CB_COL[cbI(o)] + '"></i>' + esc(S('cbI' + cbI(o))) + '</button>'; }).join('');
    var cnt = ms.map(function (m) { var o = { t: 0 }; imps.forEach(function (i) { o[i] = 0; }); R.forEach(function (r) { if (r.d.slice(0, 7) === m) { o[r.imp] += cbW(r); o.t += cbW(r); } }); return o; });
    var W = Math.max(300, mc.clientWidth || 600), H = 240, l0 = 34, mb = 22, mt = 18, n = ms.length || 1, bw = (W - l0) / n, w = Math.min(32, bw * 0.6);
    var nt = pNice(Math.max.apply(null, cnt.map(function (o) { return o.t; }).concat([1])) * 1.08), Y = function (v) { return mt + (H - mt - mb) * (1 - v / nt.top); }, g = '';
    for (var t0 = 0; t0 <= nt.top + 1e-9; t0 += nt.step) g += '<line x1="' + l0 + '" x2="' + W + '" y1="' + r1(Y(t0)) + '" y2="' + r1(Y(t0)) + '" stroke="var(--grid)"/>' + tx(l0 - 6, Y(t0) + 4, num(t0), 'mu', 'end');
    ms.forEach(function (m, i) { var x = l0 + i * bw + (bw - w) / 2, acc = 0, o = cnt[i];
      imps.forEach(function (im) { var v = o[im]; if (!v) return;
        g += '<rect x="' + r1(x) + '" y="' + r1(Y(acc + v) + 1) + '" width="' + r1(w) + '" height="' + r1(Math.max(0.5, Y(acc) - Y(acc + v) - 2)) + '" rx="3" fill="' + CB_COL[cbI(im)] + '"' + (CBF.origine && CBF.origine !== im ? ' fill-opacity=".22"' : '') + cbAttr('origine', im) +
          tip(monthName(m) + ' ' + m.slice(0, 4), imps.slice().reverse().map(function (j) { return S('cbI' + cbI(j)) + ' : ' + o[j]; }).concat([S('total') + ' : ' + o.t])) + '/>'; acc += v; });
      if (w >= 18 && o.t) g += tx(x + w / 2, Y(o.t) - 5, num(o.t), 'ink', 'middle');
      g += tx(l0 + i * bw + bw / 2, H - 6, day(m + '-15', { month: 'short' }), 'mu', 'middle'); });
    mc.innerHTML = svg(W, H, g, S(cab ? 'cbMonthC' : 'cbMonth'));
    // reason x imputation
    var cols = [['cbProd', 'Production ligne'], ['cbMach', 'Impression – machine'], ['cbOper', 'Impression – opérateur'], ['cbOther', null]], mot = {};
    R.forEach(function (r) { var a = mot[r.motif] || (mot[r.motif] = { m: r.motif, v: [0, 0, 0, 0], t: 0 }), j = r.imp === CB_IMP[0] ? 0 : r.imp === CB_IMP[1] ? 1 : r.imp === CB_IMP[2] ? 2 : 3; a.v[j] += cbW(r); a.t += cbW(r); });
    var mrows = Object.keys(mot).map(function (k) { return mot[k]; }).sort(function (a, b) { return b.t - a.t; }), mmax = Math.max.apply(null, mrows.map(function (a) { return Math.max.apply(null, a.v); }).concat([1]));
    var th = function (a) { return '<thead><tr>' + a.map(function (h, j) { return '<th scope="col"' + (j && h !== 'cbMotifs' && h !== 'cbImp' ? ' class="r"' : '') + '>' + esc(S(h)) + '</th>'; }).join('') + '</tr></thead>'; };
    document.getElementById('cbMx').innerHTML = mrows.length ? '<table class="cxt">' + th(['cbMotif', 'cbProd', 'cbMach', 'cbOper', 'cbOther', 'total']) + '<tbody>' + mrows.map(function (a) {
      return '<tr><th scope="row"' + cbAttr('motif', a.m, ' tabindex="0"') + '>' + esc(cbLab(a.m)) + '</th>' + cols.map(function (c, j) { var v = a.v[j], col = c[1] ? CB_COL[cbI(c[1])] : 'var(--dim)';
        return '<td class="r' + (c[1] ? ' cb-c' : '') + (c[1] && CBF.motif === a.m && CBF.origine === c[1] ? ' cb-on' : '') + '"' + (v ? ' style="background:color-mix(in srgb, ' + col + ' ' + Math.round(8 + 42 * v / mmax) + '%, transparent)"' : '') +
          (c[1] ? ' data-cb="cell" data-m="' + esc(a.m) + '" data-v="' + esc(c[1]) + '" tabindex="0"' : '') + '>' + num(v) + '</td>'; }).join('') + '<td class="r">' + num(a.t) + '</td></tr>'; }).join('') + '</tbody></table>' : '<p class="empty">' + esc(S('cbNone')) + '</p>';
    // cable types, the eight most frequent, cut by imputation
    var ty = {}; R.forEach(function (r) { if (!r.type) return; var a = ty[r.type] || (ty[r.type] = { t: 0, v: {} }); a.t += cbW(r); a.v[r.imp] = (a.v[r.imp] || 0) + cbW(r); });
    var tks = Object.keys(ty).sort(function (a, b) { return ty[b].t - ty[a].t; }).slice(0, 8), tmax = tks.length ? ty[tks[0]].t : 1;
    document.getElementById('cbTypes').innerHTML = tks.map(function (k) { var a = ty[k];
      return '<div class="cb-row"><span class="cb-lab">' + esc(k) + '</span><span><span class="cb-track" style="width:' + r1(100 * a.t / tmax) + '%">' + CB_IMP.filter(function (o) { return a.v[o]; }).map(function (o) {
        return '<span class="cb-seg" style="flex:' + a.v[o] + ';background:' + CB_COL[cbI(o)] + (CBF.origine && CBF.origine !== o ? ';opacity:.22' : '') + '"' + tip(k, [S('cbI' + cbI(o)) + ' : ' + a.v[o]]) + '></span>'; }).join('') + '</span></span><span class="cb-val">' + num(a.t) + '</span></div>'; }).join('') || '<p class="empty">' + esc(S('cbNone')) + '</p>';
    // proposed causes (under the imputation chosen), coloured by the imputation where each is most frequent; unknown last, in grey
    var own = {}, cn = {}; R.forEach(function (r) { var o = own[r.cause] || (own[r.cause] = {}); o[r.imp] = (o[r.imp] || 0) + cbW(r); if (!CBF.origine || r.imp === CBF.origine) cn[r.cause] = (cn[r.cause] || 0) + cbW(r); });
    var ownOf = function (c) { var o = own[c] || {}; return Object.keys(o).sort(function (a, b) { return o[b] - o[a]; })[0]; }, cks = Object.keys(cn), cmax = Math.max.apply(null, cks.map(function (c) { return cn[c]; }).concat([1]));
    var crow = function (c, col) { return '<button type="button" class="cb-row' + (CBF.cause && CBF.cause !== c ? ' dim' : '') + '"' + cbAttr('cause', c, ' aria-pressed="' + (CBF.cause === c) + '"') + '><span class="cb-lab">' + esc(cbLab(c)) + '</span><span class="cb-track"><span class="cb-seg" style="width:' + r1(100 * cn[c] / cmax) + '%;background:' + col + '"></span></span><span class="cb-val">' + num(cn[c]) + '</span></button>'; };
    document.getElementById('cbCauses').innerHTML = cks.length ? cks.filter(function (c) { return c !== CB_UNK; }).sort(function (a, b) { return cn[b] - cn[a]; }).map(function (c) { return crow(c, CB_COL[cbI(ownOf(c))]); }).join('') +
      (cn[CB_UNK] ? '<div class="cb-sep"></div>' + crow(CB_UNK, 'var(--dim)') : '') : '<p class="empty">' + esc(S('cbNone')) + '</p>';
    // recurring cables
    document.getElementById('cbRec').innerHTML = rec.length ? '<table class="cxt">' + th(['cbCable', 'NC', 'MSN', 'cbMotifs', 'cbImp']) + '<tbody>' + rec.map(function (a) {
      return '<tr' + cbAttr('cable', a.c, ' tabindex="0"') + (CBF.cable === a.c ? ' class="cb-sel"' : '') + '><td>' + esc(a.c) + '</td><td class="r">' + num(a.n) + '</td><td class="r">' + num(a.m) + '</td><td>' + esc(a.motifs.map(cbLab).join(', ')) + '</td><td>' + esc(a.imps.map(cbLab).join(', ')) + '</td></tr>'; }).join('') + '</tbody></table>' : '<p class="empty">' + esc(S('cbNone')) + '</p>';
    cbList(R);
  }
  function cbList(R) {
    var q = CB_Q.trim().toLowerCase(), rows = R.filter(function (r) {
      return (!CBF.origine || r.imp === CBF.origine) && (!CBF.motif || r.motif === CBF.motif) && (!CBF.cause || r.cause === CBF.cause) && (!CBF.cable || r.cables.indexOf(CBF.cable) >= 0) &&
        (!q || [r.nc, r.msn, r.wk, r.cables.join(' '), r.type, r.com, r.motif, r.cause, r.imp, cbLab(r.motif), cbLab(r.cause), cbLab(r.imp)].join(' ').toLowerCase().indexOf(q) >= 0); })
      .sort(function (a, b) { return b.d.localeCompare(a.d) || b.k - a.k; });
    document.getElementById('cbN').textContent = CB_M === 'cab' ? S('cbNc', { n: num(rows.length), c: num(cbSum(rows)) }) : rows.length === 1 ? S('cbN1') : S('cbN', { n: num(rows.length) });
    var h = ['cbWk', 'NC', 'cbProg', 'MSN', 'cbMotif', 'cbImp', 'cbCause', 'cbCables', 'cbCom'];
    document.getElementById('cbList').innerHTML = rows.length ? '<table class="cxt"><thead><tr>' + h.map(function (k) { return '<th scope="col">' + esc(S(k)) + '</th>'; }).join('') + '</tr></thead><tbody>' + rows.map(function (r) {
      return '<tr><td>' + esc(r.wk) + '</td><td>' + esc(r.nc) + '</td><td>' + esc(r.prog) + '</td><td>' + esc(r.msn) + '</td><td>' + esc(cbLab(r.motif)) + '</td><td>' + esc(cbLab(r.imp)) + '</td><td>' + esc(cbLab(r.cause)) + '</td><td>' + esc(r.cables.join(' ')) + '</td><td class="cb-com">' + esc(r.com) + '</td></tr>'; }).join('') + '</tbody></table>' : '<p class="empty">' + esc(S('cbNone')) + '</p>';
  }
  (function () {
    var p = document.getElementById('p-cbl'); if (!p) return;
    p.addEventListener('click', function (e) {
      var md = e.target.closest('[data-cbm]'); if (md) { CB_M = md.getAttribute('data-cbm'); hideTip(); renderCbl(); return; }
      var x = e.target.closest('[data-cbx]'); if (x) { var k = x.getAttribute('data-cbx'); if (k === 'all') CBF = { origine: '', motif: '', cause: '', cable: '' }; else CBF[k] = ''; renderCbl(); return; }
      var b = e.target.closest('[data-cb]'); if (!b) return;
      var t = b.getAttribute('data-cb'), v = b.getAttribute('data-v');
      if (t === 'cell') { var m = b.getAttribute('data-m'), on = CBF.motif === m && CBF.origine === v; CBF.motif = on ? '' : m; CBF.origine = on ? '' : v; }
      else if (t === 'motif') { CBF.motif = CBF.motif === v && !CBF.origine ? '' : v; CBF.origine = ''; }
      else CBF[t] = CBF[t] === v ? '' : v;
      hideTip(); renderCbl();
    });
    p.addEventListener('keydown', function (e) { var b = e.target.closest('[data-cb]'); if (b && b.tagName !== 'BUTTON' && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); b.click(); } });
    p.addEventListener('pointermove', function (e) { var t = e.target.closest && e.target.closest('[data-tip]'); if (t) showTip(e, t.getAttribute('data-tip').split('|')); else hideTip(); });
    p.addEventListener('pointerleave', hideTip);
    document.getElementById('cbQ').addEventListener('input', function (e) { CB_Q = e.target.value; cbList(cbRows()); });
  })();
  // ---------------------------------------------------------------- 2025 and 2026 month by month: NCs, MSN and NCs per MSN, in three
  // panels on the same months (no second scale). The line group of the per-MSN charts (A330 + A350, or A320; a line chosen in the filter
  // bar wins), split by line. Every filter applies except the period: January 2025 to the last NC. MSN 2025: products delivered in the
  // month (Livraisons 2025, as the 2025 targets); MSN 2026: products built, spread over the working days (the plan, as the other charts).
  // The two years count MSN differently: the rate's line breaks between them, each year has its own average.
  Object.assign(STR.fr, withYears({ yyT: '{PREV} et {YEAR}, mois par mois', yyS: 'MSN {PREV} : produits {LIV}és dans le mois. MSN {YEAR} : produits fabriqués, répartis sur les jours ouvrés.',
    yyNc: 'NC', yyMsn: 'MSN', yyRate: 'NC par MSN', yyAvg: 'moy. {y} : {v}', yyNo25: 'Pas de {PREV} avec ce filtre.', yyPart: 'Clair : mois en cours, jusqu’au {d}', yyTo: 'jusqu’au {d}' }));
  Object.assign(STR.en, withYears({ yyT: '{PREV} and {YEAR}, month by month', yyS: 'MSN {PREV}: products {DLV} in the month. MSN {YEAR}: products built, spread over the working days.',
    yyNc: 'NCs', yyMsn: 'MSN', yyRate: 'NCs per MSN', yyAvg: '{y} avg: {v}', yyNo25: 'No {PREV} with this filter.', yyPart: 'Light: current month, to {d}', yyTo: 'to {d}' }));
  function renderYY() {
    var box = document.getElementById('yyC'); if (!box) return;
    var E = pSrc(); if (!E || E !== D.eqmsn || !PD) { box.innerHTML = ''; document.getElementById('yyL').innerHTML = ''; return; }
    document.getElementById('yyGrp').innerHTML = grpSeg();
    var LN = GF.line ? [GF.line] : G320 ? ['A320'] : ['A330', 'A350'], inL = function (l) { return LN.indexOf(l) >= 0; };
    var last = D.meta.to.slice(0, 7), Y5 = D.y25, m25 = (Y5 && Y5.months) || [], R5 = y25Sel(), months = m25.slice();
    PD.months.forEach(function (m) { if (m <= last && months.indexOf(m) < 0) months.push(m); });
    var cols = months.map(function (m) { var o = { m: m, nc: {}, msn: {} }; LN.forEach(function (l) { o.nc[l] = 0; o.msn[l] = 0; }); return o; }), at = {};
    cols.forEach(function (o, j) { at[o.m] = j; });
    var L25 = (Y5 && Y5.prod) || {};
    Object.keys(L25).forEach(function (p) { var l = E.line[p]; if (!inL(l)) return; m25.forEach(function (m, i) { var j = at[m]; if (j != null) cols[j].msn[l] += L25[p][i] || 0; }); });
    PD.all.forEach(function (p) { var l = E.line[p]; if (!inL(l)) return; PD.months.forEach(function (m, i) { var j = at[m]; if (j != null) cols[j].msn[l] += (PD.prod[p][i] || 0) * (PD.part[i] == null ? 1 : PD.part[i]); }); });
    (R5 || []).forEach(function (x) { if (!inL(x.line)) return; var j = at[x.m]; if (j != null) cols[j].nc[x.line] += x.nc; });
    var k0 = [GF.preset, GF.from, GF.to]; GF.preset = 'custom'; GF.from = D.meta.from || YEAR + '-01-01'; GF.to = D.meta.to;   // the year followed: every NC to the last, whatever the period
    try { REP.forEach(function (n) { if (!gNc(n) || !gScope(n) || !inL(n[3])) return; var j = at[n[1].slice(0, 7)]; if (j != null) cols[j].nc[n[3]]++; }); }
    finally { GF.preset = k0[0]; GF.from = k0[1]; GF.to = k0[2]; }
    cols.forEach(function (o) { o.n = sumA(LN.map(function (l) { return o.nc[l]; })); o.e = sumA(LN.map(function (l) { return o.msn[l]; })); o.r = o.e >= EQMIN ? o.n / o.e : null; o.y = o.m.slice(0, 4); });
    var partial = +D.meta.to.slice(8, 10) < new Date(Date.UTC(+D.meta.to.slice(0, 4), +D.meta.to.slice(5, 7), 0)).getUTCDate();   // the last month is not over
    var avg = {}; [PREV, YEAR].forEach(function (y) { var c = cols.filter(function (o) { return o.y === y && o.e >= EQMIN; }), e = sumA(c.map(function (o) { return o.e; })); avg[y] = e ? sumA(c.map(function (o) { return o.n; })) / e : null; });
    var W = Math.max(320, box.clientWidth || 900), ml = 40, mr = W < 560 ? 12 : 96, pw = W - ml - mr, n = cols.length, bw = pw / n, X = function (j) { return ml + j * bw; };
    var P = [{ k: 'nc', t: S('yyNc'), h: 110 }, { k: 'msn', t: S('yyMsn'), h: 80 }, { k: 'r', t: S('yyRate'), h: 110 }], gap = 30, y0 = 18, g = '';
    P.forEach(function (p) { p.top = y0; y0 += p.h + gap; });
    var H = y0 - gap + 40;
    P.forEach(function (p) {
      var vals = cols.map(function (o) { return p.k === 'nc' ? o.n : p.k === 'msn' ? o.e : o.r || 0; }), nt = pNice(Math.max.apply(null, vals.concat(p.k === 'r' ? [avg[PREV] || 0, avg[YEAR] || 0] : [])) * 1.1, 3);
      var Yv = function (v) { return p.top + p.h - v / nt.top * p.h; };
      g += tx(ml, p.top - 6, p.t, 'ink b');
      for (var t0 = 0; t0 <= nt.top + 1e-9; t0 += nt.step) g += '<line x1="' + ml + '" x2="' + (W - mr) + '" y1="' + r1(Yv(t0)) + '" y2="' + r1(Yv(t0)) + '" stroke="var(--grid)"/>' + tx(ml - 6, Yv(t0) + 4, p.k === 'r' ? f1(t0) : num(t0), 'mu', 'end');
      if (p.k !== 'r') {
        cols.forEach(function (o, j) { var acc = 0, lt = partial && j === n - 1; LN.forEach(function (l) { var v = p.k === 'nc' ? o.nc[l] : o.msn[l]; if (v <= 0) return;
          g += '<rect x="' + r1(X(j) + bw * 0.16) + '" y="' + r1(Yv(acc + v)) + '" width="' + r1(bw * 0.68) + '" height="' + r1(Math.max(0.5, Yv(acc) - Yv(acc + v) - (LN.length > 1 ? 1 : 0))) + '" rx="2" fill="' + lineCol(l) + '"' + (lt ? ' fill-opacity=".45"' : '') + '/>'; acc += v; }); });
      } else {
        [PREV, YEAR].forEach(function (y) {   // one line per year: the two years count MSN differently
          var pts = []; cols.forEach(function (o, j) { if (o.y === y && o.r != null) pts.push([X(j) + bw / 2, Yv(o.r)]); });
          if (pts.length > 1) g += '<path d="M' + pts.map(function (q) { return r1(q[0]) + ',' + r1(q[1]); }).join('L') + '" fill="none" stroke="var(--ink)" stroke-width="2"/>';
          pts.forEach(function (q) { g += '<circle cx="' + r1(q[0]) + '" cy="' + r1(q[1]) + '" r="3.2" fill="var(--ink)" stroke="var(--surface)" stroke-width="1.5"/>'; });
          var js = cols.map(function (o, j) { return o.y === y ? j : -1; }).filter(function (j) { return j >= 0; });
          if (avg[y] != null && js.length) { var ya = Yv(avg[y]);
            g += '<line x1="' + r1(X(js[0]) + 2) + '" x2="' + r1(X(js[js.length - 1]) + bw - 2) + '" y1="' + r1(ya) + '" y2="' + r1(ya) + '" stroke="var(--ink-2)" stroke-width="1.5" stroke-dasharray="5 4"/>';
            if (mr > 40) { var other = avg[y === PREV ? YEAR : PREV], yo = other != null ? Yv(other) : null, d = yo == null ? 99 : ya - yo;   // the two labels kept 14 px apart
              g += tx(W - mr + 6, ya + 4 + (Math.abs(d) < 14 ? (d >= 0 ? 1 : -1) * (14 - Math.abs(d)) / 2 + (d === 0 && y === PREV ? 7 : 0) : 0), S('yyAvg', { y: y, v: f2(avg[y]) }), 'mu'); } }
        });
      }
    });
    var by = P[2].top + P[2].h;   // month initials, the year under its months, a rule between the years
    cols.forEach(function (o, j) { g += tx(X(j) + bw / 2, by + 14, v2Mo(o.m, bw, j), 'mu', 'middle'); });
    [PREV, YEAR].forEach(function (y) { var js = cols.map(function (o, j) { return o.y === y ? j : -1; }).filter(function (j) { return j >= 0; }); if (js.length) g += tx((X(js[0]) + X(js[js.length - 1]) + bw) / 2, by + 32, y, 'ink b', 'middle'); });
    var jb = cols.findIndex(function (o) { return o.y === YEAR; }); if (jb > 0) g += '<line x1="' + r1(X(jb)) + '" x2="' + r1(X(jb)) + '" y1="' + (P[0].top - 4) + '" y2="' + r1(by + 20) + '" stroke="var(--ink-2)" stroke-dasharray="2 3"/>';
    cols.forEach(function (o, j) {   // one hover target per month, over the three panels
      var lines = [S('yyNc') + ' : ' + num(o.n) + (LN.length > 1 ? ' (' + LN.map(function (l) { return l + ' ' + num(o.nc[l]); }).join(' · ') + ')' : ''), S('yyMsn') + ' : ' + f1(o.e), S('yyRate') + ' : ' + (o.r != null ? f2(o.r) : '—')];
      if (G.lang === 'en') lines = lines.map(function (t) { return t.replace(' : ', ': '); });
      g += '<rect x="' + r1(X(j)) + '" y="' + (P[0].top - 4) + '" width="' + r1(bw) + '" height="' + r1(by - P[0].top + 4) + '" fill="transparent"' + tip(monthName(o.m) + ' ' + o.y + (partial && j === n - 1 ? ' · ' + S('yyTo', { d: day(D.meta.to, { day: 'numeric', month: 'short' }) }) : ''), lines) + '/>';
    });
    box.innerHTML = svg(W, H, g, S('yyT')) + (R5 ? '' : '<p class="mu">' + esc(S('yyNo25')) + '</p>');
    document.getElementById('yyL').innerHTML = LN.map(function (l) { return sw(lineCol(l), l); }).join('') + (partial ? '<span class="mu">' + esc(S('yyPart', { d: day(D.meta.to, { day: 'numeric', month: 'long' }) })) + '</span>' : '');
  }
  function renderPplan() {
    if (G.tab !== 'pplan') return;
    var E = pSrc(), box = document.getElementById('ppLinesT'); if (!box) return;
    if (!E || E !== D.eqmsn) { box.innerHTML = '<p class="empty">' + esc(S('ppNone')) + '</p>'; return; }
    PD = pData(); PA = pAgg(PD);
    var L25 = (D.y25 && D.y25.prod) || {}, d25 = function (p) { return L25[p] ? sumA(L25[p]) : 0; }, yr = function (p) { return sumA(PD.prod[p] || []); };
    var O = objectif('nc'); if (!O) { box.innerHTML = '<p class="empty">' + esc(S('slWait')) + '</p>'; return; }
    var T = O.T, tl = {}; (T ? T.lines : []).forEach(function (a) { tl[a.l] = a; });
    var by = {}; P_().forEach(function (o) { var l = o.line || '—', a = by[l] || (by[l] = { l: l, eq: 0, yr: 0, d25: 0, nc: 0 }); a.eq += o.EQ; a.yr += yr(o.p); a.d25 += d25(o.p); a.nc += o.EQ >= EQMIN ? o.NC : 0; });   // under 0.5 MSN: out of plan (v2InPlan)
    var u = v2Unplanned(); Object.keys(u.by).forEach(function (l) { var a = by[l] || (by[l] = { l: l, eq: 0, yr: 0, d25: 0, nc: 0 }); a.nc += u.by[l].n; });   // NCs with no plan product: in their line, no row of their own (30 Oct)
    var lines = lineOrder(Object.keys(by)).map(function (l) { return by[l]; }), sumK = function (k) { return sumA(lines.map(function (a) { return a[k]; })); };
    // 2025 NCs (série, the same filter), by line and by plan product
    var Y5 = y25Sel() || [], E5 = pSrc(), n25p = {}, n25l = {}; Y5.forEach(function (x) { var p = E5 && E5.map && E5.map[String(x.p || '').toUpperCase()]; if (p) n25p[p] = (n25p[p] || 0) + x.nc; var l = x.line || '—'; n25l[l] = (n25l[l] || 0) + x.nc; });
    lines.forEach(function (a) { a.n25 = n25l[a.l] || 0; });
    var f = function (v) { return v ? f1(v) : '—'; }, rt = function (n, e) { return e >= EQMIN ? f2(n / e) : '—'; };
    document.getElementById('ppFigs').innerHTML = [[f1(sumK('eq')), S('ppF1')], [f1(sumK('yr')), S('ppF2')], [num(Math.round(sumK('d25'))), S('ppF3')], [num(sumK('nc')) + ' / ' + num(SEL_NC.length), S('ppF4')]]
      .map(function (x) { return '<div class="fig"><b>' + esc(x[0]) + '</b><span>' + esc(x[1]) + '</span></div>'; }).join('');
    var th = function (a) { return '<thead><tr>' + a.map(function (h, j) { return '<th scope="col"' + (j ? ' class="r"' : '') + '>' + esc(S(h)) + '</th>'; }).join('') + '</tr></thead>'; };
    var dot = function (l) { return '<span class="pp-dot" style="background:' + lineCol(l) + '"></span>'; };
    box.innerHTML = '<table class="cxt">' + th(['ppL', 'ppEq', 'ppYr', 'ppD25', 'ppNc25', 'ppNc', 'ppRate', 'ppR25', 'ppTgt', 'ppTgtY']) + '<tbody>' +
      lines.map(function (a) { var t = tl[a.l];
        return '<tr><td' + pk('line', a.l) + '>' + dot(a.l) + esc(a.l) + '</td><td class="r">' + f(a.eq) + '</td><td class="r">' + f(a.yr) + '</td><td class="r">' + (a.d25 ? num(Math.round(a.d25)) : '—') + '</td><td class="r">' + (a.n25 ? num(a.n25) : '—') + '</td><td class="r">' + num(a.nc) +
          '</td><td class="r">' + rt(a.nc, a.eq) + '</td><td class="r">' + (t && t.r25 != null ? f2(t.r25) : '—') + '</td><td class="r">' + (t ? f2(t.rt) + (t.ph ? ' *' : '') : '—') + '</td><td class="r">' + (t ? num(Math.round(t.year + t.xT)) : '—') + '</td></tr>'; }).join('') +
      '<tr class="tot"><td>' + esc(S('total')) + '</td><td class="r">' + f(sumK('eq')) + '</td><td class="r">' + f(sumK('yr')) + '</td><td class="r">' + num(Math.round(sumK('d25'))) + '</td><td class="r">' + num(sumK('n25')) + '</td><td class="r">' + num(sumK('nc')) +
      '</td><td class="r">' + rt(sumK('nc'), sumK('eq')) + '</td><td class="r"></td><td class="r"></td><td class="r">' + (T ? num(Math.round(T.year)) : '—') + '</td></tr></tbody></table>';
    var os = P_().slice().sort(function (a, b) { return lineOrder([a.line, b.line]).indexOf(a.line) - lineOrder([a.line, b.line]).indexOf(b.line) || b.NC - a.NC; });
    document.getElementById('ppProdsT').innerHTML = '<table class="cxt">' + th(['ppP', 'ppL', 'ppEq', 'ppYr', 'ppD25', 'ppNc25', 'ppNc', 'ppRate']) + '<tbody>' +
      os.map(function (o) { return '<tr><td' + ppk('pprod', o.p) + '>' + esc(o.p) + '</td><td class="r">' + dot(o.line) + esc(o.line || '—') + '</td><td class="r">' + f(o.EQ) + '</td><td class="r">' + f(yr(o.p)) + '</td><td class="r">' + (d25(o.p) ? num(d25(o.p)) : '—') +
        '</td><td class="r">' + (n25p[o.p] ? num(n25p[o.p]) : '—') + '</td><td class="r">' + num(o.NC) + '</td><td class="r">' + rt(o.NC, o.EQ) + '</td></tr>'; }).join('') + '</tbody></table>';
    document.getElementById('ppOut').innerHTML = v2UnplannedNote();
    // the plan month by month, one colour per line; the months still to come lighter
    var mc = document.getElementById('ppMonthC'), W = Math.max(300, mc.clientWidth || 520), H = 230, ml = 34, mb = 22, mt = 14, n = PD.months.length, bw = (W - ml) / n, LN = lineOrder(Object.keys(by));
    var vol = PD.months.map(function (m, i) { var o = {}; LN.forEach(function (l) { o[l] = 0; }); PD.prods.forEach(function (p) { var l = PD.line[p]; if (o[l] != null) o[l] += PD.prod[p][i] || 0; }); return o; });
    var mx = Math.max.apply(null, vol.map(function (o) { return sumA(LN.map(function (l) { return o[l]; })); }).concat([1e-9])), nt = pNice(mx * 1.08), Y = function (v) { return mt + (H - mt - mb) * (1 - v / nt.top); }, g = '';
    for (var t0 = 0; t0 <= nt.top + 1e-9; t0 += nt.step) g += '<line x1="' + ml + '" x2="' + W + '" y1="' + r1(Y(t0)) + '" y2="' + r1(Y(t0)) + '" stroke="var(--grid)"/>' + tx(ml - 6, Y(t0) + 4, num(t0), 'mu', 'end');
    PD.months.forEach(function (m, i) { var x = ml + i * bw + bw * 0.15, acc = 0, fc = i >= PD.fc, pt = i === PD.cur ? PD.part[i] : 1;
      [pt, 1 - pt].forEach(function (sh, h) { if (sh <= 0) return;   // the running month: the share of its days gone solid, the rest lighter
        LN.forEach(function (l) { var v = vol[i][l] * sh, lt = fc || h === 1; if (v <= 0) return; g += '<rect x="' + r1(x) + '" y="' + r1(Y(acc + v)) + '" width="' + r1(bw * 0.7) + '" height="' + r1(Math.max(0.5, Y(acc) - Y(acc + v) - 1)) + '" fill="' + lineCol(l) + '"' + (lt ? ' fill-opacity=".38"' : '') +
          pk('line', l) + tip(l + ' · ' + monthName(m) + ' ' + m.slice(0, 4), [S('ppTipV', { v: f1(vol[i][l]) }) + (i === PD.cur ? ' · ' + S('ppCurTip', { p: pct0(pt * 100), d: day(D.meta.to) }) : fc ? ' · ' + S('ppPlanned') : '')]) + '/>'; acc += v; }); });
      g += tx(ml + i * bw + bw / 2, H - 6, v2Mo(m, bw, i), 'mu', 'middle'); });
    mc.innerHTML = svg(W, H, g, S('ppMonth'));
    document.getElementById('ppMonthL').innerHTML = LN.map(function (l) { return sw(lineCol(l), l); }).join('') + '<span class="mu">' + esc(S('ppLight')) + (PD.cur != null ? ' ' + esc(S('ppCurL', { m: day(D.meta.to, { month: 'long' }), d: day(D.meta.to) })) : '') + '</span>';
    // how the numbers are made and used
    var exp = PR.ver === 'wd' && D.eqmsn.msnAsof ? D.eqmsn.msnAsof : D.eqmsn.asof, asof = exp ? day(exp) : '';   // the volume on working days comes from the production plan: its export date
    var cur = PD.cur != null ? ' ' + S('ppCur', { m: day(D.meta.to, { month: 'long' }), d: day(D.meta.to), p: pct0(PD.part[PD.cur] * 100) }) : '';
    renderYY();
    // the comparison year's deliveries: from the Livraisons sheet, or counted in the production plan (D.y25.delivered); the A320
    // products delivered that year; the products with NCs and no delivery that year
    var del = ' ' + S(BUILT25 ? 'ppH1p' : 'ppH1s'), a320 = sumA(PD.all.filter(function (p) { return PD.line[p] === 'A320'; }).map(d25));
    var withNc = {}; REP.forEach(function (n) { var p = E.map[String(n[26] || '').toUpperCase()]; if (p) withNc[p] = 1; });
    var none = PD.all.filter(function (p) { return withNc[p] && !d25(p); });
    document.getElementById('ppHow').innerHTML = ['ppH1', 'ppH2', 'ppH3', 'ppH4'].map(function (k) { return '<h4>' + esc(S(k + 't')) + '</h4><p>' +
      esc(S(k, { d: asof, n: num(u.n), p: u.top.join(', '), a: num(Math.round(a320)), x: none.length ? ' (' + none.join(', ') + ')' : '' }) + (k === 'ppH1' ? del + cur : '')) + '</p>'; }).join('');
  }

  // ---------------------------------------------------------------- 4. Customer returns
  function cx(r) { return D.client[r[0] + '|' + r[1]] || ['', '', '', '', '', '']; }
  var client = Board({
    grid: 'rg', chips: 'rc', search: 'rq', count: 'rn', thead: 'rth2', tbody: 'rtb2', more: 'rm', expand: true, kicker: 'kmDef',
    rows: function () { return D.defects.filter(function (r) { return CLI[r[0]] && keepMinor(r); }); },
    dims: [
      { k: 'cat', t: 'dCat', wide: true, pareto: true, color: catFill, get: dCat, show: L },
      { k: 'rca', t: 'dRca', color: rcaCol, catKey: rcaCat, get: dRca, show: L },
      { k: 'nat', t: 'dNat', sub: 'natOnly', get: function (r) { return cx(r)[0] || null; }, show: function (v) { return S('nat_' + v); }, order: function (v) { return ['phys', 'hs', 'recu', 'nc'].filter(function (c) { return v.indexOf(c) >= 0; }); } },
      { k: 'line', t: 'dLine', color: lineCol, get: function (r) { return r[4]; }, show: function (v) { return v; }, order: lineOrder },
      { k: 'month', t: 'dMonth', cols: true, get: function (r) { return r[2].slice(0, 7); }, show: monthName, order: function (v) { return v.sort(); } }
    ],
    text: function (r) { return defectText(r) + ' ' + (D.lt[r[0]] || '') + ' ' + cx(r).join(' '); },
    sort: byDate,
    head: function () { return ['cNc', 'cDate', 'cLine', 'cCat', 'cRca', 'cText'].map(function (k) { return '<th scope="col">' + esc(S(k)) + '</th>'; }).join(''); },
    row: function (r, b) {
      var key = r[0] + '-' + r[1], open = !!b.open[key], x = cx(r), n = NC[r[0]] || [];
      var main = '<tr class="open-row" tabindex="0" data-key="' + key + '" aria-expanded="' + open + '"><td class="nc">' + esc(r[0]) + (r[1] > 1 ? ' · ' + r[1] : '') + '</td><td class="num">' + esc(shortDay(r[2])) + '</td><td>' + esc(r[4]) + '</td><td>' + esc(L(dCat(r))) + '</td><td>' + esc(L(dRca(r))) + (x[0] ? '<br><span class="sub">' + esc(S('nat_' + x[0])) + '</span>' : '') + '</td><td class="txt">' + esc(tidy(r[18]) || n[22] || '') + '</td></tr>';
      if (!open) return main;
      var info = [['iTitle', n[22]], ['iPlant', x[4]], ['iLiab', x[5]], ['iDet', x[1]], ['iSym', x[2]]].map(function (p) { return '<dt>' + esc(S(p[0])) + '</dt><dd>' + esc(p[1] || S('iNone')) + '</dd>'; }).join('');
      return main + '<tr class="more-row"><td colspan="6"><div class="more-grid"><div><h4>' + esc(S('cSub')) + '</h4><p>' + esc(dSub(r)) + '</p><h4 style="margin-top:12px">' + esc(S('hInfo')) + '</h4><dl class="kv">' + info + '</dl></div><div><h4>' + esc(S('hLong')) + '</h4><pre class="long">' + esc(D.lt[r[0]] || '') + '</pre></div></div></td></tr>';
    },
    after: function (b) {
      var rs = b.base(), dmg = 0, phys = 0;
      rs.forEach(function (r) { if (dCat(r) === 'Élément Endommagé') dmg++; if (cx(r)[0] === 'phys') phys++; });
      document.getElementById('rf1').textContent = num(CLI_NC.length);
      document.getElementById('rf2').textContent = rs.length ? pct0(dmg / rs.length * 100) : '—';
      document.getElementById('rf3').textContent = rs.length ? pct0(phys / rs.length * 100) : '—';
      document.getElementById('rf4').textContent = eur(sum(CLI_NC, function (n) { return n[12]; }));
    }
  });

  // ---------------------------------------------------------------- 5. Root causes
  function rcaStats(set) {
    var tot = 0, m = {};
    D.defects.forEach(function (r) { if (!set[r[0]] || !keepMinor(r)) return; tot++; var k = dRca(r), s = m[k] || (m[k] = { d: 0, nc: {}, c: 0 }); s.d++; s.nc[r[0]] = 1; s.c += dAlloc(r); });
    return { tot: tot, m: m };
  }
  function rcaId(name) { return 'rca-' + name.normalize('NFD').replace(/[^A-Za-z0-9]+/g, '-').toLowerCase(); }
  function renderRca() {
    var st = rcaStats(SER), sc = rcaStats(CLI), cnt = function (s, k) { return s.m[k] || { d: 0, nc: {}, c: 0 }; };
    var nSub = 0, nCode = 0, cats = {}; D.rca.forEach(function (r) { cats[r.cat] = 1; nSub += r.subs.length; r.subs.forEach(function (s) { nCode += s.codes.length; }); });
    document.getElementById('rcaChain').innerHTML = [[nCode, 'stepCode'], [nSub, 'stepSub'], [D.rca.length, 'stepRca', 1], [Object.keys(cats).length, 'stepCat']].map(function (p, i) {
      return (i ? '<span class="arrow" aria-hidden="true">→</span>' : '') + '<div class="step' + (p[2] ? ' base' : '') + '"><b>' + num(p[0]) + '</b><span>' + esc(S(p[1])) + '</span></div>'; }).join('');
    document.getElementById('rth').innerHTML = [['rRca'], ['rCat'], ['rDef', 'r'], ['rShare', 'r'], ['rNc', 'r'], ['rCostS', 'r'], ['rCli', 'r']].map(function (p) { return '<th scope="col"' + (p[1] ? ' class="r"' : '') + '>' + esc(S(p[0])) + '</th>'; }).join('');
    var list = D.rca.slice().sort(function (a, b) { return cnt(st, b.rca).d - cnt(st, a.rca).d || cnt(sc, b.rca).d - cnt(sc, a.rca).d; });
    document.getElementById('rtb').innerHTML = list.map(function (r) { var c = cnt(st, r.rca);
      return '<tr tabindex="0" data-go="' + rcaId(r.rca) + '"><td>' + esc(L(r.rca)) + '</td><td>' + esc(L(r.cat)) + '</td><td class="num r">' + num(c.d) + '</td><td class="num r">' + (st.tot ? pct(c.d / st.tot * 100) : '—') + '</td><td class="num r">' + num(Object.keys(c.nc).length) + '</td><td class="num r">' + eur(c.c) + '</td><td class="num r">' + num(cnt(sc, r.rca).d) + '</td></tr>'; }).join('');
    var html = '';
    catOrder(Object.keys(cats)).forEach(function (cat) {
      html += '<section class="rcagroup"><h2>' + esc(L(cat)) + '</h2>';
      D.rca.filter(function (r) { return r.cat === cat; }).forEach(function (r) {
        var c = cnt(st, r.rca), k = cnt(sc, r.rca), other = G.lang === 'fr' ? (EN[r.rca] || '') : r.rca;
        html += '<article class="card rcacard" id="' + rcaId(r.rca) + '"><h3>' + esc(L(r.rca)) + (other && other !== L(r.rca) ? ' <span class="en">· ' + esc(other) + '</span>' : '') + '</h3>' +
          '<p>' + esc(G.lang === 'fr' ? r.fr : r.en) + '</p>' +
          '<div class="stats"><span><b>' + num(c.d) + '</b> ' + esc(S('rDef').toLowerCase()) + '</span><span><b>' + (st.tot ? pct(c.d / st.tot * 100) : '—') + '</b></span><span><b>' + num(Object.keys(c.nc).length) + '</b> NC</span><span><b>' + eur(c.c) + '</b></span><span><b>' + num(k.d) + '</b> ' + esc(S('rCli').toLowerCase()) + '</span></div>' +
          '<div class="subs"><h4>' + esc(S('subsTitle')) + '</h4>' + r.subs.map(function (s) {
            return '<details><summary>' + esc(s.name) + (s.minor ? ' <span class="tag">' + esc(S('minorTag')) + '</span>' : '') + (s.codes.length ? ' · <code>' + s.codes.map(function (x) { return esc(x[0]); }).join(' ') + '</code>' : '') + '</summary>' +
              (s.codes.length ? '<ul>' + s.codes.map(function (x) { return '<li><code>' + esc(x[0]) + '</code> ' + esc(G.lang === 'fr' ? x[2] : x[1]) + '</li>'; }).join('') + '</ul>' : '') + '</details>'; }).join('') + '</div>' +
          '<div class="ex"><h4>' + esc(S('exTitle')) + '</h4>' + (r.ex.length ? r.ex.map(function (e) { return '<div><q>' + esc(tidy(e[1])) + '</q> <span class="nc">NC ' + esc(e[0]) + '</span></div>'; }).join('') : '<p class="empty">' + esc(S('noEx')) + '</p>') + '</div></article>';
      });
      html += '</section>';
    });
    document.getElementById('rcaCards').innerHTML = html;
  }
  function goRca(tr) { var el = document.getElementById(tr.getAttribute('data-go')); if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
  document.getElementById('rtb').addEventListener('click', function (e) { var tr = e.target.closest('[data-go]'); if (tr) goRca(tr); });
  document.getElementById('rtb').addEventListener('keydown', function (e) { var tr = e.target.closest('[data-go]'); if (tr && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); goRca(tr); } });

  // ---------------------------------------------------------------- 5. Insights (selection)
  // Category colours: validated categorical order (blue, aqua, yellow, magenta, green, violet); orange stays reserved for cable.
  var A = { pin: null, top0: null, km: null, msn: null };
  // a FIN that is a product's name, not an equipment's: a product of the production plan (its name or an NC product label
  // it matches), or a product written the way the alias rules write them (742VU, 5881VB...). Left out of the FIN charts.
  var PROD_NAMES = (function () {
    var E = D.eqmsn || {}, o = {}, put = function (v) { v = String(v || '').trim().toUpperCase(); if (v) { o[v] = 1; o[v.replace(/[\s\-]+/g, '')] = 1; } };
    Object.keys(E.map || {}).forEach(function (k) { put(k); put(E.map[k]); });
    ['std', 'wd', 'adj'].forEach(function (v) { Object.keys(E[v] || {}).forEach(put); });
    Object.keys((D.y25 && D.y25.prod) || {}).forEach(put);
    (E.alias || []).forEach(function (x) { put(x[3]); });
    return o;
  })();
  var PROD_RES = ((D.eqmsn && D.eqmsn.alias) || []).map(function (x) { try { return new RegExp(x[1]); } catch (e) { return null; } }).filter(Boolean);
  function isProductName(f) {
    var v = String(f || '').trim().toUpperCase(); if (!v) return false;
    return !!(PROD_NAMES[v] || PROD_NAMES[v.replace(/[\s\-]+/g, '')]) || PROD_RES.some(function (re) { return re.test(v); });
  }
  function finReal(r) { var f = dFin(r); return f && !isProductName(f) ? f : ''; }   // the FIN of a defect line, product names left out
  function catFill(c) { return CATC[c] ? 'var(--c' + CATC[c] + ')' : 'var(--dim)'; }
  function catLabel(c) { return c === 'aside' ? S('asideGroup') : L(c); }
  // the category of a cause and of a sub-code (the most frequent among their defect lines): the colour of their bars, blue for
  // workmanship and green for connection as everywhere
  var RCA_CAT = {}, CODE_CAT = {};
  (function () { var a = {}, b = {}; D.defects.forEach(function (r) { var c = catKey(dCat(r)), x = dRca(r), y = dCode(r);
      if (x) (a[x] || (a[x] = {}))[c] = (a[x][c] || 0) + 1; if (y) (b[y] || (b[y] = {}))[c] = (b[y][c] || 0) + 1; });
    [[a, RCA_CAT], [b, CODE_CAT]].forEach(function (p) { Object.keys(p[0]).forEach(function (k) { var o = p[0][k]; p[1][k] = Object.keys(o).sort(function (u, v) { return o[v] - o[u]; })[0]; }); }); })();
  function rcaCol(v) { return catFill(RCA_CAT[v]); } function codeCol(v) { return catFill(CODE_CAT[v]); }
  function rcaCat(v) { return RCA_CAT[v]; } function codeCat(v) { return CODE_CAT[v]; }
  // all: every line (the line-profile chart shows the chosen aircraft among the others)
  function aRows(all) { return D.defects.filter(function (r) { return keepMinor(r) && (all ? inSelAnyLine(r) : SEL[r[0]]); }); }
  function aNcs() { return SEL_NC; }
  function tip(head, lines) { return ' data-tip="' + esc([head].concat(lines || []).join('|')) + '"'; }
  function tx(x, y, s, cls, anchor, extra) { return '<text x="' + r1(x) + '" y="' + r1(y) + '"' + (cls ? ' class="' + cls + '"' : '') + (anchor ? ' text-anchor="' + anchor + '"' : '') + (extra || '') + '>' + esc(s) + '</text>'; }
  function r1(x) { return Math.round(x * 10) / 10; }
  function f1(x) { return (Math.round(x * 10) / 10).toLocaleString(loc()); }
  function svg(w, h, inner, label, cls) { return '<svg class="viz' + (cls ? ' ' + cls : '') + '" width="' + Math.round(w) + '" height="' + Math.round(h) + '" viewBox="0 0 ' + Math.round(w) + ' ' + Math.round(h) + '" role="img" aria-label="' + esc(label) + '">' + inner + '</svg>'; }
  function ord(n) { return G.lang === 'fr' ? (n === 1 ? '1er' : n + 'e') : n + (n % 100 > 10 && n % 100 < 14 ? 'th' : ['th', 'st', 'nd', 'rd'][n % 10] || 'th'); }
  function kEur(c) { return G.lang === 'fr' ? (c / 1000).toLocaleString('fr-FR') + ' k€' : (c / 1000).toLocaleString('en-GB') + 'k EUR'; }
  // labels in a column must not overlap: push them apart, keeping their order
  function spread(ys, gap, lo, hi) {
    var o = ys.map(function (y, i) { return { y: y, i: i }; }).sort(function (a, b) { return a.y - b.y; });
    for (var i = 1; i < o.length; i++) if (o[i].y < o[i - 1].y + gap) o[i].y = o[i - 1].y + gap;
    if (o.length && o[o.length - 1].y > hi) { o[o.length - 1].y = hi; for (var j = o.length - 2; j >= 0; j--) if (o[j].y > o[j + 1].y - gap) o[j].y = o[j + 1].y - gap; }
    if (o.length && o[0].y < lo) { o[0].y = lo; for (var k = 1; k < o.length; k++) if (o[k].y < o[k - 1].y + gap) o[k].y = o[k - 1].y + gap; }
    var out = []; o.forEach(function (p) { out[p.i] = p.y; }); return out;
  }
  function vSet(k, html, legend, table) {
    document.getElementById('v-' + k + '-b').innerHTML = html;
    document.getElementById('v-' + k + '-l').innerHTML = legend || '';
    document.getElementById('v-' + k + '-l').hidden = !legend;
    document.getElementById('v-' + k + '-t').innerHTML = table || '';
  }
  function miniTable(head, rows, right) {
    return '<thead><tr>' + head.map(function (h, i) { return '<th scope="col"' + (i >= right ? ' class="r"' : '') + '>' + esc(h) + '</th>'; }).join('') + '</tr></thead><tbody>' +
      rows.map(function (r) { return '<tr>' + r.map(function (c, i) { return '<td' + (i >= right ? ' class="num r"' : '') + '>' + esc(c) + '</td>'; }).join('') + '</tr>'; }).join('') + '</tbody>';
  }
  function vWidth(k, min) { return Math.max(document.getElementById('v-' + k + '-b').clientWidth || 600, min || 0); }
  var EMPTY = '<p class="empty">—</p>';

  // 1. Calendar heatmap: defects per day, plus the weekday profile aligned on the rows
  function vCal(rs) {
    var W0 = vWidth('cal'), per = {}, pnc = {};
    rs.forEach(function (r) { per[r[2]] = (per[r[2]] || 0) + 1; (pnc[r[2]] || (pnc[r[2]] = {}))[r[0]] = 1; });
    var days = Object.keys(per);
    if (!days.length) { vSet('cal', EMPTY); return; }
    var wkend = days.some(function (d) { var g = new Date(d + 'T12:00:00Z').getUTCDay(); return g === 0 || g === 6; }), nR = wkend ? 7 : 5;
    var F0 = GF.from < DMIN ? DMIN : GF.from, T0 = GF.to > DMAX ? DMAX : GF.to;
    var weeks = [], m = isoMonday(isoWeekOf(new Date(F0 + 'T00:00:00Z')));
    for (; isoDay(m) <= T0; m.setUTCDate(m.getUTCDate() + 7)) weeks.push(new Date(m));
    var vals = days.map(function (d) { return per[d]; }).sort(function (a, b) { return a - b; }), cuts = [];
    [0.2, 0.4, 0.6, 0.8].forEach(function (p) { var t = vals[Math.min(vals.length - 1, Math.floor(p * vals.length))]; if (!cuts.length || t > cuts[cuts.length - 1]) cuts.push(t); });
    if (cuts[cuts.length - 1] >= vals[vals.length - 1]) cuts.pop();
    var nb = cuts.length + 1;
    function bin(n) { var b = 0; cuts.forEach(function (c) { if (n > c) b++; }); return b; }
    function shade(b) { return tint('--seq', Math.round(nb > 1 ? 18 + 82 * b / (nb - 1) : 100)); }
    var side = W0 >= 760 ? 230 : 0, lab = 36, top = 20;
    var cell = Math.max(11, Math.min(22, Math.floor((W0 - side - lab) / weeks.length) - 2)), st = cell + 2;
    var gw = lab + weeks.length * st, h = top + nR * st;
    var mon0 = new Date(Date.UTC(2026, 0, 5)), wdName = [], wdLong = [];
    for (var i = 0; i < 7; i++) { var dd = new Date(mon0); dd.setUTCDate(mon0.getUTCDate() + i); wdName.push(day(isoDay(dd), { weekday: 'short' })); wdLong.push(day(isoDay(dd), { weekday: 'long' })); }
    var out = '', prevM = '', wdTot = [0, 0, 0, 0, 0, 0, 0], wdDays = [0, 0, 0, 0, 0, 0, 0];
    for (var r = 0; r < nR; r++) out += tx(lab - 8, top + r * st + cell - 2, wdName[r], 'mu', 'end');
    weeks.forEach(function (mon, j) {
      var d7 = new Date(mon); d7.setUTCDate(mon.getUTCDate() + 6); var lm = j === 0 ? F0.slice(0, 7) : (isoDay(d7) > T0 ? T0 : isoDay(d7)).slice(0, 7);
      if (lm !== prevM) { out += tx(lab + j * st, 12, monthName(lm), 'mu'); prevM = lm; }
      for (var i2 = 0; i2 < nR; i2++) {
        var dt = new Date(mon); dt.setUTCDate(mon.getUTCDate() + i2); var iso = isoDay(dt);
        if (iso < F0 || iso > T0) continue;
        var n = per[iso] || 0, k = Object.keys(pnc[iso] || {}).length;
        if (n) { wdTot[i2] += n; wdDays[i2]++; }
        out += '<rect x="' + (lab + j * st) + '" y="' + (top + i2 * st) + '" width="' + cell + '" height="' + cell + '" rx="2" fill="' + (n ? shade(bin(n)) : 'var(--track)') + '"' +
          pk('day', iso) + tip(day(iso, { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }), [n ? S('calTip', { n: num(n), k: num(k) }) : S('calNone')]) + '/>';
      }
    });
    var T = rs.length, wmax = Math.max.apply(null, wdTot.slice(0, nR));
    function profile(x0, y0, rowH, barH, width) {
      var o = tx(x0, y0 - 8, S('wdProfile'), 'mu');
      for (var i3 = 0; i3 < nR; i3++) {
        var y = y0 + i3 * rowH, w = wmax ? wdTot[i3] / wmax * (width - 60) : 0;
        if (!side) o += tx(x0 + 34, y + barH - 1, wdName[i3], 'mu', 'end');
        var bx = x0 + (side ? 0 : 40);
        o += '<rect x="' + bx + '" y="' + (y + (rowH - 2 - barH) / 2) + '" width="' + r1(w) + '" height="' + barH + '" rx="3" fill="var(--seq)"' + tip(wdLong[i3], [S('wdTip', { p: pct(T ? wdTot[i3] / T * 100 : 0), n: num(wdTot[i3]) })]) + '/>' +
          tx(bx + w + 6, y + (rowH - 2) / 2 + 4, pct0(T ? wdTot[i3] / T * 100 : 0), 'ink');
      }
      return o;
    }
    var html;
    if (side) html = svg(gw + side, h, out + profile(gw + 24, top, st, Math.max(8, cell - 6), side - 24), S('t_cal'));
    else html = svg(gw, h, out, S('t_cal')) + svg(Math.min(W0, 360), 24 + nR * 20, profile(0, 24, 20, 12, Math.min(W0, 360) - 40), S('wdProfile'));
    var leg = '<span class="mu">' + esc(S('calLeg')) + '</span><span><i class="sw" style="background:var(--track)"></i>0</span>' + Array.apply(null, Array(nb)).map(function (_, b) {
      var a = b === 0 ? 1 : cuts[b - 1] + 1, z = b < cuts.length ? cuts[b] : vals[vals.length - 1];
      return '<span><i class="sw" style="background:' + shade(b) + '"></i>' + (a === z ? num(a) : num(a) + '–' + num(z)) + '</span>'; }).join('');
    var rows = [0, 1, 2, 3, 4, 5, 6].slice(0, nR).map(function (i5) { return [wdLong[i5], num(wdTot[i5]), pct(T ? wdTot[i5] / T * 100 : 0), num(wdDays[i5]), wdDays[i5] ? f1(wdTot[i5] / wdDays[i5]) : '—']; });
    vSet('cal', html, leg, miniTable([S('hDay'), S('hDef'), S('rShare'), S('hDays'), S('hPerDay')], rows, 1));
  }

  // 2. Flow (Sankey): where the NC was found -> defect category -> decision
  function vFlow(rs) {
    var W0 = vWidth('flow', 640), H = 420, top = 30, pad = 12, nw = 10;
    var lm = {}, mr = {}, tl = {}, tm = {}, tr = {}, T = 0;
    rs.forEach(function (r) { var n = NC[r[0]]; if (!n) return; var a = wGroup(n[8]), b = catKey(dCat(r)), c = dGroup(n[7]);
      lm[a + '|' + b] = (lm[a + '|' + b] || 0) + 1; mr[b + '|' + c] = (mr[b + '|' + c] || 0) + 1; tl[a] = (tl[a] || 0) + 1; tm[b] = (tm[b] || 0) + 1; tr[c] = (tr[c] || 0) + 1; T++; });
    if (!T) { vSet('flow', EMPTY); return; }
    var LN = ['fin', 'test', 'cab', 'int', 'oth'].filter(function (x) { return tl[x]; }), MN = MAIN_CATS.filter(function (x) { return tm[x]; }), RN = ['rw', 'rej', 'exc', 'oth'].filter(function (x) { return tr[x]; });
    var maxN = Math.max(LN.length, MN.length, RN.length), k = (H - top - 6 - pad * (maxN - 1)) / T;
    var lw = function (list, pre, tot) { return Math.max.apply(null, list.map(function (q) { return (S(pre + q) + ' ' + num(tot[q])).length; }).concat([4])) * 6.9 + 18; };
    var narrow = W0 < 820, xL = Math.max(narrow ? 130 : 180, lw(LN, 'w_', tl)), xR = W0 - Math.max(narrow ? 150 : 200, lw(RN, 'd_', tr)) - nw, xM = Math.round((xL + xR) / 2 - nw / 2);
    function place(list, tot) { var hs = list.reduce(function (s, x) { return s + tot[x] * k; }, 0) + pad * (list.length - 1), y = top + (H - top - hs) / 2, pos = {};
      list.forEach(function (x) { pos[x] = { y: y, h: tot[x] * k }; y += tot[x] * k + pad; }); return pos; }
    var pL = place(LN, tl), pM = place(MN, tm), pR = place(RN, tr);
    function band(x0, y0, x1, y1, h) { var xm = (x0 + x1) / 2; return 'M' + r1(x0) + ',' + r1(y0) + 'C' + r1(xm) + ',' + r1(y0) + ' ' + r1(xm) + ',' + r1(y1) + ' ' + r1(x1) + ',' + r1(y1) + 'L' + r1(x1) + ',' + r1(y1 + h) + 'C' + r1(xm) + ',' + r1(y1 + h) + ' ' + r1(xm) + ',' + r1(y0 + h) + ' ' + r1(x0) + ',' + r1(y0 + h) + 'Z'; }
    var wName = function (x) { return S('w_' + x); }, rName = function (x) { return S('d_' + x); };
    var links = '', oL = {}, iM = {}, oM = {}, iR = {};
    LN.forEach(function (a) { MN.forEach(function (b) { var v = lm[a + '|' + b]; if (!v) return; var h = v * k, y0 = pL[a].y + (oL[a] || 0), y1 = pM[b].y + (iM[b] || 0); oL[a] = (oL[a] || 0) + h; iM[b] = (iM[b] || 0) + h;
      links += '<path class="lnk" d="' + band(xL + nw, y0, xM, y1, Math.max(h, 0.6)) + '" fill="' + catFill(b) + '" data-a="L:' + a + '" data-b="M:' + b + '"' + tip(wName(a) + ' → ' + catLabel(b), [S('flowTip', { n: num(v), p: pct0(v / tm[b] * 100), c: catLabel(b) })]) + '/>'; }); });
    MN.forEach(function (b) { RN.forEach(function (c) { var v = mr[b + '|' + c]; if (!v) return; var h = v * k, y0 = pM[b].y + (oM[b] || 0), y1 = pR[c].y + (iR[c] || 0); oM[b] = (oM[b] || 0) + h; iR[c] = (iR[c] || 0) + h;
      links += '<path class="lnk" d="' + band(xM + nw, y0, xR, y1, Math.max(h, 0.6)) + '" fill="' + catFill(b) + '" data-a="M:' + b + '" data-b="R:' + c + '"' + tip(catLabel(b) + ' → ' + rName(c), [S('flowTip', { n: num(v), p: pct0(v / tm[b] * 100), c: catLabel(b) })]) + '/>'; }); });
    var nodes = '', labels = '';
    function col(list, pos, tot, x, fill, name, side) {
      var ys = spread(list.map(function (q) { return pos[q].y + pos[q].h / 2 + 4; }), 15, top + 8, H - 2);
      list.forEach(function (q, i) {
        nodes += '<rect class="node" x="' + x + '" y="' + r1(pos[q].y) + '" width="' + nw + '" height="' + r1(Math.max(pos[q].h, 2)) + '" rx="2" fill="' + fill(q) + '" data-node="' + side + ':' + q + '"' + (side === 'M' ? (q !== 'aside' ? pk('cat', q) : '') : pk(side === 'L' ? 'wgrp' : 'dgrp', q)) + tip(name(q), [S('nodeTip', { n: num(tot[q]), p: pct0(tot[q] / T * 100) })]) + '/>';
        var lx = side === 'L' ? x - 8 : x + nw + 8, an = side === 'L' ? 'end' : null;
        labels += '<text class="halo" x="' + lx + '" y="' + r1(ys[i]) + '"' + (an ? ' text-anchor="end"' : '') + '><tspan class="ink">' + esc(name(q)) + '</tspan> <tspan class="mu">' + esc(num(tot[q])) + '</tspan></text>';
      });
    }
    col(LN, pL, tl, xL, function () { return 'var(--ink-2)'; }, wName, 'L');
    col(MN, pM, tm, xM, catFill, catLabel, 'M');
    col(RN, pR, tr, xR, function () { return 'var(--ink-2)'; }, rName, 'R');
    var heads = tx(xL + nw, 14, S('colWhere'), 'mu b', 'end') + tx(xM, 14, S('colCat'), 'mu b') + tx(xR, 14, S('colDec'), 'mu b');
    var rows = [];
    LN.forEach(function (a) { MN.forEach(function (b) { if (lm[a + '|' + b]) rows.push([wName(a), catLabel(b), num(lm[a + '|' + b])]); }); });
    MN.forEach(function (b) { RN.forEach(function (c) { if (mr[b + '|' + c]) rows.push([catLabel(b), rName(c), num(mr[b + '|' + c])]); }); });
    vSet('flow', svg(W0, H, heads + '<g class="links">' + links + '</g>' + nodes + labels, S('t_flow'), 'flow'), '', miniTable([S('hFrom'), S('hTo'), S('hDef')], rows, 2));
  }

  // 3. Volume x unit cost per root cause, with curves of equal total cost
  function vBub(rs) {
    var W0 = vWidth('bub', 300), wide = W0 >= 900, H = W0 < 520 ? 320 : wide ? 480 : 380, ml = G.lang === 'en' ? 76 : 62, mr = 16, mt = 12, mb = 46, pw = W0 - ml - mr, ph = H - mt - mb;   // on a row of its own (Simple's Synthèse): taller, bigger bubbles, more names
    var st = {}; rs.forEach(function (r) { var a = dRca(r), s = st[a] || (st[a] = { n: 0, c: 0, cat: dCat(r) }); s.n++; s.c += dAlloc(r); });
    var list = Object.keys(st).filter(function (x) { return st[x].n >= 3; }).map(function (x) { var s = st[x]; return { k: x, n: s.n, c: s.c, a: s.c / s.n, cat: s.cat }; });
    if (list.length < 2) { vSet('bub', EMPTY); return; }
    var nMin = Math.min.apply(null, list.map(function (s) { return s.n; })), nMax = Math.max.apply(null, list.map(function (s) { return s.n; }));
    var lo = Math.log10(nMin / 1.5), hi = Math.log10(nMax * 1.5);
    var aMax = Math.max.apply(null, list.map(function (s) { return s.a; })), step = aMax <= 60 ? 10 : aMax <= 120 ? 20 : aMax <= 300 ? 50 : 100, yMax = Math.ceil(aMax * 1.12 / step) * step;
    var cMax = Math.max.apply(null, list.map(function (s) { return s.c; }));
    function X(n) { return ml + (Math.log10(n) - lo) / (hi - lo) * pw; } function Y(a) { return mt + ph - a / yMax * ph; } function R(c) { return 3 + (wide ? 28 : 21) * Math.sqrt(c / cMax); }
    var g = '';
    for (var y = 0; y <= yMax; y += step) g += '<line class="gl" x1="' + ml + '" x2="' + (ml + pw) + '" y1="' + r1(Y(y)) + '" y2="' + r1(Y(y)) + '"/>' + tx(ml - 8, Y(y) + 4, eur(y), 'mu', 'end');
    [1, 2, 5, 10, 20, 50, 100, 200, 500, 1000, 2000, 5000].forEach(function (t) { if (Math.log10(t) < lo || Math.log10(t) > hi) return; g += '<line class="gl" y1="' + mt + '" y2="' + (mt + ph) + '" x1="' + r1(X(t)) + '" x2="' + r1(X(t)) + '"/>' + tx(X(t), mt + ph + 16, num(t), 'mu', 'middle'); });
    g += tx(ml + pw / 2, H - 6, S('axDef'), 'mu', 'middle') + tx(14, mt + ph / 2, S('axAvg'), 'mu', 'middle', ' transform="rotate(-90 14 ' + r1(mt + ph / 2) + ')"');
    var iso = '', nHi = Math.pow(10, hi), nLo = Math.pow(10, lo), isoBox = [];
    [1000, 5000, 20000, 50000].forEach(function (C) {
      if (C / nHi > yMax || C / nLo < yMax * 0.12) return;
      var n0 = Math.max(nLo, C / yMax), pts = [];
      for (var i = 0; i <= 40; i++) { var n = Math.pow(10, Math.log10(n0) + (hi - Math.log10(n0)) * i / 40); pts.push(r1(X(n)) + ',' + r1(Y(C / n))); }
      iso += '<path class="iso" d="M' + pts.join('L') + '"/>';
      var lx = n0 > nLo ? X(n0) + 4 : ml + 4, ly = n0 > nLo ? mt + 11 : Y(C / nLo) - 4;
      iso += tx(lx, ly, kEur(C), 'mu halo'); isoBox.push([lx - 2, ly - 11, lx + 40, ly + 3]);
    });
    list.sort(function (a, b) { return b.c - a.c; });
    var dots = list.map(function (s) { var x = X(s.n), yy = Y(s.a), r = R(s.c), gray = ASIDE[s.cat], col = gray ? 'var(--muted)' : catFill(s.cat);   // the category's colour (20 Oct)
      return '<g class="bub"' + pk('rca', s.k) + tip(L(s.k), [S('bubTip', { n: num(s.n), c: eur(s.c), a: eur(s.a) }), L(s.cat)]) + '><circle cx="' + r1(x) + '" cy="' + r1(yy) + '" r="' + r1(Math.max(r, 12)) + '" fill="transparent"/>' +
        '<circle class="dot" cx="' + r1(x) + '" cy="' + r1(yy) + '" r="' + r1(r) + '" fill="' + (gray ? 'var(--dim)' : col) + '" fill-opacity=".32" stroke="' + col + '" stroke-width="1.5"/></g>'; }).join('');
    // direct labels: the most expensive causes first, skipped when they would collide
    var placed = isoBox.slice(), labs = '';
    function clear(b, p) { return b[2] < p[0] || b[0] > p[2] || b[3] < p[1] || b[1] > p[3]; }
    function free(b, self) {
      if (b[0] < ml || b[2] > ml + pw || b[1] < mt || b[3] > mt + ph) return false;
      return placed.every(function (p) { return clear(b, p); }) && list.every(function (s) { if (s === self) return true; var r = R(s.c) * 0.7; return clear(b, [X(s.n) - r, Y(s.a) - r, X(s.n) + r, Y(s.a) + r]); });
    }
    var byAvg = list.filter(function (s) { return s.n >= 10; }).sort(function (a, b) { return b.a - a.a; })[0];
    var nLab = wide ? 15 : 9;
    list.slice(0, nLab).concat(byAvg && list.indexOf(byAvg) >= nLab ? [byAvg] : []).forEach(function (s) {
      var x = X(s.n), yy = Y(s.a), r = R(s.c), t = L(s.k), w = t.length * 6.3 + 4;
      var tries = [[x + r + 4, yy + 4, 'start', [x + r + 2, yy - 9, x + r + 6 + w, yy + 5]], [x - r - 4, yy + 4, 'end', [x - r - 6 - w, yy - 9, x - r - 2, yy + 5]],
        [x, yy - r - 5, 'middle', [x - w / 2, yy - r - 18, x + w / 2, yy - r - 3]], [x, yy + r + 14, 'middle', [x - w / 2, yy + r + 2, x + w / 2, yy + r + 17]]];
      for (var i = 0; i < tries.length; i++) { if (free(tries[i][3], s)) { placed.push(tries[i][3]); labs += tx(tries[i][0], tries[i][1], t, 'ink halo', tries[i][2] === 'start' ? null : tries[i][2]); break; } }
    });
    var cin = {}; list.forEach(function (s) { cin[catKey(s.cat)] = 1; });
    var leg = MAIN_CATS.filter(function (c) { return cin[c]; }).map(function (c) { var cc = c === 'aside' ? 'var(--muted)' : catFill(c); return '<span><i class="sw ring" style="background:' + tint(c === 'aside' ? '--dim' : '--c' + CATC[c], 32) + ';border-color:' + cc + '"></i>' + esc(catLabel(c)) + '</span>'; }).join('') +
      '<span class="mu">' + esc(S('bubLeg')) + '</span><span><i class="dash"></i>' + esc(S('isoLeg')) + '</span>';
    var rows = list.map(function (s) { return [L(s.k), L(s.cat), num(s.n), eur(s.c), eur(s.a)]; });
    vSet('bub', svg(W0, H, g + iso + dots + labs, S('t_bub')), leg, miniTable([S('rRca'), S('rCat'), S('hDef'), S('hCost'), S('hPerDef')], rows, 2));
  }

  // 6. Bump chart: monthly rank of the top 8 root causes
  function vBump(rs) {
    var cnt = {}, tot = {}, vol = {};
    var cof = {}; rs.forEach(function (r) { var m = r[2].slice(0, 7), a = dRca(r); (cnt[m] || (cnt[m] = {}))[a] = (cnt[m][a] || 0) + 1; tot[a] = (tot[a] || 0) + 1; vol[m] = (vol[m] || 0) + 1; cof[a] = catKey(dCat(r)); });
    var months = Object.keys(cnt).sort();
    if (months.length < 2) { vSet('bump', EMPTY); return; }
    var top = Object.keys(tot).sort(function (a, b) { return tot[b] - tot[a] || (a < b ? -1 : 1); }).slice(0, 8), rank = {};
    months.forEach(function (m) { Object.keys(cnt[m]).sort(function (a, b) { return cnt[m][b] - cnt[m][a] || (a < b ? -1 : 1); }).forEach(function (a, i) { (rank[m] || (rank[m] = {}))[a] = i + 1; }); });
    A.top0 = top[0];
    var pin = A.pin == null ? top[0] : A.pin, MAXR = 10;
    var W0 = vWidth('bump', 520), right = W0 < 700 ? 160 : 210, left = 40, mt = 30, rowH = 25, H = mt + (MAXR + 1) * rowH + 8;
    var sx = (W0 - left - right - 24) / (months.length - 1);
    function X(j) { return left + 12 + j * sx; } function row(a, m) { var k = rank[m][a]; return k && k <= MAXR ? k : MAXR + 1; } function Y(rw) { return mt + (rw - 0.5) * rowH; }
    var vs = months.map(function (m) { return vol[m]; }).sort(function (a, b) { return a - b; }), med = vs[Math.floor(vs.length / 2)], g = '';
    months.forEach(function (m, j) {
      if (vol[m] < med * 0.5) g += '<rect x="' + r1(X(j) - sx / 2) + '" y="' + (mt - 4) + '" width="' + r1(sx) + '" height="' + ((MAXR + 1) * rowH + 4) + '" fill="var(--track)"' + tip(monthName(m), [S('lowTip', { n: num(vol[m]) })]) + '/>' + tx(X(j), H - 2, S('lowVol'), 'mu', 'middle');
      g += tx(X(j), 14, monthName(m), 'mu', 'middle');
    });
    for (var k = 1; k <= MAXR + 1; k++) g += tx(left - 8, Y(k) + 4, k <= MAXR ? String(k) : S('beyond'), 'mu', 'end');
    var order = top.filter(function (a) { return a !== pin; }).concat(top.indexOf(pin) >= 0 ? [pin] : []), ends = [];
    order.forEach(function (a) {
      var hl = a === pin, col = hl ? (cof[a] === 'aside' ? 'var(--ink-2)' : catFill(cof[a])) : 'var(--dim)', d = '';   // the cause picked, in its category's colour
      months.forEach(function (m, j) { var x = X(j), y = Y(row(a, m)); if (!j) d = 'M' + r1(x) + ',' + r1(y); else { var x0 = X(j - 1), y0 = Y(row(a, months[j - 1])), xm = (x0 + x) / 2; d += 'C' + r1(xm) + ',' + r1(y0) + ' ' + r1(xm) + ',' + r1(y) + ' ' + r1(x) + ',' + r1(y); } });
      g += '<g class="bline' + (hl ? ' hl' : '') + '" data-pin="' + esc(a) + '"><path d="' + d + '" fill="none" stroke="transparent" stroke-width="14"/><path d="' + d + '" fill="none" stroke="' + col + '" stroke-width="' + (hl ? 3 : 2) + '" stroke-linecap="round"/>';
      months.forEach(function (m, j) { var rk = rank[m][a], n = cnt[m][a] || 0;
        g += '<circle cx="' + r1(X(j)) + '" cy="' + r1(Y(row(a, m))) + '" r="10" fill="transparent"' + tip(L(a) + ' · ' + monthName(m), [rk ? S('bumpTip', { r: ord(rk), n: num(n) }) : S('bumpNone')]) + '/>' +
          '<circle cx="' + r1(X(j)) + '" cy="' + r1(Y(row(a, m))) + '" r="' + (hl ? 5 : 4) + '" fill="' + col + '" stroke="var(--surface)" stroke-width="2" pointer-events="none"/>'; });
      g += '</g>';
      ends.push({ a: a, y: Y(row(a, months[months.length - 1])) + 4, hl: hl });
    });
    var ys = spread(ends.map(function (e) { return e.y; }), 14, mt, H - 4), xe = X(months.length - 1) + 12, maxCh = Math.floor((right - 16) / 6.6);
    ends.forEach(function (e, i) { var t = L(e.a); if (t.length > maxCh) t = t.slice(0, maxCh - 1) + '…';
      g += '<text class="halo' + (e.hl ? ' ink b' : '') + '" x="' + r1(xe) + '" y="' + r1(ys[i]) + '" data-pin="' + esc(e.a) + '">' + esc(t) + '</text>'; });
    var rows = top.map(function (a) { return [L(a)].concat(months.map(function (m) { return rank[m][a] ? ord(rank[m][a]) + ' (' + num(cnt[m][a]) + ')' : '—'; })); });
    vSet('bump', svg(W0, H, g, S('t_bump')), cof[pin] ? sw(cof[pin] === 'aside' ? 'var(--ink-2)' : catFill(cof[pin]), L(pin) + ' · ' + catLabel(cof[pin])) : '', miniTable([S('rRca')].concat(months.map(monthName)), rows, 1));
  }

  // 6b. The causes month by month: one bar per month, the causes stacked, over the months of the year followed, within the period. The top X causes of
  // the selection (X: the card's − / +, 3 at first) and the causes added by hand (Déverrouillage and FOD from the start, for safety;
  // ✕ takes one away). The measure is the Pareto tab's (defects or cost of non-quality), or NCs with the card's switch (an NC
  // counts once for each cause it has). Colours: the cause's category, as on the other charts; two causes of one category differ by
  // their dashes, and each line is named at its end.
  var CMO = { n: 3, add: ['Déverrouillage', 'FOD'], nc: false, cat: false, cn: 3, cadd: ['Déverrouillage', 'FOD'] };   // cat: the Pareto categories instead of the causes (cn, cadd: their top and the ones added)
  function cmoMonths() {
    var y = String(YEAR), from = GF.from > y + '-01-01' ? GF.from : y + '-01-01', to = [GF.to, D.meta.to, y + '-12-31'].sort()[0], out = [];
    for (var d = new Date(from.slice(0, 7) + '-01T00:00:00Z'); d.toISOString().slice(0, 7) <= to.slice(0, 7); d.setUTCMonth(d.getUTCMonth() + 1)) out.push(d.toISOString().slice(0, 7));
    return out;
  }
  function vCmo(rs) {
    var months = cmoMonths(), mode = CMO.nc ? 'nc' : PMODE === 'cost' ? 'cost' : 'vol', fmt = mode === 'cost' ? eurK : num, mi = {}, val = {}, tot = {}, seen = {};
    months.forEach(function (m, i) { mi[m] = i; });
    var byCat = CMO.cat, N = byCat ? CMO.cn : CMO.n, ADD = byCat ? CMO.cadd : CMO.add;
    rs.forEach(function (r) { var a = byCat ? (dCat(r) ? catKey(dCat(r)) : '') : dRca(r), i = mi[r[2].slice(0, 7)]; if (!a || i == null) return;
      if (mode === 'nc') { if (seen[a + '|' + r[0]]) return; seen[a + '|' + r[0]] = 1; }
      var v = mode === 'cost' ? dAlloc(r) : 1;
      (val[a] || (val[a] = months.map(function () { return 0; })))[i] += v; tot[a] = (tot[a] || 0) + v; });
    var top = Object.keys(tot).sort(function (a, b) { return tot[b] - tot[a] || (a < b ? -1 : 1); }).slice(0, N);
    var shown = top.concat(ADD.filter(function (a) { return top.indexOf(a) < 0; }));
    function nm(a) { return byCat ? catLabel(a) : L(a); }
    function col(a) { return byCat ? catFill(a) : vqCol(a); }
    function pick(a) { return byCat ? (a === 'aside' ? '' : pk('cat', a)) : pk('rca', a); }
    var names = (byCat ? MAIN_CATS.slice() : Object.keys(RCA_CAT)).filter(function (a) { return a && ADD.indexOf(a) < 0; }).sort(function (a, b) { return nm(a).localeCompare(nm(b), loc()); });
    var C = byCat ? 'C' : '';   // the wording for categories
    var ctl = '<div class="cmo-ctl"><div class="seg grpseg" role="group" aria-label="' + esc(S('cmoLvl')) + '">' + segHtml([['rca', S('cmoRca')], ['cat', S('cmoCat')]], byCat ? 'cat' : 'rca', 'data-cmol') + '</div>' +
      '<div class="seg grpseg" role="group" aria-label="' + esc(S('cmoMeas')) + '">' + segHtml([['m', S(PMODE === 'cost' ? 'mCost' : 'mVol')], ['nc', S('cmoNc')]], CMO.nc ? 'nc' : 'm', 'data-cmom') + '</div>' +
      '<span class="cmo-n"><span>' + esc(S('cmoTop' + C)) + '</span><button type="button" data-cmon="-1" aria-label="' + esc(S('cmoLess' + C)) + '"' + (N <= 1 ? ' disabled' : '') + '>−</button><b>' + N + '</b><button type="button" data-cmon="1" aria-label="' + esc(S('cmoMore' + C)) + '"' + (N >= 10 ? ' disabled' : '') + '>+</button></span>' +
      '<select data-cmoadd aria-label="' + esc(S('cmoAdd' + C)) + '"><option value="">' + esc(S('cmoAdd' + C)) + '</option>' + names.map(function (a) { return '<option value="' + esc(a) + '">' + esc(nm(a)) + '</option>'; }).join('') + '</select>' +
      ADD.map(function (a) { return '<button type="button" class="chip" data-cmox="' + esc(a) + '" aria-label="' + esc(S('cmoDel', { c: nm(a) })) + '">' + esc(nm(a)) + ' <i aria-hidden="true">✕</i></button>'; }).join('') + '</div>';
    if (!months.length || !shown.length) { vSet('cmo', ctl + EMPTY); return; }
    // one bar per month, the causes stacked in the order of the key (the first at the bottom), a 2 px gap between them; two causes
    // of one category differ by their shade; the month in progress is pale
    var shade = {}, nCat = {}; shown.forEach(function (a) { var c = byCat ? a : RCA_CAT[a] || 'aside', j = nCat[c] = (nCat[c] || 0) + 1; shade[a] = j === 1 ? 1 : j === 2 ? 0.62 : j === 3 ? 0.4 : 0.28; });
    var W0 = vWidth('cmo', 360), ml = mode === 'cost' ? 62 : 40, mt = 14, h = 240, H = mt + h + 26, pw = W0 - ml - 12, n = months.length;
    var stack = months.map(function (m, j) { return sumA(shown.map(function (a) { return (val[a] || [])[j] || 0; })); });
    var mx = Math.max.apply(null, stack.concat([1e-9])), nt = pNice(mx * 1.08), g = '';
    var gw = pw / n, bw = Math.max(6, Math.min(30, gw * 0.34));
    function Y(v) { return mt + h - v / nt.top * h; }
    for (var t = 0; t <= nt.top + 1e-9; t += nt.step) g += '<line x1="' + ml + '" x2="' + (ml + pw) + '" y1="' + r1(Y(t)) + '" y2="' + r1(Y(t)) + '" stroke="var(--grid)"/>' + tx(ml - 6, Y(t) + 4, (mode === 'cost' && nt.top >= 10000 ? kEur : fmt)(Math.round(t * 100) / 100), 'mu', 'end');
    months.forEach(function (m, j) { g += tx(ml + gw * (j + 0.5), H - 6, v2Mo(m, gw, j), 'mu', 'middle'); });
    var cur = monthShare(months[n - 1]).p < 1 ? n - 1 : -1;
    months.forEach(function (m, j) {
      var cu = j === cur, x0 = ml + gw * j + (gw - bw) / 2, base = 0;
      shown.forEach(function (a) {
        var x = (val[a] || [])[j] || 0; if (x <= 0) return;
        var y1 = Y(base + x), y0 = Y(base), hh = Math.max(0, y0 - y1 - (base > 0 ? 2 : 0));   // the 2 px gap above the segment below
        g += '<rect x="' + r1(x0) + '" y="' + r1(y1) + '" width="' + r1(bw) + '" height="' + r1(Math.max(0.5, hh)) + '" rx="1.5" fill="' + col(a) + '" fill-opacity="' + (shade[a] * (cu ? 0.45 : 1)) + '"' + pick(a) +
          tip(nm(a) + ' · ' + monthName(m) + ' ' + m.slice(0, 4), [S('cmoTip' + mode, { v: fmt(x) })].concat(byCat ? [] : [catLabel(RCA_CAT[a] || 'aside')]).concat(cu ? [S('v2CurPt', { d: day(D.meta.to) })] : [])) + '/>';
        base += x;
      });
      if (stack[j] > 0) g += tx(ml + gw * (j + 0.5), Y(stack[j]) - 5, fmt(stack[j]), 'mu', 'middle');
    });
    g += '<line x1="' + ml + '" x2="' + (ml + pw) + '" y1="' + (mt + h) + '" y2="' + (mt + h) + '" stroke="var(--muted)"/>';
    var leg = shown.map(function (a) { return '<span><i class="sw" style="background:' + col(a) + ';opacity:' + shade[a] + '"></i>' + esc(nm(a)) + (ADD.indexOf(a) >= 0 && top.indexOf(a) < 0 ? ' (' + esc(S('cmoAdded')) + ')' : '') + '</span>'; }).join('') +
      (cur >= 0 ? '<span><i class="sw" style="background:var(--muted);opacity:.45"></i>' + esc(S('v2CurPtL', { d: day(D.meta.to) })) + '</span>' : '') + '<span class="mu">' + esc(S('cmoLeg' + mode + (byCat && mode === 'nc' ? 'C' : ''))) + '</span>';
    var rows = shown.map(function (a) { var v = val[a] || months.map(function () { return 0; }); return [nm(a)].concat(v.map(fmt)).concat([fmt(sumA(v))]); });
    vSet('cmo', ctl + svg(W0, H, g, S('t_cmo')), leg, miniTable([S(byCat ? 'rCat' : 'rRca')].concat(months.map(monthName)).concat([S('total')]), rows, 1));
  }
  document.addEventListener('click', function (e) {
    var t = e.target.closest && e.target.closest('[data-cmol], [data-cmom], [data-cmon], [data-cmox]'); if (!t) return;
    if (t.hasAttribute('data-cmol')) CMO.cat = t.getAttribute('data-cmol') === 'cat';
    else if (t.hasAttribute('data-cmom')) CMO.nc = t.getAttribute('data-cmom') === 'nc';
    else if (t.hasAttribute('data-cmon')) { var k = CMO.cat ? 'cn' : 'n'; CMO[k] = Math.max(1, Math.min(10, CMO[k] + +t.getAttribute('data-cmon'))); }
    else { var a = t.getAttribute('data-cmox'), ka = CMO.cat ? 'cadd' : 'add'; CMO[ka] = CMO[ka].filter(function (x) { return x !== a; }); }
    hideTip(); rvDraw('A:cmo');
  });
  document.addEventListener('change', function (e) {
    var t = e.target.closest && e.target.closest('[data-cmoadd]'); if (!t || !t.value) return;
    var ad = CMO.cat ? CMO.cadd : CMO.add; if (ad.indexOf(t.value) < 0) ad.push(t.value);
    rvDraw('A:cmo');
  });

  // ---- NC-level charts: aircraft (MSN), product family, lead time, hour, station, MFT actions
  // NC row extras: [25] msn, [26] product family, [27] station, [28] creation hour (Paris), [29] days to close, [30] open, [31] age if open
  var PROGS = ['A350', 'A330', 'A320', 'A400M'];
  function progName(l) { return l === 'A320' ? S('a320fam') : l; }

  // 7. Cost per aircraft: one strip per programme, one bar per MSN in order of its first NC
  function vMsn() {
    var W0 = vWidth('msn', 520), per = {};
    SEL_NC.forEach(function (n) { if (!n[25]) return; var k = n[3] + '|' + n[25], m = per[k] || (per[k] = { l: n[3], msn: n[25], first: n[1], s: 0, c: 0, ncs: [] });
      if (n[1] < m.first) m.first = n[1]; if (n[23] === 'client') m.c += n[12]; else m.s += n[12]; m.ncs.push(n); });
    var rows = PROGS.filter(function (l) { return Object.keys(per).some(function (k) { return per[k].l === l; }); }).map(function (l) {
      return { l: l, ms: Object.keys(per).filter(function (k) { return per[k].l === l; }).map(function (k) { return per[k]; }).sort(function (a, b) { return a.st < b.st ? -1 : a.st > b.st ? 1 : (+a.msn) - (+b.msn); }) }; });
    if (!rows.length) { vSet('msn', EMPTY); return; }
    Object.keys(per).forEach(function (k) { var m = per[k], x = D.eqmsn && D.eqmsn.msn && D.eqmsn.msn[k]; m.st = x ? x[0] : m.first; m.lia = m.ncs.filter(function (n) { return n[5] === 1; }).length; });   // production start, else the first NC (30 Oct)
    var recent = isoDay(new Date(new Date(D.meta.to + 'T00:00:00Z').getTime() - 30 * 864e5));
    // hatched: in production at the last NC date, from the production table (start .. OTA); without it,
    // first NC in the last 30 days. Pale: the aircraft already had NCs in 2025, so part of it was built before this view (29 Oct)
    var PM = D.eqmsn && D.eqmsn.msn, Y25M = (D.y25 && D.y25.byMsn) || {};
    function inProd(l, msn, first) { if (!PM) return first >= recent; var x = PM[l + '|' + msn]; return !!x && x[0] <= D.meta.to && D.meta.to < x[1]; }
    var lab = 136, maxN = Math.max.apply(null, rows.map(function (r) { return r.ms.length; })), step = Math.max(5, Math.min(26, Math.floor((W0 - lab - 8) / maxN))), bw = Math.max(3, step - 2);
    var maxC = Math.max.apply(null, rows.map(function (r) { return Math.max.apply(null, r.ms.map(function (m) { return m.s + m.c; })); }));
    var tick = maxC > 2500 ? 1000 : maxC > 1200 ? 500 : 250, top = Math.ceil(maxC / tick) * tick, ph = 92, rh = ph + 34, H = rows.length * rh + 4, g = '', rowsTbl = [];
    rows.forEach(function (row, ri) {
      var y0 = ri * rh + 8, base = y0 + ph, Y = function (v) { return base - v / top * ph; }, tot = 0, w = lab + row.ms.length * step;
      g += tx(0, y0 + 14, progName(row.l), 'ink b') + tx(0, y0 + 30, S('msnCount', { n: num(row.ms.length) }), 'mu');
      for (var t = tick; t <= top; t += tick) g += '<line class="gl" x1="' + lab + '" x2="' + (W0 - 4) + '" y1="' + r1(Y(t)) + '" y2="' + r1(Y(t)) + '"/>' + tx(lab - 6, Y(t) + 4, kEur(t), 'mu', 'end');
      g += '<line class="ax" x1="' + lab + '" x2="' + (W0 - 4) + '" y1="' + base + '" y2="' + base + '" stroke="var(--grid)"/>';
      row.ms.forEach(function (m, j) {
        var x = lab + j * step + 1, sel = A.msn === row.l + '|' + m.msn, rec = inProd(row.l, m.msn, m.first), n25 = Y25M[row.l + '|' + m.msn] || 0, hs = m.s / top * ph, hc = m.c / top * ph;
        tot += m.s + m.c;
        var t2 = tip('MSN ' + m.msn + ' · ' + progName(row.l), [eur(m.s + m.c), S('msnLiab', { n: num(m.ncs.length), k: num(m.lia) }), S('msnTip', { s: eur(m.s), c: eur(m.c) }), S('msnFirst', { d: shortDay(m.first) }) + (rec ? ' · ' + S(PM ? 'msnInProd' : 'msnRecent') : '')].concat(n25 ? [S('msnBefore', { n: num(n25) })] : []));
        g += '<g data-msn="' + esc(row.l + '|' + m.msn) + '"' + pk('msn', m.msn) + t2 + (A.msn && !sel ? ' opacity=".45"' : '') + '><rect x="' + r1(x - 1) + '" y="' + y0 + '" width="' + step + '" height="' + ph + '" fill="transparent"/>' +
          (hs ? '<rect x="' + r1(x) + '" y="' + r1(base - hs) + '" width="' + bw + '" height="' + r1(Math.max(hs, 1)) + '" rx="2" fill="' + (rec ? 'url(#hatchS1)' : n25 ? 'var(--dim)' : 'var(--s1)') + '"' + (rec ? ' stroke="var(--s1)" stroke-width="1"' : '') + '/>' : '') +
          (hc ? '<rect x="' + r1(x) + '" y="' + r1(base - hs - hc - (hs ? 2 : 0)) + '" width="' + bw + '" height="' + r1(Math.max(hc, 1)) + '" rx="2" fill="var(--s1-ret)"/>' : '') +
          (!hs && !hc ? '<rect x="' + r1(x) + '" y="' + (base - 3) + '" width="' + bw + '" height="3" fill="var(--muted)"/>' : '') +
          (sel ? '<rect x="' + r1(x - 2) + '" y="' + r1(base - hs - hc - 4) + '" width="' + (bw + 4) + '" height="' + r1(hs + hc + 6) + '" fill="none" stroke="var(--ink)" stroke-width="1.5" rx="3"/>' : '') + '</g>';
      });
      var avg = tot / row.ms.length;
      g += '<line class="guide" x1="' + lab + '" x2="' + r1(w) + '" y1="' + r1(Y(avg)) + '" y2="' + r1(Y(avg)) + '"/>' + tx(Math.min(w + 4, W0 - 4), Y(avg) + 4, S('avgShort', { v: eur(avg) }), 'mu halo', w + 90 > W0 ? 'end' : null);
      var placed = [];
      row.ms.slice().sort(function (a, b) { return (b.s + b.c) - (a.s + a.c); }).slice(0, 3).forEach(function (m) {
        var j = row.ms.indexOf(m), cx = lab + j * step + 1 + bw / 2, lw = String(m.msn).length * 7;   // label width, about 7 px a digit
        if (placed.some(function (p) { return Math.abs(p[0] - cx) < (p[1] + lw) / 2 + 6; })) return; placed.push([cx, lw]);
        g += tx(cx, Y(m.s + m.c) - 5, m.msn, 'ink b halo', 'middle');
      });
      rowsTbl.push([progName(row.l), num(row.ms.length), eur(tot), eur(avg), (function () { var b = row.ms.slice().sort(function (a, c) { return (c.s + c.c) - (a.s + a.c); })[0]; return b.msn + ' (' + eur(b.s + b.c) + ')'; })()]);
    });
    var defs = '<defs><pattern id="hatchS1" width="4" height="4" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><rect width="4" height="4" fill="var(--s1-soft)"/><line x1="0" y1="0" x2="0" y2="4" stroke="var(--s1)" stroke-width="1.5"/></pattern></defs>';
    var leg = '<span><i class="sw" style="background:var(--s1)"></i>' + esc(S('legSerie')) + '</span><span><i class="sw" style="background:var(--s1-ret)"></i>' + esc(S('legRet')) + '</span><span><i class="sw" style="background:repeating-linear-gradient(135deg,var(--s1) 0 2px,var(--s1-soft) 2px 4px)"></i>' + esc(S(PM ? 'msnInProdLeg' : 'msnRecentLeg')) + '</span>' + (Object.keys(Y25M).length ? '<span><i class="sw" style="background:var(--dim)"></i>' + esc(S('msnBeforeLeg')) + '</span>' : '') + '<span><i class="sw" style="height:3px;background:var(--muted)"></i>' + esc(S('msnZeroLeg')) + '</span><span><i class="dash"></i>' + esc(S('avgLeg')) + '</span>';
    vSet('msn', svg(W0, H, defs + g, S('t_msn')) + '<div class="msnlist" id="msnList"></div>', leg + '<span class="mu">' + esc(S('retNote')) + '</span>', miniTable([S('hProg'), 'MSN', S('hCost'), S('hPerMsn'), S('hMaxMsn')], rowsTbl, 1));
    renderMsnList(per);
  }
  function renderMsnList(per) {
    var el = document.getElementById('msnList'), m = A.msn && per[A.msn];
    if (!m) { el.innerHTML = '<p class="sub">' + esc(S('msnClick')) + '</p>'; return; }
    var ncs = m.ncs.slice().sort(function (a, b) { return a[1] < b[1] ? -1 : 1; });
    el.innerHTML = '<div class="card-head"><h4>MSN ' + esc(m.msn) + ' · ' + esc(progName(m.l)) + ' · ' + esc(S('msnHead', { n: num(ncs.length), k: num(m.lia), c: eur(m.s + m.c) })) + '</h4><button type="button" class="clear-one" data-msnclose="1">' + esc(S('clear')) + '</button></div>' +
      '<div class="table-wrap"><table class="mini"><thead><tr>' + ['kNc', 'kDate', 'hProd', 'hNcType', 'hNcTitle', 'kRule', 'hScope'].map(function (k) { return '<th scope="col">' + esc(S(k)) + '</th>'; }).join('') + '</tr></thead><tbody>' +
      ncs.map(function (n) { return '<tr><td class="nc">' + esc(n[0]) + '</td><td class="num">' + esc(shortDay(n[1])) + '</td><td>' + esc(prodName(n[26])) + '</td><td>' + esc(typeName(ncType(n))) + '</td><td>' + esc(n[22]) + '</td><td>' + esc(ruleName(n[7])) + '</td><td>' + (n[23] === 'client' ? '<span class="tag">' + esc(S('legRet')) + '</span>' : esc(S('legSerie'))) + '</td></tr>'; }).join('') + '</tbody></table></div>';
  }

  // 8. Product families: cost (series + customer returns), NCs, MSNs, cost per MSN
  function prodName(p) { return p === 'Other' ? S('prodUnknown') : p; }
  function vProd() {
    var W0 = vWidth('prod', 300), per = {};
    SEL_NC.forEach(function (n) { var p = n[26] || 'Other', m = per[p] || (per[p] = { p: p, s: 0, c: 0, n: 0, msn: {} }); if (n[23] === 'client') m.c += n[12]; else m.s += n[12]; m.n++; if (n[25]) m.msn[n[25]] = 1; });
    var list = Object.keys(per).map(function (k) { var m = per[k]; m.t = m.s + m.c; m.k = Object.keys(m.msn).length; return m; }).sort(function (a, b) { return b.t - a.t; });
    if (!list.length) { vSet('prod', EMPTY); return; }
    if (list.length > 11) { var rest = list.slice(10), o = { p: '__rest', s: 0, c: 0, n: 0, msn: {}, k: 0, t: 0, nf: rest.length };
      rest.forEach(function (m) { o.s += m.s; o.c += m.c; o.n += m.n; o.t += m.t; Object.keys(m.msn).forEach(function (x) { o.msn[x] = 1; }); }); o.k = Object.keys(o.msn).length; list = list.slice(0, 10).concat([o]); }
    var wide = W0 >= 480, name = wide ? 118 : 96, cols = wide ? [['hNcs', 44], ['MSN', 44], ['hPerMsn', 92]] : [['hNcs', 40], ['MSN', 40]], colW = cols.reduce(function (s, c) { return s + c[1]; }, 0);
    var valW = 64, bx = name + 8, bwMax = W0 - bx - valW - colW - 8, rh = 26, top = 22, H = top + list.length * rh + 4, mx = list[0].p === '__rest' ? list[1].t : Math.max.apply(null, list.map(function (m) { return m.t; })), g = '';
    var cx = W0 - colW; cols.forEach(function (c) { cx += c[1]; g += tx(cx - 4, 12, c[0] === 'MSN' ? 'MSN' : S(c[0]), 'mu', 'end'); });
    list.forEach(function (m, i) {
      var y = top + i * rh, ws = m.s / mx * bwMax, wc = m.c / mx * bwMax, lbl = m.p === '__rest' ? S('prodRest', { n: m.nf }) : prodName(m.p);
      g += '<g' + (m.p !== '__rest' ? pk('prod', m.p) : '') + tip(lbl, [eur(m.t), S('prodTip', { s: eur(m.s), c: eur(m.c), n: num(m.n), k: num(m.k) })]) + '><rect x="0" y="' + y + '" width="' + W0 + '" height="' + rh + '" fill="transparent"/>' +
        tx(name, y + 17, lbl.length > (wide ? 18 : 14) ? lbl.slice(0, wide ? 17 : 13) + '…' : lbl, m.p === '__rest' ? 'mu' : 'ink', 'end') +
        '<rect x="' + bx + '" y="' + (y + 6) + '" width="' + r1(Math.max(Math.min(ws, bwMax), 1)) + '" height="14" rx="2" fill="' + (m.p === '__rest' ? 'var(--dim)' : 'var(--s1)') + '"/>' +
        (wc >= 1 ? '<rect x="' + r1(bx + Math.min(ws, bwMax) + 2) + '" y="' + (y + 6) + '" width="' + r1(Math.min(wc, bwMax)) + '" height="14" rx="2" fill="var(--s1-ret)"/>' : '') +
        tx(bx + Math.min(ws + wc, bwMax) + (wc >= 1 ? 4 : 2) + 4, y + 17, eurK(m.t), 'ink') + '</g>';
      var cx2 = W0 - colW, vals = [num(m.n), num(m.k), m.k ? eur(m.t / m.k) : '—'];
      cols.forEach(function (c, ci) { cx2 += c[1]; g += tx(cx2 - 4, y + 17, vals[ci], 'mu', 'end'); });
    });
    var leg = '<span><i class="sw" style="background:var(--s1)"></i>' + esc(S('legSerie')) + '</span><span><i class="sw" style="background:var(--s1-ret)"></i>' + esc(S('legRet')) + '</span>';
    var rows = list.map(function (m) { return [m.p === '__rest' ? S('prodRest', { n: m.nf }) : prodName(m.p), eur(m.s), eur(m.c), num(m.n), num(m.k), m.k ? eur(m.t / m.k) : '—']; });
    vSet('prod', svg(W0, H, g, S('t_prod')), leg, miniTable([S('hProd'), S('legSerie'), S('legRet'), S('hNcs'), 'MSN', S('hPerMsn')], rows, 1));
  }

  // 9. Lead time: share of NCs still open N days after creation (Kaplan-Meier, open NCs counted until today)
  function km(items) {
    var ev = items.slice().sort(function (a, b) { return a.t - b.t; }), atRisk = ev.length, s = 1, pts = [[0, 1]], i = 0;
    while (i < ev.length) { var t = ev[i].t, d = 0, c = 0; while (i < ev.length && ev[i].t === t) { if (ev[i].e) d++; else c++; i++; } if (d) { s *= 1 - d / atRisk; pts.push([t, s]); } atRisk -= d + c; }
    return pts;
  }
  function kmAt(pts, t) { var s = 1; for (var i = 0; i < pts.length && pts[i][0] <= t; i++) s = pts[i][1]; return s; }
  function kmMedian(pts) { for (var i = 0; i < pts.length; i++) if (pts[i][1] <= 0.5) return pts[i][0]; return null; }
  function vLead() {
    var ncs = aNcs().filter(function (n) { return n[29] != null || n[31] != null; });
    if (ncs.length < 5) { vSet('lead', EMPTY); A.km = null; return; }
    var grp = { rw: [], rej: [], oth: [] }, all = [], open = [];
    ncs.forEach(function (n) { var it = n[29] != null ? { t: Math.round(n[29] * 10) / 10, e: 1 } : { t: Math.round(n[31] * 10) / 10, e: 0 }, gk = dGroup(n[7]);
      (grp[gk === 'exc' ? 'oth' : gk] || grp.oth).push(it); all.push(it); if (n[30]) open.push(n); });
    var keys = ['rw', 'rej', 'oth'].filter(function (k) { return grp[k].length >= 5; }), col = { rw: 'var(--ink)', rej: 'var(--s1)', oth: 'var(--muted)' };
    var curves = {}; keys.forEach(function (k) { curves[k] = km(grp[k]); });
    var W0 = vWidth('lead', 300), H = W0 < 520 ? 300 : 360, ml = 48, mr = 16, mt = 12, mb = 44, pw = W0 - ml - mr, ph = H - mt - mb, XM = 60;
    function X(t) { return ml + Math.min(t, XM) / XM * pw; } function Y(p) { return mt + ph - p * ph; }
    var g = '';
    [0, 0.25, 0.5, 0.75, 1].forEach(function (p) { g += '<line class="gl" x1="' + ml + '" x2="' + (ml + pw) + '" y1="' + r1(Y(p)) + '" y2="' + r1(Y(p)) + '"/>' + tx(ml - 8, Y(p) + 4, pct0(p * 100), 'mu', 'end'); });
    [0, 7, 14, 21, 30, 45, 60].forEach(function (t) { g += tx(X(t), mt + ph + 16, (t === 60 ? '≥ ' : '') + num(t), 'mu', 'middle'); });
    g += tx(ml + pw / 2, H - 6, S('axDays'), 'mu', 'middle');
    keys.forEach(function (k) {
      var pts = curves[k], d = 'M' + X(0) + ',' + Y(1);
      pts.slice(1).forEach(function (p) { if (p[0] > XM) return; d += 'H' + r1(X(p[0])) + 'V' + r1(Y(p[1])); });
      d += 'H' + r1(X(XM));
      g += '<path d="' + d + '" fill="none" stroke="' + col[k] + '" stroke-width="2"/>';
      var md = kmMedian(pts); if (md != null && md <= XM) g += '<circle cx="' + r1(X(md)) + '" cy="' + r1(Y(0.5)) + '" r="4.5" fill="' + col[k] + '" stroke="var(--surface)" stroke-width="2"/>';
    });
    g += '<line class="guide" x1="' + ml + '" x2="' + (ml + pw) + '" y1="' + r1(Y(0.5)) + '" y2="' + r1(Y(0.5)) + '"/>';
    var ag = GF.pick && GF.pick.k === 'age' ? +GF.pick.v : null;   // the day clicked: NCs still open after it
    if (ag != null) g += '<line x1="' + r1(X(ag)) + '" x2="' + r1(X(ag)) + '" y1="' + mt + '" y2="' + (mt + ph) + '" stroke="var(--s1)" stroke-width="1.5" stroke-dasharray="4 3"/>' + tx(X(ag) + (ag > XM * 0.5 ? -6 : 6), mt + 18, S('kmAgeMark', { n: num(ag) }), 'b halo', ag > XM * 0.5 ? 'end' : null, ' style="fill:var(--s1)"');
    g += '<line id="kmX" class="cross" y1="' + mt + '" y2="' + (mt + ph) + '" x1="-10" x2="-10"/><rect data-km="1" x="' + ml + '" y="' + mt + '" width="' + pw + '" height="' + ph + '" fill="transparent" style="cursor:pointer"/>';
    A.km = { keys: keys, curves: curves, ml: ml, pw: pw, XM: XM, ts: all.map(function (x) { return x.t; }) };
    var leg = keys.map(function (k) { var md = kmMedian(curves[k]); return '<span' + pk('lgrp', k) + '><i class="ln" style="background:' + col[k] + '"></i>' + esc(S('g_' + k)) + ' (' + num(grp[k].length) + ')' + (md != null ? ' · <b>' + esc(S('medDays', { n: num(Math.round(md)) })) + '</b>' : '') + '</span>'; }).join('') + '<span><i class="sw ring" style="background:var(--surface);border-color:var(--ink-2)"></i>' + esc(S('medLeg')) + '</span>' +
      (open.length ? '<span' + pk('open', '1') + '><i class="sw" style="background:var(--ink-2)"></i>' + esc(S('kmOpenN', { n: num(open.length) })) + '</span>' : '');
    var rows = keys.map(function (k) { var c = curves[k], md = kmMedian(c); return [S('g_' + k), num(grp[k].length), md != null ? S('daysShort', { n: num(Math.round(md)) }) : '—', pct0(kmAt(c, 7) * 100), pct0(kmAt(c, 30) * 100), num(grp[k].filter(function (x) { return !x.e; }).length)]; });
    vSet('lead', svg(W0, H, g, S('t_lead')), leg, miniTable([S('kRule'), S('hNcs'), S('hMedian'), S('hOpen7'), S('hOpen30'), S('hStillOpen')], rows, 1));
  }

  // 11. Station x category heatmap (series defects)
  function vStation(rs) {
    var per = {}, tot = {};
    rs.forEach(function (r) { var n = NC[r[0]], s = (n && n[27]) || S('noStation'), k = catKey(dCat(r)); (per[s] || (per[s] = {}))[k] = (per[s][k] || 0) + 1; tot[s] = (tot[s] || 0) + 1; });
    var st = Object.keys(tot).sort(function (a, b) { return tot[b] - tot[a]; }).slice(0, 12);
    if (!st.length) { vSet('station', EMPTY); return; }
    var W0 = vWidth('station', 300), cats = MAIN_CATS, lab = Math.min(210, Math.max(120, W0 * 0.36)), cw = Math.max(26, Math.min(48, Math.floor((W0 - lab - 56) / cats.length))), rh = 24, top = 92, H = top + st.length * rh + 4, W = lab + cats.length * cw + 56;
    var mx = 1; st.forEach(function (s) { cats.forEach(function (k) { mx = Math.max(mx, per[s][k] || 0); }); });
    var g = '', maxCh = Math.floor((lab - 10) / 7.2);
    cats.forEach(function (k, j) { var x = lab + j * cw + cw / 2, kp = k === 'aside' ? '' : pk('cat', k);   // the column head filters the category
      g += '<g' + kp + '><rect x="' + r1(x - cw / 2 + 1) + '" y="0" width="' + (cw - 2) + '" height="' + (top - 4) + '" fill="transparent"/><rect x="' + r1(x - 5) + '" y="' + (top - 14) + '" width="10" height="6" rx="2" fill="' + catFill(k) + '"/>' + tx(x + 2, top - 20, catLabel(k), 'mu', null, ' transform="rotate(-50 ' + r1(x + 2) + ' ' + (top - 20) + ')"') + '</g>'; });
    g += tx(lab + cats.length * cw + 48, top - 10, S('total'), 'mu b', 'end');
    st.forEach(function (s, i) {
      var y = top + i * rh, nm = s.length > maxCh ? s.slice(0, maxCh - 1) + '…' : s;
      var known = s !== S('noStation');   // the row name filters the station, a cell the station and that category
      g += '<text x="' + r1(lab - 8) + '" y="' + (y + 16) + '" text-anchor="end" class="ink"' + (known ? pk('station', s) : '') + '><title>' + esc(s) + '</title>' + esc(nm) + '</text>';
      cats.forEach(function (k, j) { var v = per[s][k] || 0, x = lab + j * cw;
        g += '<rect x="' + (x + 1) + '" y="' + (y + 1) + '" width="' + (cw - 2) + '" height="' + (rh - 2) + '" rx="3" fill="' + (v ? tint('--seq', Math.round(14 + 86 * v / mx)) : 'var(--track)') + '"' + (known && v ? pk('stcat', s + '§' + k) : '') + tip(s + ' · ' + catLabel(k), [S('stTip', { n: num(v), p: pct0(v / tot[s] * 100) })]) + '/>';
        if (v) g += tx(x + cw / 2, y + 16, num(v), v / mx > 0.55 ? 'b' : 'ink', 'middle', (v / mx > 0.55 ? ' style="fill:var(--on1)"' : '') + ' pointer-events="none"'); });
      g += tx(lab + cats.length * cw + 48, y + 16, num(tot[s]), 'ink b', 'end');
    });
    var rows = st.map(function (s) { return [s].concat(cats.map(function (k) { return num(per[s][k] || 0); })).concat([num(tot[s])]); });
    vSet('station', svg(W, H, g, S('t_station')), '', miniTable([S('hStation')].concat(cats.map(catLabel)).concat([S('total')]), rows, 1));
  }

  var VIZ = ['flow', 'bub', 'msn', 'lead', 'station', 'bump', 'cal', 'prod', 'cmo'];
  function vCard(k) {
    return '<article class="card vcard" id="v-' + k + '"><div class="vhead"><span class="kicker" data-t="k_' + k + '"></span><h3 data-t="t_' + k + '"></h3><p class="sub" data-t="s_' + k + '"></p></div>' +
      '<div class="vbody" id="v-' + k + '-b"></div><div class="vlegend" id="v-' + k + '-l"></div>' +
      '<details class="vdata"><summary data-t="dataView"></summary><div class="table-wrap"><table class="mini" id="v-' + k + '-t"></table></div></details></article>';
  }
  document.getElementById('ag').innerHTML = VIZ.map(vCard).join('');
  // one tooltip for every chart; flow highlighting
  var TIP = document.getElementById('tip');
  function hideTip() { TIP.hidden = true; }
  function showTip(e, parts) {
    TIP.textContent = '';
    var h = document.createElement('span'); h.className = 'th'; h.textContent = parts[0]; TIP.appendChild(h);
    parts.slice(1).forEach(function (p, i) { var s = document.createElement(i ? 'span' : 'b'); s.textContent = p; TIP.appendChild(s); });
    TIP.hidden = false;
    var w = TIP.offsetWidth, hh = TIP.offsetHeight, x = e.clientX + 14, y = e.clientY + 16;
    if (x + w > innerWidth - 8) x = e.clientX - w - 14; if (y + hh > innerHeight - 8) y = e.clientY - hh - 12;
    TIP.style.left = Math.max(8, x) + 'px'; TIP.style.top = Math.max(8, y) + 'px';
  }
  var flowKey = null;
  function flowFocus(svgEl, key, link) {
    if (!svgEl) return;
    var on = !!(key || link); svgEl.classList.toggle('focus', on);
    svgEl.querySelectorAll('.lnk').forEach(function (p) { p.classList.toggle('hl', !!(link ? p === link : key && (p.getAttribute('data-a') === key || p.getAttribute('data-b') === key))); });
  }
  function apMove(e) {
    var nk = e.target.closest && e.target.closest('[data-node]'), lk = e.target.closest && e.target.closest('.lnk');
    var key = nk ? nk.getAttribute('data-node') : lk ? lk : null;
    if (key !== flowKey) { flowFocus(document.querySelector('svg.flow'), nk ? key : null, lk); flowKey = key; }
    var kr = e.target.getAttribute && e.target.getAttribute('data-km'), kx = document.getElementById('kmX');
    if (kr && A.km) {
      var kb = e.target.ownerSVGElement.getBoundingClientRect(), kp = Math.max(0, Math.min(1, (e.clientX - kb.left - A.km.ml) / A.km.pw)), day0 = Math.round(kp * A.km.XM), kxx = r1(A.km.ml + day0 / A.km.XM * A.km.pw);
      kx.setAttribute('x1', kxx); kx.setAttribute('x2', kxx);
      showTip(e, [S('kmTipH', { d: num(day0) })].concat(A.km.keys.map(function (k) { return S('g_' + k) + ' : ' + pct0(kmAt(A.km.curves[k], day0) * 100) + ' ' + S('kmOpen'); }))
        .concat(day0 > 0 ? [S('kmClick', { d: num(day0), n: num(A.km.ts.filter(function (t) { return t > day0; }).length) })] : []));
      return;
    }
    if (kx) { kx.setAttribute('x1', -10); kx.setAttribute('x2', -10); }
    var t = e.target.closest && e.target.closest('[data-tip]');
    if (t) showTip(e, t.getAttribute('data-tip').split('|')); else hideTip();
  }
  function apLeave() { hideTip(); flowFocus(document.querySelector('svg.flow'), null, null); flowKey = null; }
  function apClick(e) {
    var ms = e.target.closest('[data-msn]');   // an MSN: its NC list opens, and the page filters on it (pickSet)
    if (ms) { var mk = ms.getAttribute('data-msn'); A.msn = A.msn === mk ? null : mk; hideTip(); if (!ms.hasAttribute('data-pick')) rvDraw('A:msn'); return; }
    if (e.target.closest && e.target.closest('[data-pick]')) return;   // handled page-wide (pickSet)
    var s = e.target.closest('[data-aline]');
    if (s) { var v = s.getAttribute('data-aline'); hideTip(); setGF({ line: GF.line === v ? '' : v }); return; }
    if (e.target.closest('[data-msnclose]')) { A.msn = null; rvDraw('A:msn'); return; }
    var p = e.target.closest('[data-pin]');
    if (p) { var a = p.getAttribute('data-pin'), cur = A.pin == null ? A.top0 : A.pin; A.pin = cur === a ? '' : a; v2Render(); }
  }
  window.addEventListener('scroll', hideTip, { passive: true });
  var rzT; window.addEventListener('resize', function () { clearTimeout(rzT); rzT = setTimeout(function () { renderPplan(); renderCbl(); alRender(); v2Render(); }, 150); });

  // ---------------------------------------------------------------- 6. Chart texts (GX, GSTR) and drawing helpers, shared by the tabs' charts
  var GX = withYears({
    fr: { mean: 'Moyenne', defN: '{n} défauts', kNc: 'NC par avion', cum: 'Coût cumulé', proj: 'Projection au rythme actuel',
      mioOnly: 'MIP A350 seulement pour l’instant : choisissez l’A350, ou toutes les lignes.', mio25: '{PREV} (par MIP {LIV}é)', mioTgt: 'objectif ({PREV} − {CUT} %)', mioTip: '{v} par million d’opérations', mioNow: 'par million d’opérations sur la période', mioSig: 'niveau sigma', vq25: '{PREV} : {v} par produit {LIV}é', vq26: '{YEAR} : {v} par MSN', vqUp: 'hausse de plus de 10 %', vqDown: 'baisse de plus de 10 %', vqFlat: 'à 10 % près', relAcN: '{n} MSN', relHist: '{n} MSN avec {v} NC',
      relSubA: 'Clair : où tombent 95 % des MSN. Foncé : intervalle de confiance à 95 % du taux. Points : NC de chaque MSN construit dans la période.',
      relSubB: 'Limites par MSN comme le suivi hebdomadaire : 2 σ attention, 3 σ alarme. Points : NC de chaque MSN construit dans la période.',
      relSubC: 'Boîte : la moitié des MSN ; moustaches : 5 % à 95 % ; trait : médiane. Points : NC de chaque MSN construit dans la période.',
      relSubD: 'Points : NC de chaque MSN construit dans la période. Bande : intervalle de confiance à 95 % du taux.',
      relSubE: 'Barres : nombre de MSN par nombre de NC. Trait : intervalle de confiance à 95 % du taux.', relSubP: 'Point : NC par MSN. Trait : intervalle de confiance à 95 % du taux moyen.', relSubW: 'NC par MSN et intervalle de confiance à 95 %.', relYtd: 'Depuis janvier', rel6: '6 derniers mois', rel3: '3 derniers mois', relSub2: 'Barre : intervalle de confiance à 95 %. Points : NC de chaque MSN.', relAc: 'NC d’un MSN', relPrev: 'Lignes précédentes', relNext: 'Lignes suivantes', relRate: 'NC par MSN sur la période', relSub: 'Barre : intervalle de confiance à 95 %. Points gris : chaque mois. A330 et A350.', relCi: 'intervalle de confiance à 95 %', relMonth: 'chaque mois', vqCat: 'couleur de la catégorie', vqChg: 'Écart {YEAR} − {PREV} (par MSN)', vqCause: 'Cause', ncCount: '{n} NC', b0: 'Aucun défaut', b1: '1 à 5 défauts', b2: '6 à 15', b3: 'Plus de 15', acTip: 'MSN {m} · {n} défauts', open: 'En cours', late: 'En retard', finCount: '{n} avions', finTip: 'FIN {f} · MSN {m}',
      comp_g: 'Gestion de la NC', comp_r: 'Reprise', comp_m: 'Matière', comp_e: 'Ingénierie', comp_p: 'Pièces', one: '1 défaut sur cet avion', twoPlus: '2 défauts ou plus', all: 'Tous' },
    en: { mean: 'Mean', defN: '{n} defects', kNc: 'NCs per aircraft', cum: 'Cumulative cost', proj: 'Projection at the current pace',
      mioOnly: 'MIP A350 only for now: pick the A350, or all lines.', mio25: '{PREV} (per MIP {DLV})', mioTgt: 'target ({PREV} − {CUT}%)', mioTip: '{v} per million operations', mioNow: 'per million operations over the period', mioSig: 'sigma level', vq25: '{PREV}: {v} per product {DLV}', vq26: '{YEAR}: {v} per MSN', vqUp: 'up more than 10%', vqDown: 'down more than 10%', vqFlat: 'within 10%', relAcN: '{n} MSN', relHist: '{n} MSN with {v} NCs',
      relSubA: 'Light: where 95% of the MSN fall. Dark: 95% confidence interval of the rate. Dots: NCs of each MSN built in the period.',
      relSubB: 'Per-MSN limits as on the weekly chart: 2 σ attention, 3 σ alarm. Dots: NCs of each MSN built in the period.',
      relSubC: 'Box: half of the MSN; whiskers: 5% to 95%; line: median. Dots: NCs of each MSN built in the period.',
      relSubD: 'Dots: NCs of each MSN built in the period. Band: 95% confidence interval of the rate.',
      relSubE: 'Bars: number of MSN per number of NCs. Line: 95% confidence interval of the rate.', relSubP: 'Dot: NCs per MSN. Line: 95% confidence interval of the average rate.', relSubW: 'NCs per MSN and 95% confidence interval.', relYtd: 'Year to date', rel6: 'Last 6 months', rel3: 'Last 3 months', relSub2: 'Bar: 95% confidence interval. Dots: NCs of each MSN.', relAc: 'NCs of one MSN', relPrev: 'Previous lines', relNext: 'Next lines', relRate: 'NCs per MSN over the period', relSub: 'Bar: 95% confidence interval. Grey dots: each month. A330 and A350.', relCi: '95% confidence interval', relMonth: 'each month', vqCat: 'category colour', vqChg: 'Change {YEAR} − {PREV} (per MSN)', vqCause: 'Root cause', ncCount: '{n} NCs', b0: 'No defect', b1: '1 to 5 defects', b2: '6 to 15', b3: 'More than 15', acTip: 'MSN {m} · {n} defects', open: 'In progress', late: 'Late', finCount: '{n} aircraft', finTip: 'FIN {f} · MSN {m}',
      comp_g: 'NC handling', comp_r: 'Rework', comp_m: 'Material', comp_e: 'Engineering', comp_p: 'Parts', one: '1 defect on this aircraft', twoPlus: '2 defects or more', all: 'All' }
  });
  function gx(k, v) { var s = GX[G.lang][k]; if (s == null) return k; Object.keys(v || {}).forEach(function (x) { s = s.split('{' + x + '}').join(v[x]); }); return s; }
  // per chart: kicker, title, one line on how to read it, the data it needs
  var GSTR = {};

  // shared helpers
  function gB(k) { return document.getElementById('g-' + k + '-b'); }
  function gWd(k, min) { return Math.max(gB(k).clientWidth || 520, min || 300); }
  function gSet(k, html, leg) { gB(k).innerHTML = html; var l = document.getElementById('g-' + k + '-l'); l.innerHTML = leg || ''; l.hidden = !leg; }
  function gT(k) { return gHead(k)[1]; }
  // a chart's texts [kicker, title, subtitle, data]: GSTR, or worked out when the title follows a choice (GDYN: the lines shown,
  // the cause followed)
  var GDYN = {};
  function gHead(k) { return GDYN[k] ? GDYN[k]() : GSTR[k][G.lang]; }
  function sw(c, lab, round) { return '<span><i class="sw" style="background:' + c + (round ? ';border-radius:50%' : '') + '"></i>' + esc(lab) + '</span>'; }
  function swl(c, lab, dash) { return '<span><i class="' + (dash ? 'dash' : 'ln') + '" style="' + (dash ? 'border-top-color:' : 'background:') + c + '"></i>' + esc(lab) + '</span>'; }
  function f2(x) { return (Math.round(x * 100) / 100).toLocaleString(loc(), { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }
  function kE(v) { return Math.round(v / 1000).toLocaleString(loc()) + (G.lang === 'fr' ? ' k€' : 'k EUR'); }
  function quant(a, p) { if (!a.length) return 0; var i = (a.length - 1) * p, lo = Math.floor(i), hi = Math.ceil(i); return a[lo] + (a[hi] - a[lo]) * (i - lo); }

  var PLANE = 'M8 .6C8.8 .6 9.2 1.6 9.2 3V6L15.4 9.5V11L9.2 9.3 9 13 11 14.5V15.4L8 14.7 5 15.4V14.5L7 13 6.8 9.3.6 11V9.5L6.8 6V3C6.8 1.6 7.2 .6 8 .6Z';

  Object.assign(GX.fr, { xAl3: '3 σ : alarme', xAl2: '2 σ : attention', xOut3: 'Au-delà de 3 σ', xIn23: 'Entre 2 et 3 σ', xZ: '{z} σ de la moyenne', xLeg: 'NC de la semaine', shutWk: 'Semaine de fermeture, hors calcul' });
  Object.assign(GX.en, { xAl3: '3 σ: alarm', xAl2: '2 σ: attention', xOut3: 'Beyond 3 σ', xIn23: 'Between 2 and 3 σ', xZ: '{z} σ from the mean', xLeg: 'NCs of the week', shutWk: 'Shutdown week, left out' });

  function avgOf(a) { return a.length ? a.reduce(function (s, v) { return s + v; }, 0) / a.length : 0; }
  function trunc(s, w) { var mc = Math.max(4, Math.floor(w / 6.5)); return s.length > mc ? s.slice(0, mc - 1) + '…' : s; }

  // ---------------------------------------------------------------- 7. NC rates: NCs, defects and cost per unit of volume built (MSN, only a denominator)
  // real: the EqMSN volumes of the reference data with the NCs of the filter bar, matched on the product family
  Object.assign(GX.fr, { fcLeg: 'Prévision', fcSpan: '{a} à {b}', actLeg: 'Réalisé', eqTip: '{v} MSN', ncEq: '{n} NC · {e} MSN',
    perEq: '{v} par MSN', overall: 'Ensemble {v}', ciTip: 'IC 95 % : {a} à {b}', noData: 'Pas de production ou de NC rattachée pour ce choix.',
    pReal: 'Données réelles', rollTip: 'moyenne sur 3 mois : {v}', monthLeg: 'Mois', roll3: 'Moyenne glissante sur 3 mois', sig2: 'Limite à 2σ (dépassée par hasard environ 1 mois sur 40)', sig3: 'Limite à 3σ (au-delà, presque jamais le hasard)' });
  Object.assign(GX.en, { fcLeg: 'Forecast', fcSpan: '{a} to {b}', actLeg: 'Actual', eqTip: '{v} MSN', ncEq: '{n} NCs · {e} MSN',
    perEq: '{v} per MSN', overall: 'All {v}', ciTip: '95% CI: {a} to {b}', noData: 'No output or matched NC for this choice.',
    pReal: 'Real data', rollTip: '3-month average: {v}', monthLeg: 'Month', roll3: '3-month rolling average', sig2: '2σ limit (crossed by chance about 1 month in 40)', sig3: '3σ limit (beyond it, hardly ever chance)' });
  Object.assign(GSTR, {
    '53': { fr: ['Causes', 'Les causes rapportées au volume', 'Défauts par MSN, 15 premières causes.', 'causes · production MSN en dénominateur'],
            en: ['Root causes', 'Root causes against volume', 'Defects per MSN, top 15 root causes.', 'root causes · MSN output as denominator'] },
    '54': { fr: ['Produits', 'Les trois premières causes de chaque produit', 'Défauts par MSN ; produits du plus touché au moins touché.', 'causes · production MSN en dénominateur'],
            en: ['Products', 'The top three root causes of each product', 'Defects per MSN; products from most to least affected.', 'root causes · MSN output as denominator'] },
    '61': { fr: ['Carte', 'Taux mensuel, produit par produit', 'NC par MSN ; tiret : moins de 0,5 MSN dans le mois.', 'production MSN · NC'], en: ['Map', 'Monthly rate, product by product', 'NCs per MSN; dash: under 0.5 MSN that month.', 'MSN output · NCs'] },
    '64': { fr: ['Fiabilité du taux', 'Quel crédit donner au taux de chaque produit ?', 'Point : NC par MSN produit. Trait : la fourchette où se trouve le vrai taux, 95 fois sur 100 ; elle dépend du nombre de NC et de MSN. Peu de MSN : fourchette large, taux peu sûr. Deux produits dont les traits se chevauchent ne sont pas vraiment différents. Échelle logarithmique.', 'production MSN · NC'],
            en: ['How sure is the rate', 'How far can each product’s rate be trusted?', 'Dot: NCs per MSN built. Line: the range the true rate lies in, 95 times out of 100; it depends on the number of NCs and of MSN. Few MSN: a wide range, an unsure rate. Two products whose lines overlap are not really different. Log scale.', 'MSN output · NCs'] },
    '65': { fr: ['Câble', 'Défauts câble par MSN, mois par mois', 'Trait : moyenne de la période ; pointillé : moyenne glissante sur 3 mois.', 'défauts câble · production MSN en dénominateur'],
            en: ['Cable', 'Cable defects per MSN, month by month', 'Line: period average; dotted: 3-month rolling average.', 'cable defects · MSN output as denominator'] },
    '76': { fr: ['Branchement', 'Erreurs de branchement par MSN, A330 et A350', 'Par produit, par cause : inversion, mauvaise borne, non connecté. Sans l’A320, dont les produits sont de petites pièces comptées à l’unité.', 'production MSN · défauts'],
            en: ['Connection', 'Connection errors per MSN, A330 and A350', 'By product and cause: swapped, wrong terminal, not connected. Without the A320, whose products are small parts counted one by one.', 'MSN output · defects'] },
    '78': { fr: ['Cause', '{C} par MSN, mois par mois', 'La cause suivie dans « Classement mensuel des causes » (un clic sur sa courbe), sinon la première cause du dernier mois. Trait : moyenne de la période ; pointillé : moyenne glissante sur 3 mois. {L}', 'défauts · production MSN en dénominateur'],
            en: ['Root cause', '{C} per MSN, month by month', 'The root cause followed in “Monthly ranking of root causes” (a click on its line), else the top root cause of the last month. Line: period average; dotted: 3-month rolling average. {L}', 'defects · MSN output as denominator'] }
  });

  function pTot(f) { return sumA(P_().filter(function (o) { return o.EQ > 0; }).map(f)); }
  function pNice(mx, n) { var raw = Math.max(mx, 1e-9) / (n || 4), p = Math.pow(10, Math.floor(Math.log10(raw))), f = raw / p, st = (f <= 1 ? 1 : f <= 2 ? 2 : f <= 2.5 ? 2.5 : f <= 5 ? 5 : 10) * p; return { step: st, top: Math.ceil(mx / st) * st || st }; }
  function pGridY(ml, pw, Y, nt, fmt) { var g = ''; for (var t = 0; t <= nt.top + 1e-9; t += nt.step) g += '<line x1="' + ml + '" x2="' + (ml + pw) + '" y1="' + r1(Y(t)) + '" y2="' + r1(Y(t)) + '" stroke="var(--grid)"/>' + tx(ml - 6, Y(t) + 4, (fmt || num)(Math.round(t * 100) / 100), 'mu', 'end'); return g; }
  function pEmpty(k) { gSet(k, '<p class="empty">' + esc(gx('noData')) + '</p>'); }
  function pWait(k) { gSet(k, '<p class="empty">' + esc(S('slWait')) + '</p>'); }   // a chart whose numbers Slate is computing
  function pAct() { return PD.months.map(function (m, i) { return i; }).filter(function (i) { return PD.mask[i]; }); }
  function pSub(o) { return gx('ncEq', { n: num(o.NC), e: f1(o.EQ) }); }

  // monthly totals over the products of the selection (the volume is only the denominator)
  function pMonthly(f, keep) { var os = P_().filter(keep || function () { return true; }); return pAct().map(function (i) { var e = sumA(os.map(function (o) { return o.eqm[i]; })); return { i: i, e: e, v: sumA(os.map(function (o) { return f(o, i); })) }; }).filter(function (x) { return x.e >= EQMIN; }); }
  // connection errors per MSN: A330 and A350 only; A320's products are small parts counted one by one, its many units pull the rate down
  var CONN_LINES = { A330: 1, A350: 1 };
  function connOk(o) { return !!CONN_LINES[o.line]; }
  // the figures and charts that pool products into one per-MSN rate: A330 + A350 by default, a switch shows the A320;
  // a line chosen in the filter bar wins and hides the switch
  var G320 = false;
  function grpOk(o) { var l = (o && o.line) || ''; return GF.line ? true : G320 ? l === 'A320' : !!CONN_LINES[l]; }
  function grpSeg() { return GF.line ? '' : '<div class="seg grpseg" role="group">' + [['0', 'A330 + A350'], ['1', 'A320']].map(function (x) { return '<button type="button" data-g320="' + x[0] + '" aria-pressed="' + ((x[0] === '1') === G320) + '">' + x[1] + '</button>'; }).join('') + '</div>'; }
  document.addEventListener('click', function (e) { var b = e.target.closest && e.target.closest('[data-g320]'); if (!b) return; G320 = b.getAttribute('data-g320') === '1'; renderAll(); });
  function connNone(k, msg) { if (GF.line && !CONN_LINES[GF.line]) { gSet(k, '<p class="empty">' + esc(S(msg || 'connOnly')) + '</p>'); return true; } return false; }
  // sig: two straight lines, the period's rate + 2 and + 3 sigma, sigma the usual spread of the monthly values of the period (the
  // month in progress left out); none with fewer than 3 months (18 Nov: limits that moved with the month's volume confused)
  function pTrend(k, rows, fmt, unitTip, col, ref, sig) {   // ref: { v, lab } a reference rate drawn dashed (2025)
    col = col || 'var(--s1)';
    if (rows.length < 2) { pEmpty(k); return; }
    var W0 = gWd(k), ml = 46, mr = 92, mt = 16, h = 220, H = mt + h + 26, pw = W0 - ml - mr, r = rows.map(function (x) { return x.v / x.e; }), mean = sumA(rows.map(function (x) { return x.v; })) / sumA(rows.map(function (x) { return x.e; }));
    var cj0 = rows.length > 2 && rows[rows.length - 1].i === PD.cur ? rows.length - 1 : -1, mo = cj0 > 0 ? r.slice(0, cj0) : r, sd = 0;
    if (sig && mo.length >= 3) { var mm = sumA(mo) / mo.length; sd = Math.sqrt(sumA(mo.map(function (v) { return (v - mm) * (v - mm); })) / (mo.length - 1)); }
    var lim = sd > 0 ? [2, 3].map(function (z) { return rows.map(function () { return mean + z * sd; }); }) : [];
    var nt = pNice(Math.max.apply(null, r.concat(ref ? [].concat(ref).map(function (q) { return q.v; }) : []).concat(lim.length ? lim[1] : [])) * 1.1), g = '';
    function X(j) { return ml + j / (rows.length - 1) * pw; } function Y(v) { return mt + h - v / nt.top * h; }
    var cj = rows.length > 2 && rows[rows.length - 1].i === PD.cur ? rows.length - 1 : -1;   // the running month: out of the 3-month average
    var roll = r.map(function (v, j) { var a = r.slice(Math.max(0, j - 2), j + 1); return sumA(a) / a.length; }); if (cj > 0) roll = roll.slice(0, cj);
    g += pGridY(ml, pw, Y, nt, fmt) + '<line x1="' + ml + '" x2="' + (ml + pw) + '" y1="' + r1(Y(mean)) + '" y2="' + r1(Y(mean)) + '" stroke="var(--ink-2)"/>';
    lim.forEach(function (L2, z) { g += '<path d="' + L2.map(function (v, j) { return (j ? 'L' : 'M') + r1(X(j)) + ',' + r1(Y(v)); }).join('') + '" fill="none" stroke="' + (z ? 'var(--up)' : 'var(--muted)') + '" stroke-width="1.3" stroke-dasharray="2 3"/>'; });
    g += '<path d="' + roll.map(function (v, j) { return (j ? 'L' : 'M') + r1(X(j)) + ',' + r1(Y(v)); }).join('') + '" fill="none" stroke="var(--ink-2)" stroke-width="1.5" stroke-dasharray="4 3"/>';
    // the running month (data stops mid-month): an open dot on a dotted segment, a few days are not a trend yet (3 Nov)
    var solid = cj > 0 ? r.slice(0, cj) : r;
    g += '<path d="' + solid.map(function (v, j) { return (j ? 'L' : 'M') + r1(X(j)) + ',' + r1(Y(v)); }).join('') + '" fill="none" stroke="' + col + '" stroke-width="2.2"/>';
    if (cj > 0) g += '<path d="M' + r1(X(cj - 1)) + ',' + r1(Y(r[cj - 1])) + 'L' + r1(X(cj)) + ',' + r1(Y(r[cj])) + '" fill="none" stroke="' + col + '" stroke-width="2" stroke-dasharray="1 4" stroke-linecap="round"/>';
    rows.forEach(function (x, j) { var cu = j === cj; g += '<circle cx="' + r1(X(j)) + '" cy="' + r1(Y(r[j])) + '" r="4" fill="' + (cu ? 'var(--surface)' : col) + '" stroke="' + (cu ? col : 'var(--surface)') + '" stroke-width="' + (cu ? 2 : 1.5) + '"' + ppk('month', PD.months[x.i]) + tip(monthName(PD.months[x.i]), [unitTip(r[j]), (cu ? S('v2CurPt', { d: day(D.meta.to) }) : gx('rollTip', { v: fmt(roll[j]) })), gx('eqTip', { v: f1(x.e) })]) + '/>' + tx(X(j), H - 6, monthName(PD.months[x.i]), 'mu', 'middle'); });
    var refs = ref ? [].concat(ref) : [], yl = spread([Y(mean) + 4].concat(refs.map(function (q) { return Y(q.v) + 4; })).concat(lim.map(function (L2) { return Y(L2[L2.length - 1]) + 4; })), 14, mt, mt + h);   // the labels at the right, apart
    g += tx(ml + pw + 8, yl[0], gx('mean') + ' ' + fmt(mean), 'mu');
    lim.forEach(function (L2, z) { g += tx(ml + pw + 8, yl[yl.length - lim.length + z], (z ? '3σ' : '2σ'), 'mu'); });
    if (refs.length > 1) {
      refs.forEach(function (q, j) { g += '<line x1="' + ml + '" x2="' + (ml + pw) + '" y1="' + r1(Y(q.v)) + '" y2="' + r1(Y(q.v)) + '" stroke="' + (q.col || 'var(--up)') + '" stroke-width="1.5" stroke-dasharray="6 4"/>' + tx(ml + pw + 8, yl[j + 1], q.short + ' ' + fmt(q.v), 'mu'); });
      ref = null; }
    if (ref) { var yr = yl[1]; g += '<line x1="' + ml + '" x2="' + (ml + pw) + '" y1="' + r1(Y(ref.v)) + '" y2="' + r1(Y(ref.v)) + '" stroke="var(--up)" stroke-width="1.5" stroke-dasharray="6 4"/>' + tx(ml + pw + 8, yr, PREV + ' ' + fmt(ref.v), 'b', null, ' style="fill:var(--up)"'); }
    gSet(k, svg(W0, H, g, gT(k)), swl(col, gx('monthLeg')) + (cj > 0 ? '<span><i class="sw" style="background:var(--surface);border:2px solid ' + col + ';border-radius:50%"></i>' + esc(S('v2CurPtL', { d: day(D.meta.to) })) + '</span>' : '') + swl('var(--ink-2)', gx('mean')) + swl('var(--ink-2)', gx('roll3'), true) + (ref ? swl('var(--up)', ref.lab, true) : '') + (refs.length > 1 ? refs.map(function (q) { return swl(q.col || 'var(--up)', q.lab, true); }).join('') : '') +
      (lim.length ? swl('var(--muted)', gx('sig2'), true) + swl('var(--up)', gx('sig3'), true) : ''));
  }

  // 53. root causes per 10 MSN, all products of the selection
  function g53(k) {
    var E0 = sumA(P_().filter(function (o) { return o.EQ > 0 && grpOk(o); }).map(function (o) { return o.EQ; })); if (!E0) { pEmpty(k); return; }
    var c = {}, cat = {}; PD.defs.forEach(function (d) { var o = PA[PD.ncs[d.n].p]; if (!o || !o.EQ || !grpOk(o)) return; c[d.rca] = (c[d.rca] || 0) + 1; cat[d.rca] = catKey(d.cat); });
    var rows = Object.keys(c).sort(function (a, b) { return c[b] - c[a]; }).slice(0, 15);
    if (!rows.length) { pEmpty(k); return; }
    var W0 = gWd(k), lab = 196, mr = 56, rh = 24, H = rows.length * rh + 6, mx = c[rows[0]] / E0, pw = W0 - lab - mr, g = '';
    rows.forEach(function (r, i) { var y = i * rh + 4, v = c[r] / E0, w = v / mx * pw;
      g += tx(lab - 10, y + 13, trunc(L(r), lab - 14), 'ink', 'end') + '<rect x="' + lab + '" y="' + (y + 3) + '" width="' + r1(Math.max(1.5, w)) + '" height="14" rx="2" fill="' + catFill(cat[r]) + '"' + ppk('rca', r) + tip(L(r), [gx('perEq', { v: f2(v) }), gx('defN', { n: num(c[r]) }), catLabel(cat[r])]) + '/>' + tx(lab + w + 6, y + 14, f2(v), 'ink'); });
    gSet(k, grpSeg() + svg(W0, H, g, gT(k)), MAIN_CATS.filter(function (cc) { return rows.some(function (r) { return cat[r] === cc; }); }).map(function (cc) { return sw(catFill(cc), catLabel(cc)); }).join(''));
  }

  // 54. top three causes of each product, per 10 MSN
  function g54(k) {
    var os = pOk().filter(function (o) { return o.DEF; }).sort(function (a, b) { return b.DEF / b.EQ - a.DEF / a.EQ; });
    if (!os.length) { pEmpty(k); return; }
    var W0 = gWd(k), cols = W0 >= 480 ? 2 : 1, gap = 26, pw = (W0 - gap * (cols - 1)) / cols, cellH = 100, H = Math.ceil(os.length / cols) * cellH, cat = {}, g = '';
    PD.defs.forEach(function (d) { cat[d.rca] = catKey(d.cat); });
    var mx = Math.max.apply(null, os.map(function (o) { return Math.max.apply(null, Object.keys(o.rcas).map(function (r) { return o.rcas[r] / o.EQ; })); }));
    os.forEach(function (o, n) {
      var x0 = (n % cols) * (pw + gap), y0 = Math.floor(n / cols) * cellH, top = Object.keys(o.rcas).sort(function (a, b) { return o.rcas[b] - o.rcas[a]; }).slice(0, 3), lw = Math.min(150, pw * 0.48);
      g += tx(x0, y0 + 14, o.p, 'ink b') + tx(x0 + pw, y0 + 14, gx('perEq', { v: f2(o.DEF / o.EQ) }), 'mu', 'end');
      top.forEach(function (r, j) { var y = y0 + 24 + j * 22, v = o.rcas[r] / o.EQ, w = v / mx * (pw - lw - 40);
        g += tx(x0 + lw - 6, y + 12, trunc(L(r), lw - 8), 'ink', 'end', ' style="font-size:11.5px"') + '<rect x="' + r1(x0 + lw) + '" y="' + (y + 3) + '" width="' + r1(Math.max(1.5, w)) + '" height="12" rx="2" fill="' + catFill(cat[r]) + '"' + ppk('rca', r) + tip(o.p + ' · ' + L(r), [gx('perEq', { v: f2(v) }), gx('defN', { n: num(o.rcas[r]) })]) + '/>' + tx(x0 + lw + w + 5, y + 13, f2(v), 'mu', null, ' style="font-size:11px"'); });
    });
    gSet(k, svg(W0, H, g, gT(k)));
  }

  // 61. heatmap product × month of the rate
  function g61(k) {
    var W0 = gWd(k), idx = pAct(), os = pOk().sort(function (a, b) { return b.EQ - a.EQ; });
    if (!os.length) { pEmpty(k); return; }
    var lab = 80, rh = 26, top = 18, cw = (W0 - lab - 4) / idx.length, H = top + os.length * rh + 4, vals = [], g = '';
    os.forEach(function (o) { idx.forEach(function (i) { if (o.eqm[i] >= EQMIN) vals.push(o.nc[i] / o.eqm[i]); }); });
    var cap = quant(vals.sort(function (a, b) { return a - b; }), 0.9) || 1;
    idx.forEach(function (i, j) { g += tx(lab + (j + 0.5) * cw, 12, monthName(PD.months[i]), 'mu', 'middle'); });
    os.forEach(function (o, r) {
      var y = top + r * rh; g += tx(lab - 8, y + 17, o.p, 'ink', 'end');
      idx.forEach(function (i, j) { var x = lab + j * cw, ok = o.eqm[i] >= EQMIN, v = ok ? o.nc[i] / o.eqm[i] : 0, t = Math.round(8 + 92 * Math.min(1, v / cap));
        g += '<rect x="' + r1(x + 1) + '" y="' + (y + 1) + '" width="' + r1(cw - 2) + '" height="' + (rh - 2) + '" rx="2" fill="' + (ok ? tint('--seq', t) : 'var(--track)') + '"' + ppk('pprod', o.p) + tip(o.p + ' · ' + monthName(PD.months[i]), ok ? [gx('perEq', { v: f2(v) }), gx('ncEq', { n: num(o.nc[i]), e: f1(o.eqm[i]) })] : ['—']) + '/>';
        if (cw > 30) g += tx(x + cw / 2, y + 17, ok ? f1(v) : '—', ok && t > 55 ? 'gk' : 'mu', 'middle', ' style="font-size:10.5px"'); });
    });
    gSet(k, svg(W0, H, g, gT(k)));
  }

  // 64, proposed (30 Oct, preview): A330 and A350 products, a plain scale, the 95 % confidence interval with both ends written, and
  // each month's rate as a grey dot to show the variation
  function g64b(k) {
    var W0 = gWd(k), os = pOk().filter(function (o) { return o.NC > 0 && connOk(o); }).map(function (o) {
      var n = o.NC, l = n * Math.pow(1 - 1 / (9 * n) - 1.96 / (3 * Math.sqrt(n)), 3), u = (n + 1) * Math.pow(1 - 1 / (9 * (n + 1)) + 1.96 / (3 * Math.sqrt(n + 1)), 3);
      var ms = pAct().filter(function (i) { return o.eqm[i] >= EQMIN; }).map(function (i) { return { i: i, v: o.nc[i] / o.eqm[i] }; });
      return { o: o, r: n / o.EQ, l: Math.max(l, 0) / o.EQ, u: u / o.EQ, ms: ms }; }).sort(function (a, b) { return b.r - a.r; });
    if (!os.length) { pEmpty(k); return; }
    var hb = V2BAND[k] && V2BAND[k].querySelector('.sub'); if (hb) hb.textContent = gx('relSub');
    var lab = 96, mr = 70, rh = 46, H = os.length * rh + 26, pw = W0 - lab - mr, hi = 0, g = '';
    os.forEach(function (x) { hi = Math.max(hi, x.u); x.ms.forEach(function (m) { hi = Math.max(hi, m.v); }); });
    var nt = pNice(hi * 1.05); function X(v) { return lab + v / nt.top * pw; }
    for (var t = 0; t <= nt.top + 1e-9; t += nt.step) g += '<line x1="' + r1(X(t)) + '" x2="' + r1(X(t)) + '" y1="0" y2="' + (H - 22) + '" stroke="var(--grid)"/>' + tx(X(t), H - 6, f1(t), 'mu', 'middle');
    os.forEach(function (x, i) { var y = i * rh + rh / 2 - 2;
      g += tx(lab - 10, y + 4, x.o.p, 'ink', 'end') + '<rect x="' + r1(X(x.l)) + '" y="' + (y - 6) + '" width="' + r1(Math.max(2, X(x.u) - X(x.l))) + '" height="12" rx="3" fill="' + lineCol(x.o.line) + '" fill-opacity=".18"/>';
      g += '<line x1="' + r1(X(x.l)) + '" x2="' + r1(X(x.l)) + '" y1="' + (y - 7) + '" y2="' + (y + 7) + '" stroke="' + lineCol(x.o.line) + '" stroke-width="2"/><line x1="' + r1(X(x.u)) + '" x2="' + r1(X(x.u)) + '" y1="' + (y - 7) + '" y2="' + (y + 7) + '" stroke="' + lineCol(x.o.line) + '" stroke-width="2"/>';
      g += tx(X(x.l) - 3, y + 20, f2(x.l), 'mu', 'end', ' style="font-size:10.5px"') + tx(X(x.u) + 3, y + 20, f2(x.u), 'mu', null, ' style="font-size:10.5px"');
      x.ms.forEach(function (m) { g += '<circle cx="' + r1(X(m.v)) + '" cy="' + (y - 13) + '" r="3" fill="var(--muted)" fill-opacity=".7"' + tip(x.o.p + ' · ' + monthName(PD.months[m.i]), [gx('perEq', { v: f2(m.v) })]) + '/>'; });
      g += '<circle cx="' + r1(X(x.r)) + '" cy="' + y + '" r="5.5" fill="' + lineCol(x.o.line) + '" stroke="var(--surface)" stroke-width="1.5"' + ppk('pprod', x.o.p) + tip(x.o.p, [gx('perEq', { v: f2(x.r) }), gx('ciTip', { a: f2(x.l), b: f2(x.u) }), S('ciMsn', { e: f1(x.o.EQ) })]) + '/>' +
        tx(lab + pw + 10, y + 4, f2(x.r), 'ink b'); });
    gSet(k, svg(W0, H, g, gT(k)), '<span><i class="sw" style="border-radius:50%;background:var(--ink-2)"></i>' + esc(gx('relRate')) + '</span><span><i class="sw" style="background:var(--ink-2);opacity:.25"></i>' + esc(gx('relCi')) + '</span><span><i class="sw" style="border-radius:50%;background:var(--muted)"></i>' + esc(gx('relMonth')) + '</span>');
  }
  // 64, second proposal (keep today's look, plot each aircraft's NCs, no scale stretched by one line): one page per
  // group of lines of a similar scale (A350 · A330, A400M, A320), ◀ ▶ to turn the page; plain scale; per product the period rate, its
  // 95 % confidence interval with both ends written, and one dot per aircraft (its NCs on that product; an aircraft of the production
  // table finished in the period with no NC counts 0)
  var RELPG = 0, RELK = null;
  function g64c(k) {
    RELK = k;
    var hb = V2BAND[k] && V2BAND[k].querySelector('.sub'); if (hb) hb.textContent = gx('relSub2');
    var G = [['A350', 'A330'], ['A400M'], ['A320']].map(function (ls) { return { ls: ls, os: pOk().filter(function (o) { return o.NC > 0 && ls.indexOf(o.line) >= 0; }) }; }).filter(function (g) { return g.os.length; });
    if (!G.length) { pEmpty(k); return; }
    RELPG = (RELPG % G.length + G.length) % G.length;
    var grp = G[RELPG], per = {}, PM = D.eqmsn && D.eqmsn.msn;
    PD.ncs.forEach(function (x) { var n = NC[x.id], m = n && n[25]; if (!m) return; var o = per[x.p] || (per[x.p] = {}); o[m] = (o[m] || 0) + 1; });
    if (PM) Object.keys(PM).forEach(function (key) { var x = PM[key], m = key.slice(key.indexOf('|') + 1); if (x[1] < GF.from || x[1] > D.meta.to) return;
      x[2].forEach(function (p) { var o = per[p] || (per[p] = {}); if (o[m] == null) o[m] = 0; }); });
    var os = grp.os.map(function (o) { var n = o.NC, l = n * Math.pow(1 - 1 / (9 * n) - 1.96 / (3 * Math.sqrt(n)), 3), u = (n + 1) * Math.pow(1 - 1 / (9 * (n + 1)) + 1.96 / (3 * Math.sqrt(n + 1)), 3), am = per[o.p] || {};
      return { o: o, r: n / o.EQ, l: Math.max(l, 0) / o.EQ, u: u / o.EQ, ac: Object.keys(am).map(function (m) { return [m, am[m]]; }) }; }).sort(function (a, b) { return b.r - a.r; });
    var W0 = gWd(k), lab = 96, mr = 92, rh = 50, top = 8, H = top + os.length * rh + 26, pw = W0 - lab - mr, hi = 0, g = '';
    os.forEach(function (x) { hi = Math.max(hi, x.u); x.ac.forEach(function (a) { hi = Math.max(hi, a[1]); }); });
    var nt = pNice(hi * 1.04); function X(v) { return lab + v / nt.top * pw; }
    for (var t = 0; t <= nt.top + 1e-9; t += nt.step) g += '<line x1="' + r1(X(t)) + '" x2="' + r1(X(t)) + '" y1="0" y2="' + (H - 22) + '" stroke="var(--grid)"/>' + tx(X(t), H - 6, num(t), 'mu', 'middle');
    os.forEach(function (x, i) { var y = top + i * rh + 30, c = lineCol(x.o.line);
      g += tx(lab - 10, y + 4, x.o.p, 'ink', 'end');
      x.ac.forEach(function (a, j) { g += '<circle cx="' + r1(X(a[1])) + '" cy="' + (y - 14 - (j % 3) * 4) + '" r="2.8" fill="var(--muted)" fill-opacity=".55"' + tip('MSN ' + a[0] + ' · ' + x.o.p, [gx('ncCount', { n: num(a[1]) })]) + '/>'; });
      g += '<line x1="' + r1(X(x.l)) + '" x2="' + r1(X(x.u)) + '" y1="' + y + '" y2="' + y + '" stroke="var(--ink-2)" stroke-width="2"/>' +
        '<line x1="' + r1(X(x.l)) + '" x2="' + r1(X(x.l)) + '" y1="' + (y - 5) + '" y2="' + (y + 5) + '" stroke="var(--ink-2)" stroke-width="1.5"/><line x1="' + r1(X(x.u)) + '" x2="' + r1(X(x.u)) + '" y1="' + (y - 5) + '" y2="' + (y + 5) + '" stroke="var(--ink-2)" stroke-width="1.5"/>' +
        tx(X(x.l) - 4, y + 16, f2(x.l), 'mu', 'end', ' style="font-size:10.5px"') + tx(X(x.u) + 4, y + 16, f2(x.u), 'mu', null, ' style="font-size:10.5px"');
      g += '<circle cx="' + r1(X(x.r)) + '" cy="' + y + '" r="5.5" fill="' + c + '" stroke="var(--surface)" stroke-width="1.5"' + ppk('pprod', x.o.p) + tip(x.o.p, [gx('perEq', { v: f2(x.r) }), gx('ciTip', { a: f2(x.l), b: f2(x.u) }), S('ciMsn', { e: f1(x.o.EQ) })]) + '/>' +
        tx(lab + pw + 10, y + 4, f2(x.r), 'ink b') + tx(lab + pw + 48, y + 4, S('ciMsn', { e: f1(x.o.EQ) }), 'mu', null, ' style="font-size:11px"'); });
    var nav = G.length > 1 ? '<div class="relnav"><button type="button" class="cxb" data-relpg="-1" aria-label="' + esc(gx('relPrev')) + '">◀</button><b>' + esc(grp.ls.join(' · ')) + '</b><span class="mu">' + (RELPG + 1) + ' / ' + G.length + '</span><button type="button" class="cxb" data-relpg="1" aria-label="' + esc(gx('relNext')) + '">▶</button></div>' : '';
    gSet(k, nav + svg(W0, H, g, gT(k)), '<span><i class="sw" style="border-radius:50%;background:var(--ink-2)"></i>' + esc(gx('relRate')) + '</span><span><i class="ln" style="width:22px;height:2px;background:var(--ink-2)"></i>' + esc(gx('relCi')) + '</span><span><i class="sw" style="border-radius:50%;background:var(--muted)"></i>' + esc(gx('relAc')) + '</span>');
  }
  document.addEventListener('click', function (e) { var b = e.target.closest && e.target.closest('[data-relpg]'); if (!b || !RELK) return; RELPG += +b.getAttribute('data-relpg'); g64(RELK); });
  // 64, five ways to show the spread of single aircraft beside the 95 % interval of the rate (30 Oct, previews 'A'..'E'). Aircraft
  // counted: those of the production table built entirely inside the period (start and OTA), so a part-built one does not read low;
  // dots on the product's own line, left to right only
  function relQ(a, q) { if (!a.length) return 0; var s = a.slice().sort(function (x, y) { return x - y; }), i = (s.length - 1) * q, lo = Math.floor(i), hi = Math.ceil(i); return s[lo] + (s[hi] - s[lo]) * (i - lo); }
  function relData() {
    var PM = D.eqmsn && D.eqmsn.msn, full = {}, per = {};
    if (PM) Object.keys(PM).forEach(function (key) { var x = PM[key]; if (x[0] < GF.from || x[1] > D.meta.to) return; var m = key.slice(key.indexOf('|') + 1); x[2].forEach(function (p) { (full[p] || (full[p] = {}))[m] = 0; }); });
    PD.ncs.forEach(function (x) { var n = NC[x.id], m = n && n[25]; if (!m) return; var f = full[x.p]; if (PM) { if (f && f[m] != null) f[m]++; } else { var o = per[x.p] || (per[x.p] = {}); o[m] = (o[m] || 0) + 1; } });
    var src = PM ? full : per;
    // pages: A350 · A330 without MDCD, A400M, A320, then MDCD alone (too few MSN yet: its interval would squeeze the others; 30 Oct)
    return [['A350 · A330', function (o) { return (o.line === 'A350' || o.line === 'A330') && o.p !== 'MDCD'; }], ['A400M', function (o) { return o.line === 'A400M'; }],
      ['A320', function (o) { return o.line === 'A320'; }], ['MDCD', function (o) { return o.p === 'MDCD'; }]].map(function (pg) {
      var os = pOk().filter(function (o) { return o.NC > 0 && pg[1](o); }).map(function (o) {
        var n = o.NC, l = n * Math.pow(1 - 1 / (9 * n) - 1.96 / (3 * Math.sqrt(n)), 3), u = (n + 1) * Math.pow(1 - 1 / (9 * (n + 1)) + 1.96 / (3 * Math.sqrt(n + 1)), 3), am = src[o.p] || {};
        var ac = Object.keys(am).map(function (m) { return [m, am[m]]; }), v = ac.map(function (a) { return a[1]; }), mu = v.length ? sumA(v) / v.length : 0;
        var sd = v.length > 1 ? Math.sqrt(sumA(v.map(function (x) { return (x - mu) * (x - mu); })) / (v.length - 1)) : 0;
        return { o: o, r: n / o.EQ, l: Math.max(l, 0) / o.EQ, u: u / o.EQ, ac: ac, v: v, mu: mu, sd: sd }; }).sort(function (a, b) { return b.r - a.r; });
      return { name: pg[0], os: os }; }).filter(function (g) { return g.os.length; });
  }
  function relSwarm(xs, y, step, cap) {   // dots that would overlap are spread up and down around the line
    var used = {}; return xs.map(function (x) { var b = Math.round(x / 5), k = used[b] || 0; used[b] = k + 1; var off = k === 0 ? 0 : (k % 2 ? 1 : -1) * Math.ceil(k / 2) * step; return y + Math.max(-cap, Math.min(cap, off)); });
  }
  function g64v(k, V) {
    RELK = k; var G = relData(); if (!G.length) { pEmpty(k); return; }
    RELPG = (RELPG % G.length + G.length) % G.length;
    var grp = G[RELPG], os = grp.os, W0 = gWd(k), lab = 96, mr = 96, rh = V === 'E' ? 64 : V === 'P' ? 40 : 56, top = 10, H = top + os.length * rh + 26, pw = W0 - lab - mr, hi = 0, g = '';
    os.forEach(function (x) { hi = Math.max(hi, x.u); if (V !== 'P') { hi = Math.max(hi, x.mu + 3 * x.sd, relQ(x.v, 0.975)); x.v.forEach(function (v) { hi = Math.max(hi, v); }); } });
    var nt = pNice(hi * 1.04); function X(v) { return lab + Math.max(0, v) / nt.top * pw; }
    for (var t = 0; t <= nt.top + 1e-9; t += nt.step) g += '<line x1="' + r1(X(t)) + '" x2="' + r1(X(t)) + '" y1="0" y2="' + (H - 22) + '" stroke="var(--grid)"/>' + tx(X(t), H - 6, num(t), 'mu', 'middle');
    var tick = function (x, y, h, c) { return '<line x1="' + r1(x) + '" x2="' + r1(x) + '" y1="' + (y - h) + '" y2="' + (y + h) + '" stroke="' + c + '" stroke-width="1.5"/>'; };
    os.forEach(function (x, i) {
      var y = top + i * rh + rh / 2, c = lineCol(x.o.line), ys = relSwarm(x.ac.map(function (a) { return X(a[1]); }), y, 4, rh / 2 - 8), lo2 = x.mu - 2 * x.sd, hi2 = x.mu + 2 * x.sd, hi3 = x.mu + 3 * x.sd;
      g += tx(lab - 10, y + 4, x.o.p, 'ink', 'end');
      if (V === 'A') {   // light: where 95 % of the aircraft fall; dark: the 95 % confidence interval of the rate
        var a1 = relQ(x.v, 0.025), a2 = relQ(x.v, 0.975);
        g += '<rect x="' + r1(X(a1)) + '" y="' + (y - 9) + '" width="' + r1(Math.max(2, X(a2) - X(a1))) + '" height="18" rx="4" fill="' + c + '" fill-opacity=".14"/>' + tx(X(a1) - 4, y + 4, f1(a1), 'mu', 'end', ' style="font-size:10.5px"') + tx(X(a2) + 4, y + 4, f1(a2), 'mu', null, ' style="font-size:10.5px"');
        g += '<rect x="' + r1(X(x.l)) + '" y="' + (y - 3) + '" width="' + r1(Math.max(2, X(x.u) - X(x.l))) + '" height="6" rx="2" fill="' + c + '" fill-opacity=".55"/>';
      } else if (V === 'B') {   // aircraft limits, as the weekly chart: 2 sigma attention, 3 sigma alarm
        g += tick(X(Math.max(0, lo2)), y, 10, 'var(--ink-2)') + tick(X(hi2), y, 10, 'var(--ink-2)') + tick(X(hi3), y, 12, 'var(--up)') + '<line x1="' + r1(X(Math.max(0, lo2))) + '" x2="' + r1(X(hi3)) + '" y1="' + y + '" y2="' + y + '" stroke="var(--grid)" stroke-width="1.5"/>' +
          tx(X(hi2), y - 13, '2 σ', 'mu', 'middle', ' style="font-size:10px"') + tx(X(hi3), y - 15, '3 σ', 'mu', 'middle', ' style="font-size:10px;fill:var(--up)"');
      } else if (V === 'C') {   // box: half of the aircraft inside, whiskers 5 % to 95 %, the median
        var q1 = relQ(x.v, 0.25), q2 = relQ(x.v, 0.5), q3 = relQ(x.v, 0.75), w1 = relQ(x.v, 0.05), w2 = relQ(x.v, 0.95);
        g += '<line x1="' + r1(X(w1)) + '" x2="' + r1(X(w2)) + '" y1="' + y + '" y2="' + y + '" stroke="var(--ink-2)"/>' + tick(X(w1), y, 5, 'var(--ink-2)') + tick(X(w2), y, 5, 'var(--ink-2)') +
          '<rect x="' + r1(X(q1)) + '" y="' + (y - 9) + '" width="' + r1(Math.max(2, X(q3) - X(q1))) + '" height="18" rx="3" fill="' + c + '" fill-opacity=".16" stroke="' + c + '"/>' + tick(X(q2), y, 9, c);
      } else if (V === 'D') {   // dots only, the rate's interval as a thin band behind them
        g += '<rect x="' + r1(X(x.l)) + '" y="' + (y - rh / 2 + 6) + '" width="' + r1(Math.max(2, X(x.u) - X(x.l))) + '" height="' + (rh - 12) + '" fill="' + c + '" fill-opacity=".12"/>';
      } else if (V === 'E') {   // a small histogram of the aircraft on the line
        var hb = {}, mx = 0; x.v.forEach(function (v) { hb[v] = (hb[v] || 0) + 1; mx = Math.max(mx, hb[v]); });
        Object.keys(hb).forEach(function (v) { var h = hb[v] / mx * (rh - 22), bw = Math.max(2, pw / nt.top * 0.8); g += '<rect x="' + r1(X(+v) - bw / 2) + '" y="' + r1(y + 8 - h) + '" width="' + r1(bw) + '" height="' + r1(h) + '" rx="1" fill="var(--muted)" fill-opacity=".45"' + tip(x.o.p, [gx('relHist', { n: num(hb[v]), v: num(+v) })]) + '/>'; });
        g += '<line x1="' + r1(X(x.l)) + '" x2="' + r1(X(x.u)) + '" y1="' + (y + 12) + '" y2="' + (y + 12) + '" stroke="' + c + '" stroke-width="3"/>';
      }
      if (V === 'P') g += '<line x1="' + r1(X(x.l)) + '" x2="' + r1(X(x.u)) + '" y1="' + y + '" y2="' + y + '" stroke="var(--ink-2)" stroke-width="2"/>' + tick(X(x.l), y, 5, 'var(--ink-2)') + tick(X(x.u), y, 5, 'var(--ink-2)') +
        tx(X(x.l) - 4, y + 16, f2(x.l), 'mu', 'end', ' style="font-size:10.5px"') + tx(X(x.u) + 4, y + 16, f2(x.u), 'mu', null, ' style="font-size:10.5px"');
      if (V !== 'E' && V !== 'P') x.ac.forEach(function (a, j) { var out3 = V === 'B' && a[1] > hi3, out2 = V === 'B' && !out3 && (a[1] > hi2 || a[1] < lo2);
        g += '<circle cx="' + r1(X(a[1])) + '" cy="' + r1(ys[j]) + '" r="2.8" fill="' + (out3 ? 'var(--up)' : out2 ? 'var(--surface)' : 'var(--muted)') + '"' + (out2 ? ' stroke="var(--up)" stroke-width="1.3"' : ' fill-opacity=".6"') + tip('MSN ' + a[0] + ' · ' + x.o.p, [gx('ncCount', { n: num(a[1]) })]) + '/>'; });
      if (V === 'A' || V === 'C' || V === 'B') g += tick(X(x.l), y, 4, c) + tick(X(x.u), y, 4, c);
      g += '<circle cx="' + r1(X(x.r)) + '" cy="' + (V === 'E' ? y + 12 : y) + '" r="5.5" fill="' + c + '" stroke="var(--surface)" stroke-width="1.5"' + ppk('pprod', x.o.p) + tip(x.o.p, [gx('perEq', { v: f2(x.r) }), gx('ciTip', { a: f2(x.l), b: f2(x.u) }), gx('relAcN', { n: num(x.v.length) })]) + '/>' +
        tx(lab + pw + 10, y + 4, f2(x.r), 'ink b') + tx(lab + pw + 46, y + 4, V === 'P' ? S('ciMsn', { e: f1(x.o.EQ) }) : gx('relAcN', { n: num(x.v.length) }), 'mu', null, ' style="font-size:11px"');
    });
    var nav = G.length > 1 ? '<div class="relnav"><button type="button" class="cxb" data-relpg="-1" aria-label="' + esc(gx('relPrev')) + '">◀</button><b>' + esc(grp.name) + '</b><span class="mu">' + (RELPG + 1) + ' / ' + G.length + '</span><button type="button" class="cxb" data-relpg="1" aria-label="' + esc(gx('relNext')) + '">▶</button></div>' : '';
    var hb2 = V2BAND[k] && V2BAND[k].querySelector('.sub'); if (hb2) hb2.textContent = gx('relSub' + V);
    gSet(k, nav + svg(W0, H, g, gT(k)), V === 'P' ? sw(lineCol(os[0].o.line), gx('relRate'), true) + '<span><i class="ln" style="width:22px;height:2px;background:var(--ink-2)"></i>' + esc(gx('relCi')) + '</span>' : '');
  }
  // 64: per product, the rate of 2025, of the year to date, of the last 6 and the last 3 months, each with its 95 %
  // confidence interval (Byar), coloured by period from light (2025) to dark (3 months). No summer rule: the volume is counted on
  // the days the plant works (D.eqmsn.wd), so July and August weigh what they produced. One page per group of lines.
  function relWin(n) { return pAct().slice(-n).reverse(); }   // month indices of the last n months of the period, newest first
  function byar(n, e) { if (!e) return null; if (!n) return { r: 0, l: 0, u: 3.689 / e };
    var l = n * Math.pow(1 - 1 / (9 * n) - 1.96 / (3 * Math.sqrt(n)), 3), u = (n + 1) * Math.pow(1 - 1 / (9 * (n + 1)) + 1.96 / (3 * Math.sqrt(n + 1)), 3); return { r: n / e, l: Math.max(l, 0) / e, u: u / e }; }
  function g64w(k) {
    RELK = k;
    var hb = V2BAND[k] && V2BAND[k].querySelector('.sub'); if (hb) hb.textContent = gx('relSubW');
    var Y5 = y25Sel(), L5 = (D.y25 && D.y25.prod) || {}, E5 = pSrc(), w6 = relWin(6), w3 = relWin(3);
    var PER = [['y25', PREV, 'var(--dim)'], ['ytd', gx('relYtd'), tint('--seq', 45)], ['m6', gx('rel6'), tint('--seq', 72)], ['m3', gx('rel3'), 'var(--seq)']];
    var pages = [['A350 · A330', function (o) { return (o.line === 'A350' || o.line === 'A330') && o.p !== 'MDCD'; }], ['A400M', function (o) { return o.line === 'A400M'; }],
      ['A320', function (o) { return o.line === 'A320'; }], ['MDCD', function (o) { return o.p === 'MDCD'; }]].map(function (pg) {
      var os = pOk().filter(function (o) { return o.NC > 0 && pg[1](o); }).map(function (o) {
        var sw = function (ix) { return byar(sumA(ix.map(function (i) { return o.nc[i]; })), sumA(ix.map(function (i) { return o.eqm[i]; }))); };
        var n25 = 0; (Y5 || []).forEach(function (x) { if (E5 && E5.map && E5.map[String(x.p || '').toUpperCase()] === o.p) n25 += x.nc; });
        var d25 = L5[o.p] ? sumA(L5[o.p]) : 0;
        return { o: o, v: { y25: d25 ? byar(n25, d25) : null, ytd: byar(o.NC, o.EQ), m6: sw(w6), m3: sw(w3) } }; }).sort(function (a, b) { return b.v.ytd.r - a.v.ytd.r; });
      return { name: pg[0], os: os }; }).filter(function (g) { return g.os.length; });
    if (!pages.length) { pEmpty(k); return; }
    RELPG = (RELPG % pages.length + pages.length) % pages.length;
    var grp = pages[RELPG], os = grp.os, W0 = gWd(k), lab = 96, mr = 64, rh = 60, top = 6, H = top + os.length * rh + 24, pw = W0 - lab - mr, hi = 0, g = '';
    os.forEach(function (x) { PER.forEach(function (q) { var v = x.v[q[0]]; if (v) hi = Math.max(hi, v.u); }); });
    var nt = pNice(hi * 1.04); function X(v) { return lab + Math.max(0, v) / nt.top * pw; }
    for (var t = 0; t <= nt.top + 1e-9; t += nt.step) g += '<line x1="' + r1(X(t)) + '" x2="' + r1(X(t)) + '" y1="0" y2="' + (H - 22) + '" stroke="var(--grid)"/>' + tx(X(t), H - 6, num(t), 'mu', 'middle');
    os.forEach(function (x, i) {
      var y0 = top + i * rh + 8;
      g += tx(lab - 10, y0 + 26, x.o.p, 'ink', 'end');
      PER.forEach(function (q, j) { var v = x.v[q[0]], y = y0 + j * 12 + 4; if (!v) return;
        g += '<line x1="' + r1(X(v.l)) + '" x2="' + r1(X(v.u)) + '" y1="' + y + '" y2="' + y + '" stroke="' + q[2] + '" stroke-width="2"/>' +
          '<line x1="' + r1(X(v.l)) + '" x2="' + r1(X(v.l)) + '" y1="' + (y - 3) + '" y2="' + (y + 3) + '" stroke="' + q[2] + '" stroke-width="1.5"/><line x1="' + r1(X(v.u)) + '" x2="' + r1(X(v.u)) + '" y1="' + (y - 3) + '" y2="' + (y + 3) + '" stroke="' + q[2] + '" stroke-width="1.5"/>' +
          '<circle cx="' + r1(X(v.r)) + '" cy="' + y + '" r="4.2" fill="' + q[2] + '" stroke="var(--surface)" stroke-width="1.2"' + ppk('pprod', x.o.p) + tip(x.o.p + ' · ' + q[1], [gx('perEq', { v: f2(v.r) }), gx('ciTip', { a: f2(v.l), b: f2(v.u) })]) + '/>' +
          tx(lab + pw + 10, y + 4, f2(v.r), j === 1 ? 'ink b' : 'mu', null, ' style="font-size:11px"'); });
    });
    var nav = pages.length > 1 ? '<div class="relnav"><button type="button" class="cxb" data-relpg="-1" aria-label="' + esc(gx('relPrev')) + '">◀</button><b>' + esc(grp.name) + '</b><span class="mu">' + (RELPG + 1) + ' / ' + pages.length + '</span><button type="button" class="cxb" data-relpg="1" aria-label="' + esc(gx('relNext')) + '">▶</button></div>' : '';
    gSet(k, nav + svg(W0, H, g, gT(k)), PER.map(function (q) { return sw(q[2], q[1], true); }).join('') + '<span><i class="ln" style="width:22px;height:2px;background:var(--ink-2)"></i>' + esc(gx('relCi')) + '</span>');
  }
  // 64. rate with its 95% interval (Byar), log scale
  function g64(k) {
    var pv = window.FTO2_PREVIEW && window.FTO2_PREVIEW.rel; if (typeof pv === 'string') { g64v(k, pv); return; } if (pv === 2) { g64c(k); return; } if (pv) { g64b(k); return; }
    g64w(k); return;   // 2025, year to date, last 6 and last 3 months, each with its 95 % interval, one page per group of lines
    var W0 = gWd(k), os = pOk().filter(function (o) { return o.NC > 0; }).map(function (o) {
      var n = o.NC, l = n * Math.pow(1 - 1 / (9 * n) - 1.96 / (3 * Math.sqrt(n)), 3), u = (n + 1) * Math.pow(1 - 1 / (9 * (n + 1)) + 1.96 / (3 * Math.sqrt(n + 1)), 3);
      return { o: o, r: n / o.EQ, l: Math.max(l, 0.01) / o.EQ, u: u / o.EQ }; }).sort(function (a, b) { return b.r - a.r; });
    if (!os.length) { pEmpty(k); return; }
    var lab = 96, mr = 112, rh = 28, H = os.length * rh + 28, pw = W0 - lab - mr, lo = Math.min.apply(null, os.map(function (x) { return x.l; })) / 1.3, hi = Math.max.apply(null, os.map(function (x) { return x.u; })) * 1.3, g = '';
    function X(v) { return lab + (Math.log10(v) - Math.log10(lo)) / (Math.log10(hi) - Math.log10(lo)) * pw; }
    (pw < 320 ? [0.01, 0.1, 1, 10] : [0.01, 0.03, 0.1, 0.3, 1, 3, 10, 30]).filter(function (t) { return t >= lo && t <= hi; }).forEach(function (t) { g += '<line x1="' + r1(X(t)) + '" x2="' + r1(X(t)) + '" y1="0" y2="' + (H - 22) + '" stroke="var(--grid)"/>' + tx(X(t), H - 6, String(t).replace('.', G.lang === 'fr' ? ',' : '.'), 'mu', 'middle'); });
    os.forEach(function (x, i) { var y = i * rh + rh / 2;
      g += tx(lab - 10, y + 4, x.o.p, 'ink', 'end') + '<line x1="' + r1(X(x.l)) + '" x2="' + r1(X(x.u)) + '" y1="' + y + '" y2="' + y + '" stroke="var(--ink-2)" stroke-width="2"/>';
      g += '<line x1="' + r1(X(x.l)) + '" x2="' + r1(X(x.l)) + '" y1="' + (y - 5) + '" y2="' + (y + 5) + '" stroke="var(--ink-2)" stroke-width="1.5"/><line x1="' + r1(X(x.u)) + '" x2="' + r1(X(x.u)) + '" y1="' + (y - 5) + '" y2="' + (y + 5) + '" stroke="var(--ink-2)" stroke-width="1.5"/>';
      g += '<circle cx="' + r1(X(x.r)) + '" cy="' + y + '" r="5" fill="var(--s1)" stroke="var(--surface)" stroke-width="1.5"' + ppk('pprod', x.o.p) + tip(x.o.p, [gx('perEq', { v: f2(x.r) }), gx('ciTip', { a: f2(x.l), b: f2(x.u) }), pSub(x.o)]) + '/>' + tx(lab + pw + 10, y + 4, f2(x.r), 'ink') + tx(lab + pw + 48, y + 4, S('ciMsn', { e: f1(x.o.EQ) }), 'mu', null, ' style="font-size:11px"'); });
    gSet(k, svg(W0, H, g, gT(k)), sw('var(--s1)', S('ciDot'), true) + '<span><i class="ln" style="width:22px;height:2px;background:var(--ink-2)"></i>' + esc(S('ciLine')) + '</span>');
  }

  // 65. cable defects per 10 MSN, month by month
  function g65(k) { pTrend(k, pMonthly(function (o, i) { return o.cab[i]; }, grpOk), f2, function (v) { return gx('perEq', { v: f2(v) }); }, 'var(--s2)'); var b = gB(k); if (b) b.insertAdjacentHTML('afterbegin', grpSeg()); }

  // 71. NCs expected by December, by product
  // the forecast's name with the months it covers, "Prévision (oct. à déc.)": from the running month, when days of it are still
  // to come, to the last forecast month. fc: the chart's forecast months ('YYYY-MM'), act: the months done before them
  function fcLeg(fc, act) {
    if (!fc || !fc.length) return gx('fcLeg');
    var run = PD && PD.cur != null && PD.part[PD.cur] < 1 && act && act.length && act[act.length - 1] === PD.months[PD.cur];
    var a = monthName(run ? act[act.length - 1] : fc[0]), b = monthName(fc[fc.length - 1]);
    return gx('fcLeg') + ' (' + (a === b ? a : gx('fcSpan', { a: a, b: b })) + ')';
  }

  // 76. connection errors per 10 MSN, by cause
  function g76(k) {
    if (connNone(k)) return;
    var keys = ['Inversion', 'Mauvaise Borne', 'Non Connecté'], tints = [100, 62, 32], rows = pOk().filter(connOk).map(function (o) { return { o: o, v: keys.map(function (r) { return (o.conn[r] || 0) / o.EQ; }) }; })
      .filter(function (r) { return sumA(r.v) > 0; }).sort(function (a, b) { return sumA(b.v) - sumA(a.v); });
    if (!rows.length) { pEmpty(k); return; }
    var W0 = gWd(k), lab = 96, mr = 56, rh = 28, H = rows.length * rh + 6, pw = W0 - lab - mr, mx = Math.max.apply(null, rows.map(function (r) { return sumA(r.v); })), g = '';
    rows.forEach(function (r, i) { var y = i * rh + 4, x = lab;
      g += tx(lab - 10, y + 14, r.o.p, 'ink', 'end');
      r.v.forEach(function (v, j) { if (!v) return; var w = v / mx * pw; g += '<rect x="' + r1(x) + '" y="' + (y + 4) + '" width="' + r1(Math.max(1, w - 1.5)) + '" height="15" fill="' + tint('--c2', tints[j]) + '"' + ppk('pprod', r.o.p) + tip(r.o.p + ' · ' + L(keys[j]), [gx('perEq', { v: f2(v) }), gx('defN', { n: num(r.o.conn[keys[j]] || 0) })]) + '/>'; x += w; });
      g += tx(x + 6, y + 16, f2(sumA(r.v)), 'ink'); });
    gSet(k, svg(W0, H, g, gT(k)), keys.map(function (r, j) { return sw(tint('--c2', tints[j]), L(r)); }).join(''));
  }

  // 78. one root cause per MSN, month by month: the cause followed in the monthly ranking (a:bump, A.pin), else the first cause of
  // that chart's last month. A330 and A350 together (A320's small parts counted one by one would pull the rate down), or the line
  // chosen in the filter bar
  function c78Cause() {
    if (A.pin) return A.pin;
    var by = {}, last = ''; aRows().forEach(function (r) { var m = r[2].slice(0, 7), a = dRca(r), o = by[m] || (by[m] = {}); if (m > last) last = m; if (a) o[a] = (o[a] || 0) + 1; });
    var c = by[last] || {}; return Object.keys(c).sort(function (a, b) { return c[b] - c[a] || (a < b ? -1 : 1); })[0] || '';
  }
  GDYN['78'] = function () { var t = GSTR['78'][G.lang].slice(), c = c78Cause(); t[1] = t[1].split('{C}').join(c ? L(c) : S('c78None')); t[2] = t[2].split('{L}').join(GF.line ? S('c78One', { l: GF.line }) : S('c78Both')); return t; };
  function g78(k) {
    var c = c78Cause(), keep = function (o) { return GF.line ? true : connOk(o); }, cm = {};
    if (!c) { pEmpty(k); return; }
    PD.defs.forEach(function (d) { if (d.rca !== c) return; var x = PD.ncs[d.n], o = cm[x.p] || (cm[x.p] = {}); o[x.m] = (o[x.m] || 0) + 1; });
    var R = y25Rca(), q = R ? y25Rate(R.filter(function (x) { return x.rca === c; }), function (x) { return x.d; }, function (p) { return GF.line ? true : !!CONN_LINES[PD.line[p]]; }) : null;   // the comparison year: this cause per product delivered
    pTrend(k, pMonthly(function (o, i) { return (cm[o.p] || {})[i] || 0; }, keep), f2, function (v) { return gx('perEq', { v: f2(v) }); }, vqCol(c), q ? { v: q.r, lab: S('v2Avg25') } : null, true); }

  // connection errors per million connection operations (a MIP has 5,572; MIP A350 only until the other products'
  // counts are known). References: 2025 (per MIP delivered), the target (2025 - 25 %), and the sigma level of the period
  var OPS_MSN = { 'MIP A350': 5572 };
  function invNorm(p) {   // inverse of the standard normal distribution (Acklam), for the sigma level
    var a = [-39.69683028665376, 220.9460984245205, -275.9285104469687, 138.357751867269, -30.66479806614716, 2.506628277459239], b = [-54.47609879822406, 161.5858368580409, -155.6989798598866, 66.80131188771972, -13.28068155288572],
      c = [-0.007784894002430293, -0.3223964580411365, -2.400758277161838, -2.549732539343734, 4.374664141464968, 2.938163982698783], d = [0.007784695709041462, 0.3224671290700398, 2.445134137142996, 3.754408661907416], q, r;
    if (p < 0.02425) { q = Math.sqrt(-2 * Math.log(p)); return (((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1); }
    if (p > 1 - 0.02425) { q = Math.sqrt(-2 * Math.log(1 - p)); return -(((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1); }
    q = p - 0.5; r = q * q; return (((((a[0] * r + a[1]) * r + a[2]) * r + a[3]) * r + a[4]) * r + a[5]) * q / (((((b[0] * r + b[1]) * r + b[2]) * r + b[3]) * r + b[4]) * r + 1);
  }
  function v2Mio(k) {
    if (GF.line && GF.line !== 'A350') { gSet(k, '<p class="empty">' + esc(gx('mioOnly')) + '</p>'); return; }
    var P = 'MIP A350', ops = OPS_MSN[P], keep = function (o) { return o.p === P; }, f0 = function (v) { return num(Math.round(v)); };
    var rows = pMonthly(function (o, i) { return o.connm[i]; }, keep).map(function (x) { return { i: x.i, e: x.e * ops / 1e6, v: x.v }; });
    var R = y25Rca(), q = R ? y25Rate(R.filter(function (x) { return x.cat === 'Erreur Branchement'; }), function (x) { return x.d; }, function (p) { return p === P; }) : null;
    var r25 = q ? q.r / ops * 1e6 : null, refs = r25 ? [{ v: r25, lab: gx('mio25'), short: PREV, col: 'var(--ink-2)' }, { v: r25 * V2CUT, lab: gx('mioTgt'), short: S('v2TgtShort'), col: 'var(--up)' }] : null;
    pTrend(k, rows, f0, function (v) { return gx('mioTip', { v: f0(v) }); }, tint('--c2', 100), refs);
    var tv = sumA(rows.map(function (x) { return x.v; })), te = sumA(rows.map(function (x) { return x.e; })), rate = te ? tv / te : 0;
    v2Stats(k, [[f0(rate), gx('mioNow')], [rate ? f1(invNorm(1 - rate / 1e6) + 1.5) + ' σ' : '—', gx('mioSig')]].concat(r25 ? [[f0(r25 * V2CUT), gx('mioTgt')]] : []));
  }

  // the numbered charts the tabs show (V2L), and their cards
  var PSPEC = [['53', g53], ['54', g54], ['61', g61], ['64', g64], ['65', g65], ['76', g76], ['78', g78]];
  function pCard(sp) {
    var id = sp[0];
    return '<article class="gcard" id="g-' + id + '"><div class="ghead"><span class="gnum">' + id + '</span><div><span class="kicker" id="g-' + id + '-k"></span><h3 id="g-' + id + '-h"></h3></div>' +
      '<button type="button" class="keep" data-keep="' + id + '" aria-pressed="false"></button></div><p class="sub" id="g-' + id + '-s"></p><p class="feas" id="g-' + id + '-f"></p>' +
      '<div class="vbody" id="g-' + id + '-b"></div><div class="vlegend" id="g-' + id + '-l" hidden></div></article>';
  }
  if (pSrc()) document.getElementById('pg2').innerHTML = PSPEC.map(pCard).join('');

  // ---------------------------------------------------------------- filter bar
  function opts(el, items, cur) { el.innerHTML = items.map(function (p) { return '<option value="' + esc(p[0]) + '"' + (p[0] === cur ? ' selected' : '') + '>' + esc(p[1]) + '</option>'; }).join(''); }
  function plantOff() { return G.tab === 'client' || G.tab === 'rca'; }
  function renderBar() {
    opts(document.getElementById('gSrc'), ['all', 'sky', 'gps', 'test'].map(function (k) { return [k, S('src_' + k)]; }), GF.src);
    opts(document.getElementById('gLine'), [['', S('line_all')]].concat(LINES.map(function (l) { return [l, l]; })), GF.line);
    opts(document.getElementById('gPreset'), PRESETS.map(function (k) { return [k, S('pr_' + k)]; }), GF.preset);
    document.getElementById('gPhase').innerHTML = [['', 'ph_all'], ['SERIE', 'ph_SERIE'], ['REC', 'ph_REC'], ['FTI', 'ph_FTI']].map(function (p) {
      return '<button type="button" role="radio" data-ph="' + p[0] + '" aria-checked="' + (GF.phase === p[0]) + '" tabindex="' + (GF.phase === p[0] ? 0 : -1) + '">' + esc(S(p[1])) + '</button>'; }).join('');
    var pl = document.getElementById('gPlant'), off = plantOff();
    pl.setAttribute('aria-checked', String(GF.fto2)); pl.disabled = off;
    var pn = document.getElementById('gPlantNote'); pn.hidden = !off; pn.textContent = off ? S('fPlantOff') : '';
    document.getElementById('gPlantTxt').textContent = S(GF.fto2 ? 'fYes' : 'fNo');
    var lc = {}, l0 = GF.liab; GF.liab = 'fso';   // the ticks, with how many NCs each holds under the other filters
    try { REP.forEach(function (n) { if (gNc(n) && gScope(n)) { var k = liabCat(n); lc[k] = (lc[k] || 0) + 1; } }); } finally { GF.liab = l0; }
    document.getElementById('gLiabMenu').innerHTML = LIABS.map(function (k) { return '<label><input type="checkbox" data-liab="' + k + '"' + (GF.liab.indexOf(k) >= 0 ? ' checked' : '') + '>' + esc(S('liab_' + k)) + '<small>' + num(lc[k] || 0) + '</small></label>'; }).join('');
    document.getElementById('gLiabTxt').textContent = GF.liab === 'fso' ? S('liab_all') : LIABS.filter(function (k) { return GF.liab.indexOf(k) >= 0; }).map(function (k) { return S('liab_' + k); }).join(', ');
    var rec = GF.phase === 'REC'; document.getElementById('gCostBox').hidden = !rec;   // the cost switch: REC only
    if (rec) document.getElementById('gCost').innerHTML = [['fto2', 'cost_fto2'], ['all', 'cost_all']].map(function (x) { return '<button type="button" role="radio" data-cost="' + x[0] + '" aria-checked="' + (GF.cost === x[0]) + '">' + esc(S(x[1])) + '</button>'; }).join('');
    ['gFrom', 'gTo'].forEach(function (id, i) { var el = document.getElementById(id); el.value = i ? GF.to : GF.from; el.min = DMIN; el.max = DMAX; });
    var gp = document.getElementById('gPick'); gp.hidden = !GF.pick; if (GF.pick) { document.getElementById('gPickTxt').textContent = pickLabel(GF.pick); document.getElementById('gPickX').setAttribute('aria-label', S('pkClear')); }
    document.getElementById('gReset').hidden = ['pick', 'src', 'org', 'fto2', 'liab', 'cost', 'phase', 'line', 'preset'].every(function (k) { return GF[k] === GF0[k]; });
    var cli = G.tab === 'client', nc = cli ? CLI_NC : SEL_NC, set = cli ? CLI : SEL;
    var nd = D.defects.filter(function (r) { return set[r[0]] && keepMinor(r); }).length;
    document.getElementById('fbSum').textContent = S(cli ? 'fbSumCli' : 'fbSum', { n: num(nc.length), d: num(nd) });
    renderInfo();
  }
  // ---------------------------------------------------------------- the ⓘ panel: every filter in order, what it removes, what is left (same tests as gNc and gScope)
  function selText(id) { var el = document.getElementById(id), o = el && el.selectedOptions && el.selectedOptions[0]; return o ? o.textContent : ''; }
  function renderInfo() {
    var box = document.getElementById('gInfo'); if (!box || box.hidden) return;
    var cur = REP.slice(), T = REP.length, rows = [];
    var nMiss = REP.filter(function (n) { return n[41] === 'missing_ids'; }).length;
    function step(lab, on, val, test, detail, offLab) {
      var keep = on ? cur.filter(test) : cur, gone = on ? cur.filter(function (n) { return !test(n); }) : [];
      rows.push({ lab: lab, val: on ? val : offLab || S('inf_all'), off: !on, out: gone.length, left: keep.length, det: on && detail ? detail(gone) : '' });
      cur = keep;
    }
    step(S('inf_period'), true, shortDay(GF.from) + ' → ' + shortDay(GF.to), function (n) { return n[1] >= GF.from && n[1] <= GF.to; });
    step(S('inf_phase'), !!GF.phase, GF.phase ? S('ph_' + GF.phase) : '', function (n) { return n[24] === GF.phase; }, function (g) {
      var c = {}; g.forEach(function (n) { c[n[24] || '—'] = (c[n[24] || '—'] || 0) + 1; });
      return Object.keys(c).length ? S('inf_phaseS', { v: phaseOrder(Object.keys(c)).map(function (k) { return k + ' ' + num(c[k]); }).join(' · ') }) : ''; });
    step(S('inf_line'), !!GF.line, GF.line, function (n) { return n[3] === GF.line; });
    step(S('inf_src'), GF.src !== 'all', S('src_' + GF.src), srcOk);
    step(S('inf_org'), !!GF.org, GF.org ? S('org_' + GF.org) : '', orgOk);
    step(S('inf_plant'), !!GF.fto2, S('fYes'), ours, function (g) {
      var cli = g.filter(function (n) { return n[23] === 'client'; }).length, oth = g.filter(function (n) { return n[23] !== 'client'; }), pl = {};
      oth.forEach(function (n) { var k = n[42] || '—'; pl[k] = (pl[k] || 0) + 1; });
      var top = Object.keys(pl).sort(function (a, b) { return pl[b] - pl[a]; }).slice(0, 4).map(function (k) { return k + ' ' + num(pl[k]); }).join(', ');
      return S('inf_plantS', { c: num(cli), o: num(oth.length), p: top ? ' (' + top + ')' : '' }); }, S('inf_plantNo'));
    step(S('inf_liab'), GF.liab !== 'fso', document.getElementById('gLiabTxt').textContent, function (n) { return GF.liab.indexOf(liabCat(n)) >= 0; }, function (g) {
      var lb = {}; g.forEach(function (n) { var k = liabCat(n); lb[k] = (lb[k] || 0) + 1; });
      return S('inf_liabS', { p: LIABS.filter(function (k) { return lb[k]; }).map(function (k) { return S('liab_' + k) + ' ' + num(lb[k]); }).join(', ') }); }, S('inf_liabNo'));
    step(S('inf_pick'), !!GF.pick, GF.pick ? pickLabel(GF.pick) : '', function (n) { return pickNc(n); });
    var set = ids(cur), nd = D.defects.filter(function (r) { return set[r[0]] && keepMinor(r); }).length;
    var zero = cur.filter(function (n) { return !costed(n); }), zeroE = sumA(zero.map(function (n) { return n[43] || 0; }));
    var noDef = cur.filter(function (n) { return !n[21]; }).length;
    var bar = function (v) { return '<span class="fn-bar"><i style="width:' + (T ? v / T * 100 : 0) + '%"></i></span>'; };
    var h = '<h3>' + esc(S('inf_title')) + '</h3><div class="fn-row hd"><span></span><span class="out">' + esc(S('inf_out')) + '</span><span class="left">' + esc(S('inf_left')) + '</span><span></span></div>';
    h += '<div class="fn-row"><span class="k">' + esc(S('inf_start')) + '<small>' + esc(S('inf_startS', { a: num(T - nMiss), b: num(nMiss) })) + '</small></span><span class="out"></span><span class="left">' + num(T) + '</span>' + bar(T) + '</div>';
    rows.forEach(function (r) {
      h += '<div class="fn-row' + (r.off ? ' off' : '') + '"><span class="k">' + esc(r.lab) + ' : ' + esc(r.val) + (r.det ? '<small>' + esc(r.det) + '</small>' : '') + '</span><span class="out">' + (r.off ? '' : '− ' + num(r.out)) + '</span><span class="left">' + num(r.left) + '</span>' + bar(r.left) + '</div>';
    });
    h += '<div class="fn-row end"><span class="k">' + esc(S('inf_end')) + '<small>' + esc(S('inf_endS', { d: num(nd) })) + '</small></span><span class="out"></span><span class="left">' + num(cur.length) + '</span>' + bar(cur.length) + '</div>';
    var notes = [zero.length ? S('inf_cost', { n: num(zero.length), e: eur(zeroE) }) : COSTALL ? S('inf_costAll') : '', S('inf_minor', { v: S(G.minor ? 'inf_in' : 'inf_ex') })];
    if (noDef) notes.push(S('inf_nodef', { n: num(noDef) }));
    if (G.tab === 'client') notes.push(S('inf_cli', { n: num(CLI_NC.length) }));
    if (cur.length !== SEL_NC.length) notes.push('⚠ ' + num(cur.length) + ' ≠ ' + num(SEL_NC.length));   // the panel and the page must agree
    box.innerHTML = h + notes.filter(Boolean).map(function (t) { return '<p class="fn-note">' + esc(t) + '</p>'; }).join('');
  }
  // ---------------------------------------------------------------- the NCs of the selection as a CSV file (Excel, French settings: ";" and
  // a decimal comma), short (the key columns) or full, one row per defect line (the minor ones as the switch says; with a pick on a defect, its lines only), an NC with no
  // defect line on one row. Saved like the PNG files: a link with a "download" name (a data URL, as tested in Slate; a blob when too big)
  function csvOf(full) {
    var p = GF.pick, keep = p && PICK_DEF[p.k] ? function (r) { return String(PICK_DEF[p.k](r)) === String(p.v); } : function () { return true; };
    var lines = {}; D.defects.forEach(function (r) { if (SEL[r[0]] && keepMinor(r) && keep(r)) (lines[r[0]] || (lines[r[0]] = [])).push(r); });
    var org = S('csvOrg').split('|'), yn = S('csvYes').split('|'), ORG = { serie: org[0], client: org[1], autre: org[2] }, E = [];
    var yes = function (v) { return v ? yn[0] : yn[1]; }, w = function (n, i) { return (n[40] || [])[i]; };
    // the columns, from the most to the least important: [value of the NC n and its defect line r (none for an NC with no line)]
    var SHORT = [function (n) { return n[0]; }, function (n) { return n[1]; }, function (n) { return n[3]; }, function (n) { return n[25]; },
      function (n) { return n[26]; }, function (n) { return n[27]; }, function (n, r) { return r ? dCat(r) : ''; }, function (n, r) { return r ? dRca(r) : ''; },
      function (n, r) { return r ? dSub(r) : ''; }, function (n, r) { return r ? dCode(r) : ''; }, function (n, r) { return r ? dFin(r) : ''; },
      function (n, r) { return r ? r[18] : ''; }, function (n) { return n[12]; }];
    var MORE = [function (n) { return n[22]; }, function (n, r) { return r ? r[1] : ''; }, function (n, r) { return r ? dAlloc(r) : ''; },
      function (n) { return n[24]; }, function (n) { return n[33]; }, function (n) { return ORG[n[23]] || n[23]; }, function (n) { return S('liab_' + liabCat(n)); },
      function (n) { return n[8]; }, function (n) { return n[7]; }, function (n) { return n[38]; }, function (n) { return yes(n[30]); }, function (n) { return n[32]; },
      function (n) { return n[31]; }, function (n) { return n[21]; }, function (n, r) { return r ? yes(dMinor(r)) : ''; }, function (n, r) { return r ? yes(dCable(r)) : ''; },
      function (n) { return n[2]; }, function (n) { return S('src_' + n[39]); }, function (n) { return S('org_' + (n[41] || 'normal')); }, function (n) { return n[44]; },
      function (n) { return n[45]; }, function (n) { return n[15]; }, function (n) { return n[17]; }, function (n) { return n[13]; }, function (n) { return n[18]; },
      function (n) { return n[46]; }, function (n) { return w(n, 12); }, function (n) { return w(n, 10); }];
    var cols = full ? SHORT.concat(MORE) : SHORT, head = S('csvCols').split('|').concat(full ? S('csvMore').split('|') : []);
    var cell = function (v) { var t = v == null ? '' : typeof v === 'number' ? (isFinite(v) ? String(Math.round(v * 100) / 100).replace('.', ',') : '') : String(v);
      return /[;"\n\r]/.test(t) ? '"' + t.replace(/"/g, '""') + '"' : t; };
    var out = [head.map(cell).join(';')];
    SEL_NC.slice().sort(function (a, b) { return a[1] < b[1] ? -1 : a[1] > b[1] ? 1 : a[0] < b[0] ? -1 : 1; }).forEach(function (n) {
      var ds = (lines[n[0]] || []).slice().sort(function (a, b) { return a[1] - b[1]; });
      (ds.length ? ds : [null]).forEach(function (r) { out.push(cols.map(function (f) { return cell(f(n, r)); }).join(';')); });
    });
    var text = '﻿' + out.join('\r\n'), name = pngName(S('csvName', { k: S(full ? 'csvKf' : 'csvKs'), a: GF.from, b: GF.to })).replace(/\.png$/, '.csv'),
      url = 'data:text/csv;charset=utf-8,' + encodeURIComponent(text), blob = null;
    if (url.length > 1800000 && window.Blob && window.URL && URL.createObjectURL) { blob = URL.createObjectURL(new Blob([text], { type: 'text/csv;charset=utf-8' })); url = blob; }
    var ln = document.createElement('a'); ln.href = url; ln.download = name; ln.style.display = 'none';
    document.body.appendChild(ln); ln.click(); setTimeout(function () { ln.remove(); if (blob) URL.revokeObjectURL(blob); }, 1000);
    return out.length - 1;
  }
  document.addEventListener('click', function (e) { var b = e.target.closest && e.target.closest('[data-csv]'); if (b) csvOf(b.getAttribute('data-csv') === 'full'); });
  document.getElementById('gInfoBtn').addEventListener('click', function () {
    var box = document.getElementById('gInfo'), open = box.hidden; box.hidden = !open; this.setAttribute('aria-expanded', String(open)); renderInfo();
  });
  function setGF(ch) { Object.keys(ch).forEach(function (k) { GF[k] = ch[k]; }); select(); A.msn = null; renderAll(); }
  document.getElementById('gPickX').addEventListener('click', function (e) { e.stopPropagation(); GF.pick = null; pickPrep(); setGF({}); });
  document.getElementById('gLine').addEventListener('change', function (e) { setGF({ line: e.target.value }); });
  document.getElementById('gPreset').addEventListener('change', function (e) { setGF({ preset: e.target.value }); });
  document.getElementById('gPlant').addEventListener('click', function () { if (!plantOff()) setGF({ fto2: !GF.fto2 }); });
  // the data source: all, Skywise only, or the NCs also on the GPS register or the Test list (18 Nov: one choice; the "missing
  // IDs", the NCs of those lists the normal Skywise search does not find, are no filter: they show in the ⓘ panel and the full extract)
  document.getElementById('gSrc').addEventListener('change', function (e) { setGF({ src: e.target.value }); });
  document.getElementById('gLiabMenu').addEventListener('change', function (e) {   // at least one tick stays
    var on = [].filter.call(this.querySelectorAll('[data-liab]'), function (i) { return i.checked; }).map(function (i) { return i.getAttribute('data-liab'); });
    if (!on.length) { e.target.checked = true; return; }
    setGF({ liab: LIABS.filter(function (k) { return on.indexOf(k) >= 0; }).join('') }); document.getElementById('gLiab').open = true;
  });
  document.addEventListener('click', function (e) { var d = document.getElementById('gLiab'); if (d && d.open && !d.contains(e.target)) d.open = false; });
  document.getElementById('gCost').addEventListener('click', function (e) { var b = e.target.closest('[data-cost]'); if (!b) return;   // "Toutes les NC" shows them all: every tick on
    var c = b.getAttribute('data-cost'); setGF(c === 'all' ? { cost: c, liab: 'fso' } : { cost: c }); });
  var PHS = ['', 'SERIE', 'REC', 'FTI'];
  document.getElementById('gPhase').addEventListener('click', function (e) { var c = e.target.closest('[data-ph]'); if (c) setGF({ phase: c.getAttribute('data-ph') }); });
  document.getElementById('gPhase').addEventListener('keydown', function (e) {
    var k = { ArrowRight: 1, ArrowDown: 1, ArrowLeft: -1, ArrowUp: -1 }[e.key]; if (!k) return; e.preventDefault();
    var i = (PHS.indexOf(GF.phase) + k + PHS.length) % PHS.length; setGF({ phase: PHS[i] });
    var b = document.querySelector('#gPhase [data-ph="' + PHS[i] + '"]'); if (b) b.focus();
  });
  // typed dates: kept only when complete and inside a sensible range; the two ends swap if reversed
  function setDate(which, v) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(v)) return;
    var f = which === 'from' ? v : GF.from, t = which === 'to' ? v : GF.to;
    if (f > t) { var x = f; f = t; t = x; }
    setGF({ preset: 'custom', from: f, to: t });
  }
  document.getElementById('gFrom').addEventListener('change', function (e) { setDate('from', e.target.value); });
  document.getElementById('gTo').addEventListener('change', function (e) { setDate('to', e.target.value); });
  document.getElementById('gReset').addEventListener('click', function () { var c = Object.assign({}, GF0); setGF(c); pickPrep(); });

  // ---------------------------------------------------------------- Drawing a chart by its key: 'A:<k>' an Analyses chart (RV_ANA), else a
  // numbered chart (PSPEC)
  var RV_ANA = { lead: function () { vLead(); }, bump: function () { vBump(aRows()); }, cmo: function () { vCmo(aRows()); }, cal: function () { vCal(aRows()); },
    flow: function () { vFlow(aRows()); }, bub: function () { vBub(aRows()); }, msn: function () { vMsn(); }, prod: function () { vProd(); }, station: function () { vStation(aRows()); } };
  function rvIsAna(c) { return c.indexOf('A:') === 0; }
  function rvDraw(c) {
    if (rvIsAna(c)) { EMPTY = '<p class="empty">—</p>'; RV_ANA[c.slice(2)](); return; }
    var t = gHead(c), sp = PSPEC.filter(function (x) { return x[0] === c; })[0];
    document.getElementById('g-' + c + '-k').textContent = t[0];
    document.getElementById('g-' + c + '-h').textContent = t[1];
    document.getElementById('g-' + c + '-s').textContent = t[2];
    var f = document.getElementById('g-' + c + '-f');
    f.className = 'feas ok'; f.innerHTML = '<i aria-hidden="true">✓</i>' + esc(gx('pReal') + ' · ' + t[3]); sp[1](c);
  }

  // ---------------------------------------------------------------- Dashboard v2 (main page): layout A. Overview: header, target per line, NC trend,
  // programmes, cost against budget, time to close, volume-then-per-MSN scorecard, control chart. Pareto: bubble and flow on top, cause charts below.
  // Where: rates by product, FINs, aircraft, stations. Cost: what it is made of, every NC. The bands are today's cards, the rate charts, and charts
  // rebuilt on the real NCs (keys V*). 2025 (D.y25): the 2025 extract through the pipeline's rules, the parser and the CNQ model, summed
  // per month, scope, phase, line and product, and the 2025 deliveries per product. Target = 2025 - 25 %, budget = 2025 cost - 25 %.
  // Without 2025 for the filter (data-source filter, no 2025 NC), the old placeholders come back, marked on the page.
  var V2B = false, V2BAND = {};
  var V2L = {
    ov: { top: ['VT', 'VN', 'VB', 'a:lead', 'VX'], fold: ['a:cal'] },
    pareto: { top: ['a:bump', '78', 'a:flow', 'a:bub', '53', '76', 'VM', 'VQ', 'a:cmo'],   // 17 Nov: the ranking beside the cause it follows   // 30 Oct: connection errors by month alone on a row; per million operations beside by product
                inboard: ['VW'], fold: ['65', 'VK'] },   // under the lists; the hundred squares sit in the lists (20 Oct); swapped pins folded until checked on the real data (21 Oct)
    where: { top: ['VP', '61', 'a:prod', '54', 'a:msn', 'VF', 'a:station'], fold: ['64'] },   // fleet pictograms removed
    cnq: { more: ['VC'], fold: ['VE'] }
  };
  // every chart card has an image button (17 Nov); a card with no chart drawn (a table) hides it
  var V2F = { VM: v2Mio, VT: v2Target, VN: v2Trend, VB: v2Budget, VS: v2Score, VX: v2Xmr, VW: v2Waffle, VQ: v2Quarters, VP: v2Prod, VF: v2Fins, VI: v2Icons, VC: v2Comp, VE: v2Each, VK: v2Pins };
  Object.assign(GSTR, withYears({
    VT: { fr: ['Objectif', 'Chaque ligne face à son objectif', 'NC par MSN produit ; trait : objectif, le taux {PREV} de la ligne (NC par produit {LIV}é) moins {CUT} %. Toutes lignes : la somme des objectifs des lignes.', 'production MSN · NC · {LIVN} {PREV}'],
          en: ['Target', 'Each line against its target', 'NCs per MSN built; tick: target, the line’s {PREV} rate (NCs per product {DLV}) minus {CUT}%. All lines: the sum of the lines’ targets.', 'MSN output · NCs · {PREV} deliveries'] },
    VN: { fr: ['Tendance', 'NC cumulées sur l’année', 'Pointillé : prévision au taux de la période × production prévue ; tirets : objectif cumulé, ligne par ligne (taux {PREV} − {CUT} % × production {YEAR}). À gauche : {PREV} et l’objectif de l’année, par ligne.', 'NC · production MSN prévue · NC {PREV}'],
          en: ['Trend', 'Cumulative NCs over the year', 'Dotted: forecast at the period rate × planned output; dashed: cumulative target, line by line ({PREV} rate − {CUT}% × {YEAR} output). Left: {PREV} and the year’s target, by line.', 'NCs · planned MSN output · {PREV} NCs'] },
    VB: { fr: ['Coût', 'Coût de non-qualité cumulé', 'Pointillé : prévision ; tirets : objectif de coût cumulé, ligne par ligne (coût {PREV} par produit {LIV}é − {CUT} % × production {YEAR}). À gauche : {PREV} et l’objectif de l’année, par ligne.', 'coût CNQ · production MSN prévue · coût {PREV}'],
          en: ['Cost', 'Cumulative cost of non-quality', 'Dotted: forecast; dashed: cumulative cost target, line by line ({PREV} cost per product {DLV} − {CUT}% × {YEAR} output). Left: {PREV} and the year’s target, by line.', 'CNQ cost · planned MSN output · {PREV} cost'] },
    VS: { fr: ['Volumes et taux', 'NC, défauts et coût : le volume, puis par MSN', 'Chaque ligne : le volume mois par mois, puis le même rapporté au nombre de MSN produits.', 'NC · défauts · coût · production MSN'],
          en: ['Volumes and rates', 'NCs, defects and cost: the volume, then per MSN', 'Each row: the volume month by month, then the same against the number of MSN built.', 'NCs · defects · cost · MSN output'] },
    VX: { fr: ['Maîtrise statistique', 'NC par semaine, avec leurs limites', 'σ = écart-type des NC par semaine. 2 σ : niveau d’attention. 3 σ : niveau d’alarme.', 'NC par semaine'],
          en: ['Process control', 'NCs per week, with their limits', 'σ = standard deviation of the NCs per week. 2 σ: attention level. 3 σ: alarm level.', 'NCs per week'] },
    VM: { fr: ['Branchement', 'Erreurs de branchement par million d’opérations, MIP A350', '5 572 opérations de branchement par MIP.', 'défauts · production MSN · {LIVN} {PREV}'],
          en: ['Connections', 'Connection errors per million operations, MIP A350', '5,572 connection operations per MIP.', 'defects · MSN output · {PREV} deliveries'] },
    VW: { fr: ['Répartition', 'Cent défauts', 'Chaque case : 1 % des défauts, par catégorie.', 'catégorie des défauts'], en: ['Breakdown', 'A hundred defects', 'Each square: 1% of defects, by category.', 'defect category'] },
    VQ: { fr: ['{PREV} / {YEAR}', 'Causes : {PREV} contre {YEAR}, {L}', 'Défauts par MSN, les 10 premières causes de {PREV} et de {YEAR}. {L}.', 'causes · production MSN · {LIVN} {PREV}'],
          en: ['{PREV} / {YEAR}', 'Root causes: {PREV} against {YEAR}, {L}', 'Defects per MSN, the top 10 root causes of {PREV} and of {YEAR}. {L}.', 'root causes · MSN output · {PREV} deliveries'] },
    VP: { fr: ['Taux', 'NC, défauts et coût par MSN, produit par produit', 'Un même ordre de produits dans les trois colonnes ; tiret : ensemble des produits.', 'production MSN · NC · défauts · coût'],
          en: ['Rates', 'NCs, defects and cost per MSN, product by product', 'The same product order in all three columns; tick: all products together.', 'MSN output · NCs · defects · cost'] },
    VF: { fr: ['Récurrence', 'Les FIN qui reviennent d’un avion à l’autre', 'Une colonne par avion (MSN), une ligne par FIN ; carré : défaut sur ce FIN. Ligne du filtre, sinon A350.', 'FIN lu par le parseur · MSN'],
          en: ['Recurrence', 'FINs that come back aircraft after aircraft', 'One column per aircraft (MSN), one row per FIN; square: a defect on that FIN. The filtered line, else A350.', 'FIN read by the parser · MSN'] },
    VK: { fr: ['Inversions', 'Quelles broches sont inversées', 'Les connecteurs (FIN) où le plus d’avions ont une inversion dont les deux broches sont écrites dans le texte. Arc : deux broches inversées ; épaisseur : nombre d’avions ; petite bosse : deux broches qui se suivent.', 'texte des défauts · FIN · MSN'],
          en: ['Swapped wires', 'Which pins get swapped', 'The connectors (FIN) where the most aircraft have a swap with both pins written in the text. Arc: two swapped pins; thickness: number of aircraft; small bump: two pins next to each other.', 'defect text · FIN · MSN'] },
    VI: { fr: ['Parc', 'Chaque avion, un pictogramme', 'Avions dans l’ordre de leur première NC ; teinte selon le nombre de défauts.', 'MSN · défauts'], en: ['Fleet', 'Each aircraft as an icon', 'Aircraft in the order of their first NC; shade by number of defects.', 'MSN · defects'] },
    VC: { fr: ['Composantes', 'De quoi est fait le coût, mois par mois', 'Gestion de la NC (alerte, rédaction, support, recontrôle), reprise, matière, ingénierie.', 'modèle CNQ'],
          en: ['Components', 'What the cost is made of, month by month', 'NC handling (alert, writing, support, re-check), rework, material, engineering.', 'CNQ model'] },
    VE: { fr: ['Coûts', 'Chaque NC dans le temps, à sa taille', 'Une bulle par NC ; surface : coût ; les cinq plus chères sont nommées.', 'coût CNQ par NC'], en: ['Costs', 'Every NC over time, at its size', 'One bubble per NC; area: cost; the five dearest are named.', 'CNQ cost per NC'] }
  }));
  function v2El(k) {
    if (k.indexOf('a:') === 0) return document.getElementById('v-' + k.slice(2));
    var el = document.getElementById('g-' + k);
    if (!el && V2F[k]) { var t = document.createElement('div'); t.innerHTML = pCard([k]); el = t.firstChild; }
    return el;
  }
  function v2Band(k) {
    var el = v2El(k); if (!el) return null;
    var c = V2BAND[k] = document.createElement('div'); c.className = 'card wide mk-band v2-band'; c.setAttribute('data-v2', k);
    c.innerHTML = '<div class="bhead"><span class="kicker"></span><h3></h3><p class="sub"></p><div class="v2stats"></div></div><div class="custom mk-body"></div>';
    c.querySelector('.mk-body').appendChild(el);
    pngBtn(c, k);
    return c;
  }
  function v2Stats(k, items) {   // [[value, label, placeholder?]]
    var e = V2BAND[k] && V2BAND[k].querySelector('.v2stats'); if (!e) return;
    e.innerHTML = items.map(function (x) { return '<div' + (x[2] ? ' class="ph"' : '') + '><b>' + esc(x[0]) + '</b><span>' + esc(x[1]) + '</span></div>'; }).join('');
  }
  // ---------------------------------------------------------------- a chart as a PNG file: a small button in its card's header (beside
  // ⤢ Agrandir in Essentiel). The SVG is copied with the styles the page gives it (the page's CSS does not reach a copied SVG), in
  // the light colours, drawn on a white canvas at twice its size, with the title, the headline figures and the key; the file is
  // named after the title and comes through a link with a "download" name (a data URL, as tested in Slate)
  var PNG_STY = ['fill', 'fill-opacity', 'stroke', 'stroke-width', 'stroke-dasharray', 'stroke-opacity', 'stroke-linecap', 'stroke-linejoin', 'opacity', 'paint-order',
    'font-family', 'font-size', 'font-weight', 'font-style', 'font-variant-numeric', 'text-anchor', 'dominant-baseline', 'letter-spacing', 'visibility', 'display'];
  function pngName(t) {
    var n = String(t || '').replace(/[’‘`]/g, "'").replace(/[\\/:*?"<>|#%&$!@=;~^\[\]\{\}\u0000-\u001f]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 120);
    return (n || 'graphique') + '.png';
  }
  function pngSvg(el) {   // a copy of the chart with its computed styles written on each node
    var c = el.cloneNode(true), a = [el].concat([].slice.call(el.querySelectorAll('*'))), b = [c].concat([].slice.call(c.querySelectorAll('*')));
    a.forEach(function (o, i) { var cs = getComputedStyle(o), st = b[i].style; PNG_STY.forEach(function (k) { var v = cs.getPropertyValue(k); if (v) st.setProperty(k, v); }); });
    var r = el.getBoundingClientRect(), w = Math.round(r.width) || +el.getAttribute('width'), h = Math.round(r.height) || +el.getAttribute('height');
    c.setAttribute('xmlns', 'http://www.w3.org/2000/svg'); c.setAttribute('width', w); c.setAttribute('height', h); c.style.overflow = 'visible';
    return { s: new XMLSerializer().serializeToString(c), w: w, h: h };
  }
  function pngClear(c) { return !c || c === 'transparent' || /rgba\(.*,\s*0\)$/.test(c); }
  function pngKey(l) {   // the key's items as drawn on the page: { m: its mark (a box, a line or a sign), text }
    return !l || l.hidden ? [] : [].slice.call(l.children).map(function (it) {
      var sm = it.tagName === 'DETAILS' ? it.querySelector('summary') : null, i = sm ? null : it.querySelector('i'), b = sm ? null : it.querySelector('b'), t = (sm || it).textContent.replace(/\s+/g, ' ').trim(), m = null;
      if (i) { var cs = getComputedStyle(i), h = parseFloat(cs.height) || 0, wd = parseFloat(cs.width) || 0, bw = parseFloat(cs.borderTopWidth) || 0;
        m = h <= 3 ? { k: 'line', c: pngClear(cs.backgroundColor) || bw ? cs.borderTopColor : cs.backgroundColor, w: Math.max(bw, h, 1.5), d: cs.borderTopStyle === 'dashed' ? [4, 3] : cs.borderTopStyle === 'dotted' ? [1.5, 2.5] : [] } :
          wd <= 3 ? { k: 'tick', c: pngClear(cs.backgroundColor) ? cs.borderLeftColor : cs.backgroundColor, w: Math.max(wd, parseFloat(cs.borderLeftWidth) || 0, 1.5), d: cs.borderLeftStyle === 'dotted' ? [1.5, 2] : [] } :
          { k: 'box', c: pngClear(cs.backgroundColor) ? '' : cs.backgroundColor, b: bw ? cs.borderTopColor : '', w: bw, r: parseFloat(cs.borderTopLeftRadius) >= 5 }; }
      else if (b && b.textContent.trim().length <= 2) { m = { k: 'sign', c: getComputedStyle(b).color, t: b.textContent.trim() }; t = t.slice(b.textContent.trim().length).trim(); }
      return { m: m, t: t };
    }).filter(function (x) { return x.t; });
  }
  function pngOf(k) {
    var band = V2BAND[k]; if (!band) return;
    var a = k.indexOf('a:') === 0, body = document.getElementById(a ? 'v-' + k.slice(2) + '-b' : 'g-' + k + '-b'), leg = document.getElementById(a ? 'v-' + k.slice(2) + '-l' : 'g-' + k + '-l');
    var svgs = body ? [].filter.call(body.querySelectorAll('svg'), function (x) { return x.getBoundingClientRect().width > 40; }) : [];
    if (!svgs.length) return;
    var root = document.documentElement, th = root.getAttribute('data-theme'), parts, key, title = (band.querySelector('.bhead h3') || {}).textContent || '', font = '';
    var stats = [].map.call(band.querySelectorAll('.v2stats > div'), function (d) { return [].map.call(d.children, function (c) { return c.textContent.trim(); }).join(' '); }).filter(Boolean).join('  ·  ');
    root.setAttribute('data-theme', 'light');   // the light colours, on the white background
    try { parts = svgs.map(pngSvg); key = pngKey(leg); font = getComputedStyle(body).fontFamily; }
    finally { if (th == null) root.removeAttribute('data-theme'); else root.setAttribute('data-theme', th); }
    var pad = 18, W = Math.max.apply(null, parts.map(function (x) { return x.w; })) + 2 * pad, Z = 2, cv = document.createElement('canvas'), ctx = cv.getContext('2d');
    ctx.font = '12px ' + font;
    var rows = [], x = 0, line = [], lw = W - 2 * pad;   // the key, item after item, on as many lines as needed
    key.forEach(function (it) { var w = (it.m ? 22 : 0) + ctx.measureText(it.t).width + 18; if (x + w > lw && line.length) { rows.push(line); line = []; x = 0; } line.push(it); x += w; });
    if (line.length) rows.push(line);
    var H = pad + 24 + (stats ? 20 : 0) + 8 + parts.reduce(function (t, p2) { return t + p2.h + 8; }, 0) + rows.length * 20 + pad;
    cv.width = W * Z; cv.height = H * Z; ctx.scale(Z, Z);
    ctx.fillStyle = '#ffffff'; ctx.fillRect(0, 0, W, H);
    ctx.fillStyle = '#15171a'; ctx.font = '600 17px ' + font; ctx.textBaseline = 'alphabetic'; ctx.fillText(title, pad, pad + 16);
    var y = pad + 24; if (stats) { ctx.fillStyle = '#474c52'; ctx.font = '12.5px ' + font; ctx.fillText(stats, pad, y + 12); y += 20; } y += 8;
    var n = 0, out = [];
    parts.forEach(function (p2, j) {
      var im = new Image(), y0 = y; y += p2.h + 8;
      im.onload = function () { out[j] = [im, y0]; if (++n === parts.length) done(); };
      im.onerror = function () { if (++n === parts.length) done(); };
      im.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(p2.s);
    });
    function done() {
      out.forEach(function (o) { if (o) ctx.drawImage(o[0], pad, o[1]); });
      ctx.font = '12px ' + font; var yy = y + 10;
      rows.forEach(function (r) { var xx = pad; r.forEach(function (it) {
        var m = it.m, x0 = m ? xx + 22 : xx;
        if (m && (m.k === 'line' || m.k === 'tick')) { ctx.save(); ctx.strokeStyle = m.c; ctx.lineWidth = m.w; ctx.setLineDash(m.d); ctx.beginPath();
          if (m.k === 'line') { ctx.moveTo(xx, yy - 4); ctx.lineTo(xx + 16, yy - 4); } else { ctx.moveTo(xx + 8, yy - 10); ctx.lineTo(xx + 8, yy + 2); } ctx.stroke(); ctx.restore(); }
        else if (m && m.k === 'box') { ctx.beginPath(); if (m.r) ctx.arc(xx + 8, yy - 4, 5.5, 0, 2 * Math.PI); else ctx.rect(xx + 2, yy - 10, 12, 12);
          if (m.c) { ctx.fillStyle = m.c; ctx.fill(); } if (m.b) { ctx.strokeStyle = m.b; ctx.lineWidth = Math.max(1.2, m.w); ctx.stroke(); } }
        else if (m && m.k === 'sign') { ctx.fillStyle = m.c; ctx.fillText(m.t, xx + 2, yy); }
        ctx.fillStyle = m ? '#474c52' : '#737980'; ctx.fillText(it.t, x0, yy); xx = x0 + ctx.measureText(it.t).width + 18; }); yy += 20; });
      var ln = document.createElement('a'); ln.href = cv.toDataURL('image/png'); ln.download = pngName(title); ln.style.display = 'none';
      document.body.appendChild(ln); ln.click(); setTimeout(function () { ln.remove(); }, 1000);
    }
  }
  function pngBtn(b, k) {
    if (b.querySelector('.png-x')) return;
    var x = document.createElement('button'); x.type = 'button'; x.className = 'png-x'; x.setAttribute('data-png', k);
    b.classList.add('png-b'); b.querySelector('.bhead').appendChild(x); pngT(x);
  }
  function pngT(x) { x.textContent = '⤓ ' + S('pngB'); x.title = S('pngT'); x.setAttribute('aria-label', S('pngT')); }
  document.addEventListener('click', function (e) { var b = e.target.closest && e.target.closest('[data-png]'); if (!b) return; e.stopPropagation(); hideTip(); pngOf(b.getAttribute('data-png')); });
  function v2Wire(el) { el.addEventListener('pointermove', apMove); el.addEventListener('pointerleave', apLeave); el.addEventListener('click', apClick); return el; }
  function v2Grid(keys) { var g = document.createElement('div'); g.className = 'grid'; keys.forEach(function (k) { var b = v2Band(k); if (b) g.appendChild(b); }); return v2Wire(g); }
  function v2Fold(key, keys) {
    var d = document.createElement('details'); d.className = 'detail';
    d.innerHTML = '<summary><span data-t="' + key + '"></span></summary><div class="inner"></div>';
    d.querySelector('.inner').appendChild(v2Grid(keys));
    d.addEventListener('toggle', function () { if (d.open) v2Render(); });
    return d;
  }
  function v2Build() {
    if (V2B) return; V2B = true;
    var ov = document.getElementById('p-ov'), figs = ov.querySelector('.figs');
    var og = v2Grid(V2L.ov.top); og.classList.add('v2ov'); ov.insertBefore(og, figs.nextSibling);
    var pie0 = document.querySelector('#ngx [data-card="prog"]'); if (pie0) { og.appendChild(pie0); ncBoard.watch(pie0); }   // NCs by line: up with the charts (20 Oct)
    ov.setAttribute('data-lay', '5');   // the Magazine layout
    var inner = document.querySelector('#ngxBox .inner'); inner.insertBefore(document.getElementById('ncChips'), inner.firstChild);   // the breakdown lists and their filter chips fold together
    var ngx = v2Wire(document.getElementById('ngx'));
    V2L.ov.fold.forEach(function (k) { var b = v2Band(k); if (b) ngx.appendChild(b); });
    document.getElementById('ngxBox').addEventListener('toggle', function (e) { if (e.target.open) v2Render(); });
    var pp = document.getElementById('p-pareto');
    var pt = v2Grid(V2L.pareto.top); pt.id = 'parTop'; pt.classList.add('v2par'); pp.appendChild(pt);
    V2L.pareto.inboard.forEach(function (k) { v2Band(k); }); ['pgl', 'kgl'].forEach(function (id) { v2Wire(document.getElementById(id)); });
    var pf = v2Fold('parMore', V2L.pareto.fold); pf.id = 'parFold'; pp.appendChild(pf);
    var wh = document.getElementById('p-where'), wg = v2Grid(V2L.where.top); wg.classList.add('v2mag'); wh.appendChild(wg); if (V2L.where.fold.length) wh.appendChild(v2Fold('whereMore', V2L.where.fold)); wh.appendChild(document.getElementById('whBox'));
    v2Chapters(wg);
    var cq = v2Grid(V2L.cnq.more); cq.classList.add('v2cq'); document.getElementById('p-cnq').insertBefore(cq, document.getElementById('cgxBox'));
    var cgb = document.getElementById('cgxBox'), cgx = v2Wire(document.getElementById('cgx')); cgb.hidden = false;
    V2L.cnq.fold.forEach(function (k) { var b = v2Band(k); if (b) cgx.appendChild(b); });
    var wo = document.getElementById('cWo'); if (wo) cgx.appendChild(wo.closest('.card'));   // how the rework is costed: in the other cost charts
    cgb.addEventListener('toggle', function () { if (cgb.open) v2Render(); });
    applyText();
  }
  // Où in chapters: products, aircraft, stations
  var WLGS = ['prod', 'ac', 'st'];
  function v2Chapters(wg) {
    WLGS.forEach(function (gk, i) {
      var c = document.createElement('div'); c.className = 'wl-chap'; c.setAttribute('data-chap', gk);
      c.innerHTML = '<div><span class="n">0' + (i + 1) + '</span><h3 data-t="wlCh_' + gk + '"></h3><p class="sub" data-t="wlChs_' + gk + '"></p></div>'; wg.appendChild(c);
    });
  }
  function v2Head(k) { if (k.indexOf('a:') === 0) { var a = k.slice(2); return [S('k_' + a), S('t_' + a), S('s_' + a)]; } return gHead(k); }
  function v2Draw(k) {
    if (k.indexOf('a:') === 0) { rvDraw('A:' + k.slice(2)); return; }
    if (!V2F[k]) { rvDraw(k); return; }
    var t = gHead(k);
    document.getElementById('g-' + k + '-k').textContent = t[0]; document.getElementById('g-' + k + '-h').textContent = t[1]; document.getElementById('g-' + k + '-s').textContent = t[2];
    if (!PD && k !== 'VW' && k !== 'VQ' && k !== 'VX' && k !== 'VF' && k !== 'VI' && k !== 'VC' && k !== 'VE' && k !== 'VK') { pEmpty(k); return; }
    V2F[k](k);
  }
  function v2Render() {
    v2Build(); document.querySelectorAll('.png-x').forEach(pngT);
    PD = pSrc() ? pData() : null; PA = PD ? pAgg(PD) : null;
    var L2 = V2L[G.tab]; if (!L2) return;
    if (G.tab === 'ov') v2Kpis();
    if (G.tab === 'pareto') {   // in the active measure: category Pareto, the lists (hundred squares under Ligne, sub-codes under them), the charts, the fold, the detail table (lists up, 20 Oct)
      var vol = PMODE === 'vol', sec = document.getElementById(vol ? 'pVol' : 'pCost'), gl = document.getElementById(vol ? 'pgl' : 'kgl');
      var det = sec.querySelector(':scope > details.detail'), pt = document.getElementById('parTop'), pf = document.getElementById('parFold');
      if (pt && pt.previousSibling !== gl) sec.insertBefore(pt, gl.nextSibling);
      if (V2BAND.VW && V2BAND.VW.parentNode !== gl) gl.appendChild(V2BAND.VW);
      if (pf && det && pf.nextSibling !== det) sec.insertBefore(pf, det); }
    ['top', 'inboard', 'mid', 'more', 'fold'].forEach(function (s2) {
      (L2[s2] || []).forEach(function (k) {
        var b = V2BAND[k]; if (!b || !b.isConnected) return;
        var h = v2Head(k); b.querySelector('.kicker').textContent = h[0]; b.querySelector('h3').textContent = h[1]; b.querySelector('.sub').textContent = h[2];
        v2Draw(k);
      });
    });
  }

  // months of the selection, then the months left to December when it reaches the end of the data (the forecast)
  // the share of month m covered by the data and the period: { p: share, d: days gone, n: days in the month }; p = 1 for a month that is over
  function monthShare(m) {
    var end = GF.to < D.meta.to ? GF.to : D.meta.to, n = new Date(Date.UTC(+m.slice(0, 4), +m.slice(5, 7), 0)).getUTCDate();
    if (end.slice(0, 7) !== m) return { p: 1, d: n, n: n };
    var d = +end.slice(8, 10); return { p: d >= n ? 1 : dayShare(end), d: d, n: n };   // the share of its working time gone
  }
  // month label that fits a slot of w px: 'janv', then 'J', then every other month
  function v2Mo(m, w, i) { var t = monthName(m); return w >= 30 ? t.slice(0, 4) : w >= 12 ? t.charAt(0).toUpperCase() : i % 2 ? '' : t.charAt(0).toUpperCase(); }

  // headline figures: a small monthly curve under each, and the per-MSN figure beside the volume
  function v2Kpis() {
    var M = v2Months().act, defBy = {}; if (!M.length) return;
    D.defects.forEach(function (r) { if (SEL[r[0]] && keepMinor(r)) { var m = NC[r[0]][1].slice(0, 7); defBy[m] = (defBy[m] || 0) + 1; } });
    var ncBy = {}, cBy = {}; SEL_NC.forEach(function (n) { var m = n[1].slice(0, 7); ncBy[m] = (ncBy[m] || 0) + 1; cBy[m] = (cBy[m] || 0) + n[12]; });
    var rate = function (f) { return PD ? pMonthly(f, grpOk) : []; }, tot = function (rs) { var e = sumA(rs.map(function (x) { return x.e; })); return e ? sumA(rs.map(function (x) { return x.v; })) / e : null; };
    var rN = rate(function (o, i) { return o.nc[i]; }), rD = rate(function (o, i) { return o.def[i]; }), rC = rate(function (o, i) { return o.cost[i]; });
    function spark(vals, line) {
      var w = 132, h = 28, n = vals.length, mx = Math.max.apply(null, vals.map(function (v) { return v || 0; }).concat([1e-9])), g = '';
      if (line) { var pts = vals.map(function (v, i) { return r1(3 + i / Math.max(1, n - 1) * (w - 6)) + ',' + r1(h - 3 - (v || 0) / mx * (h - 8)); }); g = '<path d="M' + pts.join('L') + '" fill="none" stroke="var(--ink-2)" stroke-width="1.5"/><circle cx="' + pts[n - 1].split(',')[0] + '" cy="' + pts[n - 1].split(',')[1] + '" r="2.5" fill="var(--ink)"/>'; }
      else vals.forEach(function (v, i) { var bw = w / n; g += '<rect x="' + r1(i * bw + bw * 0.14) + '" y="' + r1(h - v / mx * (h - 2)) + '" width="' + r1(bw * 0.72) + '" height="' + r1(Math.max(0.6, v / mx * (h - 2))) + '" rx="1" fill="' + (i === n - 1 ? 'var(--ink-2)' : tint('--ink-2', 32)) + '"/>'; });
      return '<svg class="viz" width="' + w + '" height="' + h + '" viewBox="0 0 ' + w + ' ' + h + '" aria-hidden="true">' + g + '</svg>';
    }
    var put = function (id, html, sub) {
      var b = document.getElementById(id); if (!b) return; var f = b.closest('.fig'), sp = f.querySelector('.v2spark'), sm = f.querySelector('.v2per');
      if (sp) sp.remove();
      if (sub != null) { if (!sm) { sm = document.createElement('small'); sm.className = 'v2per'; b.insertAdjacentElement('afterend', sm); } sm.textContent = sub; }
    };
    var pdf = tot(rD), pc = tot(rC);
    put('nf1', spark(M.map(function (m) { return ncBy[m] || 0; })), null);
    put('nfD', spark(M.map(function (m) { return defBy[m] || 0; })), pdf != null ? S('v2PerMsnV', { v: f2(pdf) }) : null);
    put('nfC', spark(M.map(function (m) { return cBy[m] || 0; })), pc != null ? S('v2PerMsnV', { v: eur(pc) }) : null);
    put('nfR', spark(rN.map(function (x) { return x.e ? x.v / x.e : 0; }), true), null);
  }
  function v2Target(k) {
    var L2 = lignes(); if (!L2) { pWait(k); return; }   // each line: 2026 rate v, 2025 rate b, target t (no 2025 for that line: placeholder ph, 2026 - 25 %)
    var rows = L2.map(function (r) { return Object.assign({}, r); }), anyPh = rows.some(function (r) { return r.ph; });
    if (!rows.length) { pEmpty(k); return; }
    if (rows.length > 1) rows.unshift({ l: S('allLines'), nc: sumA(rows.map(function (r) { return r.nc; })), eq: sumA(rows.map(function (r) { return r.eq; })), all: true });
    var A0 = rows[0] && rows[0].all ? rows[0] : null;
    if (A0) {   // all lines: the sum of the lines' targets (in NCs), never a pooled rate that A320's many small parts would loosen (20 Oct)
      var ln = rows.slice(1), bn = ln.filter(function (r) { return r.b != null; }); A0.stack = ln; A0.v = A0.nc / A0.eq;
      A0.tn = sumA(ln.map(function (r) { return r.t * r.eq; })); A0.t = A0.tn / A0.eq; A0.ph = ln.some(function (r) { return r.ph; });
      if (bn.length) A0.b = sumA(bn.map(function (r) { return r.b * r.eq; })) / sumA(bn.map(function (r) { return r.eq; }));   // 2025 rates at the 2026 mix
    }
    var tipT = function (r) { return r.all ? [gx('perEq', { v: f2(r.v) }), S('v2TgtN', { a: num(r.nc), t: num(Math.round(r.tn)) }), r.b != null ? S('v2Mix', { v: f2(r.b) }) : S('v2Ph'), gx('ncEq', { n: num(r.nc), e: f1(r.eq) })]
      : [gx('perEq', { v: f2(r.v) }), (r.ph ? S('v2TgtPh') : S('v2Tgt')) + ' : ' + f2(r.t), r.b != null ? S('v2Rate25', { v: f2(r.b) }) : S('v2Ph'), gx('ncEq', { n: num(r.nc), e: f1(r.eq) })]; };
    var vbar = function (r, X, x0, yy) {   // a line in its colour; all lines: one segment per line, same colours
      if (r.all && r.stack) { var acc = x0, o = ''; r.stack.forEach(function (s2) { var w = X(s2.nc / r.eq) - X(0);
        o += '<rect x="' + r1(acc) + '" y="' + yy + '" width="' + r1(Math.max(0, w - 1)) + '" height="8" fill="' + lineCol(s2.l) + '"' + pk('line', s2.l) + tip(s2.l, tipT(s2)) + '/>'; acc += w; }); return o; }
      return '<rect x="' + r1(x0) + '" y="' + yy + '" width="' + r1(Math.max(2, X(r.v) - x0)) + '" height="8" rx="4" fill="' + lineCol(r.l) + '"' + (r.l === '—' ? '' : pk('line', r.l)) + tip(r.l, tipT(r)) + '/>'; };
    var tick = function (r) { return '" stroke="var(--ink)" stroke-width="2"' + (r.ph ? ' stroke-dasharray="2 2"' : '') + '/>'; };
    var W0 = gWd(k, 200), stack = W0 < 440, narrow = W0 < 640, lab = stack ? 0 : narrow ? 104 : 112, mr = stack ? 0 : narrow ? 104 : 214, rh = stack ? 44 : 36, H = rows.length * rh + 6, pw = W0 - lab - mr, g = '';
    rows.forEach(function (r, i) {
      var y = i * rh + (stack ? 22 : 8), mx = Math.max(r.v, r.t, r.b || 0) * 1.18 || 1, X = function (v) { return lab + v / mx * pw; }, gap = r.t ? r.v / r.t - 1 : null;   // no gap against a zero target
      var gt = gap == null ? '—' : (gap > 0 ? '+' : '') + pct0(gap * 100), gs = ' style="fill:' + (gap == null ? 'var(--muted)' : gap > 0 ? 'var(--up)' : 'var(--down)') + '"';
      var b25 = r.b != null ? '<circle cx="' + r1(X(r.b)) + '" cy="' + (y + 6) + '" r="3.5" fill="var(--surface)" stroke="var(--muted)" stroke-width="1.6"' + (r.all || r.l === '—' ? '' : pk('line', r.l)) + tip(r.l, tipT(r)) + '/>' : '';   // the 2025 rate
      if (stack) {   // narrow card: line name and figures on a row, the bar under them
        g += tx(0, y - 6, r.l, r.all ? 'ink b' : 'ink') + tx(W0 - 10 - gt.length * 7.5, y - 6, f2(r.v), 'ink b', 'end') + tx(W0 - 2, y - 6, gt, 'b', 'end', gs);
        g += '<rect x="0" y="' + (y + 2) + '" width="' + r1(pw) + '" height="8" rx="4" fill="var(--track)"/>' + vbar(r, X, 0, y + 2) + b25 +
          '<line x1="' + r1(X(r.t)) + '" x2="' + r1(X(r.t)) + '" y1="' + (y - 3) + '" y2="' + (y + 15) + tick(r);
        return;
      }
      g += tx(lab - 12, y + 10, r.l, r.all ? 'ink b' : 'ink', 'end');
      g += '<rect x="' + lab + '" y="' + (y + 2) + '" width="' + r1(pw) + '" height="8" rx="4" fill="var(--track)"/>';
      g += vbar(r, X, lab, y + 2);
      g += b25 + '<line x1="' + r1(X(r.t)) + '" x2="' + r1(X(r.t)) + '" y1="' + (y - 3) + '" y2="' + (y + 15) + tick(r);
      g += tx(lab + pw + 12, y + 10, f2(r.v), 'ink b') + (narrow ? '' : tx(lab + pw + 58, y + 10, S('v2Tgt').toLowerCase() + ' ' + f2(r.t), 'mu')) + tx(W0 - 2, y + 10, gt, 'b', 'end', gs);
    });
    gSet(k, svg(W0, H, g, gT(k)), sw('var(--ink-2)', S('nKR')) + (rows.some(function (r) { return !r.ph; }) ? '<span><i class="ln" style="width:2px;height:12px;background:var(--ink)"></i>' + esc(S('v2TgtR')) + '</span>' : '') +
      (anyPh ? '<span><i class="ln" style="width:0;height:12px;border-left:2px dotted var(--ink)"></i>' + esc(S('v2TgtPh')) + '</span>' : '') +
      (rows.some(function (r) { return r.b != null; }) ? '<span><i class="sw" style="border-radius:50%;background:var(--surface);border:1.6px solid var(--muted)"></i>' + esc(S('v2Rate25s')) + '</span>' : '') + v2UnplannedNote());
  }

  // left of a cumulative chart: 2025 and the year's target as two stacked bars, one colour per line, the part out of the plan grey
  function v2TgtBars(T, Y, x0, bw, fmt, H, key) {
    var g = '', bars = [[PREV, T.lines.map(function (a) { return [a.l, a.v25 + a.n25o + a.x25, a.x25]; })], [S(key), T.lines.map(function (a) { return [a.l, a.year + a.xT, a.xT]; })]];   // by plane type, its NCs out of the plan included (21 Oct)
    bars.forEach(function (b, j) { var x = x0 + j * (bw + 8), acc = 0, tot = sumA(b[1].map(function (s2) { return s2[1]; }));
      b[1].forEach(function (s2) { if (s2[1] <= 0) return; var y1 = Y(acc + s2[1]), y0 = Y(acc), o = s2[0] === 'out';
        g += '<rect x="' + r1(x + (o ? 0.75 : 0)) + '" y="' + r1(y1 + (o ? 0.75 : 0)) + '" width="' + r1(bw - (o ? 1.5 : 0)) + '" height="' + r1(Math.max(0.5, y0 - y1 - 1 - (o ? 1.5 : 0))) + '" fill="' + (o ? 'var(--surface)' : lineCol(s2[0])) + '"' + (o ? ' stroke="var(--muted)" stroke-width="1.5" stroke-dasharray="3 2"' : pk('line', s2[0])) +
          tip(b[0] + ' · ' + (o ? S('vpOutRow') : s2[0]), [fmt(s2[1])].concat(s2[2] > 0.5 ? [S('v2InclOut', { n: fmt(s2[2]) })] : [])) + '/>'; acc += s2[1]; });
      g += tx(x + bw / 2, Y(tot) - 6, fmt(tot), 'ink b', 'middle') + tx(x + bw / 2, H - 6, b[0], 'ink', 'middle'); });
    return g;
  }
  // how the monthly target is spread over the months, in words: by the planned working volume (v2W), when there is a plan
  function v2Light() { return PD ? S('v2MonthW') : ''; }
  function v2LineKeys(T) { return T.lines.map(function (a) { return sw(lineCol(a.l), a.l + (a.ph ? ' (' + S('v2Ph') + ')' : '')); }).join(''); }
  function v2Trend(k) {
    var O = objectif('nc'); if (!O) { pWait(k); return; }
    var S2 = O.S2, all = S2.act.concat(S2.fc); if (!S2.act.length) { pEmpty(k); return; }
    var fcl = fcLeg(S2.fc.map(function (x) { return x.m; }), S2.act.map(function (x) { return x.m; }));
    var R5 = y25Sel(), n25 = R5 ? sumA(R5.map(function (x) { return x.nc; })) : 0, real = n25 > 0;   // without 2025 for the filter: placeholder 2025 = this year
    var T = real ? O.T : null;   // the target line by line (needs the production plan)
    var year = S2.tot + S2.ftot, y25 = real ? n25 : year, tgt = T ? T.year : y25 * V2CUT, c25 = real ? y25Cum(R5, function (x) { return x.nc; }, all.map(function (x) { return x.m; })) : null;
    var wsum = 0, y0 = (all[0] || { m: YEAR }).m.slice(0, 4); for (var mm = 1; mm <= 12; mm++) wsum += v2W(y0 + '-' + (mm < 10 ? '0' : '') + mm);
    var mTgt = T ? T.tm : function (m) { return tgt * v2W(m) / wsum; };
    v2Stats(k, [[num(S2.tot), S('v2StNow')], [num(Math.round(year)), S('v2StFc')], [num(Math.round(tgt)), S(T ? 'v2StTgtL' : real ? 'v2StTgtR' : 'v2StTgt'), !real]]);
    var cum = [0], ct = [0], c = 0, t = 0;
    all.forEach(function (x) { c += x.v; cum.push(c); t += mTgt(x.m); ct.push(t); });
    var W0 = gWd(k, 300), cp = W0 < 560, ml = cp ? 34 : 40, lb = T ? (cp ? 70 : 112) : (cp ? 44 : 70), gap = cp ? 14 : 34, mr = cp ? 54 : 118, mt = 22, mb = 26, H = cp ? 260 : 300, ph = H - mt - mb, x1 = ml + lb + gap, pw = W0 - x1 - mr, n = all.length, na = S2.act.length;
    var nt = pNice(Math.max(y25, year, tgt, 1) * 1.08), g = '';
    function Y(v) { return mt + ph - v / nt.top * ph; } function X(i) { return x1 + i / n * pw; }
    for (var tk = 0; tk <= nt.top + 1e-9; tk += nt.step) g += '<line x1="' + ml + '" x2="' + r1(x1 + pw) + '" y1="' + r1(Y(tk)) + '" y2="' + r1(Y(tk)) + '" stroke="var(--grid)"/>' + tx(ml - 6, Y(tk) + 4, num(tk), 'mu', 'end');
    // 2025 and the year's target, one colour per line; without the production plan, one 2025 bar
    if (T) g += v2TgtBars(T, Y, ml + (cp ? 6 : 10), cp ? 26 : 42, function (v) { return num(Math.round(v)); }, H, 'v2TgtBar');
    else {
    var bx = ml + (cp ? 8 : 14), bwd = lb - (cp ? 16 : 28);
    g += '<rect x="' + bx + '" y="' + r1(Y(y25)) + '" width="' + bwd + '" height="' + r1(mt + ph - Y(y25)) + '" rx="2" fill="' + tint('--ink-2', real ? 30 : 18) + '"' + (real ? '' : ' stroke="var(--ink-2)" stroke-opacity=".5" stroke-dasharray="3 3"') + tip(PREV, [gx('ncCount', { n: num(Math.round(y25)) }), S(real ? 'v2Y25b' : 'v2Ph')]) + '/>' +
      tx(bx + bwd / 2, Y(y25) - 6, num(Math.round(y25)), 'ink b', 'middle') + tx(bx + bwd / 2, H - 6, PREV, 'ink', 'middle');
    }
    all.forEach(function (x, i) { g += tx(X(i + 0.5), H - 6, v2Mo(x.m, pw / n, i), 'mu', 'middle'); });
    // actual, then the forecast
    g += '<path d="M' + r1(X(0)) + ',' + r1(Y(0)) + 'L' + cum.slice(0, na + 1).map(function (v, i) { return r1(X(i)) + ',' + r1(Y(v)); }).join('L') + 'L' + r1(X(na)) + ',' + r1(Y(0)) + 'Z" fill="' + tint('--s1', 10) + '"/>';
    g += '<path d="M' + cum.slice(0, na + 1).map(function (v, i) { return r1(X(i)) + ',' + r1(Y(v)); }).join('L') + '" fill="none" stroke="var(--s1)" stroke-width="2"/>';
    if (n > na) g += '<path d="M' + cum.slice(na).map(function (v, i) { return r1(X(na + i)) + ',' + r1(Y(v)); }).join('L') + '" fill="none" stroke="var(--s1)" stroke-width="2" stroke-dasharray="1 5" stroke-linecap="round"/>';
    // 2025 at the same date, month by month
    if (c25) g += '<path d="M' + c25.map(function (v, i) { return r1(X(i)) + ',' + r1(Y(v)); }).join('L') + '" fill="none" stroke="' + tint('--ink-2', 55) + '" stroke-width="1.5"/>';
    // year-end target, spread month by month (drawn over the shaded area)
    g += '<path d="M' + ct.map(function (v, i) { return r1(X(i)) + ',' + r1(Y(v)); }).join('L') + '" fill="none" stroke="var(--ink)" stroke-width="1.3" stroke-dasharray="5 4"/>';
    // a month not over yet (the data stops mid-month, or the period does) is judged against its target pro-rated to the days gone (3 Nov):
    // 3 days of November against a whole month's target always looked green. Drawn as an open dot.
    var hasCur = false;
    S2.act.forEach(function (x, i) { var sh = monthShare(x.m), mt2 = mTgt(x.m) * sh.p, over = x.v > mt2, col = over ? 'var(--up)' : 'var(--down)'; if (sh.p < 1) hasCur = true;
      g += '<circle cx="' + r1(X(i + 1)) + '" cy="' + r1(Y(cum[i + 1])) + '" r="4.5" fill="' + (sh.p < 1 ? 'var(--surface)' : col) + '" stroke="' + (sh.p < 1 ? col : 'var(--surface)') + '" stroke-width="' + (sh.p < 1 ? 2.2 : 1.8) + '"' +
        pk('month', x.m) + tip(monthName(x.m) + ' ' + x.m.slice(0, 4), [gx('ncCount', { n: num(x.v) }) + ' · ' + (sh.p < 1 ? S('v2CurTip', { d: sh.d, n: sh.n, v: num(Math.round(mt2)) }) : S('v2MonTgt', { v: num(Math.round(mt2)) })), S('v2Cum', { v: num(cum[i + 1]) })].concat(c25 ? [S('v2Y25at', { v: num(Math.round(c25[i] + (c25[i + 1] - c25[i]) * sh.p)) })] : [])) + '/>'; });   // last year's month pro-rated as this one
    if (n > na) g += '<circle cx="' + r1(X(n)) + '" cy="' + r1(Y(year)) + '" r="4" fill="var(--surface)" stroke="var(--s1)" stroke-width="2"' + tip(fcl, [num(Math.round(year))]) + '/>';
    var ly = spread([Y(year) + 4, Y(tgt) + 4], 16, mt + 6, mt + ph);
    g += tx(X(n) + 8, ly[0], num(Math.round(year)) + (cp ? '' : ' ' + S('v2Fc')), 'ink b') + tx(X(n) + 8, ly[1], num(Math.round(tgt)) + (cp ? '' : ' ' + S('v2TgtShort')), 'ink');
    gSet(k, svg(W0, H, g, gT(k)), '<span><i class="sw" style="background:var(--down);border-radius:50%"></i>' + esc(S('v2Under')) + '</span><span><i class="sw" style="background:var(--up);border-radius:50%"></i>' + esc(S('v2Over')) + '</span>' +
      (hasCur ? '<span><i class="sw" style="background:var(--surface);border:2px solid var(--ink-2);border-radius:50%"></i>' + esc(S('v2CurLeg')) + '</span>' : '') +
      swl('var(--s1)', S('v2CumLeg')) + '<span><i class="dash" style="border-top:2px dotted var(--s1)"></i>' + esc(fcl) + '</span>' + swl('var(--ink)', S(T ? 'v2TgtCumL' : real ? 'v2TgtCumR' : 'v2TgtCum'), true) + (T ? v2LineKeys(T) : '') +
      (real ? (T ? '' : '<span><i class="sw" style="background:' + tint('--ink-2', 30) + '"></i>' + esc(S('v2Y25b')) + '</span>') + swl(tint('--ink-2', 55), S('v2Y25c'))
        : '<span><i class="sw" style="background:' + tint('--ink-2', 18) + ';border:1px dashed var(--ink-2)"></i>' + esc(S('v2Ph25')) + '</span>') +
      (real && !GF.fto2 ? '<span class="mu">' + esc(S('v2NoCli25')) + '</span>' : '') + (v2Light() ? '<span class="mu">' + esc(v2Light()) + '</span>' : ''));
  }

  function v2Budget(k) {
    var O = objectif('cost'); if (!O) { pWait(k); return; }
    var S2 = O.S2; if (!S2.act.length) { pEmpty(k); return; }
    var fcl = fcLeg(S2.fc.map(function (x) { return x.m; }), S2.act.map(function (x) { return x.m; }));
    var R5 = y25Sel(), b25 = R5 ? sumA(R5.map(function (x) { return x.cost; })) : 0, real = b25 > 0;   // without 2025 for the filter: placeholder budget = forecast - 25 %
    var T = real ? O.T : null;   // the budget line by line (needs the production plan)
    var all = S2.act.concat(S2.fc), year = S2.tot + S2.ftot, bud = T ? T.year : (real ? b25 : year) * V2CUT, cum = [0], c = 0;
    var c25 = real ? y25Cum(R5, function (x) { return x.cost; }, all.map(function (x) { return x.m; })) : null;
    all.forEach(function (x) { c += x.v; cum.push(c); });
    v2Stats(k, [[kE(S2.tot), S('v2StCost')], [kE(year), S('v2StFc')], [kE(bud), S(T ? 'v2StBudL' : real ? 'v2StBudR' : 'v2StBud'), !real]]);
    var na = S2.act.length, n = all.length, W0 = gWd(k, 300), cp = W0 < 560, ml = cp ? 46 : 52, mr = cp ? 58 : 104, mt = 14, mb = 26, H = cp ? 250 : 280, lb = T ? (cp ? 70 : 112) : 0, gp = T ? (cp ? 14 : 30) : 0, x1 = ml + lb + gp, pw = W0 - x1 - mr, ph = H - mt - mb, nt = pNice(Math.max(year, bud, c25 ? c25[c25.length - 1] : 0) * 1.06), g = '';
    function X(i) { return x1 + i / n * pw; } function Y(v) { return mt + ph - v / nt.top * ph; }
    g += pGridY(ml, x1 - ml + pw, Y, nt, function (v) { return kE(v); });
    if (T) g += v2TgtBars(T, Y, ml + (cp ? 6 : 10), cp ? 26 : 42, kE, H, 'v2BudBar');
    all.forEach(function (x, i) { g += tx(X(i + 0.5), H - 8, v2Mo(x.m, pw / n, i), 'mu', 'middle'); });
    var act = cum.slice(0, na + 1).map(function (v, i) { return r1(X(i)) + ',' + r1(Y(v)); });
    g += '<path d="M' + r1(X(0)) + ',' + r1(Y(0)) + 'L' + act.join('L') + 'L' + r1(X(na)) + ',' + r1(Y(0)) + 'Z" fill="' + tint('--s1', 10) + '"/>';
    if (T) { var cb = [0], ab = 0; all.forEach(function (x) { ab += T.tm(x.m); cb.push(ab); });   // month by month, as the production plan goes
      g += '<path d="M' + cb.map(function (v, i) { return r1(X(i)) + ',' + r1(Y(v)); }).join('L') + '" fill="none" stroke="var(--ink-2)" stroke-width="1.4" stroke-dasharray="5 4"/>'; }
    else g += '<line x1="' + r1(X(0)) + '" y1="' + r1(Y(0)) + '" x2="' + r1(X(n)) + '" y2="' + r1(Y(bud)) + '" stroke="var(--ink-2)" stroke-width="1.4" stroke-dasharray="5 4"/>';
    if (c25) g += '<path d="M' + c25.map(function (v, i) { return r1(X(i)) + ',' + r1(Y(v)); }).join('L') + '" fill="none" stroke="' + tint('--ink-2', 55) + '" stroke-width="1.5"' + tip(PREV, [kE(c25[c25.length - 1])]) + '/>';
    g += '<path d="M' + act.join('L') + '" fill="none" stroke="var(--s1)" stroke-width="1.8"/>';
    if (n > na) g += '<path d="M' + cum.slice(na).map(function (v, i) { return r1(X(na + i)) + ',' + r1(Y(v)); }).join('L') + '" fill="none" stroke="var(--s1)" stroke-width="2.2" stroke-dasharray="1 5" stroke-linecap="round"/>';
    S2.act.forEach(function (x, i) { g += '<rect x="' + r1(X(i)) + '" y="' + mt + '" width="' + r1(pw / n) + '" height="' + ph + '" fill="transparent"' + pk('month', x.m) + tip(monthName(x.m) + ' ' + x.m.slice(0, 4), [eur(x.v), gx('cum') + ' : ' + eur(cum[i + 1])]) + '/>'; });
    g += '<circle cx="' + r1(X(na)) + '" cy="' + r1(Y(cum[na])) + '" r="4.5" fill="var(--s1)" stroke="var(--surface)" stroke-width="2"' + tip(gx('cum'), [eur(cum[na])]) + '/>';
    g += '<circle cx="' + r1(X(n)) + '" cy="' + r1(Y(year)) + '" r="3.5" fill="var(--surface)" stroke="var(--s1)" stroke-width="2"' + tip(gx('proj'), [eur(year)]) + '/>';
    var ly = spread([Y(year) + 4, Y(bud) + 4], 16, mt + 6, mt + ph);
    g += tx(X(n) + 8, ly[0], kE(year), 'ink b') + tx(X(n) + 8, ly[1], kE(bud) + (cp ? '' : ' ' + S(real ? 'v2BudR2' : 'v2Ph')), 'mu') + tx(X(na) - 8, Y(cum[na]) - 10, kE(cum[na]), 'ink b', 'end');
    gSet(k, svg(W0, H, g, gT(k)), swl('var(--s1)', gx('cum')) + '<span><i class="dash" style="border-top:2px dotted var(--s1)"></i>' + esc(fcl) + '</span>' + swl('var(--ink-2)', S(T ? 'v2BudL' : real ? 'v2BudR' : 'v2BudPh'), true) + (T ? v2LineKeys(T) : '') +
      (c25 ? swl(tint('--ink-2', 55), S('v2Y25c')) : '') + (real && !GF.fto2 ? '<span class="mu">' + esc(S('v2NoCli25')) + '</span>' : ''));
  }

  function v2Score(k) {
    var M = v2Months().act, defBy = {};
    D.defects.forEach(function (r) { if (!SEL[r[0]] || !keepMinor(r)) return; var m = NC[r[0]][1].slice(0, 7); defBy[m] = (defBy[m] || 0) + 1; });
    var rate = function (f) { if (!PD) return []; return pMonthly(f).map(function (x) { return { m: PD.months[x.i], r: x.e ? x.v / x.e : null, v: x.v, e: x.e }; }); };
    var defs = [
      ['scNc', function (m) { return SEL_NC.filter(function (n) { return n[1].slice(0, 7) === m; }).length; }, rate(function (o, i) { return o.nc[i]; }), num, f2],
      ['scDef', function (m) { return defBy[m] || 0; }, rate(function (o, i) { return o.def[i]; }), num, f2],
      ['scCost', function (m) { return sumA(SEL_NC.filter(function (n) { return n[1].slice(0, 7) === m; }).map(function (n) { return n[12]; })); }, rate(function (o, i) { return o.cost[i]; }), eurK, eur]
    ];
    function spark(vals, line, col) {
      var w = 170, h = 40, mx = Math.max.apply(null, vals.map(function (v) { return v || 0; }).concat([1e-9])), n = vals.length, g = '';
      if (!n) return '';
      if (line) { var pts = vals.map(function (v, i) { return v == null ? null : r1(4 + i / Math.max(1, n - 1) * (w - 8)) + ',' + r1(h - 4 - v / mx * (h - 10)); }).filter(Boolean); g += '<path d="M' + pts.join('L') + '" fill="none" stroke="' + col + '" stroke-width="2"/>'; var lp = pts[pts.length - 1].split(','); g += '<circle cx="' + lp[0] + '" cy="' + lp[1] + '" r="3" fill="' + col + '"/>'; }
      else vals.forEach(function (v, i) { var bw = (w - 4) / n; g += '<rect x="' + r1(2 + i * bw + bw * 0.12) + '" y="' + r1(h - 2 - v / mx * (h - 6)) + '" width="' + r1(bw * 0.76) + '" height="' + r1(Math.max(0.5, v / mx * (h - 6))) + '" rx="1" fill="' + col + '"/>'; });
      return '<svg class="viz" width="' + w + '" height="' + h + '" viewBox="0 0 ' + w + ' ' + h + '" aria-hidden="true">' + g + '</svg>';
    }
    var h = '<div class="table-wrap"><table class="v2sc"><thead><tr><th scope="col"></th><th scope="col">' + esc(S('scVol')) + '</th><th scope="col" class="r">' + esc(S('scTot')) + '</th><th scope="col">' + esc(S('scRate')) + '</th><th scope="col" class="r">' + esc(S('scRateP')) + '</th><th scope="col" class="r">' + esc(S('scLast3')) + '</th></tr></thead><tbody>';
    defs.forEach(function (d) {
      var vols = M.map(d[1]), rt = d[2], ev = sumA(rt.map(function (x) { return x.e; })), vv = sumA(rt.map(function (x) { return x.v; })), l3 = rt.slice(-3), e3 = sumA(l3.map(function (x) { return x.e; })), v3 = sumA(l3.map(function (x) { return x.v; }));
      var trend = e3 && ev ? v3 / e3 / (vv / ev) - 1 : null;
      h += '<tr><th scope="row">' + esc(S(d[0])) + '</th><td>' + spark(vols, false, 'var(--s1)') + '</td><td class="num r"><b>' + esc(d[3](sumA(vols))) + '</b></td><td>' + spark(rt.map(function (x) { return x.r; }), true, 'var(--ink-2)') + '</td>' +
        '<td class="num r">' + (ev ? esc(d[4](vv / ev)) : '—') + '</td><td class="num r">' + (e3 ? esc(d[4](v3 / e3)) + (trend != null ? ' <small class="' + (trend > 0 ? 'v2u' : 'v2d') + '">' + (trend > 0 ? '+' : '') + esc(pct0(trend * 100)) + '</small>' : '') : '—') + '</td></tr>';
    });
    gSet(k, h + '</tbody></table></div>', '<span class="mu">' + esc(S('scNote')) + '</span>');
  }

  function v2Xmr(k) {
    var cnt = {}; SEL_NC.forEach(function (n) { cnt[n[2]] = (cnt[n[2]] || 0) + 1; });
    var wk = WEEKS.filter(function (w) { var mo = isoDay(isoMonday(w)); return weekEnd(w) >= GF.from && mo <= GF.to && !isPartial(w); });
    if (wk.length < 6) { pEmpty(k); return; }
    // shutdown weeks (their working time under SET.semaine_faible of a normal week, from the blackout days) stay out of the mean and the limits
    var c = wk.map(function (w) { return cnt[w] || 0; }), sh = wk.map(function (w) { return calW(w) < SET.semaine_faible; }), n = c.length, on = c.filter(function (v, j) { return !sh[j]; }), mean = avgOf(on), mr = [];
    if (on.length < 6) { pEmpty(k); return; }
    for (var i = 1; i < on.length; i++) mr.push(Math.abs(on[i] - on[i - 1]));
    // σ (standard deviation) = mean week-to-week jump ÷ 1.128 (d2 for two points); 2 σ = attention, 3 σ = alarm
    var mrb = avgOf(mr), sg = mrb / 1.128, ucl = mean + 3 * sg, lcl = Math.max(0, mean - 3 * sg), u2 = mean + 2 * sg, l2 = Math.max(0, mean - 2 * sg);
    var W0 = gWd(k, 300), ml = 34, mrg = 92, pw = W0 - ml - mrg, h1 = 200, mt = 10, H = mt + h1 + 26, g = '';
    function X(j) { return ml + j / (n - 1) * pw; }
    var top = Math.ceil(Math.max(ucl, Math.max.apply(null, c)) / 5) * 5 || 5; function Y(v) { return mt + h1 - v / top * h1; }
    [0, top / 2, top].forEach(function (t) { g += tx(ml - 6, Y(t) + 4, num(t), 'mu', 'end'); });
    g += '<line x1="' + ml + '" x2="' + (ml + pw) + '" y1="' + r1(Y(0)) + '" y2="' + r1(Y(0)) + '" stroke="var(--grid)"/>';
    var lim = [[ucl, '+3 σ', 3], [u2, '+2 σ', 2], [mean, gx('mean'), 0]].concat(mean - 2 * sg > 0 ? [[l2, '−2 σ', 2]] : []).concat(mean - 3 * sg > 0 ? [[lcl, '−3 σ', 3]] : []);
    var ly = spread(lim.map(function (p) { return Y(p[0]) + 4; }), 13, mt + 4, mt + h1 + 4);
    lim.forEach(function (p, i) {
      g += '<line x1="' + ml + '" x2="' + (ml + pw) + '" y1="' + r1(Y(p[0])) + '" y2="' + r1(Y(p[0])) + '" stroke="' + (p[2] === 3 ? 'var(--up)' : 'var(--ink-2)') + '"' + (p[2] === 3 ? ' stroke-dasharray="5 3"' : p[2] === 2 ? ' stroke-dasharray="1.5 3"' : '') + '/>' +
        tx(ml + pw + 8, ly[i], p[1] + ' ' + f1(p[0]), p[2] === 3 ? 'ink' : 'mu'); });
    g += '<path d="' + c.map(function (v, j) { return sh[j] ? '' : (j && !sh[j - 1] ? 'L' : 'M') + r1(X(j)) + ',' + r1(Y(v)); }).join('') + '" fill="none" stroke="var(--s1)" stroke-width="1.5"/>';
    c.forEach(function (v, j) { var out = !sh[j] && (v > ucl || (mean - 3 * sg > 0 && v < lcl)), warn = !sh[j] && !out && (v > u2 || (mean - 2 * sg > 0 && v < l2)), z = sg ? (v - mean) / sg : 0;
      g += '<circle cx="' + r1(X(j)) + '" cy="' + r1(Y(v)) + '" r="' + (out ? 5 : warn ? 4.5 : 3.5) + '" fill="' + (sh[j] || warn ? 'var(--surface)' : out ? 'var(--up)' : 'var(--s1)') + '" stroke="' + (sh[j] ? 'var(--muted)' : warn ? 'var(--up)' : 'var(--surface)') + '" stroke-width="2"' + pk('week', wk[j]) +
        tip(weekLong(wk[j]), [gx('ncCount', { n: num(v) })].concat(sh[j] ? [gx('shutWk')] : [gx('xZ', { z: (z >= 0 ? '+' : '−') + f1(Math.abs(z)) })])) + '/>'; });
    var part = WEEKS.filter(function (w) { return isPartial(w) && weekEnd(w) >= GF.from && isoDay(isoMonday(w)) <= GF.to; }), pn = sumA(part.map(function (w) { return cnt[w] || 0; }));
    var lastM = '', seen = {}; wk.forEach(function (w, j) { var m = isoDay(isoMonday(w)).slice(0, 7); if (m !== lastM) { lastM = m; g += tx(X(j), H - 6, v2Mo(m, pw * 4.3 / (n - 1), j && Object.keys(seen).length), 'mu', 'start'); seen[m] = 1; } });
    gSet(k, svg(W0, H, g, gT(k)), swl('var(--s1)', gx('xLeg')) + swl('var(--up)', gx('xAl3'), true) + '<span><i class="dash" style="border-top:2px dotted var(--ink-2)"></i>' + esc(gx('xAl2')) + '</span>' + sw('var(--up)', gx('xOut3'), true) +
      '<span><i class="sw" style="background:var(--surface);border:2px solid var(--up);border-radius:50%"></i>' + esc(gx('xIn23')) + '</span>' + (sh.indexOf(true) >= 0 ? '<span><i class="sw" style="background:var(--surface);border:1.5px solid var(--muted);border-radius:50%"></i>' + esc(gx('shutWk')) + '</span>' : '') + (pn ? '<span class="mu">' + esc(S('xPartial', { n: num(pn) })) + '</span>' : ''));
  }

  function v2Defs() { return D.defects.filter(function (r) { return SEL[r[0]] && keepMinor(r); }); }
  function v2Waffle(k) {
    var ds = v2Defs(), W0 = gWd(k), cnt = {}, tot = ds.length; if (!tot) { pEmpty(k); return; }
    ds.forEach(function (r) { var c = catKey(dCat(r)); cnt[c] = (cnt[c] || 0) + 1; });
    var keys = MAIN_CATS.filter(function (c) { return cnt[c]; }), raw = keys.map(function (c) { return cnt[c] / tot * 100; }), cells = raw.map(Math.floor), left = 100 - sumA(cells);
    raw.map(function (v, i) { return [v - Math.floor(v), i]; }).sort(function (a, b) { return b[0] - a[0]; }).slice(0, left).forEach(function (p) { cells[p[1]]++; });
    var cs = 24, gp = 3, side = W0 >= 470, g = '', idx = 0;
    keys.forEach(function (c, i) { for (var j = 0; j < cells[i]; j++, idx++) { var col = idx % 10, row = Math.floor(idx / 10);
      g += '<rect x="' + col * (cs + gp) + '" y="' + row * (cs + gp) + '" width="' + cs + '" height="' + cs + '" rx="3" fill="' + catFill(c) + '"' + (c !== 'aside' ? pk('cat', c) : '') + tip(catLabel(c), [pct(raw[i]) + ' · ' + gx('defN', { n: num(cnt[c]) })]) + '/>'; } });
    var gw = 10 * (cs + gp);
    if (side) keys.forEach(function (c, i) { var y = 16 + i * 28; g += '<rect x="' + (gw + 26) + '" y="' + (y - 11) + '" width="12" height="12" rx="3" fill="' + catFill(c) + '"/>' + tx(gw + 46, y, catLabel(c), 'ink') + tx(Math.min(W0 - 4, gw + 380), y, pct0(raw[i]), 'ink b', 'end'); });
    gSet(k, svg(side ? Math.min(W0, gw + 384) : gw, Math.max(gw, side ? keys.length * 28 + 8 : 0), g, gT(k)), side ? '' : keys.map(function (c, i) { return sw(catFill(c), catLabel(c) + ' · ' + pct0(raw[i])); }).join(''));
  }

  // the lines of the causes 2025 against 2026: the filter bar's line, A330 + A350 with all lines (A320's small parts counted one by
  // one would pull the rate down); the card's switch (A330 + A350, A330, A350) wins while it is set, until the filter's line changes
  var VQL = null;   // { v: '' (A330 + A350) or a line, at: the filter's line when it was pressed }
  function vqLines() { var v = VQL && VQL.at === GF.line ? VQL.v : GF.line; return { v: v, lab: v || S('vqBoth') }; }
  function vqSeg(Q) { return '<div class="seg grpseg" role="group" aria-label="' + esc(S('vqSegL')) + '">' + [['', 'A330 + A350'], ['A330', 'A330'], ['A350', 'A350']].map(function (x) { return '<button type="button" data-vql="' + x[0] + '" aria-pressed="' + (Q.v === x[0]) + '">' + x[1] + '</button>'; }).join('') + '</div>'; }
  document.addEventListener('click', function (e) { var b = e.target.closest && e.target.closest('[data-vql]'); if (!b) return; VQL = { v: b.getAttribute('data-vql'), at: GF.line }; v2Render(); });
  GDYN.VQ = function () { var L2 = vqLines().lab; return GSTR.VQ[G.lang].map(function (t) { return t.split('{L}').join(L2); }); };
  // the page's numbers for another line of the filter bar, the time of fn (the filters, the selection and the production come back after)
  function withLine(l, fn) {
    if (l === GF.line) return fn();
    var l0 = GF.line, P0 = PD, A0 = PA; GF.line = l; select(); PD = pSrc() ? pData() : null; PA = PD ? pAgg(PD) : null;
    try { return fn(); } finally { GF.line = l0; select(); PD = P0; PA = A0; }
  }
  function v2Quarters(k) { var Q = vqLines(); withLine(Q.v, function () { vqDraw(k, Q); }); var b = gB(k); if (b) b.insertAdjacentHTML('afterbegin', vqSeg(Q)); }
  function vqDraw(k, Q) {   // 2025 against 2026, per MSN (21 Oct). One row per cause (the slope chart
    // hid the causes that fell and crowded its labels): the top 10 causes of either year, hollow dot 2025, filled dot 2026, the arrow between
    var on = function (l) { return Q.v ? l === Q.v : !!CONN_LINES[l]; }, keep = function (p) { return on(PD.line[p]); };
    var R = y25Rca(), e26 = PD && PA ? sumA(P_().filter(function (o) { return o.EQ > 0 && on(o.line); }).map(function (o) { return o.EQ; })) : 0; if (!R || !e26) { pEmpty(k); return; }
    var a = {}, b = {}, tot = {}, all = {};
    PD.defs.forEach(function (d) { if (keep(PD.ncs[d.n].p) && PA[PD.ncs[d.n].p].EQ > 0) tot[d.rca] = (tot[d.rca] || 0) + 1; });
    Object.keys(tot).forEach(function (c) { all[c] = 1; }); R.forEach(function (x) { if (x.rca) all[x.rca] = 1; });
    Object.keys(all).forEach(function (c) { var q = y25Rate(R.filter(function (x) { return x.rca === c; }), function (x) { return x.d; }, keep); a[c] = q ? q.r : 0; b[c] = (tot[c] || 0) / e26; });
    var by = function (o) { return Object.keys(all).sort(function (x, y) { return o[y] - o[x]; }).slice(0, 10); }, pick = {};
    by(a).concat(by(b)).forEach(function (c) { if (a[c] || b[c]) pick[c] = 1; });
    var top = Object.keys(pick).sort(function (x, y) { return Math.max(b[y], a[y]) - Math.max(b[x], a[x]); }), mx = 1e-9;
    top.forEach(function (r) { mx = Math.max(mx, a[r], b[r]); });
    if (VQV !== 'd' && VQR[VQV]) { VQR[VQV](k, top, a, b, mx); return; }
    var W0 = gWd(k), lab = Math.min(210, Math.round(W0 * 0.36)), vw = 128, pw = Math.max(80, W0 - lab - vw - 16), rh = 30, mt = 8, H = mt + top.length * rh + 26, g = '';
    var step = mx > 4 ? 1 : mx > 2 ? 0.5 : mx > 0.8 ? 0.25 : 0.1, xmax = Math.ceil(mx / step) * step;
    function X(v) { return lab + v / xmax * pw; }
    for (var t = 0; t <= xmax + 1e-9; t += step) g += '<line x1="' + r1(X(t)) + '" x2="' + r1(X(t)) + '" y1="' + mt + '" y2="' + (H - 22) + '" stroke="var(--grid)"/>' + tx(X(t), H - 6, f2(t), 'mu', 'middle');
    top.forEach(function (r, i) {
      var va = a[r] || 0, vb = b[r] || 0, y = mt + i * rh + rh / 2, dir = vb > va * 1.1 ? 1 : vb < va * 0.9 ? -1 : 0, ck = RCA_CAT[r], col = ck === 'aside' || !ck ? 'var(--ink-2)' : catFill(ck);
      var ac = dir > 0 ? 'var(--up)' : dir < 0 ? 'var(--down)' : 'var(--ink-2)', x1 = X(va), x2 = X(vb), nm = L(r), mc = Math.floor((lab - 12) / 6.6);
      if (nm.length > mc) nm = nm.slice(0, mc - 1) + '…';
      var d = vb - va, pc = va > 0 ? Math.round(d / va * 100) : null;
      g += '<g' + pk('rca', r) + tip(L(r), [gx('vq25', { v: f2(va) }), gx('vq26', { v: f2(vb) }), (d >= 0 ? '+' : '') + f2(d) + (pc != null ? ' (' + (pc >= 0 ? '+' : '') + pc + ' %)' : ''), catLabel(ck || 'aside')]) + '>';
      g += '<rect x="0" y="' + r1(y - rh / 2) + '" width="' + W0 + '" height="' + rh + '" fill="transparent"/>' + tx(lab - 10, y + 4, nm, 'ink', 'end');
      if (Math.abs(x2 - x1) > 9) {   // the arrow from 2025 to 2026, its head on the 2026 dot
        var hx = x2 - (x2 > x1 ? 7 : -7);
        g += '<line x1="' + r1(x1) + '" x2="' + r1(hx) + '" y1="' + y + '" y2="' + y + '" stroke="' + ac + '" stroke-width="2.5"/>' +
          '<path d="M' + r1(hx) + ',' + (y - 5) + 'L' + r1(x2 - (x2 > x1 ? 1 : -1)) + ',' + y + 'L' + r1(hx) + ',' + (y + 5) + 'Z" fill="' + ac + '"/>';
      }
      g += '<circle cx="' + r1(x1) + '" cy="' + y + '" r="4.5" fill="var(--surface)" stroke="var(--ink-2)" stroke-width="1.6"/>';
      g += '<circle cx="' + r1(x2) + '" cy="' + y + '" r="5.5" fill="' + col + '" stroke="var(--surface)" stroke-width="1.5"/>';
      g += tx(lab + pw + 14, y + 4, f2(va) + ' → ' + f2(vb), 'mu') + (dir ? tx(W0 - 2, y + 4, (dir > 0 ? '▲' : '▼'), 'b', 'end', ' style="fill:' + ac + '"') : tx(W0 - 2, y + 4, '=', 'mu', 'end'));
      g += '</g>';
    });
    var cin = {}; top.forEach(function (r) { cin[RCA_CAT[r] || 'aside'] = 1; });
    gSet(k, svg(W0, H, g, gT(k)), '<span><i class="sw" style="background:var(--surface);border:1.6px solid var(--ink-2);border-radius:50%"></i>' + PREV + '</span>' +
      MAIN_CATS.filter(function (c) { return cin[c]; }).map(function (c) { return sw(c === 'aside' ? 'var(--ink-2)' : catFill(c), YEAR + ' · ' + catLabel(c), true); }).join('') +
      '<span><b style="color:var(--up)">▲</b> ' + esc(gx('vqUp')) + '</span><span><b style="color:var(--down)">▼</b> ' + esc(gx('vqDown')) + '</span><span>= ' + esc(gx('vqFlat')) + '</span><span class="mu">' + esc(S('v2Q25')) + '</span>');
  }

  // five ways to draw causes 2025 vs 2026; 'a', the slope chart, is the one shown
  var VQV = (window.FTO2_PREVIEW && window.FTO2_PREVIEW.vq) || 'a';
  function vqDir(va, vb) { return vb > va * 1.1 ? 1 : vb < va * 0.9 ? -1 : 0; }
  function vqCol(r) { var ck = RCA_CAT[r]; return ck === 'aside' || !ck ? 'var(--ink-2)' : catFill(ck); }
  function vqTip(r, va, vb) { var d = vb - va, pc = va > 0 ? Math.round(d / va * 100) : null; return tip(L(r), [gx('vq25', { v: f2(va) }), gx('vq26', { v: f2(vb) }), (d >= 0 ? '+' : '') + f2(d) + (pc != null ? ' (' + (pc >= 0 ? '+' : '') + pc + ' %)' : '')]); }
  function vqArrow(dir, x, y, anchor) { return dir ? tx(x, y, dir > 0 ? '▲' : '▼', 'b', anchor || null, ' style="fill:var(--' + (dir > 0 ? 'up' : 'down') + ')"') : tx(x, y, '=', 'mu', anchor || null); }
  function vqKey() { return '<span><b style="color:var(--up)">▲</b> ' + esc(gx('vqUp')) + '</span><span><b style="color:var(--down)">▼</b> ' + esc(gx('vqDown')) + '</span><span>= ' + esc(gx('vqFlat')) + '</span>'; }
  var VQR = {
    a: function (k, top, a, b, mx) {   // the slope chart, taller, labels pushed apart, arrows on both sides of a drop
      var W0 = gWd(k), H = Math.max(360, top.length * 30 + 50), mt = 30, ph = H - mt - 14, xa = Math.min(250, W0 * 0.46), xb = W0 - 96, g = '';
      function Y(v) { return mt + ph - v / mx * ph; }
      g += tx(xa, 14, PREV, 'ink b', 'middle') + tx(xb, 14, YEAR, 'ink b', 'middle') + '<line x1="' + xa + '" x2="' + xa + '" y1="' + mt + '" y2="' + (mt + ph) + '" stroke="var(--grid)"/><line x1="' + xb + '" x2="' + xb + '" y1="' + mt + '" y2="' + (mt + ph) + '" stroke="var(--grid)"/>';
      var la = spread(top.map(function (r) { return Y(a[r]) + 4; }), 17, mt, mt + ph + 4), lb = spread(top.map(function (r) { return Y(b[r]) + 4; }), 17, mt, mt + ph + 4);
      top.forEach(function (r, i) { var va = a[r], vb = b[r], dir = vqDir(va, vb), col = vqCol(r), nm = L(r), mc = Math.floor((xa - 52) / 6.4); if (nm.length > mc) nm = nm.slice(0, mc - 1) + '…';
        g += '<line x1="' + xa + '" y1="' + r1(Y(va)) + '" x2="' + xb + '" y2="' + r1(Y(vb)) + '" stroke="' + col + '" stroke-width="2.2"' + pk('rca', r) + vqTip(r, va, vb) + '/>' + '<circle cx="' + xa + '" cy="' + r1(Y(va)) + '" r="3.5" fill="' + col + '"/><circle cx="' + xb + '" cy="' + r1(Y(vb)) + '" r="3.5" fill="' + col + '"/>';
        g += '<line x1="' + (xa - 8) + '" x2="' + xa + '" y1="' + r1(la[i] - 4) + '" y2="' + r1(Y(va)) + '" stroke="var(--grid)"/><line x1="' + xb + '" x2="' + (xb + 8) + '" y1="' + r1(Y(vb)) + '" y2="' + r1(lb[i] - 4) + '" stroke="var(--grid)"/>';
        g += tx(xa - 12, la[i], nm + '  ' + f2(va), 'ink', 'end') + tx(xb + 12, lb[i], f2(vb), 'ink') + vqArrow(dir, xb + 52, lb[i]); });
      gSet(k, svg(W0, H, g, gT(k)), vqKey());
    },
    b: function (k, top, a, b, mx) {   // two bars per cause: 2025 grey, 2026 in the category colour
      var W0 = gWd(k), lab = Math.min(200, Math.round(W0 * 0.34)), vw = 70, pw = W0 - lab - vw, rh = 34, H = top.length * rh + 8, g = '';
      top.forEach(function (r, i) { var y = i * rh + 4, va = a[r], vb = b[r], nm = L(r), mc = Math.floor((lab - 12) / 6.6); if (nm.length > mc) nm = nm.slice(0, mc - 1) + '…';
        g += '<g' + pk('rca', r) + vqTip(r, va, vb) + '><rect x="0" y="' + y + '" width="' + W0 + '" height="' + rh + '" fill="transparent"/>' + tx(lab - 10, y + 17, nm, 'ink', 'end') +
          '<rect x="' + lab + '" y="' + (y + 4) + '" width="' + r1(Math.max(1, va / mx * pw)) + '" height="10" rx="2" fill="var(--dim)"/><rect x="' + lab + '" y="' + (y + 16) + '" width="' + r1(Math.max(1, vb / mx * pw)) + '" height="10" rx="2" fill="' + vqCol(r) + '"/>' +
          tx(lab + va / mx * pw + 6, y + 13, f2(va), 'mu', null, ' style="font-size:11px"') + tx(lab + vb / mx * pw + 6, y + 25, f2(vb), 'ink', null, ' style="font-size:11px"') + vqArrow(vqDir(va, vb), W0 - 2, y + 21, 'end') + '</g>'; });
      gSet(k, svg(W0, H, g, gT(k)), sw('var(--dim)', PREV) + '<span>' + esc(YEAR + ' : ' + gx('vqCat')) + '</span>' + vqKey());
    },
    c: function (k, top, a, b) {   // the change only, sorted: up to the right in red, down to the left in green
      var rows = top.map(function (r) { return { r: r, d: b[r] - a[r] }; }).sort(function (x, y) { return y.d - x.d; }), mx = Math.max.apply(null, rows.map(function (x) { return Math.abs(x.d); }).concat([1e-9]));
      var W0 = gWd(k), lab = Math.min(200, Math.round(W0 * 0.34)), pw = W0 - lab - 10, zero = lab + pw / 2, half = pw / 2 - 56, rh = 26, H = rows.length * rh + 26, g = '';
      g += '<line x1="' + r1(zero) + '" x2="' + r1(zero) + '" y1="0" y2="' + (H - 20) + '" stroke="var(--ink-2)"/>' + tx(zero, H - 4, gx('vqChg'), 'mu', 'middle');
      rows.forEach(function (x, i) { var y = i * rh, w = x.d / mx * half, dir = vqDir(a[x.r], b[x.r]), col = dir > 0 ? 'var(--up)' : dir < 0 ? 'var(--down)' : 'var(--dim)', nm = L(x.r), mc = Math.floor((lab - 12) / 6.6); if (nm.length > mc) nm = nm.slice(0, mc - 1) + '…';
        g += '<g' + pk('rca', x.r) + vqTip(x.r, a[x.r], b[x.r]) + '><rect x="0" y="' + y + '" width="' + W0 + '" height="' + rh + '" fill="transparent"/>' + tx(lab - 10, y + 16, nm, 'ink', 'end') +
          '<rect x="' + r1(w >= 0 ? zero : zero + w) + '" y="' + (y + 6) + '" width="' + r1(Math.max(1.5, Math.abs(w))) + '" height="13" rx="2" fill="' + col + '"/>' +
          tx(w >= 0 ? zero + w + 6 : zero + w - 6, y + 16, (x.d >= 0 ? '+' : '') + f2(x.d), 'ink', w >= 0 ? null : 'end') + '</g>'; });
      gSet(k, svg(W0, H, g, gT(k)), swl('var(--up)', gx('vqUp')) + swl('var(--down)', gx('vqDown')) + swl('var(--dim)', gx('vqFlat')));
    },
    e: function (k, top, a, b) {   // a table: 2025, 2026, change
      var rows = top.map(function (r) { return { r: r, a: a[r], b: b[r], d: b[r] - a[r] }; });
      var h = '<div class="table-wrap"><table class="mini vqt"><thead><tr><th scope="col">' + esc(gx('vqCause')) + '</th><th scope="col" class="r">' + PREV + '</th><th scope="col" class="r">' + YEAR + '</th><th scope="col" class="r">' + esc(gx('vqChg')) + '</th><th scope="col"></th></tr></thead><tbody>' +
        rows.map(function (x) { var dir = vqDir(x.a, x.b), pc = x.a > 0 ? Math.round(x.d / x.a * 100) : null;
          return '<tr' + pk('rca', x.r) + '><td><i class="sw" style="display:inline-block;width:9px;height:9px;border-radius:2px;margin-right:6px;background:' + vqCol(x.r) + '"></i>' + esc(L(x.r)) + '</td><td class="num r">' + f2(x.a) + '</td><td class="num r"><b>' + f2(x.b) + '</b></td><td class="num r">' + (x.d >= 0 ? '+' : '') + f2(x.d) + (pc != null ? ' (' + (pc >= 0 ? '+' : '') + pc + ' %)' : '') + '</td><td style="color:var(--' + (dir > 0 ? 'up' : dir < 0 ? 'down' : 'muted') + ')">' + (dir > 0 ? '▲' : dir < 0 ? '▼' : '=') + '</td></tr>'; }).join('') + '</tbody></table></div>';
      gSet(k, h, vqKey());
    }
  };

  // top chart of Où: NC, defects and cost done + forecast to December (default), or per MSN
  var V2PM = 'fc';
  function v2ProdMode(k) {
    var h = V2BAND[k] && V2BAND[k].querySelector('.bhead'); if (!h) return;
    var t = h.querySelector('.v2tog');
    if (!t) { t = document.createElement('div'); t.className = 'seg v2tog'; t.setAttribute('role', 'group'); h.appendChild(t);
      t.addEventListener('click', function (e) { var x = e.target.closest('[data-vpm]'); if (x) { V2PM = x.getAttribute('data-vpm'); v2Render(); } }); }
    t.innerHTML = segHtml([['fc', S('vpFc')], ['msn', S('vpMsn')]], V2PM, 'data-vpm');
    if (V2PM === 'fc') { h.querySelector('.kicker').textContent = S('vpFcK'); h.querySelector('h3').textContent = S('vpFcT'); h.querySelector('.sub').textContent = S('vpFcS'); }
  }
  function v2Unplanned() {
    var E = pSrc(), map = (E && E.map) || {}, ids0 = {}, top = {}, o = { n: 0, d: 0, c: 0, top: [] };
    o.by = {};   // per plane type: {n, d, c} (21 Oct)
    o.list = [];
    SEL_NC.forEach(function (n) { if (PA ? v2InPlan(n) : map[String(n[26] || '').toUpperCase()]) return; ids0[n[0]] = 1; o.n++; o.c += n[12]; o.list.push(n); var p = n[3] || '—'; top[p] = (top[p] || 0) + 1;
      var b = o.by[p] || (o.by[p] = { n: 0, d: 0, c: 0 }); b.n++; b.c += n[12]; });   // by plane type (21 Oct)
    v2Defs().forEach(function (r) { if (ids0[r[0]]) { o.d++; o.by[NC[r[0]][3] || '—'].d++; } });
    o.top = Object.keys(top).sort(function (a, b) { return top[b] - top[a]; }).map(function (p) { return p + ' ' + num(top[p]); });
    return o;
  }
  function v2UnplannedNote() {   // counted in every total, shown as no row of their own: a note that opens their list
    var u = v2Unplanned(); if (!u.n) return '';
    return '<details class="vdata vnote"><summary>' + esc(S('vpOut', { n: num(u.n) })) + '</summary><div class="table-wrap"><table class="mini"><tbody>' +
      u.list.slice().sort(function (a, b) { return a[1] < b[1] ? 1 : -1; }).map(function (n) { return '<tr><td class="nc"' + pk('nc', n[0]) + '>' + esc(n[0]) + '</td><td class="num">' + esc(shortDay(n[1])) + '</td><td>' + esc(n[3]) + '</td><td>' + esc(prodName(n[26])) + '</td><td>' + esc(n[22]) + '</td></tr>'; }).join('') +
      '</tbody></table></div></details>';
  }
  function v2ProdFc(k) {
    var cnt = function (v) { return num(Math.round(v)); }, ms = [['scNc', function (o) { return o.NC; }, cnt, 70], ['scDef', function (o) { return o.DEF; }, cnt, 78], ['scCost', function (o) { return o.COST; }, kE, 96]];
    var os = pOk().filter(function (o) { return o.NC || (o.FC && !GF.pick); }).map(function (o) { var r = o.FC / o.EQ; return { o: o, v: ms.map(function (m) { var a = m[1](o); return [a, a * r]; }) }; })
      .sort(function (x, y) { return (y.v[0][0] + y.v[0][1]) - (x.v[0][0] + x.v[0][1]); });   // forecast = the period's value per MSN × the MSN planned to December
    if (!os.length) { pEmpty(k); return; }
    var W0 = gWd(k, 520), lab = 108, gapC = 22, cw = (W0 - lab - gapC * 2) / 3, rh = 26, top = 34, H = top + os.length * rh + 6, g = '';
    ms.forEach(function (m, j) {
      var x0 = lab + j * (cw + gapC), bw = cw - m[3], mx = Math.max.apply(null, os.map(function (r) { return r.v[j][0] + r.v[j][1]; }).concat([1e-9]));
      g += tx(x0, 14, S(m[0]), 'ink b') + tx(x0, 28, S('vpFcH'), 'mu', null, ' style="font-size:10.5px"');
      os.forEach(function (r, i) {
        var y = top + i * rh, a = r.v[j][0], f = r.v[j][1], c = lineCol(r.o.line), wa = a / mx * bw, wf = f / mx * bw, tp = tip(r.o.p + ' · ' + S(m[0]), [gx('actLeg') + ' : ' + m[2](a), S('vpDec') + ' : ' + m[2](a + f), gx('eqTip', { v: f1(r.o.FC) })]);
        g += '<rect x="' + r1(x0) + '" y="' + (y + 5) + '" width="' + r1(Math.max(1.5, wa)) + '" height="14" rx="2" fill="' + c + '"' + tp + '/>';
        if (wf > 0.5) g += '<rect x="' + r1(x0 + wa) + '" y="' + (y + 5) + '" width="' + r1(wf) + '" height="14" rx="2" fill="' + c + '" fill-opacity=".28" stroke="' + c + '" stroke-dasharray="3 2"' + tp + '/>';
        g += tx(x0 + wa + wf + 6, y + 16, m[2](a) + ' → ' + m[2](a + f), 'ink');
      });
    });
    os.forEach(function (r, i) { g += tx(lab - 10, top + i * rh + 16, r.o.p, 'ink', 'end'); });
    // two more rows so the columns add up to the selection: the NCs out of the production plan (done only), then the total
    var kf = horsPlanK(); if (kf == null) { pWait(k); return; }
    var u = v2Unplanned(), uv = [u.n, u.d, u.c], uf = uv.map(function (v) { return v * kf; });   // out of plan: its own monthly pace (v2Fc)
    var ul = lineOrder(Object.keys(u.by)), yU = top + os.length * rh, yT = yU + ul.length * rh + 6;   // one row per plane type (21 Oct)
    yT = yU + 6;   // no row of their own: they are in the total and listed under the chart
    g += '<line x1="0" x2="' + W0 + '" y1="' + (yT - 2) + '" y2="' + (yT - 2) + '" stroke="var(--grid)"/>' + tx(lab - 10, yT + 16, S('total'), 'ink b', 'end');
    ms.forEach(function (m, j) { var x0 = lab + j * (cw + gapC), a = sumA(os.map(function (r) { return r.v[j][0]; })) + uv[j], f = sumA(os.map(function (r) { return r.v[j][1]; })) + uf[j];
      g += tx(x0, yT + 16, m[2](a) + ' → ' + m[2](a + f), 'ink b'); });
    H = yT + rh + 4;
    gSet(k, svg(W0, H, g, S('vpFcT')), sw('var(--ink-2)', gx('actLeg')) + '<span><i class="sw" style="background:none;border:1.2px dashed var(--ink-2)"></i>' + esc(S('vpDec')) + '</span>' + v2UnplannedNote());
  }
  function v2Prod(k) {
    v2ProdMode(k); if (V2PM === 'fc') { v2ProdFc(k); return; }
    var os = pOk().slice().sort(function (a, b) { return b.NC / b.EQ - a.NC / a.EQ; }); if (!os.length) { pEmpty(k); return; }
    var ms = [['scNc', function (o) { return o.NC / o.EQ; }, f2, pTot(function (o) { return o.NC; })], ['scDef', function (o) { return o.DEF / o.EQ; }, f2, pTot(function (o) { return o.DEF; })], ['scCost', function (o) { return o.COST / o.EQ; }, function (v) { return eur(v); }, pTot(function (o) { return o.COST; })]];
    var E0 = pTot(function (o) { return o.EQ; }), W0 = gWd(k, 520), lab = 108, gapC = 22, cw = (W0 - lab - gapC * 2) / 3, rh = 26, top = 44, H = top + os.length * rh + 6, g = '';
    ms.forEach(function (m, j) {
      var x0 = lab + j * (cw + gapC), vals = os.map(m[1]), ref = E0 ? m[3] / E0 : 0, mx = Math.max.apply(null, vals.concat([ref, 1e-9])) * 1.02, bw = cw - 64;
      g += tx(x0, 14, S(m[0]) + ' ' + S('v2PerMsn'), 'ink b') + '<line x1="' + r1(x0 + ref / mx * bw) + '" x2="' + r1(x0 + ref / mx * bw) + '" y1="' + (top - 6) + '" y2="' + (H - 2) + '" stroke="var(--ink-2)" stroke-dasharray="3 3"/>' + tx(x0 + ref / mx * bw, top - 12, gx('overall', { v: m[2](ref) }), 'mu', 'middle', ' style="font-size:10.5px"');
      os.forEach(function (o, i) { var y = top + i * rh, v = vals[i], w = v / mx * bw;
        g += '<rect x="' + r1(x0) + '" y="' + (y + 5) + '" width="' + r1(Math.max(1.5, w)) + '" height="14" rx="2" fill="' + lineCol(o.line) + '"' + ppk('pprod', o.p) + tip(o.p + ' · ' + S(m[0]), [m[2](v) + ' ' + S('v2PerMsn'), gx('ncEq', { n: num(Math.round(j === 0 ? o.NC : j === 1 ? o.DEF : o.COST)), e: f1(o.EQ) })]) + '/>' + tx(x0 + w + 5, y + 16, m[2](v), 'ink', null, ' style="font-size:11.5px"'); });
    });
    os.forEach(function (o, i) { g += tx(lab - 10, top + i * rh + 16, o.p, 'ink', 'end'); });
    gSet(k, svg(W0, H, g, gT(k)), v2UnplannedNote());
  }

  function v2Fins(k) {
    var l = GF.line || 'A350', ms = {}, has = {}, fc = {};
    SEL_NC.forEach(function (n) { if (n[3] === l && n[25]) ms[n[25]] = 1; });
    var msn = Object.keys(ms).sort(function (a, b) { return (parseInt(a, 10) || 0) - (parseInt(b, 10) || 0); }), n0 = msn.length;
    v2Defs().forEach(function (r) { var n = NC[r[0]], f = finReal(r); if (!f || n[3] !== l || !n[25]) return; var key = f + '|' + n[25]; if (!has[key]) { has[key] = 0; fc[f] = (fc[f] || 0) + 1; } has[key]++; });
    var fins = Object.keys(fc).filter(function (f) { return fc[f] >= 2; }).sort(function (a, b) { return fc[b] - fc[a] || (a < b ? -1 : 1); }).slice(0, 10);
    if (!fins.length || n0 < 2) { pEmpty(k); return; }
    var W0 = gWd(k), lab = 92, mr = 78, cw = Math.max(2, (W0 - lab - mr) / n0), rh = 17, H = fins.length * rh + 26, g = '';
    fins.forEach(function (f, i) {
      var y = i * rh;
      g += '<rect x="0" y="' + y + '" width="' + W0 + '" height="' + rh + '" fill="transparent"' + pk('fin', f) + tip(f, [gx('finCount', { n: num(fc[f]) })]) + '/>';   // the whole row filters the FIN (20 Oct: only the small squares did)
      g += tx(lab - 8, y + 12, f, 'ink', 'end', ' pointer-events="none"') + '<line x1="' + lab + '" x2="' + r1(lab + n0 * cw) + '" y1="' + (y + 8) + '" y2="' + (y + 8) + '" stroke="var(--grid)" pointer-events="none"/>';
      msn.forEach(function (m, j) { var v = has[f + '|' + m]; if (v) g += '<rect x="' + r1(lab + j * cw + 0.4) + '" y="' + (y + 2) + '" width="' + r1(Math.max(1.6, cw - 0.8)) + '" height="12" fill="' + (v > 1 ? 'var(--seq)' : tint('--seq', 55)) + '"' + pk('finmsn', f + '§' + m) + tip(gx('finTip', { f: f, m: m }), [gx('defN', { n: num(v) })]) + '/>'; });
      g += tx(lab + n0 * cw + 8, y + 12, gx('finCount', { n: num(fc[f]) }), 'mu', null, ' pointer-events="none"');
    });
    g += tx(lab, H - 4, l + ' · MSN ' + msn[0], 'mu') + tx(lab + n0 * cw, H - 4, 'MSN ' + msn[n0 - 1] + ' · ' + S('v2Ac', { n: num(n0) }), 'mu', 'end');
    gSet(k, svg(W0, H, g, gT(k)), sw(tint('--seq', 55), gx('one')) + sw('var(--seq)', gx('twoPlus')));
  }

  // swapped wires, pin by pin (from the vision prototype): the two pins read in the defect's
  // text ("... ENTRE LES BORNES 41 ET 42"; 1 to 3 characters, never a plug name such as 9KSJ26), per connector (FIN), one arc per pair
  var PIN_RE = [/(?:BORNES?|PINS?|CONTACTS?|BROCHES?)\s*[<«"]?\s*([A-Z]{1,2}\d?|\d{1,3}[A-Z]?)\s*[>»"]?\s*(?:ET\s+(?:LA\s+)?BORNE|ET|\/|&|-|AND)\s*[<«"]?\s*([A-Z]{1,2}\d?|\d{1,3}[A-Z]?)(?![A-Z0-9])/i,
    /INVERS\w*[^.]*?ENTRE\s*[<«"]?\s*([A-Z]{1,2}\d?|\d{1,3}[A-Z]?)\s*[>»"]?\s+ET\s*[<«"]?\s*([A-Z]{1,2}\d?|\d{1,3}[A-Z]?)(?![A-Z0-9])/i];
  function pinKey(a, b) { var na = /^\d+$/.test(a), nb = /^\d+$/.test(b); if (na && nb) return +a - +b; if (na !== nb) return na ? -1 : 1; return a.length - b.length || (a < b ? -1 : a > b ? 1 : 0); }
  function pinPair(t) {
    if (!t) return null;
    for (var i = 0; i < PIN_RE.length; i++) { var m = PIN_RE[i].exec(String(t)); if (m) { var a = m[1].toUpperCase(), b = m[2].toUpperCase(); if (a !== b) return [a, b].sort(pinKey); } }
    return null;
  }
  function pinNext(a, b) {   // two pins that follow each other in the connector's numbering: 7 and 8, S and T, KK and LL, B1 and C1
    if (/^\d+$/.test(a) && /^\d+$/.test(b)) return Math.abs(+a - +b) === 1;
    var dbl = function (p) { return /^[A-Z]+$/.test(p) && p === new Array(p.length + 1).join(p[0]); };
    if (dbl(a) && dbl(b) && a.length === b.length) return Math.abs(a.charCodeAt(0) - b.charCodeAt(0)) === 1;
    if (a.length === 2 && b.length === 2 && a.slice(1) === b.slice(1) && /[A-Z]/.test(a[0]) && /[A-Z]/.test(b[0])) return Math.abs(a.charCodeAt(0) - b.charCodeAt(0)) === 1;
    return false;
  }
  function pinPositions(pins) {   // numbers as such, single or doubled letters by alphabet rank, other names by their rank in the list
    var pos = {}, numeric = pins.every(function (p) { return /^\d+$/.test(p); }), alpha = pins.every(function (p) { return /^([A-Z])\1*$/.test(p); });
    pins.forEach(function (p, k) { pos[p] = numeric ? +p : alpha ? (p.length - 1) * 26 + p.charCodeAt(0) - 64 : k; });
    return pos;
  }
  function v2Pins(k) {
    var inv = v2Defs().filter(function (r) { return dRca(r) === 'Inversion'; }), per = {}, pairs = {}, nOk = 0, nAdj = 0;
    inv.forEach(function (r) { var p = pinPair(r[18]); if (!p) return; nOk++; if (pinNext(p[0], p[1])) nAdj++;
      var f = finReal(r); if (!f) return; var n = NC[r[0]], ac = (n && n[25]) || 'NC ' + r[0], key = f + '|' + p[0] + '|' + p[1];
      (per[f] || (per[f] = {}))[ac] = 1; (pairs[key] || (pairs[key] = {}))[ac] = 1; });
    var rep = Object.keys(pairs).filter(function (q) { return Object.keys(pairs[q]).length >= 2; }).length;
    v2Stats(k, [[num(nOk) + ' / ' + num(inv.length), S('pinStatL')], [nOk ? pct0(nAdj / nOk * 100) : '—', S('pinAdjL')], [num(rep), S('pinRepL')]]);
    var fins = Object.keys(per).map(function (f) { return { f: f, k: Object.keys(per[f]).length }; }).sort(function (a, b) { return b.k - a.k || (a.f < b.f ? -1 : 1); }).slice(0, 6);
    if (!fins.length) { gSet(k, '<p class="empty">' + esc(S('pinNone')) + '</p>'); return; }
    var W0 = gWd(k), cols = W0 > 900 ? 3 : W0 > 560 ? 2 : 1, gap = 22, cw = (W0 - (cols - 1) * gap) / cols, ch = 132, axis = 96, pad = 14, H = Math.ceil(fins.length / cols) * ch, g = '', col = catFill('Erreur Branchement'), rows = [];
    var acN = function (n) { return S(n === 1 ? 'pinAc1' : 'pinAcN', { n: num(n) }); };
    fins.forEach(function (fo, i) {
      var x0 = (i % cols) * (cw + gap), y0 = Math.floor(i / cols) * ch, mine = Object.keys(pairs).filter(function (q) { return q.split('|')[0] === fo.f; }), set = {};
      mine.forEach(function (q) { var p = q.split('|'); set[p[1]] = 1; set[p[2]] = 1; });
      var pins = Object.keys(set).sort(pinKey), pos = pinPositions(pins), lo = Math.min.apply(null, pins.map(function (q) { return pos[q]; })), hi = Math.max.apply(null, pins.map(function (q) { return pos[q]; }));
      var px = function (q) { return x0 + (hi === lo ? cw / 2 : pad + (pos[q] - lo) * (cw - 2 * pad) / (hi - lo)); };
      g += '<g' + pk('fin', fo.f) + '><rect x="' + r1(x0) + '" y="' + y0 + '" width="' + r1(cw) + '" height="20" fill="transparent"/>' + tx(x0, y0 + 14, fo.f, 'ink b') + tx(x0 + cw, y0 + 14, acN(fo.k), 'mu', 'end') + '</g>';   // the connector's name filters it
      g += '<line x1="' + r1(x0 + pad - 6) + '" x2="' + r1(x0 + cw - pad + 6) + '" y1="' + (y0 + axis) + '" y2="' + (y0 + axis) + '" stroke="var(--grid)" stroke-width="1.5"/>';
      mine.sort(function (a, b) { return Object.keys(pairs[a]).length - Object.keys(pairs[b]).length; }).forEach(function (q) {
        var p = q.split('|'), a = px(p[1]), b = px(p[2]), acs = Object.keys(pairs[q]), n = acs.length, hh = Math.max(7, Math.min(62, Math.abs(b - a) / 2)), cy = y0 + axis - hh * 1.33, nx = pinNext(p[1], p[2]);
        var d = 'M' + r1(a) + ',' + (y0 + axis) + ' C' + r1(a) + ',' + r1(cy) + ' ' + r1(b) + ',' + r1(cy) + ' ' + r1(b) + ',' + (y0 + axis);
        g += '<path d="' + d + '" fill="none" stroke="' + col + '" stroke-opacity=".85" stroke-width="' + (n >= 3 ? 4.5 : n === 2 ? 3 : 1.6) + '" stroke-linecap="round" pointer-events="none"/>' +
          '<path d="' + d + '" fill="none" stroke="transparent" stroke-width="12" pointer-events="stroke"' + pk('fin', fo.f) + tip(S('pinTip', { a: p[1], b: p[2] }) + ' · ' + fo.f, [acN(n) + ' : ' + acs.slice(0, 8).join(', ') + (acs.length > 8 ? '…' : ''), S(nx ? 'pinNextY' : 'pinNextN')]) + '/>';   // a wide stroke to hover and click
        rows.push([fo.f, p[1] + ' ↔ ' + p[2], S(nx ? 'pinY' : 'pinN'), n]);
      });
      var last = -1e9;
      pins.forEach(function (q) { var xx = px(q); g += '<circle cx="' + r1(xx) + '" cy="' + (y0 + axis) + '" r="2.5" fill="var(--ink-2)"/>'; if (xx - last >= 16) { g += tx(xx, y0 + axis + 16, q, 'mu', 'middle', ' style="font-size:10.5px"'); last = xx; } });
    });
    rows.sort(function (a, b) { return b[3] - a[3]; }); rows.forEach(function (r) { r[3] = num(r[3]); });
    gSet(k, svg(W0, H, g, gT(k)) + '<details class="vdata"><summary>' + esc(S('dataView')) + '</summary><div class="table-wrap"><table>' + miniTable(S('pinCols'), rows, 3) + '</table></div></details>',
      ['1', '2', '3'].map(function (n, j) { return '<span><i class="ln" style="height:' + [1.6, 3, 4.5][j] + 'px;width:22px;background:' + col + '"></i>' + esc(j === 2 ? S('pinAc3') : acN(+n)) + '</span>'; }).join('') + '<span class="mu">' + esc(S('pinNo25')) + '</span>');
  }

  function v2Icons(k) {
    var first = {}, defs = {}, lines = {};
    SEL_NC.forEach(function (n) { if (!n[25]) return; var key = n[3] + '|' + n[25]; lines[n[3]] = 1; if (!first[key] || n[1] < first[key]) first[key] = n[1]; });
    v2Defs().forEach(function (r) { var n = NC[r[0]]; if (n[25]) { var key = n[3] + '|' + n[25]; defs[key] = (defs[key] || 0) + 1; } });
    var W0 = gWd(k), lab = 70, cell = 20, cols = Math.max(8, Math.floor((W0 - lab) / cell)), y = 0, g = '';
    function shade(v) { return !v ? 'var(--track)' : v <= 5 ? tint('--seq', 30) : v <= 15 ? tint('--seq', 62) : 'var(--seq)'; }
    lineOrder(Object.keys(lines)).forEach(function (l) {
      var ks = Object.keys(first).filter(function (key) { return key.indexOf(l + '|') === 0; }).sort(function (a, b) { return first[a] < first[b] ? -1 : 1; }), rows = Math.ceil(ks.length / cols);
      g += tx(0, y + 14, l, 'ink b') + tx(0, y + 30, num(ks.length), 'mu');
      ks.forEach(function (key, i) { var v = defs[key] || 0, cx = lab + (i % cols) * cell, cy = y + Math.floor(i / cols) * cell;
        g += '<g transform="translate(' + cx + ',' + cy + ')"' + pk('msn', key.split('|')[1]) + tip(l, [gx('acTip', { m: key.split('|')[1], n: num(v) })]) + '><rect width="' + cell + '" height="' + cell + '" fill="transparent"/><path d="' + PLANE + '" fill="' + shade(v) + '"' + (!v ? ' stroke="var(--dim)" stroke-width=".8"' : '') + '/></g>'; });
      y += Math.max(rows * cell, 36) + 16;
    });
    if (!y) { pEmpty(k); return; }
    gSet(k, svg(W0, y, g, gT(k)), sw('var(--track)', gx('b0')) + sw(tint('--seq', 30), gx('b1')) + sw(tint('--seq', 62), gx('b2')) + sw('var(--seq)', gx('b3')));
  }

  function v2Comp(k) {
    var ms = v2Months().act, comps = [['comp_g', 13, 'var(--s1)'], ['comp_r', 15, tint('--s1', 62)], ['comp_m', 17, tint('--s1', 34)], ['comp_e', 18, 'var(--s2)']];   // not blue / green: those are the categories' (20 Oct)
    if (SEL_NC.some(function (n) { return n[46] > 0; })) comps.push(['comp_p', 46, 'var(--ink-2)']);   // the parts' value, once the price list holds prices
    var v = ms.map(function () { return comps.map(function () { return 0; }); });
    SEL_NC.forEach(function (n) { var i = ms.indexOf(n[1].slice(0, 7)); if (i >= 0) comps.forEach(function (c, j) { v[i][j] += n[c[1]] || 0; }); });
    var tots = v.map(sumA), mx = Math.max.apply(null, tots.concat([1])); if (!ms.length) { pEmpty(k); return; }
    var W0 = gWd(k), ml = 52, mt = 22, mb = 24, H = 270, ph = H - mt - mb, pw = W0 - ml - 6, bw = pw / ms.length, nt = pNice(mx), g = '';
    function Y(x) { return mt + ph - x / nt.top * ph; }
    g += pGridY(ml, pw, Y, nt, function (t) { return kE(t); });
    ms.forEach(function (m, i) {
      var x = ml + i * bw + bw * 0.18, w = bw * 0.64, acc = 0;
      comps.forEach(function (c, j) { var h = v[i][j] / nt.top * ph; if (h > 0.5) g += '<rect x="' + r1(x) + '" y="' + r1(Y(acc + v[i][j])) + '" width="' + r1(w) + '" height="' + r1(Math.max(1, h - 2)) + '" fill="' + c[2] + '"' + pk('month', m) + tip(monthName(m) + ' · ' + gx(c[0]), [eur(v[i][j]) + ' · ' + pct0(tots[i] ? v[i][j] / tots[i] * 100 : 0)]) + '/>'; acc += v[i][j]; });
      g += tx(x + w / 2, Y(tots[i]) - 6, kE(tots[i]), 'ink', 'middle') + tx(x + w / 2, H - 6, monthName(m).slice(0, 4), 'mu', 'middle');
    });
    gSet(k, svg(W0, H, g, gT(k)), comps.map(function (c) { return sw(c[2], gx(c[0])); }).join(''));
  }

  function v2Each(k) {
    var lines = lineOrder(SEL_NC.map(function (n) { return n[3]; }).filter(function (v, i, a) { return a.indexOf(v) === i; })); if (!lines.length) { pEmpty(k); return; }
    var ns = SEL_NC.filter(function (n) { return lines.indexOf(n[3]) >= 0 && n[12] > 0; }), to = GF.to < D.meta.to ? GF.to : D.meta.to;
    var W0 = gWd(k), lab = 66, mr = 12, rh = 76, mt = 6, H = mt + lines.length * rh + 24, pw = W0 - lab - mr, t0 = Date.parse(GF.from + 'T00:00:00Z'), t1 = Math.max(t0 + 864e5, Date.parse(to + 'T00:00:00Z'));
    var mxC = Math.max.apply(null, ns.map(function (n) { return n[12]; }).concat([1])), g = '';
    function X(iso) { return lab + (Date.parse(iso + 'T00:00:00Z') - t0) / (t1 - t0) * pw; }
    function R(c) { return 1 + 13 * Math.sqrt(c / mxC); }
    lines.forEach(function (l, li) { var cy = mt + li * rh + rh / 2; g += '<line x1="' + lab + '" x2="' + (lab + pw) + '" y1="' + cy + '" y2="' + cy + '" stroke="var(--grid)"/>' + tx(0, cy + 4, l, 'ink b'); });
    ns.slice().sort(function (a, b) { return b[12] - a[12]; }).forEach(function (n) {
      var cy = mt + lines.indexOf(n[3]) * rh + rh / 2, col = PROG_COL[n[3]] || 'var(--dim)';
      g += '<circle cx="' + r1(X(n[1])) + '" cy="' + cy + '" r="' + r1(R(n[12])) + '" fill="' + col + '" fill-opacity=".2" stroke="' + col + '" stroke-opacity=".75"' + pk('nc', n[0]) + tip(n[0] + ' · ' + n[3], [eur(n[12]), shortDay(n[1]), n[22] || '']) + '/>';
    });
    var put = [];
    ns.slice().sort(function (a, b) { return b[12] - a[12]; }).slice(0, 5).forEach(function (n) {
      var cy = mt + lines.indexOf(n[3]) * rh + rh / 2, t = n[0] + ' · ' + eurK(n[12]), w = t.length * 6, x = Math.max(lab + w / 2, Math.min(W0 - w / 2 - 2, X(n[1]))), y = cy - R(n[12]) - 4;
      while (put.some(function (p) { return Math.abs(p[0] - x) < (p[2] + w) / 2 && Math.abs(p[1] - y) < 13; })) y -= 13;
      put.push([x, y, w]); g += tx(x, y, t, 'ink halo', 'middle', ' style="font-size:11px"');
    });
    var d = new Date(GF.from.slice(0, 7) + '-01T00:00:00Z');
    while (d.toISOString().slice(0, 10) <= to) { var iso = d.toISOString().slice(0, 10); if (iso >= GF.from) g += tx(X(iso), H - 6, monthName(iso.slice(0, 7)).slice(0, 4), 'mu', 'middle'); d.setUTCMonth(d.getUTCMonth() + 1); }
    gSet(k, svg(W0, H, g, gT(k)), lines.map(function (l) { return sw(PROG_COL[l] || 'var(--dim)', progName(l), true); }).join(''));
  }

  // ---------------------------------------------------------------- language, tabs, minor switch
  function applyText() {
    if (!EMBED) { document.documentElement.lang = G.lang; document.title = S('title'); }
    document.querySelectorAll('[data-t]').forEach(function (el) { el.textContent = S(el.getAttribute('data-t')); });
    document.querySelectorAll('[data-csv]').forEach(function (b) { b.title = S('csvT'); });
    document.querySelectorAll('[data-ta]').forEach(function (el) { el.setAttribute('aria-label', S(el.getAttribute('data-ta'))); });
    var dates = { from: day(D.meta.from), to: day(D.meta.to) }, A = D.meta.aside;
    document.getElementById('period').textContent = S('period', { from: day(GF.from), to: day(GF.to) });
    document.getElementById('asof').textContent = S('asof', { to: day(D.meta.to) });
    document.getElementById('foot1').textContent = S('foot1', dates);
    document.querySelectorAll('[data-t="serieSub"]').forEach(function (el) { el.textContent = S((GF.fto2 ? 'serieSub' : 'serieSubAll') + (GF.liab === 'f' ? 'Aec' : '')); });
    document.getElementById('foot3').textContent = S('foot3', { n: num(D.meta.noLine), o: num(((A || {}).other || [0])[0]), oe: eur(((A || {}).other || [0, 0])[1]) });
    // the method's footnote quotes the settings as they are today: the shutdown threshold, the hourly rates by who works
    // (config/1_cout_parametres.csv), and whether a part's value is counted (config/1_prix_pieces.csv holds prices)
    var cp = (CXP && CXP.p) || {}, who = cp.who || {}, rs = cp.rates || {}, rate = function (a, b) { var v = a != null ? a : b; return v != null ? num(v) : '—'; };
    var priced = D.ncs.some(function (n) { return (n[46] || 0) > 0 || (n._w && n._w[7] > 0); });
    document.getElementById('foot4').textContent = S('foot4', { sh: num(Math.round(SET.semaine_faible * 100)), rp: rate(who.production, cp.rateProd), rq: rate(who.qualite, rs.writing),
      rm: rate(who.me, rs.support), re: rate(cp.rateEng), pv: S(priced ? 'footPart1' : 'footPart0') });
    ['nq', 'pq', 'kq', 'cq', 'rq', 'whQ'].forEach(function (id) { var q = document.getElementById(id); q.placeholder = S('search'); q.setAttribute('aria-label', S('search')); });
    document.getElementById('lFr').setAttribute('aria-pressed', String(G.lang === 'fr'));
    document.getElementById('lEn').setAttribute('aria-pressed', String(G.lang === 'en'));
    document.getElementById('miIn').setAttribute('aria-pressed', String(G.minor));
    document.getElementById('miOut').setAttribute('aria-pressed', String(!G.minor));
    document.getElementById('minorCtl').hidden = G.tab === 'cnq' || G.tab === 'ov';
    renderBar();
  }
  function showTab() {
    TABS.forEach(function (t) {
      var b = document.getElementById('tab-' + t);
      b.setAttribute('aria-selected', String(G.tab === t)); b.tabIndex = G.tab === t ? 0 : -1;
      document.getElementById('p-' + t).hidden = G.tab !== t;
    });
  }
  function renderAll() { applyText(); showTab(); renderPMode(); ncBoard.render(); pareto.render(); costPareto.render(); cnq.render(); renderCx(); renderDis(); renderWhereTbl(); client.render(); renderCbl(); renderRca(); alRender(); renderPplan(); v2Render(); }
  function setTab(t) { G.tab = t; if (!EMBED) { try { history.replaceState(null, '', '#' + t); } catch (x) {} } applyText(); showTab(); if (t === 'ov') ncBoard.render(); if (t === 'pplan') renderPplan(); if (t === 'cbl') renderCbl(); v2Render(); hideTip(); }
  document.getElementById('tabs').addEventListener('click', function (e) { var t = e.target.closest('[data-tab]'); if (t) setTab(t.getAttribute('data-tab')); });
  document.getElementById('tabs').addEventListener('keydown', function (e) {
    if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
    var i = TABS.indexOf(G.tab) + (e.key === 'ArrowRight' ? 1 : -1);
    setTab(TABS[(i + TABS.length) % TABS.length]); document.getElementById('tab-' + G.tab).focus();
  });
  function setLang(l) { G.lang = l; try { localStorage.setItem('fto2-dash-lang', l); } catch (e) {} renderAll(); }
  document.getElementById('lFr').addEventListener('click', function () { setLang('fr'); });
  document.getElementById('lEn').addEventListener('click', function () { setLang('en'); });
  function setMinor(v) { G.minor = v; pareto.f = {}; costPareto.f = {}; client.f = {}; renderAll(); }
  document.getElementById('miIn').addEventListener('click', function () { setMinor(true); });
  document.getElementById('miOut').addEventListener('click', function () { setMinor(false); });

  // ---------------------------------------------------------------- Simple mode: two monthly views made of this dashboard's
  // own charts, for the QCMs (Synthèse: the plant, the year) and the QLS (Détail: one line, one month). Détail's Pareto opens a level at a time
  // (category, then cause, then sub-code), in volume by default; its charts run from January to that month. Charts show without their notes;
  // the icon at a chart's corner opens the complete chart over the page. The Expert layout lends Simple its bands, the Pareto tab's boards
  // and the overview's NC table, and gets them back when the switch goes to Expert. The switch animates (a double click or tap skips).
  (function () {
    Object.assign(STR.fr, { tabSyn: 'Synthèse', tabDet: 'Détail', vuOpen: 'Agrandir', vuClose: 'Fermer', modeLab: 'Affichage', modeSimple: 'Essentiel', modeExpert: 'Deep dive',
      modeSimpleT: 'Quelques graphiques : Synthèse et Détail', modeExpertT: 'Le tableau de bord complet',
      vuNcY: 'NC depuis janvier', vuNcP: 'NC sur la période', vuRate: 'NC par MSN', vuCost: 'Coût de non-qualité', vuRet: 'Retours clients',
      vuDef: 'Défauts', vuRateY: 'NC par MSN depuis janvier', vuFc: 'prévision fin déc. : {f} · objectif : {t}',
      vuVsT: 'par rapport à l’objectif ({t})', vuPrevP: 'période d’avant : {v}' });
    Object.assign(STR.en, { tabSyn: 'Summary', tabDet: 'Detail', vuOpen: 'Enlarge', vuClose: 'Close', modeLab: 'View', modeSimple: 'Essential', modeExpert: 'Deep dive',
      modeSimpleT: 'A few charts: Summary and Detail', modeExpertT: 'The full dashboard',
      vuNcY: 'NCs since January', vuNcP: 'NCs in the period', vuRate: 'NCs per MSN', vuCost: 'Cost of non-quality', vuRet: 'Customer returns',
      vuDef: 'Defects', vuRateY: 'NCs per MSN since January', vuFc: 'forecast end Dec.: {f} · target: {t}',
      vuVsT: 'against the target ({t})', vuPrevP: 'period before: {v}' });
    var PM = { simple: 'vol', expert: PMODE }; if (MODE === 'simple') PMODE = 'vol';   // each mode keeps its Pareto measure; Simple opens in volume
    V2L.syn = { top: ['VN', 'VT', 'a:bump', 'VQ', 'a:bub'], more: ['VB'] };   // VB: drawn out of sight, for its forecast and budget
    V2L.det = { top: ['a:bump', '78', '54'] };
    var $v = function (id) { return document.getElementById(id); };
    // Détail's charts run from January (or the period's start if earlier) to the period's end: a monthly view still shows its year
    function ytd(fn) {
      var k = [GF.preset, GF.from, GF.to], y0 = GF.to.slice(0, 4) + '-01-01';
      GF.preset = 'custom'; if (y0 < GF.from) GF.from = y0; select(); PD = pSrc() ? pData() : null; PA = PD ? pAgg(PD) : null;
      try { return fn(); } finally { GF.preset = k[0]; GF.from = k[1]; GF.to = k[2]; select(); }
    }
    function inCtx(fn) { if (G.tab === 'det') ytd(fn); else fn(); }

    // what Simple borrows from the Expert layout: a mark where it lives, to give it back
    var HOME = [];
    function borrow(el) { if (!el || el._vuHome) return; var m = document.createComment('vu'); el.parentNode.insertBefore(m, el); el._vuHome = m; HOME.push(el); }
    function giveBack() { HOME.forEach(function (el) { var m = el._vuHome; if (m.parentNode && el.previousSibling !== m) m.parentNode.insertBefore(el, m.nextSibling); }); }
    // the bands are the Expert layout's (built first), each placed in the open view's slot (the cause ranking shows in both views)
    var VUB = false, LEND = null;
    function vuX(x) { x.innerHTML = '<span aria-hidden="true">⤢</span>'; x.title = S('vuOpen'); x.setAttribute('aria-label', S('vuOpen')); }
    function vuBuild() {
      if (VUB) return; VUB = true;
      v2Build();
      [['vuSynGrid', V2L.syn.top], ['vuDetGrid', V2L.det.top]].forEach(function (p) {
        var g = v2Wire($v(p[0]));
        p[1].forEach(function (k) { var s2 = document.createElement('div'); s2.className = 'vu-slot'; s2.setAttribute('data-slot', k); g.appendChild(s2); });
      });
      V2L.syn.top.concat(V2L.det.top, V2L.syn.more).forEach(function (k) {
        var b = V2BAND[k] || v2Band(k); if (!b) return;
        if (V2L.syn.more.indexOf(k) >= 0) { if (!b.isConnected) $v('vuSynCalc').appendChild(b); return; }
        if (b.querySelector('.vu-x')) return;
        b.classList.add('vu-band');
        var x = document.createElement('button'); x.type = 'button'; x.className = 'vu-x'; x.setAttribute('data-vux', k); vuX(x);
        b.querySelector('.bhead').appendChild(x);
      });
      // Détail: the Pareto tab's two boards (volume / cost switch, the lists, the defect table at the very bottom, under the charts);
      // Synthèse: the overview's NC table, folded at the bottom
      LEND = [[$v('p-pareto').querySelector(':scope > .controls'), 'vuPar'], [$v('pVol'), 'vuPar'], [$v('pCost'), 'vuPar'], [$v('nq') && $v('nq').closest('details'), 'p-syn']];
      v2Wire($v('vuPanel'));
      applyText();
    }
    function vuPlace() {
      LEND.forEach(function (p) { var el = p[0], to = $v(p[1]); if (el && el.parentNode !== to) { borrow(el); to.appendChild(el); } });
      document.querySelectorAll('#p-' + G.tab + ' .vu-slot').forEach(function (s2) { var b = V2BAND[s2.getAttribute('data-slot')]; if (b && b.parentNode !== s2 && !b.classList.contains('vu-full')) { borrow(b); s2.appendChild(b); } });
      if (G.tab === 'det') {   // the charts sit between the lists and the defect table of the measure shown
        var sec = $v(PMODE === 'vol' ? 'pVol' : 'pCost'), dt = sec.querySelector(':scope > details.detail'), g = $v('vuDetGrid');
        if (dt && g.nextSibling !== dt) { borrow(g); sec.insertBefore(g, dt); }
      }
    }

    // the Pareto one level at a time, full width: the categories; a category pressed, its causes; a cause pressed, its sub-codes.
    // The chips above are the way back (a level removed closes those under it)
    [[pareto, ['pg', 'pgl'], 'pc'], [costPareto, ['kg', 'kgl'], 'kc']].forEach(function (p) {
      var b = p[0], r0 = b.render;
      b.render = function () {
        if (MODE !== 'simple') { r0(); return; }
        if (!b.f.cat) { delete b.f.rca; delete b.f.code; } else if (!b.f.rca) delete b.f.code;
        delete b.f.line; delete b.f.fin;
        r0();
        var lvl = !b.f.cat ? 'cat' : !b.f.rca ? 'rca' : 'code';
        p[1].forEach(function (id) { var g = $v(id), any = false; g.querySelectorAll(':scope > [data-card]').forEach(function (c) { c.hidden = c.getAttribute('data-card') !== lvl; if (!c.hidden) any = true; }); g.hidden = !any; });
        $v(p[2]).hidden = !Object.keys(b.f).length;
      };
    });

    // numbers: the plant's trend and cost as their charts compute them; NC per MSN and its target as the target chart
    function rateOf(l) {
      if (!PD || !PA) return null;
      var L2 = lignes(), ls = (L2 || []).filter(function (a) { return !l || a.l === l; });   // null while Slate computes the targets
      if (!ls.length) return null;
      var nc = 0, eq = 0, tn = 0;
      ls.forEach(function (a) { nc += a.nc; eq += a.eq; tn += a.t * a.eq; });
      return { v: nc / eq, t: tn / eq };
    }
    function stats(k) { var b = V2BAND[k]; return b ? [].map.call(b.querySelectorAll('.v2stats > div > b'), function (x) { return x.textContent; }) : []; }
    function fig(v, lab, sub) { return '<div class="fig"><b>' + esc(v) + '</b><span>' + esc(lab) + '</span>' + (sub ? '<small>' + sub + '</small>' : '') + '</div>'; }
    function gapTx(r) { if (!r || !r.t) return ''; var g = r.v / r.t - 1; return '<span class="' + (g > 0 ? 'vu-up' : 'vu-down') + '">' + (g > 0 ? '+' : '') + pct0(g * 100) + '</span> ' + esc(S('vuVsT', { t: f2(r.t) })); }
    function count() { var d = 0, c = 0; D.defects.forEach(function (r) { if (SEL[r[0]] && keepMinor(r)) d++; }); SEL_NC.forEach(function (n) { c += n[12] || 0; }); return { n: SEL_NC.length, d: d, c: c }; }
    var RATE_DET = null;
    function vuFigs() {
      var ncLab = S(GF.preset === 'ytd' ? 'vuNcY' : 'vuNcP');
      if (G.tab === 'syn') {
        var n = stats('VN'), c = stats('VB'), r = rateOf(GF.line), rc = 0; CLI_NC.forEach(function (x) { rc += x[12] || 0; });
        $v('vuSF').innerHTML = fig(n[0] || num(SEL_NC.length), ncLab, n[1] ? esc(S('vuFc', { f: n[1], t: n[2] })) : '') +
          fig(r ? f2(r.v) : '—', S('vuRate'), gapTx(r)) + fig(c[0] || '—', S('vuCost'), c[1] ? esc(S('vuFc', { f: c[1], t: c[2] })) : '') +
          fig(num(CLI_NC.length), S('vuRet'), esc(eur(rc)));
      } else {   // the period against the one just before it, of the same length, when the data has it
        var now = count(), days = Math.round((Date.parse(GF.to) - Date.parse(GF.from)) / 864e5) + 1, p0 = plusDays(GF.from, -days), prev = null;
        if (p0 >= DMIN) { var k = [GF.preset, GF.from, GF.to]; GF.preset = 'custom'; GF.from = p0; GF.to = plusDays(k[1], -1); select(); prev = count(); GF.preset = k[0]; GF.from = k[1]; GF.to = k[2]; select(); }
        var pv = function (v) { return prev ? esc(S('vuPrevP', { v: v })) : ''; };
        $v('vuDF').innerHTML = fig(num(now.n), ncLab, pv(prev && num(prev.n))) + fig(num(now.d), S('vuDef'), pv(prev && num(prev.d))) +
          fig(RATE_DET ? f2(RATE_DET.v) : '—', S('vuRateY'), gapTx(RATE_DET)) + fig(eurK(now.c), S('vuCost'), pv(prev && eurK(prev.c)));
      }
    }

    // every redraw of this page goes through here: bands in place, Détail's charts over the year, then the numbers
    var v2R0 = v2Render;
    v2Render = function () {
      if (G.tab !== 'syn' && G.tab !== 'det') { v2R0(); return; }
      vuBuild(); vuPlace();
      if (G.tab === 'det') ytd(function () { v2R0(); RATE_DET = rateOf(GF.line); }); else v2R0();
      document.querySelectorAll('.vu-x').forEach(vuX);
      vuFigs();
      if (OPEN) inCtx(function () { v2Draw(OPEN.k); });
    };
    var setTab0 = setTab;
    setTab = function (t) { if (OPEN) vuClose(true); setTab0(t); };

    // the complete chart: the band grows out of its place over the page; a double click or tap finishes the animation
    var OPEN = null, RUN = [], OPENED = 0, lastTap = 0, REDUCE = matchMedia('(prefers-reduced-motion: reduce)').matches;
    function anim(el, kf, o) { if (REDUCE || !el.animate) return null; var a = el.animate(kf, o); RUN.push(a); a.finished.then(function () { RUN = RUN.filter(function (x) { return x !== a; }); }, function () { RUN = RUN.filter(function (x) { return x !== a; }); }); return a; }
    var SKIPT = 0;
    function skip() { SKIPT = Date.now(); RUN.slice().forEach(function (a) { try { a.finish(); } catch (e) {} }); }
    function vuOpen(k) {
      var b = V2BAND[k]; if (!b || OPEN) return;
      var q0 = b.getBoundingClientRect(), ph = document.createElement('div'); ph.style.height = q0.height + 'px'; b.parentNode.insertBefore(ph, b);
      OPEN = { k: k, b: b, ph: ph }; OPENED = Date.now();
      $v('vuHold').appendChild(b); b.classList.add('vu-full'); $v('vuOv').hidden = false; $v('vuOv').scrollTop = 0; document.documentElement.classList.add('vu-lock');
      $v('vuPanel').setAttribute('aria-label', b.querySelector('h3') ? b.querySelector('h3').textContent : '');
      inCtx(function () { v2Draw(k); });
      var q1 = b.getBoundingClientRect(), sx = q0.width / q1.width, dx = q0.left - q1.left, dy = q0.top - q1.top, E = 'cubic-bezier(.2,.8,.2,1)';
      anim($v('vuScrim'), [{ opacity: 0 }, { opacity: 1 }], { duration: 420, easing: 'ease-out' });
      anim(b, [{ transform: 'translate(' + dx + 'px,' + dy + 'px) scale(' + sx + ')', boxShadow: '0 0 0 rgba(0,0,0,0)' },
        { transform: 'translate(' + r1(dx * .3) + 'px,' + r1(dy * .3 - 16) + 'px) scale(' + (sx + (1 - sx) * .78) + ')', offset: .6 },
        { transform: 'none', boxShadow: '0 24px 60px rgba(0,0,0,.28)' }], { duration: 720, easing: E });
      b.querySelectorAll('.bhead > .kicker, .bhead > .sub, .v2stats, details').forEach(function (e, i) { anim(e, [{ opacity: 0, transform: 'translateY(6px)' }, { opacity: 1, transform: 'none' }], { duration: 320, delay: 520 + i * 70, easing: E, fill: 'backwards' }); });
      $v('vuClose').focus();
    }
    function vuClose(now) {
      if (!OPEN) return; var o = OPEN; OPEN = null;
      var done = function () {
        o.b.classList.remove('vu-full'); o.ph.parentNode.insertBefore(o.b, o.ph); o.ph.remove();
        $v('vuOv').hidden = true; document.documentElement.classList.remove('vu-lock');
        if (!now) { inCtx(function () { v2Draw(o.k); }); var x = o.b.querySelector('.vu-x'); if (x) x.focus(); }
      };
      if (now || REDUCE || !o.b.animate) { skip(); done(); return; }
      anim($v('vuScrim'), [{ opacity: 1 }, { opacity: 0 }], { duration: 220, easing: 'ease-in', fill: 'forwards' });
      var a = anim(o.b, [{ opacity: 1, transform: 'none' }, { opacity: 0, transform: 'translateY(10px) scale(.98)' }], { duration: 200, easing: 'ease-in', fill: 'forwards' });
      a.finished.then(function () { done(); [$v('vuScrim'), o.b].forEach(function (e) { e.getAnimations().forEach(function (x) { x.cancel(); }); }); }, done);
    }
    document.addEventListener('click', function (e) {
      var md = e.target.closest && e.target.closest('#modeSw [data-mode]'); if (md) { setMode(md.getAttribute('data-mode')); return; }
      var x = e.target.closest && e.target.closest('[data-vux]'); if (x) { vuOpen(x.getAttribute('data-vux')); return; }
      if (e.target.id === 'vuClose') { vuClose(); return; }
      if (e.target.id === 'vuScrim' || e.target.id === 'vuOv') { if (RUN.length || Date.now() - OPENED < 900) skip(); else vuClose(); }   // the second tap of a double tap skips, it does not close
    });
    // the bell (shared alarm engine): an alarm opens Détail on its line, the Pareto open on its category, cause or sub-code
    var alTab0 = alTab, alGo0 = alGo;   // in Expert, the dashboard's own
    alTab = function (a) { return MODE === 'simple' ? 'det' : alTab0(a); };
    alGo = function (key) {
      if (MODE !== 'simple') { alGo0(key); return; }
      var g = ((alarmesNow() || {}).res || []).filter(function (x) { return x.key === key; })[0]; if (!g) return;
      var a = g.head, f = {}, r = null; AL.open = false;
      if (a.lv === 'cat') f.cat = a.v;
      else if (a.lv === 'rca' || a.lv === 'code') {
        D.defects.some(function (x) { if ((a.lv === 'rca' ? dRca(x) : dCode(x)) === a.v) { r = x; return true; } return false; });
        if (r) { f.cat = dCat(r); f.rca = dRca(r); if (a.lv === 'code') f.code = a.v; }
      }
      pareto.f = Object.assign({}, f); costPareto.f = Object.assign({}, f); pareto.limit = costPareto.limit = 100;
      GF.line = g.kind === 'cross' ? '' : g.line; GF.pick = null; pickPrep(); setGF({}); setTab('det');   // an alarm on several lines: all lines
      var el = $v('vuPar'); if (el && el.scrollIntoView) el.scrollIntoView({ block: 'start' });
    };

    // ---- the switch: Simple <-> Expert. The page leaves (shrinks or grows away), then the other mode opens from the switch, a circle
    // that widens over the page, its tabs sliding in; a double click or tap skips
    var LASTTAB = { simple: MODE === 'simple' ? G.tab : SIMPLE_TABS[0], expert: MODE === 'expert' ? G.tab : EXPERT_TABS[0] }, SW = false;
    function modeUI() {
      var sw = $v('modeSw'); if (!sw) return;
      sw.hidden = false; sw.setAttribute('data-mode', MODE); sw.setAttribute('aria-label', S('modeLab'));
      sw.querySelectorAll('[data-mode]').forEach(function (bt) { var m = bt.getAttribute('data-mode');
        bt.textContent = S(m === 'simple' ? 'modeSimple' : 'modeExpert'); bt.title = S(m === 'simple' ? 'modeSimpleT' : 'modeExpertT'); bt.setAttribute('aria-pressed', String(m === MODE)); });
    }
    var applyText0 = applyText; applyText = function () { applyText0(); modeUI(); };
    function swap(m) {
      if (OPEN) vuClose(true);
      LASTTAB[MODE] = G.tab; PM[MODE] = PMODE;
      if (m === 'expert') {   // give the Expert layout its pieces back, its boards whole again
        giveBack();
        ['pg', 'pgl', 'kg', 'kgl', 'pc', 'kc'].forEach(function (id) { var g = $v(id); if (!g) return; g.hidden = false; g.querySelectorAll(':scope > [data-card]').forEach(function (c) { c.hidden = false; }); });
      }
      TABS.forEach(function (t) { var p = $v('p-' + t); if (p) p.hidden = true; });
      MODE = m; PMODE = PM[m]; TABS = m === 'simple' ? SIMPLE_TABS : EXPERT_TABS; tabsShow();
      try { localStorage.setItem('fto2-dash-mode', m); } catch (e) {}
      G.tab = LASTTAB[m]; if (!EMBED) { try { history.replaceState(null, '', '#' + G.tab); } catch (x) {} }
      renderAll();
    }
    function setMode(m) {
      if (m === MODE || SW) return;
      var tb = $v('tabs'), p0 = $v('p-' + G.tab), bt = document.querySelector('#modeSw [data-mode="' + m + '"]'), E = 'cubic-bezier(.2,.8,.2,1)', far = m === 'expert' ? .96 : 1.04;
      if (REDUCE || !tb.animate || !p0) { swap(m); return; }
      SW = true;
      var a = anim(p0, [{ opacity: 1, transform: 'none' }, { opacity: 0, transform: 'scale(' + far + ')' }], { duration: 240, easing: 'ease-in', fill: 'forwards' });
      anim(tb, [{ opacity: 1 }, { opacity: 0 }], { duration: 200, easing: 'ease-in', fill: 'forwards' });
      var next = function () {
        [p0, tb].forEach(function (e) { e.getAnimations().forEach(function (x) { x.cancel(); }); });
        swap(m); SW = false;
        if (Date.now() - SKIPT < 600) return;   // skipped: the new mode at once
        var p = $v('p-' + G.tab); if (!p) return;
        var r = p.getBoundingClientRect(), q = bt.getBoundingClientRect(), cx = q.left + q.width / 2 - r.left, cy = q.top + q.height / 2 - r.top;
        var h = Math.min(r.height, innerHeight * 1.5), R = Math.hypot(Math.max(cx, r.width - cx), Math.max(Math.abs(cy), Math.abs(h - cy))) + 40;
        anim(p, [{ clipPath: 'circle(20px at ' + r1(cx) + 'px ' + r1(cy) + 'px)', transform: 'scale(' + (2 - far) + ')', opacity: .5 },
          { clipPath: 'circle(' + r1(R) + 'px at ' + r1(cx) + 'px ' + r1(cy) + 'px)', transform: 'none', opacity: 1 }], { duration: 780, easing: E });
        [].slice.call(tb.querySelectorAll('[role="tab"]:not([hidden])')).forEach(function (t, i) {
          anim(t, [{ opacity: 0, transform: 'translateX(' + (m === 'expert' ? 16 : -16) + 'px)' }, { opacity: 1, transform: 'none' }], { duration: 420, delay: 160 + i * 50, easing: E, fill: 'backwards' }); });
        [].slice.call(p.querySelectorAll(':scope > .figs > .fig')).forEach(function (f, i) {
          anim(f, [{ opacity: 0, transform: 'translateY(12px)' }, { opacity: 1, transform: 'none' }], { duration: 420, delay: 260 + i * 70, easing: E, fill: 'backwards' }); });
      };
      if (a) a.finished.then(next, next); else next();
    }
    modeUI();
    document.addEventListener('dblclick', function () { if (RUN.length) skip(); });
    document.addEventListener('pointerdown', function (e) { if (e.pointerType !== 'touch') return; var t = Date.now(); if (RUN.length && t - lastTap < 320) skip(); lastTap = t; });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && OPEN) { skip(); vuClose(); } });
  })();
  renderAll(); CALC.live = true;
})();
  }
  var got = {}, started = false, ready = false, disTimer = null, cxTimer = null, rgTimer = null;
  // The calculations Slate can run as functions (optional): the state key "fonctions" lists them
  // ("objectifs alarmes cout", or "objectifs alarmes" with the cost explanation from the notebook's table, state key "cout_table").
  // The page asks through the state key "filtres" and the sandbox event fto2Filtres (which sets the variable v_fto2_filtres); each
  // answer arrives in the state key of its name. No double brace in this file: Slate would read it as a binding.
  var SLF = { use: {}, latest: {}, take: null }, sent = null, fired = true, fnMsg = false;
  function fonctions(v) { String(v || '').split(/[\s,;]+/).forEach(function (n) { if (n === 'objectifs' || n === 'alarmes' || n === 'cout') SLF.use[n] = true; }); }
  function writeState(key, v) {   // setState: an object merged into the state, or (key, value); both forms are accepted
    if (api.setState.length >= 2) { api.setState(key, v); return; }
    var st = {}; try { st = (api.getState && api.getState()) || {}; } catch (e) {}
    var nx = {}; Object.keys(st).forEach(function (k) { nx[k] = st[k]; }); nx[key] = v;
    api.setState(nx);
  }
  function fire() { if (fired) return; fired = true; api.triggerEvent('fto2Filtres'); }
  SLF.ask = function (requests) {
    if (!api.setState || !api.triggerEvent) throw new Error('SlateFunctions.setState / triggerEvent missing');
    var v = { demandes: requests }; sent = JSON.stringify(v); fired = false;
    writeState('filtres', v);
    setTimeout(fire, 400);   // the event reads the state: fired once the state shows the new filters (watch below), at the latest after 0.4 s
  };
  SLF.show = function (waiting, failed) {   // only a failure is shown; the charts themselves say "Calcul dans Slate…"
    var f = Object.keys(failed || {});
    if (f.length) { fnMsg = true; status(f.map(function (n) { var e = failed[n], w = e === 'late' ? MSG.fnLate : MSG.fnErr.map(function (x) { return x.replace('{m}', e); });
      return MSG.fnDown.replace(/\{f\}/g, 'f_fto2_' + n).replace('{fr}', w[0]).replace('{en}', w[1]); }).join(' '), true); }
    else if (fnMsg) { fnMsg = false; status(''); }
  };
  function parse(v) {   // a query result arrives as an object of columns; accept JSON text too
    if (typeof v !== 'string') return v;
    var s = v.trim(); if (!s) return null;
    try { return JSON.parse(s); } catch (e) { return null; }
  }
  function count(t) {
    if (!t) return 0;
    if (Array.isArray(t)) return t.length;
    var k = Object.keys(t);
    for (var i = 0; i < k.length; i++) if (t[k[i]] && t[k[i]].length) return t[k[i]].length;
    return 0;
  }
  function loaded(t) { return !!t && (Array.isArray(t) || Object.keys(t).length > 0); }   // a result with its columns, even with no row
  function tables() {
    var nc = parse(got.nc), def = parse(got.def), dis = parse(got.dis), tb = parse(got.tables);
    if (tb) { nc = nc || tb.nc; def = def || tb.def; dis = dis || tb.dis; }
    return [nc, def, typeof dis === 'object' ? dis : null];
  }
  function reference() { return window.FTO2_REF ? { dashboard: window.FTO2_REF } : fto2RefBlocks(got.ref); }
  function tryStart() {
    if (started || !ready) return;
    var t = tables(), nc = t[0], def = t[1], dis = t[2], n1 = count(nc), n2 = count(def), R = reference();
    if (loaded(nc) && !n1) { status(MSG.empty, true); return; }
    if (!n1 || !loaded(def) || !R) { status(MSG.wait); return; }   // the queries can arrive one after the other
    if (!loaded(dis) && !disTimer) { disTimer = setTimeout(function () { disTimer = 'over'; tryStart(); }, 4000); return; }   // the block's query: optional
    if (!loaded(dis) && disTimer !== 'over') return;
    var st0 = {}; try { st0 = (api.getState && api.getState()) || {}; } catch (e) {}
    if ('cout_table' in st0 && !loaded(parse(got.cout_table)) && cxTimer !== 'over') {   // the notebook's cost explanation, when the state reads it
      if (!cxTimer) cxTimer = setTimeout(function () { cxTimer = 'over'; tryStart(); }, 8000);
      return;
    }
    var withSheet = 'reglages' in st0 || got.reglages != null;   // the state reads the Fusion sheet's settings (optional)
    if (withSheet && !loaded(parse(got.reglages)) && rgTimer !== 'over') {   // a few seconds for them to arrive
      if (!rgTimer) rgTimer = setTimeout(function () { rgTimer = 'over'; tryStart(); }, 8000);
      return;
    }
    started = true;
    try {
      try { fonctions((api.getState && api.getState() || {}).fonctions); } catch (e) {}
      fonctions(got.fonctions);
      if (Object.keys(SLF.use).length) window.FTO2_SLATE = SLF;
      var cx = parse(got.cout_table);
      window.DASH = fto2FromTables(nc, def, R.dashboard, loaded(dis) ? dis : null, !SLF.use.cout && loaded(cx) ? cx : null);
      if (withSheet) fto2Reglages(window.DASH.settings, got.reglages);   // before the page reads its settings (texts, filters at opening, targets)
      if (!window.DASH.ncs.length) {   // rows arrived but none could be read: say what came, to fix the query or the state
        var c = Array.isArray(nc) ? Object.keys(nc[0] || {}) : Object.keys(nc);
        showError('aucune NC lisible dans q_fto2_nc (colonnes reçues : ' + c.join(', ') + ') / no readable NC in q_fto2_nc (columns received: ' + c.join(', ') + ')');
        return;
      }
      status('');
      main();
      var lim = [1000, 2000, 5000, 10000, 20000, 50000, 100000], warn = [];
      if (lim.indexOf(n1) >= 0) warn.push(MSG.cut.replace('{n}', n1).replace('{q}', 'q_fto2_nc'));
      if (lim.indexOf(n2) >= 0) warn.push(MSG.cut.replace('{n}', n2).replace('{q}', 'q_fto2_def'));
      if (warn.length) status(warn.join(' '), true);
      if (window.console) console.info('[FTO2 dashboard] rows received: NC ' + n1 + ', defect lines ' + n2 + ', aléas ' + (loaded(dis) ? count(dis) : 'none (no q_fto2_dis)'));
    } catch (err) { showError((err && err.message) || String(err)); }
  }
  var api = window.SlateFunctions;
  if (api && typeof api.watch === 'function') {
    ['nc', 'def', 'dis', 'tables', 'ref', 'fonctions', 'cout_table', 'reglages'].forEach(function (k) { api.watch(k, function (v) { got[k] = v; tryStart(); }); });
    ['objectifs', 'alarmes', 'cout'].forEach(function (k) { api.watch(k, function (v) { var x = parse(v); if (!x) return; SLF.latest[k] = x; if (SLF.take) SLF.take(k, x); }); });
    api.watch('filtres', function (v) { if (sent && (typeof v === 'string' ? v : JSON.stringify(v)) === sent) setTimeout(fire, 0); });
  }
  function boot() {
    ready = true;
    if (!document.getElementById('tabs')) { showError('HTML part missing: paste the HTML part into the HTML box.'); return; }
    if (!(api && typeof api.watch === 'function')) { showError(MSG.noapi); return; }
    status(MSG.wait);
    tryStart();
    setTimeout(function () {
      if (started) return;
      var t = tables(), miss = [];
      if (!count(t[0])) miss.push('q_fto2_nc');
      if (!loaded(t[1])) miss.push('q_fto2_def');
      if (!reference()) miss.push('q_fto2_ref');
      if (miss.length) status(MSG.slow.replace(/\{q\}/g, miss.join(', ')), true);
    }, 20000);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();
