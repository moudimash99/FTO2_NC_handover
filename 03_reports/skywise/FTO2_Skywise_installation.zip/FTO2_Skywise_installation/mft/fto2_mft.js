/* FTO2 MFT for Slate: data from the queries q_fto2_nc, q_fto2_def and q_fto2_ref through the code sandbox's state; actions kept in this browser, or for everyone with the state key store (q_fto2_mft_store). */
// The reference data (sub-code names, the production plan's products and their alias rules, MSN built per line and week, the
// end of build of each MSN, the MFT actions) comes from the query q_fto2_ref, part "mft" (dataset fto2_dash_ref).
function fto2RefBlocks(v) {
  if (typeof v === 'string') { try { v = JSON.parse(v); } catch (e) { return null; } }
  if (!v || (!Array.isArray(v) && !Object.keys(v).length)) return null;
  var rows = Array.isArray(v) ? v : (v.partie || []).map(function (p, i) { return { partie: p, morceau: v.morceau[i], texte: v.texte[i] }; });
  if (!rows.length) return null;
  var by = {}, out = {};
  rows.forEach(function (r) { (by[r.partie] = by[r.partie] || []).push(r); });
  Object.keys(by).forEach(function (p) {
    out[p] = JSON.parse(by[p].sort(function (a, b) { return +a.morceau - +b.morceau; }).map(function (r) { return r.texte; }).join(''));
  });
  return out;
}

// The settings of the Fusion sheet "Target and pages" (dataset fto2_set_targets, Slate query q_fto2_set_targets, state key
// "reglages"; optional): the page reads them itself, so that a change in the sheet shows without waiting for the notebook's
// next run. One row per setting, columns nom and valeur (names written in any case, with or without accents, spaces or signs);
// the table comes as rows, one array per column, or JSON text. Each line below replaces the reference value (fto2/reference.py,
// page_settings) before the page uses it; a line missing or wrong keeps the reference value, and the console says which.
function fto2Reglages(SET, v) {
  function say(kind, t) { if (window.console && console[kind]) console[kind]('[FTO2] Fusion settings (q_fto2_set_targets): ' + t); }
  if (typeof v === 'string') { var s = v.trim(); try { v = s ? JSON.parse(s) : null; } catch (e) { say('warn', 'not readable as a table: every reference value is kept'); return []; } }
  if (!SET || !v || typeof v !== 'object') { say('warn', 'no table received: every reference value is kept'); return []; }
  function key(t) { return String(t == null ? '' : t).normalize('NFKD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^0-9a-z]/g, ''); }
  function text(x) { return String(x == null ? '' : x).replace(/\u00a0/g, ' ').trim(); }
  function num(x) {   // 0.25, '0,25', ' 4 ': a number; null otherwise
    if (typeof x === 'number') return isFinite(x) ? x : null;
    var t = text(x).replace(/,/g, '.');
    return /^[-+]?(\d+\.?\d*|\.\d+)(e[-+]?\d+)?$/i.test(t) ? parseFloat(t) : null;
  }
  function share(x) {   // 0.25, '0,25', '25 %' and 25 all mean a quarter
    var n = num(typeof x === 'string' ? x.replace(/%/g, '') : x);
    if (n != null && n > 1) n = n / 100;
    return n != null && n >= 0 && n <= 1 ? n : undefined;
  }
  function coef(x) { return Math.round((1 - x) * 1e12) / 1e12; }
  var rows = v;
  if (!Array.isArray(v)) {   // one array per column, as Slate gives a query result
    rows = []; var cols = Object.keys(v), n = 0;
    cols.forEach(function (c) { if (Array.isArray(v[c]) && v[c].length > n) n = v[c].length; });
    for (var i = 0; i < n; i++) { var o = {}; cols.forEach(function (c) { o[c] = Array.isArray(v[c]) ? v[c][i] : null; }); rows.push(o); }
  }
  var got = {};
  rows.forEach(function (r) {
    if (!r || typeof r !== 'object') return;
    var nom = null, val = null;
    Object.keys(r).forEach(function (c) { var k = key(c); if (k === 'nom') nom = r[c]; else if (k === 'valeur') val = r[c]; });
    if (key(nom)) got[key(nom)] = val;
  });
  var DEF = SET.defauts || (SET.defauts = {});
  // [line of the sheet, what it must be, its reading (undefined: wrong), the value the page has, how to set it]
  var LINES = [
    ['objectif_baisse', 'a share (0.25, 0,25 or 25 %)', share, function () { return SET.objectif_baisse; },
      function (x) { SET.objectif_baisse = x; SET.objectif_coef = coef(x); }],
    ['defaut_phase', 'SERIE, REC, FTI or empty', function (x) { var t = text(x).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toUpperCase();
      return ['SERIE', 'REC', 'FTI', ''].indexOf(t) >= 0 ? t : undefined; }, function () { return DEF.phase; }, function (x) { DEF.phase = x; }],
    ['defaut_responsabilite', 'letters among f, s, o', function (x) { var t = text(x).toLowerCase();
      return t && !/[^fso]/.test(t) ? 'fso'.split('').filter(function (c) { return t.indexOf(c) >= 0; }).join('') : undefined; },
      function () { return DEF.liab; }, function (x) { DEF.liab = x; }],
    ['defaut_periode', 'one of ytd, m1, mp, m3, m6, m12, all', function (x) { var t = text(x).toLowerCase();
      return ['ytd', 'm1', 'mp', 'm3', 'm6', 'm12', 'all'].indexOf(t) >= 0 ? t : undefined; }, function () { return DEF.preset; }, function (x) { DEF.preset = x; }],
    ['action_objectif_baisse', 'a share (0.3, 0,3 or 30 %)', share, function () { return SET.action_baisse; },
      function (x) { SET.action_baisse = x; SET.action_coef = coef(x); }],
    ['action_semaines_tenues', 'a whole number of weeks, 1 or more', function (x) { var n = num(x); return n != null && n >= 1 && Math.floor(n) === n ? n : undefined; },
      function () { return SET.action_semaines; }, function (x) { SET.action_semaines = x; }]
  ];
  var used = [], missing = [];
  LINES.forEach(function (L) {
    var k = key(L[0]);
    if (!Object.prototype.hasOwnProperty.call(got, k)) { missing.push(L[0]); return; }
    var x = L[2](got[k]), was = L[3]();
    if (x === undefined) { say('warn', L[0] + ': "' + text(got[k]) + '" is not ' + L[1] + ', the reference value ' + JSON.stringify(was) + ' is kept'); return; }
    if (x === was) return;
    L[4](x); used.push(L[0] + ' ' + JSON.stringify(x) + ' (reference ' + JSON.stringify(was) + ')');
  });
  if (used.length) say('info', 'taken from the sheet: ' + used.join(', '));
  if (missing.length) say('info', 'not in the sheet, the reference value is kept: ' + missing.join(', '));
  return used;
}

// ---------------------------------------------------------------- the two Slate tables -> the page's data
// NCs raised at FTO2 (plant FTO2 or FT02) created in the year
// followed (config/2_parametres.csv, annee: it comes with the settings), their
// defect lines, values numbered in dictionaries. Tables as Slate gives them (one array per column) or as rows.
function mftFromTables(ncIn, defIn, R) {
  function rows(t) {
    if (!t) return [];
    if (Array.isArray(t)) return t;
    var cols = Object.keys(t), n = 0, out = [];
    cols.forEach(function (c) { if (t[c] && t[c].length > n) n = t[c].length; });
    for (var i = 0; i < n; i++) { var o = {}; cols.forEach(function (c) { o[c] = t[c] ? t[c][i] : null; }); out.push(o); }
    return out;
  }
  function str(v) { return v == null ? '' : String(v); }
  function tidy(v, n) { return str(v).replace(/\s+/g, ' ').trim().slice(0, n || 320); }
  function id(v) { return str(v).trim().replace(/\.0$/, ''); }
  function isoWeek(s) { var d = new Date(s.slice(0, 10) + 'T00:00:00Z'), dw = (d.getUTCDay() + 6) % 7; d.setUTCDate(d.getUTCDate() - dw + 3);
    var y = d.getUTCFullYear(), j4 = new Date(Date.UTC(y, 0, 4)), w = 1 + Math.round(((d - j4) / 864e5 - 3 + ((j4.getUTCDay() + 6) % 7)) / 7); return y + '-W' + (w < 10 ? '0' : '') + w; }
  var plan = R.plan || {}, alias = R.alias || [];
  // the NC's Responsabilité group, as the dashboard decides it (model.js liabCat): f FTO2 liable, s a supplier's number, o the others
  function liabGroup(r) { if (Math.round(parseFloat(r.on_aec) || 0) === 1) return 'f'; var c = str(r.liability).replace(/[\[\]\s]/g, '').replace(/^0+/, ''); return /^\d+$/.test(c) ? 's' : 'o'; }
  function planProd(line, prod, station) {   // the settings' product aliases, then the plan's name; '' when not in the plan
    var p = prod || 'Other';
    if (!plan[p.toUpperCase()]) for (var i = 0; i < alias.length; i++) { var x = alias[i];
      if (x[0] === line && new RegExp(x[1]).test(p) && (!x[2] || new RegExp(x[2], 'i').test(station || ''))) { p = x[3]; break; } }
    return plan[p.toUpperCase()] || '';
  }
  var keys = ['line', 'phase', 'msn', 'station', 'where', 'cat', 'rca', 'sub', 'code', 'fin', 'prod'], dic = {}, idx = {};
  keys.forEach(function (k) { dic[k] = []; idx[k] = {}; });
  function code(k, v) { v = tidy(v, 120); if (!(v in idx[k])) { idx[k][v] = dic[k].length; dic[k].push(v); } return idx[k][v]; }
  // the comparison year too: a week, a month or an action is compared with the weeks before it, across the new year
  var year = R.settings && (R.settings.annee_ref || R.settings.annee), since = year ? year + '-01-01' : '';
  var n = rows(ncIn).map(function (r) { return { r: r, created: str(r.created), plant: str(r.plant).trim().toUpperCase() }; })
    .filter(function (x) { return (x.plant === 'FTO2' || x.plant === 'FT02') && x.created >= since; });
  n.sort(function (a, b) { return a.created < b.created ? -1 : a.created > b.created ? 1 : 0; });
  var ncs = [], pos = {}, to = '';
  n.forEach(function (x) { var r = x.r, c = x.created.slice(0, 10), k = id(r.nc); pos[k] = ncs.length; if (c > to) to = c;
    ncs.push([k, c, code('line', str(r.line) || '—'), code('phase', r.phase), code('msn', id(r.msn)), code('station', r.station), code('where', r.where_found),
      code('prod', planProd(str(r.line), str(r.product), str(r.station))), liabGroup(r)]); });   // last: the Responsabilité group
  var defs = [];
  rows(defIn).forEach(function (r) { var i = pos[id(r.nc)]; if (i == null) return;
    defs.push([i, code('cat', r.cat), code('rca', r.rca), code('sub', r.sub), code('code', r.subcode), code('fin', r.fin), Math.round(parseFloat(r.minor) || 0), tidy(r.text)]); });
  var codes = {}; dic.code.forEach(function (c) { if (c) codes[c] = tidy((R.codes || {})[c] || '', 90); });
  var codesEn = {}; dic.code.forEach(function (c) { if (c && (R.codesEn || {})[c]) codesEn[c] = R.codesEn[c]; });   // the English page (2 Nov)
  return { to: to, toWeek: to ? isoWeek(to) : '', ncs: ncs, defs: defs, dic: dic, codes: codes, codesEn: codesEn, vol: R.vol || null, msnEnd: R.msnEnd || {}, settings: R.settings };
}

// ---------------------------------------------------------------- the store: the page's actions and alarm marks, in this browser
/* ===== STORE START ===== */
// The store of the MFT page. Its calls:
// use('db') gives collection(name), then doc(id) with set, update and delete, and onSnapshot; note(lang) says where the actions
// are kept. Neither page has a shared store: the shared actions are the table config/1_actions_mft.csv (they reach the page in
// FTO2_MFT_REF.actions and replace this browser's copy at every load); an action typed on the page is kept in this browser
// only, until it is added to the table.
window.FTO2_STORE = (function () {
  var mem = {}, subs = {}, ok = true, KEY = 'mft-fto2-slate-';
  function copy(o) { return JSON.parse(JSON.stringify(o)); }
  function save(c) { try { localStorage.setItem(KEY + c, JSON.stringify(mem[c])); } catch (e) { ok = false; } }
  function load(c) {
    if (mem[c]) return mem[c];
    var v = null; try { v = JSON.parse(localStorage.getItem(KEY + c) || 'null'); } catch (e) { ok = false; }
    v = v || {};
    if (c === 'actions') (window.FTO2_MFT_REF.actions || []).forEach(function (a) { v[a.id] = copy(a); });   // the table wins
    mem[c] = v; save(c); return v;
  }
  function emit(c) { setTimeout(function () {
    var docs = Object.keys(mem[c]).map(function (k) { var x = mem[c][k]; return { id: k, data: function () { return copy(x); } }; });
    (subs[c] || []).forEach(function (f) { try { f({ docs: docs }); } catch (e) { } }); }, 0); }
  function collection(c) {
    load(c);
    return {
      doc: function (k) {
        k = k || 'a' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
        return {
          id: k,
          set: function (b) { mem[c][k] = copy(b); save(c); emit(c); return Promise.resolve(); },
          update: function (f) { if (!mem[c][k]) return Promise.reject(new Error('introuvable')); Object.assign(mem[c][k], copy(f)); save(c); emit(c); return Promise.resolve(); },
          delete: function () { delete mem[c][k]; save(c); emit(c); return Promise.resolve(); }
        };
      },
      onSnapshot: function (f) { (subs[c] = subs[c] || []).push(f); emit(c); return function () { subs[c] = subs[c].filter(function (g) { return g !== f; }); }; }
    };
  }
  return {
    use: function (k) { return Promise.resolve(k === 'db' ? { collection: collection } : null); },
    note: function (lang) { try { localStorage.setItem(KEY + 'probe', '1'); localStorage.removeItem(KEY + 'probe'); } catch (e) { ok = false; }
      if (lang === 'en') return ok ? 'Actions saved in this browser, on this computer: they are not shared with the app’s other users.'
        : 'The browser blocks saving: actions changed here will be lost on reload.';
      return ok ? 'Actions enregistrées dans ce navigateur, sur ce poste : elles ne sont pas partagées avec les autres utilisateurs de l’app.'
      : 'Le navigateur bloque l’enregistrement : les actions modifiées ici seront perdues au rechargement.'; }
  };
})();
/* ===== STORE END ===== */

// ---------------------------------------------------------------- the shared store: the actions kept for everyone (Slate only)
// Used when the sandbox's state has the key "store" (the query q_fto2_mft_store); without it, the browser store above. The
// actions are kept in one object of the NC writer's object type ("a30 Nc Writer Dataset"): the object whose Msn is MFT-ACTIONS,
// its Texte Sap holding every action as JSON {page, saved_at, actions}. Each save adds such an object; the page reads the one
// saved last (saved_at). A row without the page's mark is not read. With no row at
// all, the page starts from the table's actions (config/1_actions_mft.csv), and its first save writes them into the store.
// Writing takes the NC writer's route: at each change the page fires the event "save" with the row to write (and puts it in
// its state, key "store_row"); a Slate event copies it into a variable, the object type's Action widget takes its default
// values from that variable, and the user presses Submit. Meanwhile the page keeps its own copy, and its note asks to press
// Submit until the query brings back a row saved at or after that copy.
// Same calls as the browser store (use, collection, doc, set, update, delete, onSnapshot, note), so the page itself does not
// change. The alarms' marks (collection 'alarmes') stay in the browser store.
//   api: SlateFunctions; local: the browser store; seed: the table's actions (FTO2_MFT_REF.actions)
function fto2SharedStore(api, local, seed) {
  var MSN = 'MFT-ACTIONS', PAGE = 'MFT', LIMIT = 30000;
  var mem = {}, subs = [], ready = false, cur = '', pending = '', size = 0, bad = 0, open = null;
  var whenRead = new Promise(function (res) { open = res; });   // the page gets the store once the query has answered
  function copy(o) { return JSON.parse(JSON.stringify(o)); }
  function key(t) { return String(t == null ? '' : t).normalize('NFKD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^0-9a-z]/g, ''); }
  // a property of a row: msn, Msn, MSN, texte_sap, texteSap...; an object of an Ontology query may hold them one level down
  // (properties, ...)
  function cell(r, name) {
    var ks = Object.keys(r), i;
    for (i = 0; i < ks.length; i++) if (key(ks[i]) === name) return r[ks[i]];
    for (i = 0; i < ks.length; i++) { var o = r[ks[i]]; if (o && typeof o === 'object' && !Array.isArray(o)) { var x = cell(o, name); if (x != null) return x; } }
    return null;
  }
  function rowsOf(v) {   // rows, or one array per column, or (an Ontology query) the objects under data / objects
    if (Array.isArray(v)) return v;
    var list = v.data || v.objects || v.results || v.result;   // result: an HTTP query's extractor ("result": "$") wraps the answer
    if (Array.isArray(list) && (!list.length || (list[0] && typeof list[0] === 'object' && !Array.isArray(list[0])))) return list;
    if (list && typeof list === 'object' && !Array.isArray(list)) return rowsOf(list);
    var cols = Object.keys(v), n = 0, out = [];
    cols.forEach(function (c) { if (Array.isArray(v[c]) && v[c].length > n) n = v[c].length; });
    for (var i = 0; i < n; i++) { var o = {}; cols.forEach(function (c) { o[c] = Array.isArray(v[c]) ? v[c][i] : null; }); out.push(o); }
    return out;
  }
  // a value of the state key: the latest store row, and how many later store rows could not be read; null before the query answers
  function read(v) {
    if (typeof v === 'string') { var s = v.trim(); if (!s) return null; try { v = JSON.parse(s); } catch (e) { return null; } }
    if (!v || typeof v !== 'object' || (!Array.isArray(v) && !Object.keys(v).length)) return null;
    var best = null, cut = [];
    rowsOf(v).forEach(function (r) {
      if (!r || typeof r !== 'object' || String(cell(r, 'msn') == null ? '' : cell(r, 'msn')).trim().toUpperCase() !== MSN) return;
      var t = cell(r, 'textesap'), x = null;
      try { x = typeof t === 'string' ? JSON.parse(t) : t; } catch (e) {   // a text cut short: kept aside, to say so if it is the latest
        var raw = String(t), at = /"saved_at":"([^"]*)"/.exec(raw);
        if (raw.indexOf('"page":"' + PAGE + '"') >= 0) cut.push(at ? at[1] : '');
        return;
      }
      if (!x || typeof x !== 'object' || x.page !== PAGE || !Array.isArray(x.actions)) return;   // another tool's row
      x.saved_at = String(x.saved_at || ''); x.size = typeof t === 'string' ? t.length : JSON.stringify(x).length;
      if (!best || x.saved_at > best.saved_at) best = x;
    });
    return { best: best, bad: cut.filter(function (at) { return !best || !at || at > best.saved_at; }).length };
  }
  function adopt(list, at, n) {   // this copy becomes a row's actions (or the table's)
    mem = {}; (list || []).forEach(function (a) { if (a && a.id != null) { var o = copy(a); delete o.id; mem[String(a.id)] = o; } });
    cur = at; size = n || 0;
  }
  function emit() { setTimeout(function () {
    var docs = Object.keys(mem).map(function (k) { var x = mem[k]; return { id: k, data: function () { return copy(x); } }; });
    subs.slice().forEach(function (f) { try { f({ docs: docs }); } catch (e) { } }); }, 0); }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function send() {   // the whole list as one row, the way the NC writer hands over an NC: state key "store_row", then the event "save"
    var t = Date.now(), c = Date.parse(cur); if (isFinite(c) && t <= c) t = c + 1;   // later than the copy it changes, whatever this computer's clock says
    var d = new Date(t), at = d.toISOString(), list = Object.keys(mem).map(function (k) { return Object.assign({ id: k }, mem[k]); });
    var text = JSON.stringify({ page: PAGE, saved_at: at, actions: list });
    var row = { timestamp: d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds()),
      msn: MSN, produit: 'MFT', detection: 'store', total_defauts: list.length, texte_sap: text };
    if (api.setState.length >= 2) api.setState('store_row', row); else { var st = {}; st.store_row = row; api.setState(st); }
    api.triggerEvent('save', row);
    cur = pending = at; size = text.length;
    if (size > LIMIT && window.console) console.warn('[FTO2 MFT] the actions take ' + size + ' characters: beyond ' + LIMIT + ', the save may cut them');
  }
  function change(f) {   // a change of the actions: on this copy at once (the page redraws), then sent
    if (!ready) return Promise.reject(new Error('the shared actions are not read yet'));
    if (!api || typeof api.setState !== 'function' || typeof api.triggerEvent !== 'function') return Promise.reject(new Error('SlateFunctions.setState / triggerEvent missing'));
    var keep = copy(mem), was = [cur, pending, size], err = f(); if (err) return err;
    try { send(); } catch (e) {
      mem = keep; cur = was[0]; pending = was[1]; size = was[2];
      if (window.console) console.error('[FTO2 MFT] the actions could not be sent', e);
      return Promise.reject(e);
    }
    emit(); return Promise.resolve();
  }
  var actions = {
    doc: function (k) {
      k = k || 'a' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
      return {
        id: k,
        set: function (b) { return change(function () { mem[k] = copy(b); }); },
        update: function (f) { return change(function () { if (!mem[k]) return Promise.reject(new Error('introuvable')); Object.assign(mem[k], copy(f)); }); },
        delete: function () { return change(function () { delete mem[k]; }); }
      };
    },
    onSnapshot: function (f) { subs.push(f); if (ready) emit(); return function () { subs = subs.filter(function (g) { return g !== f; }); }; }
  };
  return {
    use: function (k) {
      if (k !== 'db') return Promise.resolve(null);
      return Promise.all([whenRead, local && local.use ? local.use('db') : null]).then(function (x) {
        var ldb = x[1];
        return { collection: function (c) { return c === 'actions' ? actions : ldb ? ldb.collection(c) : null; } };
      });
    },
    note: function (lang) {
      var en = lang === 'en', out = [], n = size.toLocaleString(en ? 'en-GB' : 'fr-FR');
      if (pending) out.push(en ? 'Saving the change for everyone… (if this note stays, press Submit in the actions’ save form)'
        : 'Enregistrement de la modification pour tous… (si cette note reste, appuyez sur « Submit » dans le formulaire d’enregistrement des actions)');
      if (size > LIMIT) out.push(en ? 'Warning: the actions take ' + n + ' characters; beyond 30,000 the save may cut them. Delete some closed actions.'
        : 'Attention : les actions font ' + n + ' caractères ; au-delà de 30 000, l’enregistrement risque de les couper. Supprimez des actions closes.');
      if (bad) out.push(en ? 'A later save of the actions cannot be read (its text was cut?): the page shows the last one it can read.'
        : 'Un enregistrement plus récent des actions est illisible (texte coupé ?) : la page montre le dernier lisible.');
      return out.join(' ');
    },
    // a value of the state key "store": the first one gives the actions; then a later save replaces this copy, and a row
    // saved at or after this copy's last change ends the note asking for Submit
    take: function (v) {
      var r = read(v), b = r && r.best; if (!r) return;
      bad = r.bad;
      if (!ready) { if (b) adopt(b.actions, b.saved_at, b.size); else adopt(seed, '', 0); ready = true; open(); }
      else if (b && b.saved_at > cur) adopt(b.actions, b.saved_at, b.size);
      if (pending && b && b.saved_at >= pending) pending = '';
      emit();
    },
    ready: function () { return ready; }
  };
}

// ---------------------------------------------------------------- the page, started once the tables are in
function mftMain() {
var D = window.FTO2_MFT_D;
(function () {
  'use strict';
  // ---------------------------------------------------------------- data
  var DIC = D.dic, NCS = D.ncs, DEFS = D.defs, CODES = D.codes || {};
  // the dashboard's nine categories and colours (2 Nov: Kitting Factory, FOD and Autre are categories like the others, as on the dashboard since 29 Oct)
  // the pages' settings, from config/ through the backend (fto2/reference.py page_settings)
  var SET = D.settings;
  window.FTO2_ALARM_P = SET.alarmes;   // the alarm settings, read by the alarm block below (config/3_alarmes.csv)
  // the year followed (config/2_parametres.csv, annee): the weeks of the production volume and of the alarms are its weeks
  var YEAR = String(SET.annee || String(D.to).slice(0, 4)); window.FTO2_YEAR = +YEAR;
  // the dashboard's categories and colours (config/2_categories.csv) and line colours (config/2_lignes.csv)
  var CATS = SET.categories.filter(function (c) { return c.couleur; }).map(function (c) { return c.nom; });
  var CATC = {}; SET.categories.forEach(function (c) { if (c.couleur) CATC[c.nom] = 'var(--c' + c.couleur + ')'; });
  var LINEC = {}; Object.keys(SET.lignes).forEach(function (l) { LINEC[l] = 'var(--l' + SET.lignes[l] + ')'; });
  var LEVELS = { cat: 'Catégorie', rca: 'Cause', sub: 'Sous-catégorie', code: 'Sous-code', grp: 'Code', fin: 'FIN', where: 'Lieu de détection', station: 'Poste', msn: 'MSN', prod: 'Produit' };
  var WHERE_FR = { 'Final inspection': 'Contrôle final', 'TEST': 'Test', 'Cables': 'Câbles', 'In-process (internal)': 'En cours de fabrication', 'Supplier': 'Fournisseur', 'QUALITE': 'Qualité', 'Customer return': 'Retour client', 'NC Interne': 'NC interne' };
  var STATUSES = ['À lancer', 'En cours', 'Clos', 'Abandonnée'];
  function catCol(c) { return CATC[c] || 'var(--dim)'; }
  function fld(d, k) { var n = NCS[d[0]]; return k === 'cat' ? DIC.cat[d[1]] : k === 'rca' ? DIC.rca[d[2]] : k === 'sub' ? DIC.sub[d[3]] : k === 'code' ? DIC.code[d[4]] : k === 'fin' ? DIC.fin[d[5]] : k === 'where' ? DIC.where[n[6]] :
    k === 'grp' ? grpOf(DIC.code[d[4]]) : k === 'station' ? DIC.station[n[5]] : k === 'msn' ? DIC.msn[n[4]] : k === 'prod' ? (DIC.prod ? DIC.prod[n[7]] : '') : k === 'text' ? d[7] : ''; }
  function grpOf(c) { var m = /^[A-Z]\d{2}/.exec(c || ''); return m ? m[0] : ''; }   // the code of a sub-code: Q11-003 -> Q11
  // a FIN that is a product's name, not an equipment's: a product of the production plan (its name, an NC product label it matches,
  // the plan products of the NCs), or a product written the way the alias rules write them (742VU, 5881VB...). The plan and the
  // rules come with the reference data (FTO2_MFT_REF: plan, alias). Left out of the FIN lists.
  var PROD_NAMES = {}, PROD_RES = [];
  (function () {
    var R = window.FTO2_MFT_REF || {}, put = function (v) { v = String(v || '').trim().toUpperCase(); if (v) { PROD_NAMES[v] = 1; PROD_NAMES[v.replace(/[\s\-]+/g, '')] = 1; } };
    Object.keys(R.plan || {}).forEach(function (k) { put(k); put(R.plan[k]); });
    (DIC.prod || []).forEach(put);
    (R.alias || []).forEach(function (x) { put(x[3]); try { PROD_RES.push(new RegExp(x[1])); } catch (e) { } });
  })();
  function isProductName(f) {
    var v = String(f || '').trim().toUpperCase(); if (!v) return false;
    return !!(PROD_NAMES[v] || PROD_NAMES[v.replace(/[\s\-]+/g, '')]) || PROD_RES.some(function (re) { return re.test(v); });
  }
  // English: FR / EN at the top right, as the dashboard, remembered in the browser. The data keep their words (NC
  // texts, FIN, stations); category and cause names are the dashboard's English ones, sub-code descriptions the official sheet's.
  var LANG = 'fr'; try { LANG = localStorage.getItem('mft-fto2-lang') === 'en' ? 'en' : 'fr'; } catch (e) { }
  var NAME_EN = {
    'MEO Facteur humain': 'Workmanship (human factor)', 'Erreur Branchement': 'Connection error', 'Élément Manquant': 'Missing item',
    'Élément Endommagé': 'Damaged item', 'Déverrouillage': 'Unlocked contact', 'Grounding/Bonding': 'Grounding/Bonding',
    'Kitting Factory': 'Kitting Factory', 'FOD': 'FOD', 'Autre': 'Other', 'Non classé': 'Not classified',
    'Inversion': 'Swapped wires', 'Mauvaise Borne': 'Wrong terminal', 'Non Connecté': 'Not connected',
    'Frettage Incorrect': 'Incorrect lacing', 'Serrage Incorrect': 'Incorrect tightening', 'Mauvais Cheminement': 'Incorrect routing',
    'MEO Gainage': 'Sleeving workmanship', 'Finition Inachevée': 'Incomplete finishing',
    'Défaut de Sertissage sur câble standard': 'Crimping defect, standard cable', 'Défaut de Sertissage sur câble spécifique': 'Crimping defect, special cable',
    'Erreur Fixation ou Protection': 'Wrong fastener or protection', 'Erreur Composant Électrique': 'Wrong electrical component',
    'Fixation ou Protection Manquante': 'Missing fastener or protection', 'Obturateur Manquant': 'Missing blanking plug',
    'Câble ou Élément Manquant': 'Missing cable or item', 'Identification Manquante': 'Missing identification',
    'Câble Endommagé': 'Damaged cable', 'Composant Endommagé': 'Damaged component', 'Protection Endommagée': 'Damaged protection',
    'Structure Endommagée': 'Damaged structure', 'Défaut de Métallisation': 'Bonding defect', "Défaut d'Impression": 'Printing defect',
    'Erreur Dossier': 'Documentation error' };
  var WHERE_EN = { 'Final inspection': 'Final inspection', 'TEST': 'Test', 'Cables': 'Cables', 'In-process (internal)': 'Internal', 'Supplier': 'Supplier', 'QUALITE': 'Quality', 'Customer return': 'Customer return', 'NC Interne': 'Internal' };
  var UI_EN = {
    'MFT Qualité FTO2': 'FTO2 Quality MFT', 'Ligne': 'Line', 'Production': 'Production', 'Période': 'Period', 'du': 'from', 'au': 'to', 'Alarmes': 'Alarms', 'Langue': 'Language',
    'Onglets': 'Tabs', 'Pareto de la semaine': 'Weekly Pareto', 'Analyse': 'Analysis', 'Suivi des actions': 'Action tracking', 'Catégories': 'Categories', 'Causes': 'Causes',
    'Sous-codes officiels': 'Official sub-codes', 'FIN (repères)': 'FIN (reference)', 'Date': 'Date', 'Poste': 'Station', 'Cause': 'Cause', 'Défaut': 'Defect', 'Voir plus': 'Show more',
    'Défauts par semaine, par catégorie': 'Defects per week, by category', '26 semaines': '26 weeks', 'Ce qui monte': 'Rising', 'Ce qui baisse': 'Falling',
    '4 sem. vs 8 préc.': '4 wk vs 8 before', 'Nouveau cette semaine': 'New this week', 'vs 8 sem. préc.': 'vs 8 wk before', 'FIN récurrents': 'Recurring FINs',
    '8 sem. · 3 avions ou plus': '8 wk · 3 aircraft or more', 'Statut': 'Status', '+ Nouvelle action': '+ New action',
    'Catégorie': 'Category', 'Sous-catégorie': 'Sub-category', 'Sous-code': 'Sub-code', 'Code': 'Code', 'Lieu de détection': 'Where found', 'Produit': 'Product', 'Texte du défaut': 'Defect text',
    'est l’une des valeurs': 'is one of the values', 'contient l’un des mots': 'contains one of the words', 'expression régulière': 'regular expression',
    'À lancer': 'To start', 'En cours': 'In progress', 'Clos': 'Closed', 'Abandonnée': 'Dropped',
    'Retirer {x}': 'Remove {x}', 'Tout retirer': 'Remove all', 'Toutes les lignes': 'All lines', 'Toutes': 'All', 'Tout': 'All', 'Série': 'Series', 'Responsabilité': 'Liability', 'Fournisseurs': 'Suppliers', 'Autres': 'Others',
    'en cours': 'in progress', 'fermeture': 'shutdown', 'Semaine': 'Week', '1 mois': '1 month', '3 mois': '3 months', 'Personnalisée': 'Custom', 'Jusqu’à la semaine': 'Up to week',
    'Données au {d}': 'Data as of {d}', 'Ouvertes': 'Open', 'Closes': 'Closed',
    'A400M : les textes des NC sont masqués, aucun défaut n’est lu.': 'A400M: the NC texts are hidden, no defect is read.', 'Aucun défaut sur la période.': 'No defect in the period.',
    '{n} défauts sur la période': '{n} defects in the period', 'avant : {r} par semaine ({w})': 'before: {r} per week ({w})', ', soit {t} sur {p} semaines': ', i.e. {t} over {p} weeks',
    'catégorie : {c}': 'category: {c}', ' à ': ' to ', '{n} semaines': '{n} weeks', 'Semaine de fermeture': 'Shutdown week', 'Semaine en cours, incomplète': 'Current week, incomplete',
    ' / sem.': ' / wk', 'moy. {w}': 'avg {w}', ', ramenée à {n} sem.': ', scaled to {n} wk', 'pas de semaine avant': 'no week before',
    'Compter': 'Count', '{n} NC sur la période': '{n} NCs in the period', 'Une NC compte une fois par barre, même avec plusieurs défauts.': 'An NC counts once per bar, even with several defects.',
    'NC': 'NCs', 'Défauts': 'Defects', 'Défauts par NC': 'Defects per NC', 'Première catégorie': 'Top category', '{n} défauts': '{n} defects', '{n} défaut': '{n} defect',
    'Les défauts': 'Defects', '{n} lignes': '{n} lines', '{n} ligne': '{n} line', 'Aucun défaut.': 'No defect.', ' · jusqu’à ': ' · up to ', 'Non classé': 'Not classified', 'Total': 'Total',
    'Début d’action': 'Action start', 'Défauts par semaine': 'Defects per week', '▼ Débuts d’action': '▼ Action starts', 'Fermeture / en cours': 'Shutdown / in progress',
    'nouveau': 'new', 'Aucune cause en nette hausse.': 'No cause clearly rising.', 'Aucune cause en nette baisse.': 'No cause clearly falling.',
    '{n} défauts cette semaine': '{n} defects this week', '{n} défaut cette semaine': '{n} defect this week', 'Rien de nouveau cette semaine.': 'Nothing new this week.',
    '{k} avions · {n} défauts · surtout {r}': '{k} aircraft · {n} defects · mostly {r}', 'Aucun repère sur 3 avions ou plus.': 'No FIN on 3 aircraft or more.',
    'Code / sous-code': 'Code / sub-code', ' (tous ses sous-codes)': ' (all its sub-codes)', 'Problème à préciser': 'Problem to specify', 'correspond à': 'matches', ' · et ': ' · and ',
    'Objectif atteint': 'Target met', 'Sous l’objectif': 'Below target', 'En baisse': 'Falling', 'En hausse': 'Rising', 'Stable': 'Steady', 'Trop tôt pour juger': 'Too early to tell',
    'Pas de référence': 'No reference', 'Date de début à saisir': 'Start date to enter', ' depuis {n} sem.': ' for {n} wk',
    ' · fermeture, non comptée': ' · shutdown, not counted', ' · en cours, non comptée': ' · in progress, not counted', 'moyenne 4 sem. : {v}': '4-wk average: {v}', 'objectif {v}': 'target {v}',
    'Action': 'Action', 'Le problème suivi, semaine par semaine': 'The problem followed, week by week', 'défauts par semaine': 'defects per week', 'moyenne glissante 4 sem.': '4-wk rolling average',
    'référence (8 sem. avant)': 'reference (8 wk before)', 'objectif −{p} %': 'target −{p}%', 'Réf.': 'Ref.', '(début de l’analyse)': '(analysis start)', 'Objectif': 'Target',
    '{n} sem. sur 4': '{n} wk of 4', 'Actuel': 'Current', 'tenu {n} sem.': 'held {n} wk', 'quelqu’un': 'someone',
    '{n} actions': '{n} actions', '{n} action': '{n} action', '{n} à l’objectif': '{n} on target', '{n} en hausse': '{n} rising',
    'Aucune action close': 'No closed action', 'Aucune action ouverte': 'No open action', 'Aucune action': 'No action', ' sur {l}': ' on {l}',
    'Problème suivi': 'Problem followed', 'Porteur de l’action': 'Action owner', 'Porteur de l’analyse': 'Analysis owner', 'Début de l’analyse': 'Analysis start',
    'Début de l’action': 'Action start', 'Bénéfice attendu': 'Expected benefit', 'Rédigée par': 'Written by', 'Close le': 'Closed on',
    'Supprimer ce point ?': 'Delete this point?', 'Oui': 'Yes', 'Non': 'No', 'Supprimer': 'Delete', 'Défauts, analyse, action et suivi': 'Defects, analysis, action and follow-up',
    '{n} points': '{n} points', '{n} point': '{n} point', 'Catégorie (tracker)': 'Category (tracker)', 'Défauts constatés': 'Defects found', 'Analyse de cause racine': 'Root cause analysis',
    'Informations': 'Information', 'Point de la semaine': 'This week’s point', 'Votre nom': 'Your name', 'Ajouter le point': 'Add the point', 'Modifier': 'Edit', 'Rouvrir': 'Reopen',
    'Clore': 'Close', 'Supprimer cette action ?': 'Delete this action?', 'Oui, supprimer': 'Yes, delete', 'Modifier l’action': 'Edit the action', 'Nouvelle action': 'New action',
    'Fermer': 'Close', 'Choisir…': 'Choose…', 'Titre': 'Title', 'Ex. : Erreurs et inversions de branchement': 'E.g.: connection errors and swapped wires',
    'Plus de détails': 'More details', 'Bénéfice attendu (date)': 'Expected benefit (date)', 'Catégorie (comme dans le tracker)': 'Category (as in the tracker)',
    'Ex. : Erreurs/Inversions de branchements': 'E.g.: connection errors / swaps', 'Enregistrer': 'Save', 'Créer l’action': 'Create the action', 'Annuler': 'Cancel',
    ' · tous ses sous-codes ({n})': ' · all its sub-codes ({n})', ' · tous ses sous-codes': ' · all its sub-codes', 'Simple': 'Simple', 'Expert': 'Expert',
    'Un code (Q11 : tous ses sous-codes) ou un sous-code (Q11003 ou Q11-003).': 'A code (Q11: all its sub-codes) or a sub-code (Q11003 or Q11-003).',
    'Une ou plusieurs conditions ; un défaut est suivi s’il les remplit toutes.': 'One or more conditions; a defect is followed if it meets them all.',
    'Code ou sous-code': 'Code or sub-code', 'Ex. : Q11 ou Q11-003': 'E.g.: Q11 or Q11-003', 'Ajouter': 'Add', 'Retirer': 'Remove', 'Aucun code choisi.': 'No code chosen.',
    'Colonne': 'Column', 'Type de filtre': 'Filter type', 'Expression régulière': 'Regular expression', 'un mot ou un bout de texte': 'a word or a piece of text', 'une valeur': 'a value',
    'Valeur': 'Value', 'Retirer la condition': 'Remove the condition', 'Aucune valeur.': 'No value.', '+ Ajouter une condition': '+ Add a condition',
    '<b>est</b> : la valeur exacte, l’une de la liste. <b>contient</b> : l’un des mots ou bouts de texte, sans tenir compte des accents ni des majuscules (utile sur le texte du défaut).':
      '<b>is</b>: the exact value, one of the list. <b>contains</b>: one of the words or pieces of text, ignoring accents and capitals (useful on the defect text).',
    '<b>Expression régulière</b> : très puissante mais difficile à écrire. Demandez-la à Gemini, par exemple : « Écris une expression régulière JavaScript, insensible à la casse, qui trouve un câble DR20 ou DR24 coupé trop court ». Décrivez ce que vous cherchez sans coller de texte de NC, puis vérifiez les exemples trouvés ci-dessous.':
      '<b>Regular expression</b>: very powerful but hard to write. Ask Gemini for it, for example: “Write a case-insensitive JavaScript regular expression that finds a DR20 or DR24 cable cut too short”. Describe what you are looking for without pasting any NC text, then check the examples found below.',
    'Saisissez l’expression.': 'Type the expression.', 'Expression non valide': 'Invalid expression',
    'Choisissez au moins un code pour suivre le problème.': 'Choose at least one code to follow the problem.', 'Complétez chaque condition pour suivre le problème.': 'Complete each condition to follow the problem.',
    'Ce problème sur {l} : {n} défauts sur les 8 dernières semaines de travail ({w} par semaine), {a} depuis janvier.': 'This problem on {l}: {n} defects over the last 8 working weeks ({w} per week), {a} since January.',
    'Ce problème sur {l} : {n} défaut sur les 8 dernières semaines de travail ({w} par semaine), {a} depuis janvier.': 'This problem on {l}: {n} defect over the last 8 working weeks ({w} per week), {a} since January.',
    'Aucun défaut avec : {x}.': 'No defect with: {x}.', 'Le stockage de la page est plein : supprimez des actions closes.': 'The page’s storage is full: delete some closed actions.',
    'Vous ne pouvez pas modifier les actions de cette page (accès en lecture).': 'You cannot change this page’s actions (read access).',
    'Enregistrement impossible pour l’instant, réessayez dans un moment.': 'Cannot save for now, try again in a moment.', 'Choisissez la ligne.': 'Choose the line.',
    'Donnez au moins un titre.': 'Give at least a title.', 'Indiquez qui rédige l’action.': 'Say who writes the action.', 'L’expression régulière n’est pas valide.': 'The regular expression is not valid.',
    'Toutes les causes': 'All causes', 'poste {v}': 'station {v}', 'MSN {m} : {n} NC, un {p} en a {d} d’habitude': 'MSN {m}: {n} NCs, a {p} usually has {d}',
    '{w} en hausse sur plusieurs lignes depuis {s}': '{w} rising on several lines since {s}', '{w} en hausse lente depuis {s}': '{w} creeping up since {s}', '{w} en hausse depuis {s}': '{w} rising since {s}',
    'dont {l}': 'incl. {l}', 'aussi : {l}': 'also: {l}', 'action en cours : {t}': 'action in progress: {t}', 'Majeure': 'Major', 'Mineure': 'Minor', '→ Pareto de la semaine': '→ Weekly Pareto',
    'Remettre': 'Put back', 'Vu': 'Seen', 'À regarder · {w}': 'To look at · {w}', 'Pas encore assez de semaines pour comparer.': 'Not enough weeks yet to compare.', 'Rien à signaler.': 'Nothing to report.',
    '{n} autres': '{n} more', '{n} autre': '{n} more', '+{n} sur les autres lignes': '+{n} on the other lines', 'Vues ({n})': 'Seen ({n})',
    'Accès en lecture : vous voyez les actions sans pouvoir les modifier.': 'Read access: you see the actions but cannot change them.',
    'La liste des actions ne se met plus à jour : rechargez la page.': 'The action list no longer updates: reload the page.' };
  function T(s0, o) { var t = LANG === 'en' && UI_EN[s0] != null ? UI_EN[s0] : s0; return o ? t.replace(/\{(\w+)\}/g, function (m, k) { return o[k] != null ? o[k] : m; }) : t; }
  function L(v) { return LANG === 'en' && NAME_EN[v] ? NAME_EN[v] : v; }   // a category or cause name
  function codeDesc(v) { return LANG === 'en' && D.codesEn && D.codesEn[v] ? D.codesEn[v] : CODES[v] || ''; }
  function whereName(v) { return (LANG === 'en' ? WHERE_EN[v] : WHERE_FR[v]) || v; }
  function lev(k) { return T(LEVELS[k]); }
  function COL() { return LANG === 'en' ? ': ' : ' : '; }
  function PC() { return LANG === 'en' ? '%' : ' %'; }
  function WK() { return LANG === 'en' ? 'W' : 'S'; }
  function applyText() {
    document.documentElement.lang = LANG;
    document.querySelectorAll('[data-i]').forEach(function (el) { if (el._fr == null) el._fr = el.textContent; el.textContent = T(el._fr); });
    document.querySelectorAll('[data-ia]').forEach(function (el) { if (el._fra == null) el._fra = el.getAttribute('aria-label'); el.setAttribute('aria-label', T(el._fra)); });
    document.querySelectorAll('#lang [data-lang]').forEach(function (b) { b.setAttribute('aria-pressed', String(b.getAttribute('data-lang') === LANG)); });
  }
  function shown(k, v) { return k === 'code' ? (v + (codeDesc(v) ? ' · ' + codeDesc(v) : '')) : k === 'where' ? whereName(v) : k === 'cat' || k === 'rca' ? L(v) : v; }
  // the category a value belongs to (most frequent), for its colour
  var VCAT = { rca: {}, sub: {}, code: {}, fin: {} };
  (function () { var t = { rca: {}, sub: {}, code: {}, fin: {} };
    DEFS.forEach(function (d) { var c = DIC.cat[d[1]]; ['rca', 'sub', 'code', 'fin'].forEach(function (k) { var v = fld(d, k); if (!v) return; var o = t[k][v] || (t[k][v] = {}); o[c] = (o[c] || 0) + 1; }); });
    Object.keys(t).forEach(function (k) { Object.keys(t[k]).forEach(function (v) { var o = t[k][v]; VCAT[k][v] = Object.keys(o).sort(function (a, b) { return o[b] - o[a]; })[0]; }); }); })();
  function valCol(k, v) { return k === 'cat' ? catCol(v) : VCAT[k] && VCAT[k][v] ? catCol(VCAT[k][v]) : 'var(--ink-2)'; }

  // ---------------------------------------------------------------- weeks (ISO)
  function isoWeek(s) { var d = new Date(s.slice(0, 10) + 'T00:00:00Z'), day = (d.getUTCDay() + 6) % 7; d.setUTCDate(d.getUTCDate() - day + 3);
    var y = d.getUTCFullYear(), j4 = new Date(Date.UTC(y, 0, 4)), w = 1 + Math.round(((d - j4) / 864e5 - 3 + ((j4.getUTCDay() + 6) % 7)) / 7); return y + '-W' + (w < 10 ? '0' : '') + w; }
  function monday(s) { var d = new Date(s.slice(0, 10) + 'T00:00:00Z'); d.setUTCDate(d.getUTCDate() - (d.getUTCDay() + 6) % 7); return d; }
  var first = monday(NCS.length ? NCS[0][1] : D.to), last = monday(D.to), WEEKS = [], WMON = [];
  for (var dd = new Date(first); dd <= last; dd.setUTCDate(dd.getUTCDate() + 7)) { WEEKS.push(isoWeek(dd.toISOString())); WMON.push(new Date(dd)); }
  var WIDX = {}; WEEKS.forEach(function (w, i) { WIDX[w] = i; });
  var NW = WEEKS.length, PARTIAL = new Date(D.to + 'T00:00:00Z').getUTCDay() !== 0;   // the week of the last NC is incomplete unless it ends on Sunday
  var NCW = NCS.map(function (n) { return WIDX[isoWeek(n[1])]; });
  // a week's working time (config/1_calendrier_production.csv: weekends, public holidays, closures), 1 = a normal week; weeks of
  // a year with no calendar (before the comparison year) count as normal
  function calW(w) { var P = SET.semaines_poids || {}, y = String(w).slice(0, 4), n = +String(w).slice(6), L = Array.isArray(P) ? (y === String(YEAR) ? P : null) : P[y];
    return L && L[n - 1] != null ? L[n - 1] : 1; }
  var SHUT = WEEKS.map(function (w, i) { return calW(w) < SET.semaine_faible && !(PARTIAL && i === NW - 1); });   // closure weeks, from the blackout days
  function valid(i) { return i >= 0 && i < NW && !SHUT[i] && !(PARTIAL && i === NW - 1); }
  var LASTC = NW - 1; while (LASTC > 0 && !valid(LASTC)) LASTC--;   // the last complete, working week
  var MOIS = ['janv.', 'févr.', 'mars', 'avr.', 'mai', 'juin', 'juil.', 'août', 'sept.', 'oct.', 'nov.', 'déc.'], MOIS_EN = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  function MO(i) { return (LANG === 'en' ? MOIS_EN : MOIS)[i]; }
  function wkShort(i) { return WK() + +WEEKS[i].slice(6); }
  function wkLong(i) { var m = WMON[i], e = new Date(m); e.setUTCDate(e.getUTCDate() + 6);
    return WK() + +WEEKS[i].slice(6) + ' · ' + m.getUTCDate() + (m.getUTCMonth() !== e.getUTCMonth() ? ' ' + MO(m.getUTCMonth()) : '') + '–' + e.getUTCDate() + ' ' + MO(e.getUTCMonth()); }
  function dayFr(s) { if (!s) return ''; var p = s.slice(0, 10).split('-'); return +p[2] + ' ' + MO(+p[1] - 1) + ' ' + p[0]; }
  function monthFr(s) { if (!s) return ''; var p = s.slice(0, 10).split('-'); return MO(+p[1] - 1) + ' ' + p[0]; }

  // ---------------------------------------------------------------- state
  var LINES = (function () { var c = {}; NCS.forEach(function (n) { var l = DIC.line[n[2]]; if (l && l !== '—') c[l] = (c[l] || 0) + 1; }); return Object.keys(c).sort(function (a, b) { return c[b] - c[a]; }).map(function (l) { return [l, c[l]]; }); })();
  var S = { line: LINES.length ? LINES[0][0] : 'all', from: LASTC, week: LASTC, pm: 1, mk: false, ph: 'SERIE', liab: 'f', tab: 'pareto', cnt: 'def', per: 1, f: {}, lim: 40, fSt: 'open' };   // from..week: the weeks shown, per: how many; pm: 1, 4 or 13 weeks ending at week, 0 = chosen freely
  try { var sv = JSON.parse(localStorage.getItem('mft-fto2') || '{}'); if (sv.line && (sv.line === 'all' || LINES.some(function (x) { return x[0] === sv.line; }))) S.line = sv.line; if (sv.ph != null) S.ph = sv.ph; if (typeof sv.liab === 'string' && /^f?s?o?$/.test(sv.liab) && sv.liab) S.liab = sv.liab; S.mk = !!sv.mk; if (sv.cnt === 'nc') S.cnt = 'nc'; } catch (e) { }
  function remember() { try { localStorage.setItem('mft-fto2', JSON.stringify({ line: S.line, ph: S.ph, liab: S.liab, mk: S.mk, cnt: S.cnt })); } catch (e) { } }
  // a press on a bar filters the whole page (figures, the other lists, the table, the Analyse tab), as on the dashboard: one value
  // per list, each list filtered by the picks of the others
  function selOk(d, except) { for (var k in S.f) { if (k !== except && fld(d, k) !== S.f[k]) return false; } return true; }
  function anySel() { return Object.keys(S.f).length > 0; }
  function selChips() { var ks = Object.keys(S.f); return ks.map(function (k) { return '<span class="chip">' + esc(lev(k) + COL() + shown(k, S.f[k])) + ' <button type="button" data-unsel="' + k + '" aria-label="' + esc(T('Retirer {x}', { x: lev(k) })) + '">✕</button></span>'; }).join('') +
    (ks.length > 1 ? '<button type="button" class="btn sm" data-unsel="*">' + esc(T('Tout retirer')) + '</button>' : ''); }
  // the NCs the page counts: the line, the type of production, and (by default, as the dashboard opens) only those FTO2 is liable for
  function inScope(ni, line) { var n = NCS[ni], l = line || S.line; return (l === 'all' || DIC.line[n[2]] === l) && (!S.ph || DIC.phase[n[3]] === S.ph) && S.liab.indexOf(n[8]) >= 0; }
  var LIABS = [['f', 'FTO2'], ['s', 'Fournisseurs'], ['o', 'Autres']];
  function lineName() { return S.line === 'all' ? T('Toutes les lignes') : S.line; }
  function onLine(a) { return S.line === 'all' || a.line === S.line; }
  function setRange(f, t) { S.from = Math.max(0, Math.min(f, t)); S.week = Math.max(f, t); S.per = S.week - S.from + 1; }

  // ---------------------------------------------------------------- helpers
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function num(v, d) { return Number(v).toLocaleString(LANG === 'en' ? 'en-GB' : 'fr-FR', { maximumFractionDigits: d == null ? 0 : d, minimumFractionDigits: d || 0 }); }
  function pct(v) { return (v > 0 ? '+' : v < 0 ? '−' : '') + num(Math.abs(v) * 100) + PC(); }
  function tipA(head, lines) { return ' data-tip="' + esc([head].concat(lines || []).join('|')) + '"'; }
  function $(id) { return document.getElementById(id); }
  function width(el, min) { return Math.max(min || 280, Math.floor(el.clientWidth || el.parentNode.clientWidth || 600)); }
  function mean(a) { return a.length ? a.reduce(function (s, x) { return s + x; }, 0) / a.length : null; }
  // weekly counts of the defects matching pred on a line (all weeks)
  function weekly(pred, line) { var a = WEEKS.map(function () { return 0; }); DEFS.forEach(function (d) { if (inScope(d[0], line) && (!pred || pred(d))) a[NCW[d[0]]]++; }); return a; }
  // the n working weeks ending at i (included), newest last
  function validBefore(i, n) { var out = []; for (var k = i; k >= 0 && out.length < n; k--) if (valid(k)) out.unshift(k); return out; }
  function per() { var o = []; for (var k = S.from; k <= S.week; k++) o.push(k); return o; }
  // the reference of a period: the working weeks just before it, as many as the period (4 at least), compared per week
  // (a week against the 4 before, a month against the month before, the weeks named)
  // weeks of low production are left out too (holidays: the line's MSN that week, from the production plan, under 60 % of its usual
  // week), so that a period after the summer is not compared with August
  var TYP = {};
  function volOf(i) { var V = D.vol, w = WEEKS[i]; if (!V || !w || w.slice(0, 4) !== YEAR) return null;
    var ls = S.line === 'all' ? Object.keys(V) : V[S.line] ? [S.line] : []; if (!ls.length) return null;
    return ls.reduce(function (t, l) { return t + (V[l][+w.slice(6) - 1] || 0); }, 0); }
  function lowWeek(i) {
    var v = volOf(i); if (v == null) return false;
    if (TYP[S.line] == null) { var a = WEEKS.map(function (w, k) { return volOf(k); }).filter(function (x) { return x > 0; }).sort(function (x, y) { return x - y; }); TYP[S.line] = a.length ? a[Math.floor(a.length / 2)] : 0; }
    return TYP[S.line] > 0 && v < TYP[S.line] * SET.semaine_faible;
  }
  // how far back the reference goes: a week against the 4 weeks before, 1 month (4 weeks) against the 3 months before
  // (13 weeks), 3 months (13 weeks) against the 12 months before (52 weeks); a custom period against as many weeks as it has (4 at least).
  // The data start in January of the year followed: early in the year the reference holds the weeks there are, and says which.
  var REFN = SET.mft_fenetres;   // config/2_reglages_pages.csv
  function refWeeks() { var out = [], n = REFN[S.pm] || Math.max(4, S.per); for (var k = per()[0] - 1; k >= 0 && out.length < n; k--) if (valid(k) && !lowWeek(k)) out.unshift(k); return out; }
  function refLab(ws) {   // the weeks in runs, a gap showing the closure weeks left out: 'S29–S31, S35'
    var out = [], i = 0;
    while (i < ws.length) { var j = i; while (j + 1 < ws.length && ws[j + 1] === ws[j] + 1) j++; out.push(wkShort(ws[i]) + (j > i ? '–' + wkShort(ws[j]) : '')); i = j + 1; }
    return out.join(', ');
  }

  // ---------------------------------------------------------------- controls
  function seg(el, items, cur, attr) { el.innerHTML = items.map(function (x) { return '<button type="button" ' + attr + '="' + esc(x[0]) + '" aria-pressed="' + (String(x[0]) === String(cur)) + '">' + esc(x[1]) + (x[2] != null ? '<small>' + esc(x[2]) + '</small>' : '') + '</button>'; }).join(''); }
  function renderControls() {
    seg($('lines'), [['all', T('Toutes')]].concat(LINES.map(function (x) { return [x[0], x[0]]; })), S.line, 'data-line');
    seg($('phases'), [['SERIE', T('Série')], ['REC', 'REC'], ['FTI', 'FTI'], ['', T('Tout')]], S.ph, 'data-ph');
    var pw = per(), w0 = pw[0], w1 = pw[pw.length - 1], lc = {};   // the ticks, with how many NCs each holds in the weeks shown
    NCS.forEach(function (n, i) { if (NCW[i] >= w0 && NCW[i] <= w1 && (S.line === 'all' || DIC.line[n[2]] === S.line) && (!S.ph || DIC.phase[n[3]] === S.ph)) lc[n[8]] = (lc[n[8]] || 0) + 1; });
    $('liabMenu').innerHTML = LIABS.map(function (x) { return '<label><input type="checkbox" data-liabk="' + x[0] + '"' + (S.liab.indexOf(x[0]) >= 0 ? ' checked' : '') + '>' + esc(T(x[1])) + '<small>' + num(lc[x[0]] || 0) + '</small></label>'; }).join('');
    $('liabTxt').textContent = S.liab === 'fso' ? T('Toutes') : LIABS.filter(function (x) { return S.liab.indexOf(x[0]) >= 0; }).map(function (x) { return T(x[1]); }).join(', ');
    var wkOpts = function (cur) { return WEEKS.map(function (w, i) { return i; }).reverse().map(function (i) { return '<option value="' + i + '"' + (i === cur ? ' selected' : '') + '>' + esc(wkLong(i) + (PARTIAL && i === NW - 1 ? ' (' + T('en cours') + ')' : SHUT[i] ? ' (' + T('fermeture') + ')' : '')) + '</option>'; }).join(''); };
    $('wkF').innerHTML = wkOpts(S.from); $('wk').innerHTML = wkOpts(S.week);
    seg($('per'), [[1, T('Semaine')], [4, T('1 mois')], [13, T('3 mois')], [0, T('Personnalisée')]], S.pm, 'data-per');
    $('lF').hidden = $('wkF').hidden = $('lT').hidden = !!S.pm;
    if (S.pm) $('wk').setAttribute('aria-label', S.pm === 1 ? T('Semaine') : T('Jusqu’à la semaine')); else $('wk').removeAttribute('aria-label');
    $('asof').textContent = T('Données au {d}', { d: dayFr(D.to) });
    seg($('cnt'), [['def', T('Défauts')], ['nc', T('NC')]], S.cnt, 'data-cnt');
    seg($('fSt'), [['open', T('Ouvertes')], ['all', T('Toutes')], ['closed', T('Closes')]], S.fSt, 'data-fst');
    ['pareto', 'analyse', 'actions'].forEach(function (t) { $('tb-' + t).setAttribute('aria-selected', String(S.tab === t)); $('t-' + t).hidden = S.tab !== t; });
  }

  // ---------------------------------------------------------------- tab 1: the week's Pareto
  // value -> count over the weeks ws, for the line: its defects, or with byNc the NCs having at least one such defect (3 Nov)
  function counts(ws, k, byNc) {
    var set = {}; ws.forEach(function (i) { set[i] = 1; }); var m = {}, seen = {};
    DEFS.forEach(function (d) { if (set[NCW[d[0]]] && inScope(d[0]) && selOk(d, k)) { var v = fld(d, k); if (!v || (k === 'fin' && isProductName(v))) return;
      if (byNc) { var key = v + '|' + d[0]; if (seen[key]) return; seen[key] = 1; seen['#' + d[0]] = 1; }
      m[v] = (m[v] || 0) + 1; } });
    if (byNc) Object.defineProperty(m, 'nNc', { value: Object.keys(seen).filter(function (x) { return x.charAt(0) === '#'; }).length });   // NCs counted once, whatever their values
    return m;
  }
  function barList(el, k, top) {
    var nc = S.cnt === 'nc', ws = per(), prev = refWeeks(), m = counts(ws, k, nc), pm = counts(prev, k, nc), np = prev.length || 1, tot = 0;
    Object.keys(m).forEach(function (v) { tot += m[v]; }); if (nc) tot = m.nNc || 1;   // NCs: an NC can have defects in several values, the share is of the NCs
    var vals = Object.keys(m);
    if (k === 'cat') { var main = vals.filter(function (v) { return CATC[v]; }).sort(function (a, b) { return m[b] - m[a]; }), side = vals.filter(function (v) { return !CATC[v]; }).sort(function (a, b) { return m[b] - m[a]; }); vals = main.concat(side); }
    else vals.sort(function (a, b) { return m[b] - m[a] || (a < b ? -1 : 1); });
    if (top) vals = vals.slice(0, top);
    if (S.f[k] != null && vals.indexOf(S.f[k]) < 0 && m[S.f[k]]) vals.push(S.f[k]);   // the value picked stays in its list, to see it and undo it
    if (!vals.length) { el.innerHTML = '<p class="empty">' + esc(T(S.line === 'A400M' ? 'A400M : les textes des NC sont masqués, aucun défaut n’est lu.' : 'Aucun défaut sur la période.')) + '</p>'; return; }
    var ref = function (v) { return (pm[v] || 0) / np * S.per; }, mx = Math.max.apply(null, vals.map(function (v) { return Math.max(m[v], ref(v)); }).concat([1e-9])), cum = 0;
    el.classList.toggle('sel', k in S.f);
    el.innerHTML = vals.map(function (v) { cum += m[v]; var on = S.f[k] === v, r = ref(v);
      return '<button type="button" class="bar" data-k="' + k + '" data-v="' + esc(v) + '" aria-pressed="' + !!on + '"' + tipA(shown(k, v), [T(nc ? '{n} NC sur la période' : '{n} défauts sur la période', { n: num(m[v]) }), T('avant : {r} par semaine ({w})', { r: num(r / S.per, 1), w: refLab(prev) }) + (S.per > 1 ? T(', soit {t} sur {p} semaines', { t: num(r, 1), p: S.per }) : ''), k === 'cat' ? '' : (VCAT[k] && VCAT[k][v] ? T('catégorie : {c}', { c: L(VCAT[k][v]) }) : '')].filter(Boolean)) + '>' +
        '<span class="nm">' + esc(shown(k, v)) + '</span><span class="v">' + num(m[v]) + '</span><span class="p">' + (k === 'cat' && CATC[v] && !nc ? num(cum / tot * 100) + PC() : num(m[v] / tot * 100) + PC()) + '</span>' +
        '<span class="tr"><i style="width:' + (m[v] / mx * 100) + '%;background:' + valCol(k, v) + '"></i><em style="left:calc(' + (r / mx * 100) + '% - 1px)"></em></span></button>'; }).join('');
  }
  function renderPareto() {
    var ws = per(), wl = S.per === 1 ? wkLong(S.week) : wkShort(ws[0]) + T(' à ') + wkShort(ws[ws.length - 1]) + ' · ' + T('{n} semaines', { n: S.per });
    $('pTitle').textContent = lineName() + ' · ' + wl;
    $('pSub').textContent = S.per === 1 && SHUT[S.week] ? T('Semaine de fermeture') : PARTIAL && S.week === NW - 1 ? T('Semaine en cours, incomplète') : '';
    $('pSub').hidden = !$('pSub').textContent;
    var set = {}; ws.forEach(function (i) { set[i] = 1; });
    // with picks: the defects that match them and the NCs that have one; without: every NC of the period, a defect or not
    var sel = anySel(), ncs = 0, ncSet = {}; NCS.forEach(function (n, i) { if (set[NCW[i]] && inScope(i)) ncSet[i] = 1; });
    var defs = DEFS.filter(function (d) { return ncSet[d[0]] && selOk(d); }), hit = {};
    if (sel) { defs.forEach(function (d) { hit[d[0]] = 1; }); ncs = Object.keys(hit).length; } else ncs = Object.keys(ncSet).length;
    var prev = refWeeks(), pd = 0, pn = 0, pset = {}, phit = {};
    prev.forEach(function (i) { pset[i] = 1; });
    DEFS.forEach(function (d) { if (pset[NCW[d[0]]] && inScope(d[0]) && selOk(d)) { pd++; phit[d[0]] = 1; } });
    if (sel) pn = Object.keys(phit).length; else NCS.forEach(function (n, i) { if (pset[NCW[i]] && inScope(i)) pn++; });
    var refD = prev.length ? pd / prev.length * S.per : null, refN = prev.length ? pn / prev.length * S.per : null;
    var cm = {}; defs.forEach(function (d) { var c = fld(d, 'cat'); if (CATC[c]) cm[c] = (cm[c] || 0) + 1; }); var topc = Object.keys(cm).sort(function (a, b) { return cm[b] - cm[a]; })[0];
    // per week, the period and its reference on the same scale whatever the period's length, the reference weeks named
    var rl = refLab(prev), dlt = function (v, r) { return r ? '<small>' + (S.per > 1 ? num(v / S.per, 1) + T(' / sem.') + ' · ' : '') + '<span class="delta ' + (v > r * 1.1 ? 'up' : v < r * 0.9 ? 'down' : '') + '">' + pct(v / r - 1) + ' vs ' + num(r / S.per, 1) + (S.per > 1 ? T(' / sem.') : '') + '</span> <span class="mu">(' + esc(rl) + ')</span></small>' : '<small>—</small>'; };
    $('refKey').textContent = rl ? T('moy. {w}', { w: rl }) + (S.per > 1 ? T(', ramenée à {n} sem.', { n: S.per }) : '') : T('pas de semaine avant');
    $('pFigs').innerHTML = '<div class="fig"><span class="k">' + T('NC') + '</span><b>' + num(ncs) + '</b>' + dlt(ncs, refN) + '</div>' +
      '<div class="fig"><span class="k">' + T('Défauts') + '</span><b>' + num(defs.length) + '</b>' + dlt(defs.length, refD) + '</div>' +
      '<div class="fig"><span class="k">' + T('Défauts par NC') + '</span><b>' + (ncs ? num(defs.length / ncs, 1) : '—') + '</b><small></small></div>' +
      '<div class="fig"><span class="k">' + T('Première catégorie') + '</span><b style="font-size:21px">' + esc(topc ? L(topc) : '—') + '</b><small>' + (topc ? T('{n} défauts', { n: num(cm[topc]) }) + ' · ' + num(cm[topc] / (defs.length || 1) * 100) + PC() : '') + '</small></div>';
    $('cntNote').textContent = S.cnt === 'nc' ? T('Une NC compte une fois par barre, même avec plusieurs défauts.') : '';
    barList($('bCat'), 'cat'); barList($('bRca'), 'rca', 12); barList($('bCode'), 'code', 10); barList($('bFin'), 'fin', 10);
    $('selRow').hidden = !sel; $('selChip').innerHTML = selChips();
    var rows = defs.slice().sort(function (a, b) {   // the newest first; one day's NCs by number, whatever order the data came in
      var x = NCS[a[0]], y = NCS[b[0]]; return y[1] < x[1] ? -1 : y[1] > x[1] ? 1 : String(y[0]) < String(x[0]) ? -1 : String(y[0]) > String(x[0]) ? 1 : 0; });
    $('detH').textContent = sel ? T('Les défauts') + ' · ' + Object.keys(S.f).map(function (k) { return shown(k, S.f[k]); }).join(' · ') : T('Les défauts');
    $('detN').textContent = T(rows.length > 1 ? '{n} lignes' : '{n} ligne', { n: num(rows.length) });
    $('detB').innerHTML = rows.length ? rows.slice(0, S.lim).map(function (d) { var n = NCS[d[0]];
      return '<tr><td class="n">' + esc(dayFr(n[1])) + '</td><td class="n">' + esc(n[0]) + '</td><td class="n">' + esc(DIC.msn[n[4]]) + '</td><td>' + esc(DIC.station[n[5]]) + '</td><td class="n">' + esc(fld(d, 'fin')) + '</td><td><span style="color:' + catCol(fld(d, 'cat')) + '">■</span> ' + esc(L(fld(d, 'rca'))) + '</td><td class="txt">' + esc(d[7]) + '</td></tr>'; }).join('')
      : '<tr><td colspan="7" class="mu">' + esc(T('Aucun défaut.')) + '</td></tr>';
    $('detMore').hidden = rows.length <= S.lim;
  }

  // ---------------------------------------------------------------- tab 2: analysis
  function spark(ser, ws, col) {
    var w = 104, h = 26, vs = ws.map(function (i) { return valid(i) ? ser[i] : null; }), mx = Math.max.apply(null, vs.filter(function (v) { return v != null; }).concat([1])), g = '', pts = [];
    ws.forEach(function (i, j) { var v = vs[j]; if (v == null) return; pts.push([2 + j / Math.max(1, ws.length - 1) * (w - 4), h - 3 - v / mx * (h - 7)]); });
    if (pts.length) g = '<path d="M' + pts.map(function (p) { return p[0].toFixed(1) + ',' + p[1].toFixed(1); }).join('L') + '" fill="none" stroke="' + col + '" stroke-width="1.6"/><circle cx="' + pts[pts.length - 1][0].toFixed(1) + '" cy="' + pts[pts.length - 1][1].toFixed(1) + '" r="2.4" fill="' + col + '"/>';
    // under the curve, a week every 4 weeks counted back from the last one (always named), a tiny tick above each name; size and
    // colour inline, the page's "svg text" rule would win over the attributes
    ws.forEach(function (i, j) { if ((ws.length - 1 - j) % 4) return; var x = (2 + j / Math.max(1, ws.length - 1) * (w - 4)).toFixed(1);
      g += '<line x1="' + x + '" x2="' + x + '" y1="' + (h - 1) + '" y2="' + (h + 2.5) + '" stroke="#d3d8de" stroke-width="1"/>' +
        '<text x="' + x + '" y="' + (h + 10.5) + '" text-anchor="middle" style="font-size:7.5px;fill:#b3bbc4">' + wkShort(i) + '</text>'; });
    return '<svg width="' + w + '" height="' + (h + 13) + '" viewBox="0 0 ' + w + ' ' + (h + 13) + '" style="overflow:visible" aria-hidden="true">' + g + '</svg>';
  }
  function plusBtn(k, v) { return '<button type="button" class="btn sm" data-new="' + esc(k + '|' + v) + '">+ Action</button>'; }
  function renderAnalyse() {
    $('aTitle').textContent = lineName() + T(' · jusqu’à ') + wkLong(S.week);
    $('selRowA').hidden = !anySel(); $('selChipA').innerHTML = selChips();
    // weekly stacked bars, 26 weeks
    var box = $('aWeeks'), W = width(box, 300), ws = []; for (var i = Math.max(0, S.week - 25); i <= S.week; i++) ws.push(i);
    var by = {}; ws.forEach(function (i) { by[i] = {}; }); var keys = CATS.concat(['aside']);
    DEFS.forEach(function (d) { var i = NCW[d[0]]; if (by[i] && inScope(d[0]) && selOk(d)) { var c = fld(d, 'cat'), k = CATC[c] ? c : 'aside'; by[i][k] = (by[i][k] || 0) + 1; } });
    var tot = ws.map(function (i) { return keys.reduce(function (s, k) { return s + (by[i][k] || 0); }, 0); }), mx = Math.max.apply(null, tot.concat([1]));
    var ml = 34, mb = 26, mt = 22, H = 230, pw = W - ml - 6, bw = pw / ws.length, Y = function (v) { return mt + (H - mt - mb) * (1 - v / mx); }, g = '';
    var step = mx > 40 ? 20 : mx > 20 ? 10 : 5;
    for (var t = 0; t <= mx; t += step) g += '<line x1="' + ml + '" x2="' + W + '" y1="' + Y(t).toFixed(1) + '" y2="' + Y(t).toFixed(1) + '" stroke="var(--grid)"/><text x="' + (ml - 6) + '" y="' + (Y(t) + 4).toFixed(1) + '" text-anchor="end">' + t + '</text>';
    var acts = ACTIONS.filter(onLine), marks = 0;
    ws.forEach(function (i, j) { var x = ml + j * bw + bw * 0.14, acc = 0, sh = SHUT[i], pa = PARTIAL && i === NW - 1;
      keys.forEach(function (k) { var v = by[i][k] || 0; if (!v) return; var y1 = Y(acc + v), y0 = Y(acc);
        g += '<rect x="' + x.toFixed(1) + '" y="' + y1.toFixed(1) + '" width="' + (bw * 0.72).toFixed(1) + '" height="' + Math.max(0.6, y0 - y1 - 0.8).toFixed(1) + '" fill="' + (k === 'aside' ? 'var(--dim)' : CATC[k]) + '"' + (sh || pa ? ' fill-opacity=".35"' : '') + '/>'; acc += v; });
      g += '<rect x="' + (ml + j * bw).toFixed(1) + '" y="' + mt + '" width="' + bw.toFixed(1) + '" height="' + (H - mt - mb) + '" fill="transparent" style="cursor:pointer" data-wk="' + i + '"' + tipA(wkLong(i) + (sh ? ' · ' + T('fermeture') : pa ? ' · ' + T('en cours') : ''), keys.filter(function (k) { return by[i][k]; }).map(function (k) { return (k === 'aside' ? T('Non classé') : L(k)) + COL() + by[i][k]; }).concat([T('Total') + COL() + tot[j]])) + '/>';
      if (j % (ws.length > 18 && W < 700 ? 3 : 2) === 0 || i === S.week) g += '<text x="' + (ml + j * bw + bw / 2).toFixed(1) + '" y="' + (H - 8) + '" text-anchor="middle"' + (i === S.week ? ' class="ink b"' : '') + '>' + wkShort(i) + '</text>';
      // one mark per week, whatever the number of actions starting that week (the trackers give a month: several land on its first week)
      var st = acts.filter(function (a) { return a.actionStart && WIDX[isoWeek(a.actionStart)] === i; }); marks += st.length;
      if (st.length && S.mk) { var cx = ml + j * bw + bw / 2, tp = tipA(T('Début d’action') + ' · ' + wkShort(i), st.map(function (a) { return a.title || a.category; }));
        g += '<path d="M' + (cx - 5).toFixed(1) + ',10 l5,8 l5,-8z" fill="var(--ink)"' + tp + '/>' + (st.length > 1 ? '<text x="' + (cx + 7).toFixed(1) + '" y="17" class="ink b"' + tp + '>' + st.length + '</text>' : ''); } });
    box.innerHTML = '<svg width="' + W + '" height="' + H + '" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="' + esc(T('Défauts par semaine')) + '">' + g + '</svg>';
    var mk = $('mkT'); mk.setAttribute('aria-pressed', String(S.mk && marks > 0)); mk.disabled = !marks; mk.textContent = T('▼ Débuts d’action') + (marks ? ' (' + marks + ')' : '');
    var has = function (k) { return ws.some(function (i) { return by[i][k]; }); };   // the key lists the categories the chart shows
    $('aWeeksKey').innerHTML = CATS.filter(has).map(function (c) { return '<span><i style="background:' + CATC[c] + '"></i>' + esc(L(c)) + '</span>'; }).join('') + (has('aside') ? '<span><i style="background:var(--dim)"></i>' + esc(T('Non classé')) + '</span>' : '') + (marks && S.mk ? '<span>▼ ' + esc(T('Début d’action')) + '</span>' : '') + '<span><i style="background:var(--ink-2);opacity:.35"></i>' + esc(T('Fermeture / en cours')) + '</span>';
    // rising / falling causes
    var last4 = validBefore(S.week, 4), prev8 = validBefore((last4[0] || S.week) - 1, 8), ser = {}, wsS = validBefore(S.week, 13);
    DEFS.forEach(function (d) { if (!inScope(d[0]) || !selOk(d, 'rca')) return; var v = fld(d, 'rca'); if (!v) return; (ser[v] || (ser[v] = WEEKS.map(function () { return 0; })))[NCW[d[0]]]++; });
    var rows = Object.keys(ser).map(function (v) { var a = mean(last4.map(function (i) { return ser[v][i]; })) || 0, b = mean(prev8.map(function (i) { return ser[v][i]; })) || 0;
      return { v: v, a: a, b: b, n4: a * last4.length, r: b ? a / b - 1 : (a ? Infinity : 0) }; });
    var item = function (x, cls) { var c = valCol('rca', x.v);
      return '<div class="it"><div class="nm"><i style="background:' + c + '"></i><span>' + esc(L(x.v)) + '</span></div><div class="d">' + num(x.b, 1) + ' → ' + num(x.a, 1) + T(' / sem.') + '</div>' +
        '<div class="r"><span class="delta ' + cls + '">' + (isFinite(x.r) ? pct(x.r) : T('nouveau')) + '</span>' + spark(ser[x.v], wsS, c) + plusBtn('rca', x.v) + '</div></div>'; };
    var up = rows.filter(function (x) { return x.n4 >= SET.mft_hausse_min && x.a > x.b * SET.mft_hausse_facteur; }).sort(function (a, b) { return (b.a - b.b) - (a.a - a.b); }).slice(0, 6);
    var dn = rows.filter(function (x) { return x.b * 8 >= SET.mft_baisse_min && x.a < x.b * SET.mft_baisse_facteur; }).sort(function (a, b) { return (a.a - a.b) - (b.a - b.b); }).slice(0, 6);
    $('aUp').innerHTML = up.length ? up.map(function (x) { return item(x, 'up'); }).join('') : '<p class="empty">' + esc(T('Aucune cause en nette hausse.')) + '</p>';
    $('aDown').innerHTML = dn.length ? dn.map(function (x) { return item(x, 'down'); }).join('') : '<p class="empty">' + esc(T('Aucune cause en nette baisse.')) + '</p>';
    // new this week: causes and sub-codes absent from the 8 working weeks before
    var p8 = validBefore(S.week - 1, 8), nw = [];
    ['rca', 'code'].forEach(function (k) { var now = counts([S.week], k), before = counts(p8, k);
      Object.keys(now).forEach(function (v) { if (!before[v] && !(k === 'code' && PLACEHOLDER.test(v))) nw.push({ k: k, v: v, n: now[v] }); }); });
    nw.sort(function (a, b) { return b.n - a.n; });
    $('aNew').innerHTML = nw.length ? nw.slice(0, 8).map(function (x) { return '<div class="it"><div class="nm"><i style="background:' + valCol(x.k, x.v) + '"></i><span>' + esc(shown(x.k, x.v)) + '</span></div><div class="d">' + esc(lev(x.k)) + ' · ' + T(x.n > 1 ? '{n} défauts cette semaine' : '{n} défaut cette semaine', { n: num(x.n) }) + '</div><div class="r">' + plusBtn(x.k, x.v) + '</div></div>'; }).join('')
      : '<p class="empty">' + esc(T('Rien de nouveau cette semaine.')) + '</p>';
    // FINs on several aircraft over 8 working weeks
    var w8 = {}; validBefore(S.week, 8).forEach(function (i) { w8[i] = 1; }); var fm = {};
    DEFS.forEach(function (d) { if (!w8[NCW[d[0]]] || !inScope(d[0]) || !selOk(d, 'fin')) return; var f = fld(d, 'fin'); if (!f || isProductName(f)) return; var o = fm[f] || (fm[f] = { ac: {}, n: 0, rca: {} }); o.ac[DIC.msn[NCS[d[0]][4]] || 'NC ' + NCS[d[0]][0]] = 1; o.n++; var r = fld(d, 'rca'); o.rca[r] = (o.rca[r] || 0) + 1; });
    var fins = Object.keys(fm).map(function (f) { var o = fm[f]; return { f: f, k: Object.keys(o.ac).length, n: o.n, r: Object.keys(o.rca).sort(function (a, b) { return o.rca[b] - o.rca[a]; })[0] }; })
      .filter(function (x) { return x.k >= SET.mft_fin_min; }).sort(function (a, b) { return b.k - a.k || b.n - a.n; }).slice(0, 8);
    $('aFin').innerHTML = fins.length ? fins.map(function (x) { return '<div class="it"><div class="nm"><i style="background:' + valCol('rca', x.r) + '"></i><span>' + esc(x.f) + '</span></div><div class="d">' + T('{k} avions · {n} défauts · surtout {r}', { k: num(x.k), n: num(x.n), r: esc(L(x.r)) }) + '</div><div class="r">' + plusBtn('fin', x.f) + '</div></div>'; }).join('')
      : '<p class="empty">' + esc(T('Aucun repère sur 3 avions ou plus.')) + '</p>';
  }

  // ---------------------------------------------------------------- tab 3: actions
  var DBN = null;   // the note above the actions, a function so that it follows the language (and the store: an empty note hides it)
  function setNote(f) { DBN = f; var t = f ? f() : ''; $('dbNote').hidden = !t; if (f) $('dbNote').textContent = t; }
  var ACTIONS = [], DB = null, USER = null, UID = null, CANW = null, NAMES = {}, CONF = null, CONFL = null, BUSY = false, OPEN = {};   // OPEN: cards whose details are unfolded; CONFL: point waiting for its delete confirmation
  // the account's name is not always given to the page, so whoever writes types it; this browser remembers it
  var MYNAME = ''; try { MYNAME = localStorage.getItem('mft-fto2-name') || ''; } catch (e) { }
  function setName(n) { MYNAME = n; try { localStorage.setItem('mft-fto2-name', n); } catch (e) { } }
  // the problem an action follows: simple = codes or sub-codes (Q11 = every Q11 sub-code; Q11003 or Q11-003 = that
  // sub-code); expert = conditions on a column, all of them true: is one of the values, contains one of the words, regular expression.
  // An action saved before ({ level, values }) reads as one 'is' condition (a sub-code level as the simple mode).
  var FIELDS = { cat: 'Catégorie', rca: 'Cause', sub: 'Sous-catégorie', grp: 'Code', code: 'Sous-code', fin: 'FIN', where: 'Lieu de détection', station: 'Poste', msn: 'MSN', text: 'Texte du défaut' };
  var OPS = { is: 'est l’une des valeurs', contains: 'contient l’un des mots', regex: 'expression régulière' };
  function ckey(c) { return String(c || '').toUpperCase().replace(/[^A-Z0-9]/g, ''); }
  function isGrp(c) { return /^[A-Z]\d{2}$/.test(ckey(c)); }
  function fold(s) { return String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim(); }
  // a cause is a set of sub-codes (each sub-code has one cause): the whole code when no other cause uses it, so later sub-codes are followed too
  function causeCodes(v) {
    var mine = {}, other = {}; DEFS.forEach(function (d) { var c = fld(d, 'code'); if (!c) return; if (fld(d, 'rca') === v) mine[c] = 1; else other[grpOf(c)] = 1; });
    var out = []; Object.keys(mine).sort().forEach(function (c) { var g = grpOf(c), k = g && !other[g] ? g : c; if (out.indexOf(k) < 0) out.push(k); });
    return out;
  }
  function normProb(p) {
    if (!p) return { mode: 'simple', codes: [] };
    if (p.mode === 'simple') return { mode: 'simple', codes: (p.codes || []).slice() };
    if (p.mode === 'expert') return { mode: 'expert', rules: (p.rules || []).map(function (r) { return { f: r.f, op: r.op || 'is', v: (r.v || []).slice() }; }) };
    if (p.level === 'code') return { mode: 'simple', codes: (p.values || []).slice() };
    return p.level ? { mode: 'expert', rules: [{ f: p.level, op: 'is', v: (p.values || []).slice() }] } : { mode: 'simple', codes: [] };
  }
  function ruleTest(r) {   // null: an empty condition, or an expression that does not compile
    var v = (r.v || []).filter(function (x) { return String(x).trim(); }); if (!v.length || !FIELDS[r.f]) return null;
    if (r.op === 'regex') { try { var re = new RegExp(v.join('|'), 'i'); return function (s) { return re.test(s || ''); }; } catch (e) { return null; } }
    if (r.op === 'contains') { var w = v.map(fold); return function (s) { var t = fold(s); return w.some(function (x) { return t.indexOf(x) >= 0; }); }; }
    var set = {}; v.forEach(function (x) { set[fold(x)] = 1; }); return function (s) { return !!set[fold(s)]; };
  }
  function problemPred(p0) {
    var p = normProb(p0);
    if (p.mode === 'simple') { if (!p.codes.length) return null; var G = {}, K = {};
      p.codes.forEach(function (c) { if (isGrp(c)) G[ckey(c)] = 1; else K[ckey(c)] = 1; });
      return function (d) { var c = fld(d, 'code'); return !!c && (!!G[grpOf(c)] || !!K[ckey(c)]); }; }
    var ts = p.rules.map(function (r) { var t = ruleTest(r); return t && { f: r.f, t: t }; });
    if (!ts.length || ts.some(function (x) { return !x; })) return null;
    return function (d) { return ts.every(function (x) { return x.t(fld(d, x.f)); }); };
  }
  function problemText(p0) {
    var p = normProb(p0);
    if (p.mode === 'simple') return p.codes.length ? T('Code / sous-code') + COL() + p.codes.map(function (c) { return isGrp(c) ? ckey(c) + T(' (tous ses sous-codes)') : shown('code', c); }).join(', ') : T('Problème à préciser');
    if (!p.rules.length) return T('Problème à préciser');
    return p.rules.map(function (r) { return T(FIELDS[r.f]) + ' ' + (r.op === 'regex' ? T('correspond à') + ' /' + r.v.join('|') + '/' : T(OPS[r.op]) + COL() + r.v.map(function (x) { return r.f === 'where' || r.f === 'cat' || r.f === 'rca' ? shown(r.f, x) : x; }).join(', ')); }).join(T(' · et '));
  }
  // the indicator: reference = mean of the 8 working weeks before the action start; rolling mean over 4 working weeks; target −30 % held 4 weeks
  function stats(a) {
    var pred = problemPred(a.problem); if (!pred) return { st: 'none' };
    var ser = weekly(pred, a.line), start = a.actionStart || a.analysisStart, si = start ? WIDX[isoWeek(start)] : null;
    if (start && si == null) si = start < D.to ? 0 : NW;
    var roll = WEEKS.map(function (w, i) { if (!valid(i)) return null; var b = validBefore(i, 4); return mean(b.map(function (k) { return ser[k]; })); });
    var o = { ser: ser, roll: roll, si: si, st: 'nostart', fromAnalysis: !a.actionStart && !!a.analysisStart }; if (si == null) return o;
    var pre = validBefore(si - 1, 8); o.pre = pre; if (pre.length < 4) { o.st = 'noref'; return o; }
    o.base = mean(pre.map(function (k) { return ser[k]; })); o.tgt = o.base * SET.action_coef;
    var post = []; for (var k = Math.max(si, 0); k <= LASTC; k++) if (valid(k)) post.push(k); o.post = post;
    if (!o.base) { o.st = 'noref'; return o; }
    if (post.length < 4) { o.st = 'early'; o.cur = post.length ? roll[post[post.length - 1]] : null; return o; }
    o.cur = roll[post[post.length - 1]]; o.chg = o.cur / o.base - 1; o.steady = 0;
    for (var j = post.length - 1; j >= 0 && roll[post[j]] <= o.tgt + 1e-9; j--) o.steady++;
    o.st = o.steady >= SET.action_semaines ? 'met' : o.chg <= -SET.action_baisse ? 'below' : o.chg <= -SET.action_tendance ? 'down' : o.chg >= SET.action_tendance ? 'up' : 'flat';
    return o;
  }
  var VLAB = { met: 'Objectif atteint', below: 'Sous l’objectif', down: 'En baisse', up: 'En hausse', flat: 'Stable', early: 'Trop tôt pour juger', noref: 'Pas de référence', nostart: 'Date de début à saisir', none: 'Problème à préciser' };
  function verdictPill(o) { var ic = { met: '✓', below: '↓', down: '↓', up: '↑', flat: '→' }[o.st] || '·'; return '<span class="pill v-' + o.st + '">' + ic + ' ' + esc(T(VLAB[o.st])) + (o.st === 'below' ? esc(T(' depuis {n} sem.', { n: o.steady })) : '') + '</span>'; }
  function stPill(s) { return '<span class="pill ' + (s === 'Clos' ? 'st-closed' : s === 'À lancer' ? 'st-todo' : 'st-open') + '">' + esc(T(s || 'En cours')) + '</span>'; }
  function actChart(a, o, W) {
    var H = 190, ml = 30, mr = 10, mt = 18, mb = 24, i0 = Math.max(0, Math.min(o.si != null ? o.si - 10 : LASTC - 25, LASTC - 25)), ws = [];
    for (var i = i0; i <= Math.min(NW - 1, LASTC + (PARTIAL ? 1 : 0)); i++) ws.push(i);
    var vals = ws.map(function (i) { return o.ser[i]; }), mx = Math.max.apply(null, vals.concat([o.base || 0, 1])) * 1.12, pw = W - ml - mr, bw = pw / ws.length;
    var X = function (j) { return ml + j * bw + bw / 2; }, Y = function (v) { return mt + (H - mt - mb) * (1 - v / mx); }, g = '', col = a.problem && a.problem.level ? valCol(a.problem.level, a.problem.values[0]) : 'var(--ink-2)';
    var step = mx > 30 ? 10 : mx > 12 ? 5 : mx > 5 ? 2 : 1;
    for (var t = 0; t <= mx; t += step) g += '<line x1="' + ml + '" x2="' + (W - mr) + '" y1="' + Y(t).toFixed(1) + '" y2="' + Y(t).toFixed(1) + '" stroke="var(--grid)"/><text x="' + (ml - 5) + '" y="' + (Y(t) + 4).toFixed(1) + '" text-anchor="end">' + t + '</text>';
    ws.forEach(function (i, j) { var v = o.ser[i], ok = valid(i);
      g += '<rect x="' + (ml + j * bw + bw * 0.18).toFixed(1) + '" y="' + Y(v).toFixed(1) + '" width="' + (bw * 0.64).toFixed(1) + '" height="' + Math.max(0, Y(0) - Y(v)).toFixed(1) + '" fill="' + col + '" fill-opacity="' + (ok ? 0.42 : 0.15) + '"' + tipA(wkLong(i) + (ok ? '' : SHUT[i] ? T(' · fermeture, non comptée') : T(' · en cours, non comptée')), [T(v > 1 ? '{n} défauts' : '{n} défaut', { n: num(v) }), o.roll[i] != null ? T('moyenne 4 sem. : {v}', { v: num(o.roll[i], 1) }) : ''].filter(Boolean)) + '/>';
      if (j % Math.max(1, Math.round(ws.length / (W < 500 ? 5 : 9))) === 0) g += '<text x="' + X(j).toFixed(1) + '" y="' + (H - 7) + '" text-anchor="middle">' + wkShort(i) + '</text>'; });
    if (o.base != null && o.pre && o.pre.length) { var j0 = ws.indexOf(o.pre[0]), j1 = ws.indexOf(Math.min(o.si, NW) - 1); if (j0 < 0) j0 = 0; if (j1 < 0) j1 = ws.length - 1;
      g += '<line x1="' + (ml + j0 * bw).toFixed(1) + '" x2="' + (ml + (j1 + 1) * bw).toFixed(1) + '" y1="' + Y(o.base).toFixed(1) + '" y2="' + Y(o.base).toFixed(1) + '" stroke="var(--ink-2)" stroke-width="1.5" stroke-dasharray="5 4"/>';
      var js = Math.max(0, ws.indexOf(Math.max(o.si, i0))); if (o.si <= ws[ws.length - 1]) g += '<line x1="' + (ml + js * bw).toFixed(1) + '" x2="' + (W - mr) + '" y1="' + Y(o.tgt).toFixed(1) + '" y2="' + Y(o.tgt).toFixed(1) + '" stroke="var(--down)" stroke-width="2" stroke-dasharray="2 4" stroke-linecap="round"/>' +
        '<text x="' + (W - mr) + '" y="' + (Y(o.tgt) - 5).toFixed(1) + '" text-anchor="end" style="fill:var(--down)">' + esc(T('objectif {v}', { v: num(o.tgt, 1) })) + '</text>'; }
    var pts = []; ws.forEach(function (i, j) { if (o.roll[i] != null) pts.push(X(j).toFixed(1) + ',' + Y(o.roll[i]).toFixed(1)); });
    if (pts.length > 1) g += '<path d="M' + pts.join('L') + '" fill="none" stroke="var(--ink)" stroke-width="2"/>';
    [['analysisStart', 'Analyse'], ['actionStart', 'Action']].forEach(function (m) { if (!a[m[0]]) return; var i = WIDX[isoWeek(a[m[0]])], j = ws.indexOf(i); if (j < 0) return;
      g += '<line x1="' + (ml + j * bw).toFixed(1) + '" x2="' + (ml + j * bw).toFixed(1) + '" y1="' + (mt - 6) + '" y2="' + (H - mb) + '" stroke="var(--ink)" stroke-width="1.2"/><text x="' + (ml + j * bw + 4).toFixed(1) + '" y="' + (mt - 6 + 9) + '" class="ink b">' + esc(T(m[1])) + '</text>'; });
    return '<svg width="' + W + '" height="' + H + '" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="' + esc(T('Le problème suivi, semaine par semaine')) + '">' + g + '</svg>' +
      '<div class="key"><span><i style="background:' + col + ';opacity:.5"></i>' + esc(T('défauts par semaine')) + '</span><span><i class="ln" style="background:var(--ink)"></i>' + esc(T('moyenne glissante 4 sem.')) + '</span><span><i class="dash"></i>' + esc(T('référence (8 sem. avant)')) + '</span><span><i class="dot"></i>' + esc(T('objectif −{p} %', { p: Math.round(SET.action_baisse * 1000) / 10 })) + '</span></div>';
  }
  function kpiText(o) {
    if (o.st === 'none' || o.st === 'nostart' || o.st === 'noref') return '';
    var t = T('Réf.') + ' ' + (o.fromAnalysis ? T('(début de l’analyse)') + ' ' : '') + '<b>' + num(o.base, 1) + '</b>' + T(' / sem.') + ' · ' + T('Objectif') + ' ≤ <b>' + num(o.tgt, 1) + '</b>';
    if (o.st === 'early') return t + ' · ' + T('{n} sem. sur 4', { n: o.post.length });
    return t + ' · ' + T('Actuel') + ' <b>' + num(o.cur, 1) + '</b>' + T(' / sem.') + ' · <b>' + pct(o.chg) + '</b>' + (o.st === 'met' ? ' · ' + T('tenu {n} sem.', { n: o.steady }) : '');
  }
  function who(id) { return id ? T(NAMES[id] || 'quelqu’un') : ''; }
  function renderActions() {
    $('nAct').textContent = ACTIONS.filter(function (a) { return onLine(a) && a.status !== 'Clos' && a.status !== 'Abandonnée'; }).length;
    var list = ACTIONS.filter(function (a) { return onLine(a) && (S.fSt === 'all' || (S.fSt === 'closed' ? a.status === 'Clos' || a.status === 'Abandonnée' : a.status !== 'Clos' && a.status !== 'Abandonnée')); });
    list.sort(function (a, b) { return (a.line < b.line ? -1 : a.line > b.line ? 1 : 0) || String(b.actionStart || '').localeCompare(String(a.actionStart || '')); });
    $('newAct').hidden = !DB || CANW === false;
    var keep = {}; document.querySelectorAll('#acts input[id^="lg-"], #acts input[id^="lgn-"]').forEach(function (i) { if (i.value) keep[i.id] = i.value; });   // a point being typed survives a refresh
    var box = $('acts'), W = Math.max(260, Math.min(640, Math.floor((box.clientWidth || 900) * (box.clientWidth > 860 ? 0.55 : 1)) - 40)), sts = list.map(stats);
    var nMet = sts.filter(function (o) { return o.st === 'met'; }).length, nUp = sts.filter(function (o) { return o.st === 'up'; }).length;
    $('actSum').textContent = T(list.length > 1 ? '{n} actions' : '{n} action', { n: list.length }) + (nMet ? ' · ' + T('{n} à l’objectif', { n: nMet }) : '') + (nUp ? ' · ' + T('{n} en hausse', { n: nUp }) : '');
    if (!DB) { box.innerHTML = ''; return; }   // the store answers right after the first drawing
    if (!list.length) { box.innerHTML = '<p class="empty">' + esc(T(S.fSt === 'closed' ? 'Aucune action close' : S.fSt === 'open' ? 'Aucune action ouverte' : 'Aucune action') + (S.line === 'all' ? '' : T(' sur {l}', { l: S.line }))) + '</p>'; return; }
    box.innerHTML = list.map(function (a, n) { var o = sts[n], ed = CANW !== false, closed = a.status === 'Clos' || a.status === 'Abandonnée';
      var dl = [[T('Problème suivi'), esc(problemText(a.problem))], [T('Porteur de l’action'), esc(a.actionOwner || '—')], [T('Porteur de l’analyse'), esc(a.analysisOwner || '—')],
        [T('Début de l’analyse'), esc(monthFr(a.analysisStart) || '—')], [T('Début de l’action'), esc(a.actionStart ? (a.actionStart.slice(8, 10) === '01' ? monthFr(a.actionStart) : dayFr(a.actionStart)) : '—')], [T('Bénéfice attendu'), esc(/^\d{4}-\d\d/.test(a.expected || '') ? monthFr(a.expected) : (a.expected || '—'))],
        [T('Rédigée par'), esc(a.author || (a.createdBy ? who(a.createdBy) : (a.source || '—')))]].concat(a.closedAt ? [[T('Close le'), esc(dayFr(a.closedAt))]] : []);
      var logs = (a.log || []).map(function (e, k) { return [e, k]; }).reverse().map(function (x) { var e = x[0], key = a.id + '|' + x[1], by = e.name || (e.by ? who(e.by) : '');
        return '<div class="e">' + esc(e.text) + '<small>' + esc(dayFr(e.at)) + (by ? ' · ' + esc(by) : '') + (!ed ? '' : CONFL === key
          ? ' <span class="confirm">' + esc(T('Supprimer ce point ?')) + ' <button type="button" class="btn sm" data-lgok="' + esc(key) + '">' + esc(T('Oui')) + '</button><button type="button" class="btn sm" data-lgno="1">' + esc(T('Non')) + '</button></span>'
          : ' <button type="button" class="btn link" data-lgdel="' + esc(key) + '">' + esc(T('Supprimer')) + '</button>') + '</small></div>'; }).join('');
      return '<article class="act" data-id="' + esc(a.id) + '"><div class="ah"><span class="linechip" style="--lc:' + (LINEC[a.line] || 'var(--ring)') + '">' + esc(a.line) + '</span><h3>' + esc(a.title || a.category || 'Action') + '</h3>' + stPill(a.status) + verdictPill(o) + '</div>' +
        '<div><dl>' + dl.map(function (x) { return '<dt>' + x[0] + '</dt><dd>' + x[1] + '</dd>'; }).join('') + '</dl></div>' +
        '<div style="display:grid;gap:6px;min-width:0">' + (o.ser ? actChart(a, o, W) : '') + '<div class="kpi">' + kpiText(o) + '</div></div>' +
        '<details data-d="' + esc(a.id) + '"' + (OPEN[a.id] ? ' open' : '') + '><summary>' + esc(T('Défauts, analyse, action et suivi')) + ((a.log || []).length ? ' · ' + T(a.log.length > 1 ? '{n} points' : '{n} point', { n: a.log.length }) : '') + '</summary><div class="txtb">' +
          [['Catégorie (tracker)', a.category], ['Défauts constatés', a.defects], ['Analyse de cause racine', a.rootCause], ['Action', a.action], ['Informations', a.note]].filter(function (x) { return x[1]; }).map(function (x) { return '<div><h4>' + esc(T(x[0])) + '</h4><p>' + esc(x[1]) + '</p></div>'; }).join('') + '</div>' +
          '<div class="log">' + logs + (ed ? '<div class="row"><input type="text" id="lg-' + esc(a.id) + '" placeholder="' + esc(T('Point de la semaine')) + '" style="flex:1;min-width:200px" maxlength="400"><input type="text" id="lgn-' + esc(a.id) + '" placeholder="' + esc(T('Votre nom')) + '" aria-label="' + esc(T('Votre nom')) + '" value="' + esc(MYNAME) + '" style="width:11em" maxlength="60"><button type="button" class="btn sm" data-log="' + esc(a.id) + '">' + esc(T('Ajouter le point')) + '</button></div>' : '') + '</div></details>' +
        (ed ? '<div class="ops"><button type="button" class="btn sm" data-edit="' + esc(a.id) + '">' + esc(T('Modifier')) + '</button>' + (closed ? '<button type="button" class="btn sm" data-reopen="' + esc(a.id) + '">' + esc(T('Rouvrir')) + '</button>' : '<button type="button" class="btn sm" data-close="' + esc(a.id) + '">' + esc(T('Clore')) + '</button>') +
          (CONF === a.id ? '<span class="confirm">' + esc(T('Supprimer cette action ?')) + ' <button type="button" class="btn sm" data-delok="' + esc(a.id) + '">' + esc(T('Oui, supprimer')) + '</button><button type="button" class="btn sm" data-delno="1">' + esc(T('Non')) + '</button></span>' : '<button type="button" class="btn link" data-del="' + esc(a.id) + '">' + esc(T('Supprimer')) + '</button>') + '</div>' : '') +
        '</article>'; }).join('');
    Object.keys(keep).forEach(function (k) { var i = $(k); if (i) i.value = keep[k]; });
  }

  // ---------------------------------------------------------------- the action form
  var FORM = null, MORE = false;   // MORE: the form's "Plus de détails" is unfolded
  function topValues(line, level) { var m = {}; DEFS.forEach(function (d) { if (inScope(d[0], line)) { var v = fld(d, level); if (v) m[v] = (m[v] || 0) + 1; } }); return Object.keys(m).sort(function (a, b) { return m[b] - m[a]; }).slice(0, 60).map(function (v) { return [v, m[v]]; }); }
  function openForm(a) {
    FORM = JSON.parse(JSON.stringify(a || { line: S.line === 'all' ? '' : S.line, title: '', category: '', problem: { mode: 'simple', codes: [] }, defects: '', rootCause: '', analysisOwner: '', analysisStart: '', action: '', actionOwner: '', actionStart: '', status: 'En cours', expected: '', note: '', log: [] }));
    FORM.problem = normProb(FORM.problem); if (!FORM.id && !FORM.author) FORM.author = MYNAME;
    MORE = !!FORM.id && ['category', 'defects', 'rootCause', 'analysisOwner', 'analysisStart', 'expected', 'note'].some(function (k) { return FORM[k]; });
    drawForm(); var ov = $('ov'); ov.hidden = false;
    // in a frame taller than the screen (a Slate widget), the top of the frame can be out of sight: the form opens where the click was
    ov.style.paddingTop = innerHeight > ((window.screen && screen.availHeight) || 900) ? Math.max(24, Math.min(LASTY - 80, innerHeight - 640)) + 'px' : '';
    var t = $('fTitle'); if (t) t.focus({ preventScroll: true });
  }
  var LASTY = 0; document.addEventListener('pointerdown', function (e) { LASTY = e.clientY; }, true);
  function fval(k) { return esc(FORM[k] || ''); }
  function drawForm() {
    var dIn = function (k) { var v = FORM[k] || ''; return /^\d{4}-\d\d-\d\d$/.test(v) ? v : /^\d{4}-\d\d$/.test(v) ? v + '-01' : ''; };
    $('frm').innerHTML = '<div class="head" style="display:flex;justify-content:space-between;gap:10px;align-items:baseline"><h3>' + esc(T(FORM.id ? 'Modifier l’action' : 'Nouvelle action')) + '</h3><button type="button" class="btn link" data-cancel="1">' + esc(T('Fermer')) + '</button></div>' +
      '<div class="fg">' +
      '<div class="f"><label for="fLine">' + esc(T('Ligne')) + '</label><select id="fLine">' + (FORM.line ? '' : '<option value="" selected>' + esc(T('Choisir…')) + '</option>') + LINES.map(function (x) { return '<option' + (x[0] === FORM.line ? ' selected' : '') + '>' + esc(x[0]) + '</option>'; }).join('') + '</select></div>' +
      '<div class="f"><label for="fAuth">' + esc(T('Rédigée par')) + '</label><input type="text" id="fAuth" maxlength="60" value="' + fval('author') + '" placeholder="' + esc(T('Votre nom')) + '"></div>' +
      '<div class="f w"><label for="fTitle">' + esc(T('Titre')) + '</label><input type="text" id="fTitle" maxlength="120" value="' + fval('title') + '" placeholder="' + esc(T('Ex. : Erreurs et inversions de branchement')) + '"></div>' +
      probHtml() +
      '<div class="f w"><label for="fAct">' + esc(T('Action')) + '</label><textarea id="fAct" maxlength="3000">' + fval('action') + '</textarea></div>' +
      '<div class="f"><label for="fOwn">' + esc(T('Porteur de l’action')) + '</label><input type="text" id="fOwn" maxlength="120" value="' + fval('actionOwner') + '"></div>' +
      '<div class="f"><label for="fStart">' + esc(T('Début de l’action')) + '</label><input type="date" id="fStart" value="' + dIn('actionStart') + '"></div>' +
      '</div><details class="more" id="fMore"' + (MORE ? ' open' : '') + '><summary>' + esc(T('Plus de détails')) + '</summary><div class="fg">' +
      '<div class="f"><label for="fStatus">' + esc(T('Statut')) + '</label><select id="fStatus">' + STATUSES.map(function (s) { return '<option value="' + esc(s) + '"' + (s === FORM.status ? ' selected' : '') + '>' + esc(T(s)) + '</option>'; }).join('') + '</select></div>' +
      '<div class="f"><label for="fExp">' + esc(T('Bénéfice attendu (date)')) + '</label><input type="date" id="fExp" value="' + dIn('expected') + '"></div>' +
      '<div class="f w"><label for="fCat">' + esc(T('Catégorie (comme dans le tracker)')) + '</label><input type="text" id="fCat" maxlength="160" value="' + fval('category') + '" placeholder="' + esc(T('Ex. : Erreurs/Inversions de branchements')) + '"></div>' +
      '<div class="f w"><label for="fDef">' + esc(T('Défauts constatés')) + '</label><textarea id="fDef" maxlength="2000">' + fval('defects') + '</textarea></div>' +
      '<div class="f w"><label for="fRoot">' + esc(T('Analyse de cause racine')) + '</label><textarea id="fRoot" maxlength="3000">' + fval('rootCause') + '</textarea></div>' +
      '<div class="f"><label for="fAOwn">' + esc(T('Porteur de l’analyse')) + '</label><input type="text" id="fAOwn" maxlength="120" value="' + fval('analysisOwner') + '"></div>' +
      '<div class="f"><label for="fAStart">' + esc(T('Début de l’analyse')) + '</label><input type="date" id="fAStart" value="' + dIn('analysisStart') + '"></div>' +
      '<div class="f w"><label for="fNote">' + esc(T('Informations')) + '</label><textarea id="fNote" maxlength="1200">' + fval('note') + '</textarea></div>' +
      '</div></details>' +
      '<div class="row"><button type="submit" class="btn pri" id="fSave">' + esc(T(FORM.id ? 'Enregistrer' : 'Créer l’action')) + '</button><button type="button" class="btn" data-cancel="1">' + esc(T('Annuler')) + '</button><span class="err" id="fErr"></span></div>';
  }
  // the problem editor: simple (codes, sub-codes) or expert (conditions); the preview counts and shows what it catches
  function codeSuggest(line) { var c = {}, g = {}; DEFS.forEach(function (d) { if (!inScope(d[0], line)) return; var v = fld(d, 'code'); if (!v) return; c[v] = (c[v] || 0) + 1; var k = grpOf(v); if (k) g[k] = (g[k] || 0) + 1; });
    var by = function (o) { return Object.keys(o).sort(function (a, b) { return o[b] - o[a]; }); };
    return by(g).map(function (k) { return [k, k + T(' · tous ses sous-codes ({n})', { n: g[k] })]; }).concat(by(c).map(function (k) { return [k, shown('code', k) + ' (' + c[k] + ')']; })); }
  function probHtml() {
    var p = FORM.problem, simple = p.mode === 'simple', h = '';
    h += '<div class="f w"><label id="lPm">' + esc(T('Problème suivi')) + '</label><div class="row"><div class="seg" role="group" aria-labelledby="lPm"><button type="button" data-pm="simple" aria-pressed="' + simple + '">' + esc(T('Simple')) + '</button><button type="button" data-pm="expert" aria-pressed="' + !simple + '">' + esc(T('Expert')) + '</button></div>' +
      '<span class="mu">' + esc(T(simple ? 'Un code (Q11 : tous ses sous-codes) ou un sous-code (Q11003 ou Q11-003).' : 'Une ou plusieurs conditions ; un défaut est suivi s’il les remplit toutes.')) + '</span></div></div>';
    if (simple) {
      h += '<div class="f w"><label for="fCode">' + esc(T('Code ou sous-code')) + '</label><div class="row"><input type="text" id="fCode" list="dlCode" autocomplete="off" spellcheck="false" placeholder="' + esc(T('Ex. : Q11 ou Q11-003')) + '" style="flex:1 1 220px;width:auto"><button type="button" class="btn" data-addcode="1">' + esc(T('Ajouter')) + '</button></div>' +
        '<datalist id="dlCode">' + codeSuggest(FORM.line).map(function (x) { return '<option value="' + esc(x[0]) + '">' + esc(x[1]) + '</option>'; }).join('') + '</datalist>' +
        '<div class="row">' + (p.codes.length ? p.codes.map(function (c, j) { return '<span class="chip">' + esc(isGrp(c) ? ckey(c) + T(' · tous ses sous-codes') : shown('code', c)) + ' <button type="button" data-rmc="' + j + '" aria-label="' + esc(T('Retirer')) + '">✕</button></span>'; }).join('') : '<span class="mu">' + esc(T('Aucun code choisi.')) + '</span>') + '</div><span class="err" id="fCodeErr"></span></div>';
    } else {
      var anyRx = false;
      h += '<div class="f w rules">' + p.rules.map(function (r, i) {
        var rx = r.op === 'regex'; if (rx) anyRx = true;
        var sel = function (o, cur, attr) { return '<select ' + attr + '="' + i + '" aria-label="' + esc(T(attr === 'data-rf' ? 'Colonne' : 'Type de filtre')) + '">' + Object.keys(o).map(function (k) { return '<option value="' + k + '"' + (k === cur ? ' selected' : '') + '>' + esc(T(o[k])) + '</option>'; }).join('') + '</select>'; };
        var sug = r.f === 'text' ? [] : topValues(FORM.line, r.f);
        return '<div class="rule">' + sel(FIELDS, r.f, 'data-rf') + sel(OPS, r.op, 'data-ro') +
          (rx ? '<input type="text" data-rx="' + i + '" value="' + esc(r.v.join('|')) + '" spellcheck="false" autocomplete="off" placeholder="Ex. : DR2[04].{0,40}court" aria-label="' + esc(T('Expression régulière')) + '">'
              : '<input type="text" id="rv-' + i + '" data-rv="' + i + '" list="dl-' + i + '" autocomplete="off" placeholder="' + esc(T(r.op === 'contains' ? 'un mot ou un bout de texte' : 'une valeur')) + '" aria-label="' + esc(T('Valeur')) + '"><button type="button" class="btn sm" data-rva="' + i + '">' + esc(T('Ajouter')) + '</button>' +
                '<datalist id="dl-' + i + '">' + sug.map(function (x) { return '<option value="' + esc(x[0]) + '">' + esc(shown(r.f, x[0]) + ' (' + x[1] + ')') + '</option>'; }).join('') + '</datalist>') +
          '<button type="button" class="btn link" data-rdel="' + i + '" aria-label="' + esc(T('Retirer la condition')) + '">✕</button>' +
          (rx ? '<div class="row"><span class="err" id="rxErr-' + i + '">' + esc(rxErr(r)) + '</span></div>'
              : '<div class="row">' + (r.v.length ? r.v.map(function (v, j) { return '<span class="chip">' + esc(shown(r.f, v)) + ' <button type="button" data-rvx="' + i + '|' + j + '" aria-label="' + esc(T('Retirer')) + '">✕</button></span>'; }).join('') : '<span class="mu">' + esc(T('Aucune valeur.')) + '</span>') + '</div>') + '</div>';
      }).join('') + '<div class="row"><button type="button" class="btn sm" data-radd="1">' + esc(T('+ Ajouter une condition')) + '</button></div>' +
        '<div class="help">' + T('<b>est</b> : la valeur exacte, l’une de la liste. <b>contient</b> : l’un des mots ou bouts de texte, sans tenir compte des accents ni des majuscules (utile sur le texte du défaut).') +
        (anyRx ? '<br>' + T('<b>Expression régulière</b> : très puissante mais difficile à écrire. Demandez-la à Gemini, par exemple : « Écris une expression régulière JavaScript, insensible à la casse, qui trouve un câble DR20 ou DR24 coupé trop court ». Décrivez ce que vous cherchez sans coller de texte de NC, puis vérifiez les exemples trouvés ci-dessous.') : '') + '</div></div>';
    }
    return h + '<div class="f w"><div class="prev" id="fPrev">' + prevHtml() + '</div></div>';
  }
  function rxErr(r) { var v = (r.v || []).join('|'); if (!v.trim()) return T('Saisissez l’expression.'); try { new RegExp(v, 'i'); return ''; } catch (e) { return T('Expression non valide') + COL() + e.message; } }
  function prevHtml() {
    var p = problemPred(FORM.problem); if (!p) return esc(T(FORM.problem.mode === 'simple' ? 'Choisissez au moins un code pour suivre le problème.' : 'Complétez chaque condition pour suivre le problème.'));
    var last8 = validBefore(LASTC, 8), ser = weekly(p, FORM.line), all = 0, ex = [];
    DEFS.forEach(function (d) { if (inScope(d[0], FORM.line) && p(d) && String(NCS[d[0]][1]).slice(0, 4) === YEAR) all++; });   // since January: the year followed only
    for (var k = DEFS.length - 1; k >= 0 && ex.length < 3; k--) { var d = DEFS[k]; if (inScope(d[0], FORM.line) && p(d)) ex.push(d); }
    ex.sort(function (a, b) { return NCS[b[0]][1] < NCS[a[0]][1] ? -1 : 1; });
    var n8 = last8.reduce(function (s, i) { return s + ser[i]; }, 0);
    return esc(T(n8 > 1 ? 'Ce problème sur {l} : {n} défauts sur les 8 dernières semaines de travail ({w} par semaine), {a} depuis janvier.' : 'Ce problème sur {l} : {n} défaut sur les 8 dernières semaines de travail ({w} par semaine), {a} depuis janvier.', { l: FORM.line, n: num(n8), w: num(mean(last8.map(function (i) { return ser[i]; })) || 0, 1), a: num(all) })) +
      (ex.length ? '<ul>' + ex.map(function (d) { var n = NCS[d[0]]; return '<li>' + esc(n[1].slice(8, 10) + '/' + n[1].slice(5, 7) + ' · MSN ' + (DIC.msn[n[4]] || '—') + ' · ' + String(d[7] || '').slice(0, 140)) + '</li>'; }).join('') + '</ul>' : '');
  }
  function addCode() {
    var e = $('fCode'), raw = e ? e.value.trim() : ''; if (!raw) return;
    var out = [], miss = [];
    raw.split(/[,;\s]+/).forEach(function (t) { if (!t) return; var k = ckey(t);
      if (isGrp(k)) { out.push(k); return; }
      var hit = DIC.code.filter(function (c) { return c && ckey(c) === k; })[0]; if (hit) out.push(hit); else miss.push(t); });
    readForm(); out.forEach(function (c) { if (FORM.problem.codes.indexOf(c) < 0) FORM.problem.codes.push(c); }); drawForm();
    if (miss.length) $('fCodeErr').textContent = T('Aucun défaut avec : {x}.', { x: miss.join(', ') }); else { var f = $('fCode'); if (f) f.focus(); }
  }
  function addVal(i) { var e = $('rv-' + i), v = e ? e.value.trim() : ''; if (!v) return; readForm(); var r = FORM.problem.rules[i]; if (r.v.indexOf(v) < 0) r.v.push(v); drawForm(); var f = $('rv-' + i); if (f) f.focus(); }
  function readForm() {
    var g = function (id) { var e = $(id); return e ? e.value.trim() : ''; };
    FORM.line = g('fLine') || FORM.line; FORM.status = g('fStatus') || FORM.status; FORM.title = g('fTitle'); FORM.category = g('fCat');
    FORM.defects = g('fDef'); FORM.rootCause = g('fRoot'); FORM.analysisOwner = g('fAOwn'); FORM.analysisStart = g('fAStart'); FORM.action = g('fAct');
    FORM.actionOwner = g('fOwn'); FORM.actionStart = g('fStart'); FORM.expected = g('fExp'); FORM.note = g('fNote'); FORM.author = g('fAuth');
  }
  function today() { return new Date().toISOString().slice(0, 10); }
  function dbErr(e) { var c = e && e.code; return T(c === 'quota_exceeded' ? 'Le stockage de la page est plein : supprimez des actions closes.' : c === 'invalid_argument' ? 'Vous ne pouvez pas modifier les actions de cette page (accès en lecture).' : 'Enregistrement impossible pour l’instant, réessayez dans un moment.'); }
  async function saveForm() {
    if (BUSY) return; readForm();
    if (!FORM.line) { $('fErr').textContent = T('Choisissez la ligne.'); $('fLine').focus(); return; }
    if (!FORM.title && !FORM.category) { $('fErr').textContent = T('Donnez au moins un titre.'); return; }
    if (!FORM.author) { $('fErr').textContent = T('Indiquez qui rédige l’action.'); $('fAuth').focus(); return; }
    setName(FORM.author);
    if (FORM.problem.mode === 'expert' && FORM.problem.rules.some(function (r) { return r.op === 'regex' && rxErr(r); })) { $('fErr').textContent = T('L’expression régulière n’est pas valide.'); return; }
    var body = JSON.parse(JSON.stringify(FORM)), id = body.id; delete body.id;
    body.updatedAt = today(); if (UID) body.updatedBy = UID;
    if (body.status === 'Clos' && !body.closedAt) body.closedAt = today(); if (body.status !== 'Clos') body.closedAt = '';
    if (!id) { body.createdAt = today(); body.createdBy = UID || ''; body.source = 'Page MFT'; body.log = body.log || []; }
    BUSY = true; $('fSave').disabled = true; $('fErr').textContent = '';
    try { await (id ? DB.collection('actions').doc(id) : DB.collection('actions').doc()).set(body); $('ov').hidden = true; FORM = null; S.tab = 'actions'; renderAll(); }
    catch (e) { $('fErr').textContent = dbErr(e); if (e && e.code === 'invalid_argument') CANW = false; }
    finally { BUSY = false; var b = $('fSave'); if (b) b.disabled = false; }
  }
  async function patch(id, fields, btn) {
    if (BUSY) return; BUSY = true; if (btn) btn.disabled = true;
    try { await DB.collection('actions').doc(id).update(fields); return true; } catch (e) { var a = document.querySelector('[data-id="' + id + '"] .ops'); if (a) a.insertAdjacentHTML('beforeend', '<span class="err">' + esc(dbErr(e)) + '</span>'); if (e && e.code === 'invalid_argument') { CANW = false; } }
    finally { BUSY = false; if (btn) btn.disabled = false; }
  }

  // ---------------------------------------------------------------- the bell: what to look at. The dashboard's alarm rule, copied
  // here, for the production type chosen, as of the week shown (its finished week); the line picker chooses whose
  // alarms are listed; five lines at most. Seen marks: the page's store, collection 'alarmes' (the dashboard keeps its own).
  /* ===== ALARM ENGINE START ===== */
  // Alarms: the bell lists what to look at, few lines, nothing raised by a single bad week. One rule for the
  // dashboard and the MFT page (the MFT page has a copy of this block). Four ways something goes wrong, each tested on
  // 2026 against a year where nothing changes:
  //  - rise ("en hausse"): an item of a line (all its defects, a category, a cause, a sub-code, a station, where they are found, a
  //    product, a cable imputation or reason), last 4 finished weeks against the 12 before, per MSN built (working days), binomial
  //    test read in σ. Minor 2.5 σ and still 1.5 σ with the biggest week set aside; major 3 σ, still 2 σ without it and 10 more
  //    defects than usual over the 4 weeks, also without it. Open until 4 weeks under 1 σ, off the list once back under 1 σ;
  //  - several lines ("sur A350 + A330"): a category or cause rising on two lines or more at once, each below the bar on its own
  //    and none carrying 70 % of the rise (a cause they share: a machine, a supplier, a training). 2026: printing defects in
  //    week 39; chance: about 0.2 in 23 weeks;
  //  - slow creep ("en hausse lente"): three blocks of 8 weeks, each 10 % above the one before, the last 3 σ above the first and
  //    still 2 σ without its biggest week, with no rise alarm on it in those last 8 weeks (the weekly view hides it). 2026: A330
  //    Structure Endommagée; chance: about 0.3 in 23 weeks;
  //  - an aircraft far above its siblings: its NCs above both 2.5 times the median and the 90th percentile + 3 of the finished
  //    aircraft of its product, while it still gets NCs. 2026: MSN 851 (14 NCs, a MIP usually ends with 5).
  // Tried and left out: a FIN coming back on several aircraft (as frequent in 2026 as in shuffled data: chance), a new sub-code on
  // 2 aircraft (mostly one-week bursts). Then one line per problem: a sub-code with the same weeks as its cause shows with it
  // ("Inversion (T04)"), a parent gives way to the child carrying 60 % of its rise, stations / places / products / cables join the
  // problem sharing more than half of their NCs; a problem an action covers says so. Weeks: 0 = ISO week 1 of the year followed.
  var ALARM = (function () {
    var P = window.FTO2_ALARM_P;   // the alarm settings (config/3_alarmes.csv), set by the page before this block
    var YEAR = +window.FTO2_YEAR;   // the year followed (config/2_parametres.csv, annee), set by the page before this block
    var LF = [0];
    function lf(n) { for (var i = LF.length; i <= n; i++) LF[i] = LF[i - 1] + Math.log(i); return LF[n]; }
    function tail(x, n, p) {   // P(K >= x) for K binomial (n, p)
      if (x <= 0 || p >= 1) return 1;
      if (p <= 0 || x > n) return 0;
      var lp = Math.log(p), lq = Math.log(1 - p), t = [], m = -Infinity, s = 0, k, v;
      for (k = x; k <= n; k++) { v = lf(n) - lf(k) - lf(n - k) + k * lp + (n - k) * lq; t.push(v); if (v > m) m = v; }
      for (k = 0; k < t.length; k++) s += Math.exp(t[k] - m);
      return Math.min(1, Math.exp(m) * s);
    }
    function invN(p) {   // inverse of the standard normal distribution (Acklam)
      var a = [-39.69683028665376, 220.9460984245205, -275.9285104469687, 138.357751867269, -30.66479806614716, 2.506628277459239],
        b = [-54.47609879822406, 161.5858368580409, -155.6989798598866, 66.80131188771972, -13.28068155288572],
        c = [-0.007784894002430293, -0.3223964580411365, -2.400758277161838, -2.549732539343734, 4.374664141464968, 2.938163982698783],
        d = [0.007784695709041462, 0.3224671290700398, 2.445134137142996, 3.754408661907416], q, r;
      if (p < 0.02425) { q = Math.sqrt(-2 * Math.log(p)); return (((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1); }
      if (p > 1 - 0.02425) { q = Math.sqrt(-2 * Math.log(1 - p)); return -(((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1); }
      q = p - 0.5; r = q * q; return (((((a[0] * r + a[1]) * r + a[2]) * r + a[3]) * r + a[4]) * r + a[5]) * q / (((((b[0] * r + b[1]) * r + b[2]) * r + b[3]) * r + b[4]) * r + 1);
    }
    function sig(x, er, b, eb) {   // how many σ x events over the exposure er stand above b events over eb (0 under 3 events)
      if (x < P.minX || er <= 0 || eb <= 0) return 0;
      return invN(1 - Math.min(Math.max(tail(x, x + b, er / (er + eb)), 1e-12), 1 - 1e-12));
    }
    function week(iso) {   // '2026-05-14' -> its ISO week in the year followed, 0 for week 1; -1 outside that year
      var d = new Date(String(iso).slice(0, 10) + 'T00:00:00Z'), dow = (d.getUTCDay() + 6) % 7;
      if (isNaN(d)) return -1;
      d.setUTCDate(d.getUTCDate() - dow + 3);   // the Thursday of the week decides the year
      if (d.getUTCFullYear() !== YEAR) return -1;
      return Math.floor((d - Date.UTC(YEAR, 0, 1)) / 6048e5);   // week 1 holds the year's first Thursday
    }
    function lastDone(iso) {   // the last finished week up to that day: its own week if it is a Sunday, else the week before
      var d = new Date(String(iso).slice(0, 10) + 'T00:00:00Z');
      if (d.getUTCDay() !== 0) d.setUTCDate(d.getUTCDate() - (d.getUTCDay() + 6) % 7 - 1);
      return week(d.toISOString());
    }
    function sum(it, a, b) {   // counts and MSN over weeks a..b, with the biggest week of them
      var o = { x: 0, e: 0, big: 0, bigE: 0 };
      for (var j = Math.max(0, a); j <= b; j++) { var v = it.w[j] || 0; o.x += v; o.e += it.e ? it.e[j] || 0 : 0; if (v > o.big) { o.big = v; o.bigE = it.e ? it.e[j] || 0 : 0; } }
      return o;
    }
    function ids(it, a, b) { var o = {}; for (var j = Math.max(0, a); j <= b; j++) (it.n[j] || []).forEach(function (id) { o[id] = 1; }); return o; }
    // the rise test of one item at week i: {z, zg (without the biggest week), ex (extra over the 4 weeks, without it), lvl}
    function test(it, i) {
      var R = P.recent, B = P.base, r = sum(it, i - R + 1, i), b = sum(it, i - R - B + 1, i - R);
      var zf = sig(r.x, r.e, b.x, b.e), eg = r.e - r.bigE, zg = sig(r.x - r.big, eg, b.x, b.e);
      var ex = b.e > 0 && eg > 0 ? (r.x - r.big - b.x * eg / b.e) * r.e / eg : 0;
      var lvl = it.hist && !(it.f <= i - R - B + 1 && b.x >= P.hist) ? 0 : zf >= P.zMaj && zg >= P.gMaj && ex >= P.exMaj ? 2 : zf >= P.zMin && zg >= P.gMin ? 1 : 0;
      return { z: zf, zg: zg, ex: ex, lvl: lvl, usual: b.e > 0 ? b.x / b.e * r.e / R : 0 };
    }
    // one item week by week, from `first` to `last`: the alarm open at `last` (null if none) and the last week one was open
    function scan(it, first, last) {
      var o = null, seen = -1, ow = [];
      if (it.hist && it.f == null) { it.f = 0; while (it.f < it.w.length && !it.w[it.f]) it.f++; }   // its first week
      for (var i = Math.max(first, P.recent + P.base - 1); i <= last; i++) {
        var t = test(it, i);
        if (o) {
          o.quiet = t.z < 1 ? o.quiet + 1 : 0;
          if (o.quiet >= P.quiet) { o = null; continue; }
          if (t.lvl > o.lvl) o.lvl = t.lvl;
        } else if (t.lvl) o = { lvl: t.lvl, since: i, quiet: 0 };
        if (o) { seen = i; ow[i] = 1; if (i === last) { o.z = t.z; o.zg = t.zg; o.ex = t.ex; o.usual = t.usual; } }
      }
      return { o: o, seen: seen, ow: ow };
    }
    function creepAt(it, i) {   // three 8-week blocks up to week i, each 10 % above the one before, the last well above the first
      var K = P.block, s3 = i - K + 1, s2 = s3 - K, s1 = s2 - K; if (s1 < 0) return null;
      var b1 = sum(it, s1, s2 - 1), b2 = sum(it, s2, s3 - 1), b3 = sum(it, s3, i);
      if (!(b1.e > 0 && b2.e > 0 && b3.e > 0)) return null;
      var r1 = b1.x / b1.e, r2 = b2.x / b2.e, r3 = b3.x / b3.e;
      if (!(r2 > r1 * P.step && r3 > r2 * P.step)) return null;
      var z = sig(b3.x, b3.e, b1.x, b1.e), g = sig(b3.x - b3.big, b3.e - b3.bigE, b1.x, b1.e);
      return z >= P.creepZ && g >= P.creepG ? { since: s2, ref: b1 } : null;
    }
    // the creep week by week: it opens when nothing in its family had an alarm in those 8 weeks (famOpen) and stays while the last
    // 8 weeks are still 1 σ above the block it started from
    function creep(it, first, last, famOpen) {
      var K = P.block, c = null;
      for (var i = Math.max(first, 3 * K - 1); i <= last; i++) {
        var b3 = sum(it, i - K + 1, i);
        if (c) { c.z = sig(b3.x, b3.e, c.ref.x, c.ref.e); if (c.z < 1) c = null; }
        else { var n = creepAt(it, i); if (n && !famOpen(i - K + 1, i)) c = { lvl: 1, since: n.since, ref: n.ref, z: sig(b3.x, b3.e, n.ref.x, n.ref.e) }; }
        if (c && i === last) c.ex = b3.x - c.ref.x / c.ref.e * b3.e;
      }
      return c;
    }
    var RANK = { all: 0, cat: 0, rca: 0, code: 0, where: 1, station: 2, prod: 3, cimp: 4, cmot: 4 };
    function fam(a) { return RANK[a.lv] === 0; }
    // what is wrong at week `last`, one line per problem, the most important first.
    //  items: [{key, line, lv, v, w: [count per week], e: [MSN per week], n: [[NC ids] per week], hist}]; parentOf(item) -> the key of
    //  its parent ('' for none): line|all| <- line|cat|c <- line|rca|r <- line|code|s;
    //  planes: [{key, line, msn, prod, w: [NCs per week], end: week its build ended (99 if not yet), n}];
    //  acts: [{line, title, start: week, defs: {defect key: 1}}], the actions in progress, their problem's defect lines (items carry
    //  theirs per week in d), to say that one covers a problem
    function run(items, first, last, parentOf, planes, acts) {
      var al = [], by = {}, gone = {}, open = {}, sc = {}, kidsOf = {};
      items.forEach(function (it) { sc[it.key] = scan(it, first, last); var p = parentOf(it); if (p) (kidsOf[p] || (kidsOf[p] = [])).push(it.key); });
      var famOpen = function (key) {   // weeks a..b: was an alarm open on the item, its parents or its children?
        var keys = [key], up = function (k) { var it2 = by0[k], p = it2 ? parentOf(it2) : ''; if (p && sc[p]) { keys.push(p); up(p); } },
          down = function (k) { (kidsOf[k] || []).forEach(function (c) { keys.push(c); down(c); }); };
        up(key); down(key);
        return function (a, b) { return keys.some(function (k) { for (var j = a; j <= b; j++) if (sc[k].ow[j]) return true; return false; }); };
      }, by0 = {};
      items.forEach(function (it) { by0[it.key] = it; });
      items.forEach(function (it) {
        var s = sc[it.key], o = s.o;
        if (o) open[it.key] = 1;
        if (o && o.z >= 1) al.push(Object.assign(o, { kind: 'rise', key: it.key, line: it.line, lv: it.lv, v: it.v, it: it, ncs: ids(it, last - P.recent + 1, last) }));
        else if (!o && (it.lv === 'all' || it.lv === 'cat' || it.lv === 'rca')) {
          var c = creep(it, first, last, famOpen(it.key));
          if (c) al.push(Object.assign(c, { kind: 'creep', key: 'C|' + it.key, line: it.line, lv: it.lv, v: it.v, it: it, ncs: ids(it, last - P.block + 1, last) }));
        }
      });
      // several lines: a category or a cause rising on two lines or more at once, none alarming alone
      var grp = {};
      items.forEach(function (it) { if (it.lv === 'cat' || it.lv === 'rca') (grp[it.lv + '|' + it.v] || (grp[it.lv + '|' + it.v] = [])).push(it); });
      Object.keys(grp).forEach(function (k) {
        var its = grp[k]; if (its.length < 2 || its.some(function (it) { return open[it.key]; })) return;
        var pool = { w: [], e: [], n: [] };
        pool.d = [];
        for (var j = 0; j <= last; j++) { pool.w[j] = 0; pool.e[j] = 0; its.forEach(function (it) { pool.w[j] += it.w[j] || 0; pool.e[j] += it.e[j] || 0; if (it.n[j]) pool.n[j] = (pool.n[j] || []).concat(it.n[j]); if (it.d && it.d[j]) pool.d[j] = (pool.d[j] || []).concat(it.d[j]); }); }
        var s = scan(pool, first, last).o; if (!s || s.z < 1) return;
        var up = [], ex = [];
        its.forEach(function (it) { var t = test(it, last); if (t.z >= 1) up.push(it.line); ex.push(Math.max(0, sum(it, last - P.recent + 1, last).x - (t.usual * P.recent))); });
        var tot = ex.reduce(function (a, b) { return a + b; }, 0);
        if (up.length < 2 || Math.max.apply(null, ex) >= P.crossCarry * tot) return;
        al.push(Object.assign(s, { kind: 'cross', key: 'X|' + k, line: up.join(' + '), lines: up, lv: its[0].lv, v: its[0].v, it: pool, ncs: ids(pool, last - P.recent + 1, last) }));
      });
      // one line per problem: the family of a line (and the several-lines alarms among themselves)
      al.forEach(function (a) { by[a.key] = a; });
      var par = function (a) {   // the key of an alarm's parent alarm, of the same kind
        if (a.kind === 'cross') { var q = parentOf({ line: a.lines[0], lv: a.lv, v: a.v }); return q ? 'X|' + q.split('|').slice(1).join('|') : ''; }
        var p = parentOf(a); return a.kind === 'creep' ? (p ? 'C|' + p : '') : p;
      };
      al.forEach(function (a) { var p = by[par(a)]; if (p && sum(p.it, last - P.recent + 1, last).x === sum(a.it, last - P.recent + 1, last).x && p.kind === a.kind) { p.child = a.v; gone[a.key] = 1; } });
      ['all', 'cat', 'rca'].forEach(function (lv) {
        al.forEach(function (a) {
          if (a.lv !== lv || gone[a.key]) return;
          var kids = al.filter(function (b) { return !gone[b.key] && b.kind === a.kind && par(b) === a.key; });
          if (!kids.length) return;
          if (Math.max.apply(null, kids.map(function (b) { return b.ex; })) >= 0.6 * a.ex) gone[a.key] = 1;   // one child carries the rise
          else { a.kids = kids.map(function (b) { return b.v; }); kids.forEach(function (b) { gone[b.key] = 1; if (b.lvl > a.lvl) a.lvl = b.lvl; if (b.since < a.since) a.since = b.since; }); }
        });
      });
      // the other items join the family problem of their line that shares most of their NCs (more than half of the smaller)
      var out = [];
      al.filter(function (a) { return !gone[a.key]; }).sort(function (a, b) { return (fam(b) ? 1 : 0) - (fam(a) ? 1 : 0) || RANK[a.lv] - RANK[b.lv] || b.lvl - a.lvl || b.ex - a.ex; }).forEach(function (a) {
        var idl = Object.keys(a.ncs), best = null, bs = 0;
        if (!fam(a) && a.kind === 'rise') out.forEach(function (g) {
          if (g.line !== a.line) return;
          var n = 0, m = Object.keys(g.head.ncs).length; idl.forEach(function (id) { if (g.head.ncs[id]) n++; });
          var sh = n / Math.max(1, Math.min(idl.length, m)); if (sh > P.share && sh > bs) { best = g; bs = sh; }
        });
        if (best) { best.also.push(a); if (a.lvl > best.lvl) best.lvl = a.lvl; if (a.since < best.since) best.since = a.since; }
        else out.push({ key: a.key, kind: a.kind, line: a.line, head: a, also: [], lvl: a.lvl, since: a.since, ex: a.ex });
      });
      // aircraft far above the finished aircraft of their product, while they still get NCs
      var bp = {};
      (planes || []).forEach(function (p) { (bp[p.prod] || (bp[p.prod] = [])).push(p); });
      Object.keys(bp).forEach(function (prod) {
        var cum = function (p) { var s = 0; for (var j = 0; j <= last; j++) s += p.w[j] || 0; return s; };
        var done = bp[prod].filter(function (p) { return p.end <= last; }).map(cum).sort(function (a, b) { return a - b; });
        if (done.length < P.planeMin) return;
        var med = done[Math.floor(done.length / 2)], q90 = done[Math.floor(0.9 * (done.length - 1))], lim = Math.max(P.planeK * med, q90 + P.planePlus);
        bp[prod].forEach(function (p) {
          var c = cum(p), r = sum(p, last - P.recent + 1, last).x; if (c <= lim || !r) return;
          var s = 0, since = 0; for (var j = 0; j <= last; j++) { s += p.w[j] || 0; if (s > lim) { since = j; break; } }
          out.push({ key: 'M|' + p.key, kind: 'plane', line: p.line, head: { kind: 'plane', lv: 'msn', v: p.msn, prod: prod, n: c, med: med, it: p, ncs: ids(p, 0, last) }, also: [], lvl: 1, since: since, ex: c - med });
        });
      });
      // a problem an action in progress already covers (more than half of its defect lines): the action is named with it
      (acts || []).forEach(function (ac) {
        out.forEach(function (g) {
          var it = g.head.it; if (g.act || !it || !it.d || g.line.split(' + ').indexOf(ac.line) < 0 || ac.start > last) return;
          var k = 0, n = 0; for (var j = last - (g.kind === 'creep' ? P.block : P.recent) + 1; j <= last; j++) (it.d[j] || []).forEach(function (dk) { n++; if (ac.defs[dk]) k++; });
          if (n && k / n > P.share) g.act = ac;
        });
      });
      var KIND = { rise: 0, cross: 1, creep: 2, plane: 3 };
      return out.sort(function (a, b) { return b.lvl - a.lvl || KIND[a.kind] - KIND[b.kind] || b.ex - a.ex; });
    }
    // a problem marked as seen stays out of the list unless it got worse since: a higher level, half again as many extra defects
    // (5 at least), or it closed and opened again
    function seen(g, m) { return !!m && m.since === g.since && g.lvl <= (m.lvl || 0) && !(g.ex >= 1.5 * (m.ex || 0) && g.ex >= (m.ex || 0) + 5); }
    function docId(key) { var h = 5381; for (var i = 0; i < key.length; i++) h = ((h * 33) ^ key.charCodeAt(i)) >>> 0; return 'a' + h.toString(36) + '-' + key.length; }
    // the last 16 weeks of a problem, per MSN built (counts for an aircraft), as a small line: the last 4 weeks stand out
    function spark(g, last, col) {
      var it = g.head.it, W = 56, H = 18, n = 16, pts = [], mx = 0, i, v;
      for (i = last - n + 1; i <= last; i++) { v = it.e ? (it.e[i] > 0 ? (it.w[i] || 0) / it.e[i] : null) : it.w[i] || 0; pts.push(v); if (v != null && v > mx) mx = v; }
      if (!mx) return '';
      var xy = function (k) { return (2 + k / (n - 1) * (W - 4)).toFixed(1) + ',' + (H - 2 - pts[k] / mx * (H - 4)).toFixed(1); }, a = '', b = '';
      for (i = 0; i < n; i++) if (pts[i] != null) { var s = xy(i); if (i <= n - P.recent) a += (a ? 'L' : 'M') + s; if (i >= n - P.recent) b += (b ? 'L' : 'M') + s; }
      return '<svg class="al-sp" width="' + W + '" height="' + H + '" viewBox="0 0 ' + W + ' ' + H + '" aria-hidden="true"><path d="' + a + '" fill="none" stroke="var(--dim)" stroke-width="1.5"/><path d="' + b + '" fill="none" stroke="' + col + '" stroke-width="2"/></svg>';
    }
    return { P: P, run: run, seen: seen, week: week, lastDone: lastDone, docId: docId, sig: sig, spark: spark };
  })();
  /* ===== ALARM ENGINE END ===== */
  // a sub-code that only says the defect has none yet ("T04 (non précisé)": a new line not yet labelled by the AI pass; "Non codé"):
  // new lines all land there until labelled, which looks like a rise, so no alarm and not "new" (3 Nov)
  var PLACEHOLDER = new RegExp(SET.placeholder);   // sub-codes "not specified": no alarm on them (config/2_reglages_pages.csv)
  var AL = { open: false, more: false, marks: {}, res: null, sigK: '', first: 0, last: -1 };
  function alCompute() {
    var V = D.vol; if (!V) return null;
    var wi = S.week; if (PARTIAL && wi === NW - 1) wi--;
    var wk = WEEKS[wi] || '', last = wk.slice(0, 4) === YEAR ? +wk.slice(6) - 1 : -1, key = [S.ph, S.liab, last, ACTIONS.length, ACTIONS.map(function (a) { return a.id + a.status + a.actionStart; }).join()].join('|');
    if (key === AL.sigK) return AL.res;
    var items = {}, planes = {}, cnt = { rca: {}, code: {} }, w0 = 53, z = function () { var a = []; for (var i = 0; i < 53; i++) a.push(0); return a; }, ME = D.msnEnd || {};
    function it(line, lv, v, hist) { var k = line + '|' + lv + '|' + v; return items[k] || (items[k] = { key: k, line: line, lv: lv, v: v, w: z(), e: V[line], n: [], d: [], hist: !!hist }); }
    function add(o, i, id, dk) { o.w[i]++; (o.n[i] || (o.n[i] = [])).push(id); if (dk != null) (o.d[i] || (o.d[i] = [])).push(dk); if (i < w0) w0 = i; }
    function tally(m, k, v) { var q = m[k] || (m[k] = {}); q[v] = (q[v] || 0) + 1; }
    var inPh = function (n) { return (!S.ph || DIC.phase[n[3]] === S.ph) && S.liab.indexOf(n[8]) >= 0; };
    DEFS.forEach(function (d, j) {
      var n = NCS[d[0]]; if (!inPh(n)) return;
      var l = DIC.line[n[2]], i = ALARM.week(n[1]); if (!V[l] || i < 0) return;
      var c = fld(d, 'cat'), ca = fld(d, 'rca'), co = fld(d, 'code'), st = fld(d, 'station'), wh = fld(d, 'where');
      add(it(l, 'all', ''), i, n[0], j);
      if (c) add(it(l, 'cat', c), i, n[0], j);
      if (ca) { add(it(l, 'rca', ca), i, n[0], j); tally(cnt.rca, l + '|' + ca, c); }
      if (co && !PLACEHOLDER.test(co)) { add(it(l, 'code', co), i, n[0], j); tally(cnt.code, l + '|' + co, ca); }   // no alarm on a placeholder sub-code (3 Nov)
      if (st) add(it(l, 'station', st, true), i, n[0], j);
      if (wh) add(it(l, 'where', wh, true), i, n[0], j);
    });
    NCS.forEach(function (n) {   // aircraft: NCs per aircraft and product
      if (!inPh(n)) return;
      var l = DIC.line[n[2]], m = DIC.msn[n[4]] || '', p = DIC.prod ? DIC.prod[n[7]] : '', i = ALARM.week(n[1]), end = ME[l + '|' + String(m).replace(/^0+/, '')];
      if (!p || !m || i < 0 || end == null) return;
      var k = l + '|' + m + '|' + p, o = planes[k], ew = ALARM.week(end);
      if (!o) o = planes[k] = { key: k, line: l, msn: m, prod: p, w: z(), n: [], end: ew < 0 ? 99 : ew };
      o.w[i]++; (o.n[i] || (o.n[i] = [])).push(n[0]);
    });
    // the actions in progress: the NCs of their problem, to say that one already covers an alarm
    var acts = ACTIONS.filter(function (a) { return a.actionStart && a.status !== 'Clos' && a.status !== 'Abandonnée'; }).map(function (a) {
      var pred = problemPred(a.problem), o = { line: a.line, title: a.title || a.category, start: ALARM.week(a.actionStart), defs: {} };
      if (pred) DEFS.forEach(function (d, j) { var n = NCS[d[0]]; if (DIC.line[n[2]] === a.line && inPh(n) && pred(d)) o.defs[j] = 1; });
      return o;
    });
    var dom = function (m) { m = m || {}; return Object.keys(m).sort(function (a, b) { return m[b] - m[a]; })[0] || ''; };
    AL.first = w0 + ALARM.P.recent + ALARM.P.base - 1; AL.last = last; AL.sigK = key;
    AL.res = last < AL.first ? [] : ALARM.run(Object.keys(items).map(function (x) { return items[x]; }), AL.first, last, function (a) {
      return a.lv === 'cat' ? a.line + '|all|' : a.lv === 'rca' ? a.line + '|cat|' + dom(cnt.rca[a.line + '|' + a.v]) : a.lv === 'code' ? a.line + '|rca|' + dom(cnt.code[a.line + '|' + a.v]) : ''; },
      Object.keys(planes).map(function (x) { return planes[x]; }), acts);
    return AL.res;
  }
  function alName(a) {
    var v = a.v, s = a.lv === 'all' ? T('Toutes les causes') : a.lv === 'code' ? v + (codeDesc(v) ? ' · ' + String(codeDesc(v)).split(' (')[0] : '') :
      a.lv === 'where' ? whereName(v) : a.lv === 'station' ? T('poste {v}', { v: v }) : L(v);
    return s + (a.child ? ' (' + L(a.child) + ')' : '');
  }
  function alText(g) {
    var a = g.head, s = WK() + (g.since + 1);
    if (g.kind === 'plane') return T('MSN {m} : {n} NC, un {p} en a {d} d’habitude', { m: a.v, n: a.n, p: a.prod, d: a.med });
    return T(g.kind === 'cross' ? '{w} en hausse sur plusieurs lignes depuis {s}' : g.kind === 'creep' ? '{w} en hausse lente depuis {s}' : '{w} en hausse depuis {s}', { w: alName(a), s: s });
  }
  function alRender() {
    var btn = $('alBtn'), pop = $('alPop'); if (!btn) return;
    var res = alCompute(); btn.hidden = !res; if (!res) { pop.hidden = true; return; }
    var mine = res.filter(function (g) { return S.line === 'all' || g.line.split(' + ').indexOf(S.line) >= 0; }), other = res.length - mine.length;
    var show = mine.filter(function (g) { return !ALARM.seen(g, AL.marks[g.key]); }), hid = mine.filter(function (g) { return ALARM.seen(g, AL.marks[g.key]); });
    btn.classList.toggle('maj', show.some(function (g) { return g.lvl === 2; })); $('alN').hidden = !show.length; $('alN').textContent = show.length;
    btn.setAttribute('aria-expanded', String(AL.open)); btn.title = T('Alarmes') + (show.length ? ' · ' + show.length : '');
    pop.hidden = !AL.open; if (!AL.open) return;
    var wr = $('alWrap').getBoundingClientRect(), PW = document.documentElement.clientWidth, pw = Math.min(460, PW - 32), px = Math.max(16, Math.min(wr.right - pw, PW - pw - 16));
    pop.style.width = pw + 'px'; pop.style.left = Math.round(px - wr.left) + 'px'; pop.style.right = 'auto';
    var can = !!DB && CANW !== false, row = function (g, isSeen) {
      var a = g.head, sub = [], also = g.also.filter(function (x) { return x.lv !== 'prod'; });
      if (a.kids) sub.push(T('dont {l}', { l: a.kids.map(function (v) { return alName({ lv: a.lv === 'all' ? 'cat' : a.lv === 'cat' ? 'rca' : 'code', v: v }); }).join(', ') }));
      if (also.length) sub.push(T('aussi : {l}', { l: also.map(alName).join(', ') }));
      if (g.act) sub.push(T('action en cours : {t}', { t: g.act.title }));
      var lvNew = g.kind === 'plane' ? 'msn' : a.lv;
      return '<div class="al-row"><button type="button" class="al-go" data-algo="' + esc(g.key) + '"><i class="al-dot ' + (g.lvl === 2 ? 'maj' : 'min') + '" title="' + T(g.lvl === 2 ? 'Majeure' : 'Mineure') + '"></i>' +
        '<span class="al-what"><b>' + esc(g.line) + '</b> · ' + esc(alText(g)) + '</span>' + (sub.length ? '<span class="al-sub">' + esc(sub.join(' · ')) + '</span>' : '') +
        '<span class="al-sub">' + esc(T('→ Pareto de la semaine')) + '</span></button><span class="al-ops">' + ALARM.spark(g, AL.last, g.lvl === 2 ? 'var(--up)' : 'var(--ink-2)') +
        (can && lvNew !== 'all' && g.kind !== 'cross' && !g.act && !isSeen ? plusBtn(lvNew, a.v) : '') +
        (can ? '<button type="button" class="al-vu" data-al' + (isSeen ? 'un' : 'vu') + '="' + esc(g.key) + '">' + esc(T(isSeen ? 'Remettre' : 'Vu')) + '</button>' : '') + '</span></div>';
    };
    var top = show.slice(0, ALARM.P.show), rest = show.slice(ALARM.P.show);
    pop.innerHTML = '<div class="al-head"><h3 id="alT">' + esc(T('À regarder · {w}', { w: WK() + (AL.last + 1) })) + '</h3><button type="button" class="al-x" id="alX" aria-label="' + esc(T('Fermer')) + '">✕</button></div>' +
      (AL.last < AL.first ? '<p class="mu">' + esc(T('Pas encore assez de semaines pour comparer.')) + '</p>' : top.length ? top.map(function (g) { return row(g, false); }).join('') : '<p class="mu">' + esc(T('Rien à signaler.')) + '</p>') +
      (rest.length ? '<details class="al-seen" id="alMore"' + (AL.more ? ' open' : '') + '><summary>' + esc(T(rest.length > 1 ? '{n} autres' : '{n} autre', { n: rest.length })) + '</summary>' + rest.map(function (g) { return row(g, false); }).join('') + '</details>' : '') +
      (other ? '<p class="mu">' + esc(T('+{n} sur les autres lignes', { n: other })) + '</p>' : '') +
      (hid.length ? '<details class="al-seen"><summary>' + esc(T('Vues ({n})', { n: hid.length })) + '</summary>' + hid.map(function (g) { return row(g, true); }).join('') + '</details>' : '');
    var mo = $('alMore'); if (mo) mo.addEventListener('toggle', function () { AL.more = mo.open; });
  }
  function alGo(key) {
    var g = (AL.res || []).filter(function (x) { return x.key === key; })[0]; if (!g) return;
    var a = g.head; AL.open = false;
    S.line = g.kind === 'cross' ? 'all' : g.line; S.f = {}; if (g.kind === 'plane') S.f.msn = a.v; else if (a.lv !== 'all') S.f[a.lv] = a.v; S.tab = 'pareto'; S.lim = 40; remember();
    try { history.replaceState(null, '', '#pareto'); } catch (x) { }
    renderAll();
  }
  function alMark(key, on) {
    var g = (AL.res || []).filter(function (x) { return x.key === key; })[0]; if (!DB || !g) return;
    var ref = DB.collection('alarmes').doc(ALARM.docId(key));
    (on ? ref.set({ key: key, line: g.line, since: g.since, lvl: g.lvl, ex: Math.round(g.ex * 10) / 10, at: today(), by: UID || '' }) : ref.delete()).catch(function () { });
  }
  (function () {
    var w = $('alWrap'); if (!w) return;
    w.addEventListener('click', function (e) {
      var t = e.target.closest('button'); if (!t) return;
      if (t.id === 'alBtn') { AL.open = !AL.open; alRender(); return; }
      if (t.id === 'alX') { AL.open = false; alRender(); $('alBtn').focus(); return; }
      if (t.hasAttribute('data-algo')) { alGo(t.getAttribute('data-algo')); return; }
      if (t.hasAttribute('data-alvu')) { alMark(t.getAttribute('data-alvu'), true); return; }
      if (t.hasAttribute('data-alun')) { alMark(t.getAttribute('data-alun'), false); return; }
      if (t.hasAttribute('data-new')) { AL.open = false; $('alPop').hidden = true; $('alBtn').setAttribute('aria-expanded', 'false'); }   // the action form opens (page handler)
    });
    document.addEventListener('click', function (e) { if (AL.open && !w.contains(e.target)) { AL.open = false; alRender(); } });
    document.addEventListener('keydown', function (e) { if (AL.open && e.key === 'Escape') { AL.open = false; alRender(); $('alBtn').focus(); } });
  })();

  // ---------------------------------------------------------------- events
  $('liabMenu').addEventListener('change', function (e) {   // the Responsabilité ticks; at least one stays, as on the dashboard
    var on = Array.prototype.slice.call(document.querySelectorAll('#liabMenu input:checked')).map(function (x) { return x.getAttribute('data-liabk'); });
    if (!on.length) { e.target.checked = true; return; }
    S.liab = LIABS.map(function (x) { return x[0]; }).filter(function (k) { return on.indexOf(k) >= 0; }).join(''); remember(); renderAll(); $('liab').open = true;
  });
  document.addEventListener('click', function (e) { var d = $('liab'); if (d && d.open && !d.contains(e.target)) d.open = false; });
  document.addEventListener('click', function (e) {
    var t = e.target.closest('button, [data-wk]'); if (!t) return;
    var a = t.getAttribute.bind(t);
    if (a('data-lang')) { LANG = a('data-lang') === 'en' ? 'en' : 'fr'; try { localStorage.setItem('mft-fto2-lang', LANG); } catch (x) { } renderAll(); if (FORM && !$('ov').hidden) drawForm(); return; }
    if (a('data-line') != null) { S.line = a('data-line'); S.f = {}; S.lim = 40; remember(); renderAll(); return; }   // values differ by line: picks cleared
    if (a('data-ph') != null) { S.ph = a('data-ph'); remember(); renderAll(); return; }
    if (a('data-tab')) { S.tab = a('data-tab'); try { history.replaceState(null, '', '#' + S.tab); } catch (x) { } renderAll(); return; }
    if (a('data-k')) { var k = a('data-k'), v = a('data-v'); if (S.f[k] === v) delete S.f[k]; else S.f[k] = v; S.lim = 40; renderAll(); return; }
    if (a('data-unsel')) { var u = a('data-unsel'); if (u === '*') S.f = {}; else delete S.f[u]; S.lim = 40; renderAll(); return; }
    if (t.id === 'mkT') { S.mk = !S.mk; remember(); renderAnalyse(); return; }
    if (t.id === 'detMore') { S.lim += 100; renderPareto(); return; }
    if (a('data-per') != null) { S.pm = +a('data-per'); if (S.pm) setRange(S.week - S.pm + 1, S.week); renderAll(); return; }
    if (a('data-wk')) { var wi = +a('data-wk'); setRange(wi - S.per + 1, wi); S.tab = 'pareto'; renderAll(); return; }   // the week clicked ends a period of the same length
    if (a('data-cnt')) { S.cnt = a('data-cnt') === 'nc' ? 'nc' : 'def'; remember(); renderControls(); renderPareto(); return; }
    if (a('data-fst')) { S.fSt = a('data-fst'); renderActions(); renderControls(); return; }
    if (t.id === 'newAct') { openForm(null); return; }
    if (a('data-new')) { var p = a('data-new'), i = p.indexOf('|'), lv = p.slice(0, i), val = p.slice(i + 1);
      if (!DB || CANW === false) return;
      openForm({ line: S.line === 'all' ? '' : S.line, title: shown(lv, val), category: '', problem: lv === 'code' ? { mode: 'simple', codes: [val] } : lv === 'rca' ? { mode: 'simple', codes: causeCodes(val) } : { level: lv, values: [val] }, defects: '', rootCause: '', analysisOwner: '', analysisStart: today(), action: '', actionOwner: '', actionStart: '', status: 'À lancer', expected: '', note: '', log: [] }); return; }
    if (a('data-cancel')) { $('ov').hidden = true; FORM = null; return; }
    if (FORM && a('data-pm')) { readForm(); var P = FORM.problem, to = a('data-pm'); if (to === P.mode) return;
      if (to === 'expert') { var gs = P.codes.filter(isGrp), cs = P.codes.filter(function (c) { return !isGrp(c); }), rs;   // the codes stay one 'or': one condition
        rs = gs.length && cs.length ? [{ f: 'code', op: 'regex', v: ['^(' + P.codes.map(function (c) { return String(c).replace(/[.*+?^${}()|[\]\\-]/g, '\\$&'); }).join('|') + ')'] }]
          : gs.length ? [{ f: 'grp', op: 'is', v: gs }] : cs.length ? [{ f: 'code', op: 'is', v: cs }] : [{ f: 'rca', op: 'is', v: [] }];
        FORM.problem = { mode: 'expert', rules: rs }; }
      else { var cc = []; P.rules.forEach(function (r) { if (r.op === 'is' && (r.f === 'code' || r.f === 'grp')) cc = cc.concat(r.v); }); FORM.problem = { mode: 'simple', codes: cc }; }
      drawForm(); return; }
    if (FORM && a('data-addcode')) { addCode(); return; }
    if (FORM && a('data-rmc') != null) { readForm(); FORM.problem.codes.splice(+a('data-rmc'), 1); drawForm(); return; }
    if (FORM && a('data-radd')) { readForm(); FORM.problem.rules.push({ f: 'rca', op: 'is', v: [] }); drawForm(); return; }
    if (FORM && a('data-rdel') != null) { readForm(); FORM.problem.rules.splice(+a('data-rdel'), 1); drawForm(); return; }
    if (FORM && a('data-rva') != null) { addVal(+a('data-rva')); return; }
    if (FORM && a('data-rvx')) { readForm(); var q = a('data-rvx').split('|'); FORM.problem.rules[+q[0]].v.splice(+q[1], 1); drawForm(); return; }
    if (a('data-edit')) { var x = ACTIONS.filter(function (y) { return y.id === a('data-edit'); })[0]; if (x) openForm(x); return; }
    if (a('data-close')) { patch(a('data-close'), { status: 'Clos', closedAt: today(), updatedAt: today() }, t); return; }
    if (a('data-reopen')) { patch(a('data-reopen'), { status: 'En cours', closedAt: '', updatedAt: today() }, t); return; }
    if (a('data-del')) { CONF = a('data-del'); renderActions(); return; }
    if (a('data-delno')) { CONF = null; renderActions(); return; }
    if (a('data-delok')) { var id = a('data-delok'); CONF = null; if (BUSY) return; BUSY = true; DB.collection('actions').doc(id).delete().catch(function () { }).then(function () { BUSY = false; }); return; }
    if (a('data-log')) { var lid = a('data-log'), inp = $('lg-' + lid), txt = inp && inp.value.trim(), nin = $('lgn-' + lid), nm = nin ? nin.value.trim() : ''; if (!txt) return;
      if (!nm) { if (nin) { nin.focus(); nin.setAttribute('aria-invalid', 'true'); } return; }
      var cur = ACTIONS.filter(function (y) { return y.id === lid; })[0]; if (!cur) return; setName(nm);
      patch(lid, { log: (cur.log || []).concat([{ at: today(), by: UID || '', name: nm.slice(0, 60), text: txt.slice(0, 400) }]), updatedAt: today() }, t)
        .then(function (ok) { var i = $('lg-' + lid); if (ok && i) i.value = ''; }); return; }
    if (a('data-lgdel')) { CONFL = a('data-lgdel'); renderActions(); return; }
    if (a('data-lgno')) { CONFL = null; renderActions(); return; }
    if (a('data-lgok')) { var q = a('data-lgok'), qj = q.lastIndexOf('|'), aid = q.slice(0, qj), k = +q.slice(qj + 1), ca = ACTIONS.filter(function (y) { return y.id === aid; })[0]; CONFL = null;
      if (!ca || !ca.log || !ca.log[k]) { renderActions(); return; }
      var lg = ca.log.slice(); lg.splice(k, 1); patch(aid, { log: lg, updatedAt: today() }, t); return; }
  });
  document.addEventListener('toggle', function (e) { var d = e.target; if (d && d.getAttribute && d.getAttribute('data-d')) OPEN[d.getAttribute('data-d')] = d.open; if (d && d.id === 'fMore') MORE = d.open; }, true);
  $('frm').addEventListener('submit', function (e) { e.preventDefault(); saveForm(); });
  $('frm').addEventListener('change', function (e) {
    if (!FORM) return; var id = e.target.id;
    var t = e.target;
    if (t.hasAttribute('data-rf')) { readForm(); var r = FORM.problem.rules[+t.getAttribute('data-rf')]; r.f = t.value; if (r.op !== 'regex') r.v = []; drawForm(); }
    else if (t.hasAttribute('data-ro')) { readForm(); var r2 = FORM.problem.rules[+t.getAttribute('data-ro')]; if ((r2.op === 'regex') !== (t.value === 'regex')) r2.v = []; r2.op = t.value; drawForm(); }
    else if (id === 'fLine') { readForm(); drawForm(); }
  });
  $('frm').addEventListener('input', function (e) {   // a regular expression is checked and previewed as it is typed
    var t = e.target; if (!FORM || !t.hasAttribute('data-rx')) return; var i = +t.getAttribute('data-rx'), r = FORM.problem.rules[i]; r.v = t.value ? [t.value] : [];
    var er = $('rxErr-' + i); if (er) er.textContent = rxErr(r); var pv = $('fPrev'); if (pv) pv.innerHTML = prevHtml(); });
  $('frm').addEventListener('keydown', function (e) {   // Enter in a value box adds the value instead of saving the action
    if (e.key !== 'Enter' || !FORM) return; var t = e.target;
    if (t.id === 'fCode') { e.preventDefault(); addCode(); } else if (t.hasAttribute && t.hasAttribute('data-rv')) { e.preventDefault(); addVal(+t.getAttribute('data-rv')); } else if (t.hasAttribute && t.hasAttribute('data-rx')) e.preventDefault();
    else if (t.tagName === 'INPUT' && t.type !== 'checkbox' && t.type !== 'radio') { e.preventDefault(); saveForm(); } });   // Enter saves, as the form would
  // Slate runs the page in a frame that allows no form submission ('allow-forms'): the save button saves the form itself
  $('frm').addEventListener('click', function (e) { if (e.target.closest && e.target.closest('#fSave')) { e.preventDefault(); saveForm(); } });
  $('ov').addEventListener('click', function (e) { if (e.target.id === 'ov') { $('ov').hidden = true; FORM = null; } });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !$('ov').hidden) { $('ov').hidden = true; FORM = null; } });
  $('wkF').addEventListener('change', function (e) { var f = +e.target.value; setRange(f, Math.max(f, S.week)); renderAll(); });
  $('wk').addEventListener('change', function (e) { var t = +e.target.value; setRange(S.pm ? t - S.pm + 1 : Math.min(S.from, t), t); renderAll(); });
  var tip = $('tip');
  document.addEventListener('mousemove', function (e) { var t = e.target.closest && e.target.closest('[data-tip]'); if (!t) { tip.hidden = true; return; }
    var p = t.getAttribute('data-tip').split('|'); tip.innerHTML = '<b>' + esc(p[0]) + '</b>' + p.slice(1).map(esc).join('<br>'); tip.hidden = false;
    var x = e.clientX + 14, y = e.clientY + 14, r = tip.getBoundingClientRect(); if (x + r.width > innerWidth - 8) x = e.clientX - r.width - 14; if (y + r.height > innerHeight - 8) y = e.clientY - r.height - 14; tip.style.left = x + 'px'; tip.style.top = y + 'px'; });
  document.addEventListener('scroll', function () { tip.hidden = true; }, true);
  var rt; addEventListener('resize', function () { clearTimeout(rt); rt = setTimeout(renderAll, 150); });

  function renderAll() { applyText(); if (DBN) setNote(DBN); renderControls(); if (S.tab === 'pareto') renderPareto(); else if (S.tab === 'analyse') renderAnalyse(); else renderActions(); $('nAct').textContent = ACTIONS.filter(function (a) { return onLine(a) && a.status !== 'Clos' && a.status !== 'Abandonnée'; }).length; alRender(); }
  var h = (location.hash || '').slice(1); if (h === 'analyse' || h === 'actions' || h === 'pareto') S.tab = h;
  renderAll();

  // ---------------------------------------------------------------- the store: the actions and the alarms' marks
  (async function () {
    var cl = window.FTO2_STORE;   // the store (STORE START): this browser; in Slate with the state key "store", the shared one
    try { USER = cl && cl.use ? await cl.use('user') : null; } catch (e) { USER = null; }
    try { DB = cl && cl.use ? await cl.use('db') : null; } catch (e) { DB = null; }
    if (USER) { try { UID = await USER.id(); } catch (e) { } try { CANW = await USER.can('data.write'); } catch (e) { CANW = null; } }
    if (!DB) { renderAll(); return; }
    if (cl.note) setNote(function () { return cl.note(LANG); });
    if (CANW === false) setNote(function () { return T('Accès en lecture : vous voyez les actions sans pouvoir les modifier.'); });
    DB.collection('alarmes').onSnapshot(function (snap) { var m = {}; snap.docs.forEach(function (d) { var x = d.data(); if (x && x.key) m[x.key] = x; }); AL.marks = m; alRender(); }, function () { });
    DB.collection('actions').onSnapshot(async function (snap) {
      ACTIONS = snap.docs.map(function (d) { return Object.assign({ id: d.id }, d.data()); });
      var ids = {}; ACTIONS.forEach(function (a) { if (a.createdBy) ids[a.createdBy] = 1; (a.log || []).forEach(function (e) { if (e.by) ids[e.by] = 1; }); });
      var need = Object.keys(ids).filter(function (i) { return !NAMES[i]; });
      if (USER && need.length) { try { var ps = await USER.profiles(need); need.forEach(function (i) { NAMES[i] = (ps[i] && ps[i].name) || 'quelqu’un'; }); } catch (e) { } }
      renderAll();
    }, function () { setNote(function () { return T('La liste des actions ne se met plus à jour : rechargez la page.'); }); });
  })();
})();
}

// ---------------------------------------------------------------- Slate: wait for the two queries, then start the page
// Optional state keys: "reglages" (q_fto2_set_targets, the Fusion sheet's settings: the page waits a few seconds for them, then
// applies them before it starts) and "store" (q_fto2_mft_store, the actions kept for everyone: the shared store above).
(function () {
  var MSG = {
    wait: 'Chargement des données Slate… / Loading the Slate data…',
    nostore: ['Enregistrement impossible : la requête q_fto2_mft_store n’a pas répondu (vérifiez qu’elle existe dans l’app et s’exécute, et la ligne "store" de l’état). Les actions modifiées ici seront perdues au rechargement.',
      'Saving impossible: the query q_fto2_mft_store did not answer (check it exists in the app and runs, and the line "store" of the state). Actions changed here will be lost on reload.'],
    empty: 'La requête q_fto2_nc n’a renvoyé aucune ligne : vérifiez la requête et son jeu de données. / The q_fto2_nc query returned no row: check the query and its dataset.',
    noapi: 'État Slate introuvable : ce JavaScript doit tourner dans un code sandbox Slate dont l’état contient les deux requêtes (voir state.json). / No Slate state: this JavaScript must run in a Slate code sandbox whose state holds the two queries (see state.json).',
    slow: 'Toujours en attente de {q} : vérifiez que la requête existe, porte ce nom et s’exécute sans erreur. / Still waiting for {q}: check that the query exists, has this name and runs without error.',
    store: 'Les actions partagées ne sont pas encore lues : vérifiez la requête q_fto2_mft_store. D’ici là, les actions ne s’affichent pas et ne peuvent pas être modifiées. / The shared actions are not read yet: check the query q_fto2_mft_store. Until then the actions are not shown and cannot be changed.'
  };
  function showError(msg) {
    var e = document.getElementById('fto2-err');
    if (e) { e.hidden = false; e.textContent = 'La page MFT n\'a pas pu s\'afficher / The MFT page could not load: ' + msg; }
    var w = document.getElementById('fto2-wait'); if (w) w.hidden = true;
    if (window.console) console.error('[FTO2 MFT]', msg);
  }
  function status(msg, warn) { var e = document.getElementById('fto2-wait'); if (!e) return; e.hidden = !msg; e.textContent = msg || ''; e.className = 'fto2-wait' + (warn ? ' warn' : ''); }
  window.addEventListener('error', function (ev) { showError((ev && ev.message) || 'unknown error'); });
  function parse(v) { if (typeof v !== 'string') return v; var s = v.trim(); if (!s) return null; try { return JSON.parse(s); } catch (e) { return null; } }
  function count(t) { if (!t) return 0; if (Array.isArray(t)) return t.length; var k = Object.keys(t); for (var i = 0; i < k.length; i++) if (t[k[i]] && t[k[i]].length) return t[k[i]].length; return 0; }
  function loaded(t) { return !!t && (Array.isArray(t) || Object.keys(t).length > 0); }
  var got = {}, started = false, api = null, rgTimer = null, stTimer = null, shared = null, storeLate = false;
  function stateKeys() { var st = {}; try { st = (api.getState && api.getState()) || {}; } catch (e) { } return st; }
  function tryStart() {
    if (started) return;
    var nc = parse(got.nc), def = parse(got.def), R = fto2RefBlocks(got.ref);
    if (loaded(nc) && !count(nc)) { status(MSG.empty, true); return; }
    if (!count(nc) || !loaded(def) || !R) { status(MSG.wait); return; }   // the queries can arrive one after the other
    var st0 = stateKeys(), has = function (k) { return k in st0 || got[k] != null; };   // a key of the state, or a value arrived for it
    if (has('reglages') && !loaded(parse(got.reglages)) && rgTimer !== 'over') {   // the Fusion sheet's settings: a few seconds to arrive
      if (!rgTimer) rgTimer = setTimeout(function () { rgTimer = 'over'; tryStart(); }, 8000);
      return;
    }
    // the actions kept for everyone: the query q_fto2_mft_store may answer after the NCs, and with no row while the store is
    // empty: a few seconds for it, and any answer counts (17 Nov: a page started before it had answered kept the actions in the
    // browser, which Slate blocks)
    if (!has('store') && stTimer !== 'over') {
      if (!stTimer) stTimer = setTimeout(function () { stTimer = 'over'; tryStart(); }, 8000);
      return;
    }
    started = true;
    try {
      var D = window.FTO2_MFT_D = mftFromTables(nc, def, window.FTO2_MFT_REF = R.mft);
      if (has('reglages')) fto2Reglages(D.settings, got.reglages);   // before the page reads its settings (the action target)
      if (!D.ncs.length) {   // rows arrived but none is an FTO2 NC of the year followed: say what came, to fix the query or the state
        var c = Array.isArray(nc) ? Object.keys(nc[0] || {}) : Object.keys(nc);
        showError('aucune NC FTO2 de l’année suivie lisible dans q_fto2_nc (colonnes reçues : ' + c.join(', ') + ') / no readable FTO2 NC of the year followed in q_fto2_nc (columns received: ' + c.join(', ') + ')');
        return;
      }
      if (has('store')) {   // the actions kept for everyone; without the key, in this browser (the browser store)
        shared = window.FTO2_STORE = fto2SharedStore(api, window.FTO2_STORE, R.mft.actions || []);
        if (got.store !== undefined) shared.take(got.store);
        setTimeout(function () { if (!shared.ready()) { storeLate = true; status(MSG.store, true); } }, 20000);
      } else if (window.FTO2_STORE && window.FTO2_STORE.note) {   // no answer from q_fto2_mft_store: say so, rather than blame the browser
        var note0 = window.FTO2_STORE.note;
        window.FTO2_STORE.note = function (lang) { var t = note0(lang); return /bloque|blocks/.test(t) ? MSG.nostore[lang === 'en' ? 1 : 0] : t; };
      }
      status(''); mftMain();
    } catch (e) { showError((e && e.message) || String(e)); }
  }
  function boot() {
    if (!document.getElementById('lines')) { showError('HTML part missing: paste fto2_mft.html into the HTML tab.'); return; }
    api = window.SlateFunctions;
    if (!api || !api.watch) { showError(MSG.noapi); return; }
    status(MSG.wait);
    api.watch('store', function (v) {   // each answer of q_fto2_mft_store: after a Submit, once the query has run again
      got.store = v; if (!shared) { tryStart(); return; }
      shared.take(v);
      if (storeLate && shared.ready()) { storeLate = false; status(''); }
    });
    ['reglages', 'nc', 'def', 'ref'].forEach(function (k) { api.watch(k, function (v) { got[k] = v; tryStart(); }); });   // the optional keys first
    setTimeout(function () {
      if (started) return;
      var miss = []; if (!count(parse(got.nc))) miss.push('q_fto2_nc'); if (!loaded(parse(got.def))) miss.push('q_fto2_def'); if (!fto2RefBlocks(got.ref)) miss.push('q_fto2_ref');
      if (miss.length) status(MSG.slow.replace(/\{q\}/g, miss.join(', ')), true);
    }, 20000);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();
