FTO2 NC dashboard: the files to set it up in Skywise

Already installed? Follow UPDATE.md. A first installation: README.md, steps 1 to 5. Every file they name is in this
zip, at the same place.

  level3_datasets/   the notebook, its code (notebook_kit), the settings (config),
                     the dashboard page (fto2_level23.*, state.json) and its four queries (q_fto2_*.sql)
  mft/               the MFT page
  nc_writer/         the NC writer page (optional): its README.md gives the Slate set-up
  elizabeth/         the Tableau Elizabeth (optional)
  docs/              how to change a setting once it runs (comment_faire.md, in French)
  code_repository/   the same update as a transform that Skywise runs on a schedule (its README.md gives the steps)

Not in this zip: the Slate functions (step 6 of README.md, optional) and the local test pages.
