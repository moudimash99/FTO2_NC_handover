FTO2 NC dashboard: the files to set it up in Skywise

Follow README.md, steps 1 to 5. Every file it names is in this zip, at the same place.

  level3_datasets/   the notebook, its code (notebook_kit), the settings (config),
                     the dashboard page (fto2_level23.*, state.json) and its four queries (q_fto2_*.sql)
  mft/               the MFT page
  elizabeth/         the Tableau Elizabeth (optional)
  docs/              how to change a setting once it runs (comment_faire.md, in French)

Not in this zip: the Slate functions (step 6 of README.md, optional) and the local test pages.
